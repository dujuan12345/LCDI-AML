﻿LCDI AML: ordered analysis source code (v42, 2026-10-08)

本包按分析逻辑排序，仅含代码和本说明。01入口为用户确认的“临床数据诊断.R”，
已经合并的4.x/5.x脚本不再分发。结果CSV、图件、日志、审计及校验清单留在原归档。
目录编号给出阅读和分模块运行顺序；它不是从原始数据开始的一键流水线。

READ FIRST
01_Gene_screening/临床数据诊断.R is the consolidated target-gene screening entry
identified by the project owner. Its sequence is differential expression,
univariable Cox, coexpression, LASSO, candidate selection and survival plots.
It replaces the separate historical 4.x and 5.x development files in this edition.
The GPL96 frozen Cox model is fitted separately in stage 02. The screening script's
TCGA LASSO output must not be substituted for the final frozen model coefficients.
Original analysis code is retained; packaging does not update historical thresholds.

ORDER AND INPUTS
01 Gene screening
   Input: GSE42519 CD34+ control, TCGA-LAML expression/survival and combined gene set
   RDS files under AML_Lactylation_PCD/data. Output: deg_results_all,
   univariate_cox_results, lasso_coefficients, final_genes and stepwise_results.
02 Cohorts and LCDI
   01_Cohort_preparation -> 02_Frozen_model -> 03_Clinical_alignment.
   Input: raw/processed cohort objects and B_gene_set.rds. Output includes
   B_cohort_data, E_LCDI_formula.csv, E_risk_scores and aligned clinical data.
   The saved B_gene_set is a prerequisite; this edition does not infer an
   undocumented direct conversion from the stage-01 final_genes object.
03 Survival validation
   Run C-index inputs before the final TCGA branch. LCDI-vs-MPO, external cohort
   analysis and fixed-formula bootstrap are separate branches sharing frozen inputs.
04 Clinical increment
   Nomogram -> single/joint baseline branches -> DCA inference.
   DCA_first_1000 MUST precede DCA_final_5000: the final code reuses the first
   1,000 resamples. Keep real successful .run.json records for validation scripts.
05 Age and expression
   Age interaction and same-platform expression are independent analyses.
06 Bulk mechanisms
   Pathways/PPI, signature sensitivity and deconvolution require their source
   expression, gene sets and cached AUCell data. The source-mode deconvolution
   entry also requires the external quantiseqr source files named in the script.
   In 02_Signature_sensitivity, 02b extraction precedes 02 single-cell sensitivity
   when the compact extracted AUCell input is not already available.
07 Single-cell states
   Dual-axis signature definition -> raw-count pseudobulk -> dual-axis tests ->
   TMM sensitivity -> method concordance -> gene-driver analysis.
   External marker, author-label and malignant-label branches are separate.
   Compact extraction precedes state scoring. Run state scoring twice with
   arguments D0 and patient_mean. Lineage controls require the precomputed
   14_lineage_decomposition_results.rds object; they do not rebuild it here.
08 Trajectories and TF
   Adult and pediatric trajectories are separate branches. Recovered scripts
   require existing annotated Seurat/SCE objects. TF export precedes TF inference.
   Original adult J1/J2 and pediatric J9 preprocessing is not included.
09 Virtual perturbation
   Prepare common matrices, run the specified datasets/targets, validate outputs,
   then integrate and compare against MPO. Server entry requires LCDI_VP_BASE and
   arguments <adult|pediatric> <CREB1|GPX4> <formal|smoke>.
   CASP1/MPO input preparation and runs are a separate branch. Existing network
   objects, enrichment references and recorded run outputs are prerequisites.
10 qPCR
   Workbook extraction -> patient-level analysis -> statistical verification.
   Requires the original workbook and pre-existing source inventory JSON referenced
   by the scripts. Neither patient data nor the internal inventory is distributed.
11 Robustness
   01_prepare_cohorts.R FIRST, then 01_meta_analysis_audited.R,
   02_nonmpo_increment_final.R and 03_selection_stability_final.R.
12 Figures
   Run after the required statistical result tables and successful QC records exist.
   Figure5 panel/overlap data precede the Figure5 builders. Figure1 inputs precede
   Figure1 assembly. S6-S11 follow stage11; S12-S13 follow stage10.
   For the final-font branch, call 01_redraw.py once for each of Figure1, Figure2,
   Figure3, Figure4, Figure5, Supplement, to populate the expected *_r4 folders;
   then 02_finish_figures.py and 05_addendum_figures.py.
   Manuscript-only English label edits, v42 PDF text patches and Word embedding
   are excluded. These analysis/plot sources do not alone regenerate identical
   final v42 manuscript pages or every final English panel label.
90 Required helpers
   Imported figure functions, R formatting and Windows R launchers.
   Do not run the older figure helper files as alternative analysis branches.
   The palette helper has only its figure functions/loop; Word operations removed.

PREPARE A CODE WORKSPACE
The numbered folders are for navigation. Many original scripts depend on original
sibling directories or __file__, so do not execute them from renamed folders.

    python 00_prepare_workspace.py --list
    python 00_prepare_workspace.py --prepare PATH_TO_A_NEW_WORKSPACE

The second command creates a NEW directory, restores original relative code paths
and verifies source hashes before copying. It never runs an analysis or downloads
anything, and refuses an existing destination. The original-to-ordered map is
part of this functional preparation utility; it is not a second data manifest.

Before scientific execution, supply the required raw/processed data and caches,
configure Windows/Linux absolute input/output paths in the prepared copies,
and use separate output locations. Preparing code does not remap absolute paths.
The scripts retain historical local and server path assumptions. Some recovered
entries install missing packages or invoke child R processes; review these entry
sections and configure the environment explicitly before running. No analysis,
package installation, download or remote job was run while creating this edition.

For local Windows R, use 90_Required_helpers/06_Windows_R/Run-RscriptSafe.ps1
or its Python companion, with a new log prefix. Historical R was 4.5.2. The
launcher restores the required processor architecture and preserves real exit codes.
Dependencies must match the chosen module, not a guessed global environment lock:
R sources include survival, glmnet, limma, Matrix, edgeR, Seurat, monocle/tradeSeq,
and scTenifoldKnk where called; Python sources include numpy, pandas, scipy,
matplotlib and PDF/image libraries where called. Inspect the selected entry's
imports and original module session records in the full internal archive.

CONTENTS AND VERIFICATION
This ZIP contains source code and this README only. No CSV/TSV tables, data objects,
figures, Word/PDF documents, logs, JSON records or audit directories are bundled.
No license or public DOI is asserted. No external upload has occurred.
Static parsing and byte/source checks were performed; no full analysis rerun or
cross-machine execution was performed. Detailed internal validation stays outside
the publication ZIP.

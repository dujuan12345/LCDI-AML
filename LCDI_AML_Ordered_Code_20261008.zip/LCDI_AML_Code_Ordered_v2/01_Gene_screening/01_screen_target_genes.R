# ============================================================================
# AML 乳酸化修饰 × PCD 预后基因筛选——完整流程
#
# 筛选顺序：
#   步骤一：差异表达筛选      → 确认基因在AML中发生改变
#   步骤二：单变量Cox预后筛选  → 确认改变与临床结局相关
#   步骤三：共表达分析        → 确认与乳酸化存在协同关系
#   步骤四：LASSO-Cox筛选     → 去除冗余，选择最优特征基因
#   步骤五：湿实验候选精选    → 综合差异幅度+FDR取最终3-4个
#   步骤六：KM曲线和风险评分  → 评估最终模型效果
# ============================================================================

# 清空环境
rm(list = ls())
gc()
while (sink.number() > 0) {
  sink()
}

# 设置工作目录
project_dir <- "D:/26_01_AML/AML_Lactylation_PCD"
setwd(project_dir)

# 创建目录
dir.create("results/figures/diff_analysis", recursive = TRUE, showWarnings = FALSE)
dir.create("results/figures/coexpression", recursive = TRUE, showWarnings = FALSE)
dir.create("results/figures/network", recursive = TRUE, showWarnings = FALSE)
dir.create("results/figures/survival", recursive = TRUE, showWarnings = FALSE)
dir.create("results/tables/coexpression", recursive = TRUE, showWarnings = FALSE)
dir.create("results/tables/network", recursive = TRUE, showWarnings = FALSE)
dir.create("results/tables/survival", recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed/gene_sets/filtered", recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed/network", recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed/coexpression", recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed/survival", recursive = TRUE, showWarnings = FALSE)
dir.create("data/logs", recursive = TRUE, showWarnings = FALSE)

log_file <- file.path("data/logs",
                      paste0("pipeline_full_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt"))
sink(log_file, split = TRUE)

cat("============================================================\n")
cat("AML 乳酸化修饰 × PCD 预后基因筛选（完整流程）\n")
cat("顺序：差异表达 → 单变量Cox → 共表达 → LASSO-Cox → 湿实验候选 → KM曲线\n")
cat("开始时间:", date(), "\n")
cat("============================================================\n\n")

# 加载包
pkgs <- c("limma","ggplot2","pheatmap","dplyr","tidyr","ggrepel",
          "igraph","survival","survminer","reshape2",
          "RColorBrewer","STRINGdb","openxlsx","glmnet")
for (p in pkgs) {
  if (!require(p, character.only = TRUE)) {
    install.packages(p, repos = "https://cloud.r-project.org")
    library(p, character.only = TRUE)
  }
}

# ============================================================================
# 辅助函数
# ============================================================================

safe_rds <- function(path, label) {
  if (file.exists(path)) {
    obj <- readRDS(path)
    cat("✅", label, "加载成功\n")
    return(obj)
  }
  stop(paste("❌", label, "不存在:", path))
}

step_header <- function(n, title, detail = NULL) {
  cat("\n============================================================\n")
  cat(sprintf("步骤 %s：%s\n", n, title))
  if (!is.null(detail)) cat("  条件:", detail, "\n")
  cat("============================================================\n")
}

# ============================================================================
# 1. 加载数据
# ============================================================================
step_header("1", "加载输入数据")

# 正常对照
normal_data <- safe_rds("data/normal_control/normal_control_GSE42519_CD34only.rds",
                        "GSE42519 CD34+ 干/祖细胞")
normal_expr <- normal_data$expr_matrix
cat(sprintf("  正常样本数: %d  |  基因数: %d\n", normal_data$n_samples, normal_data$n_genes))

# TCGA 数据
tcga_data <- safe_rds("data/TCGA/TCGAbiolinks/processed/TCGA_LAML_PanCancer.rds",
                      "TCGA-LAML PanCancer")
tcga_expr <- tcga_data$expr_matrix
tcga_survival_raw <- tcga_data$survival_data
cat(sprintf("  TCGA样本数: %d  |  生存样本数: %d\n", ncol(tcga_expr), nrow(tcga_survival_raw)))

# 基因集
lact_pcd_raw <- safe_rds("data/gene_sets/raw/lactylation_pcd_combined_raw.rds",
                         "乳酸化×PCD 基因集")
lact_genes <- toupper(lact_pcd_raw$GeneSymbol[lact_pcd_raw$GeneCategory == "乳酸化修饰相关"])
pcd_genes <- toupper(lact_pcd_raw$GeneSymbol[lact_pcd_raw$GeneCategory == "PCD模式相关"])
all_genes <- toupper(lact_pcd_raw$GeneSymbol)
cat(sprintf("  乳酸化基因: %d  |  PCD基因: %d  |  合计: %d\n",
            length(lact_genes), length(pcd_genes), length(all_genes)))

# 统一基因名格式
rownames(normal_expr) <- toupper(rownames(normal_expr))
rownames(tcga_expr) <- toupper(rownames(tcga_expr))

# ============================================================================
# 2. 数据预处理
# ============================================================================
step_header("2", "数据预处理")

# 共同基因
common_genes <- Reduce(intersect, list(rownames(tcga_expr), rownames(normal_expr), all_genes))
cat(sprintf("三方交集基因数: %d\n", length(common_genes)))

# log2 转换
tcga_sub <- tcga_expr[common_genes, ]
normal_sub <- normal_expr[common_genes, ]

if (max(tcga_sub, na.rm = TRUE) > 50) {
  cat("TCGA 数据较大，进行 log2(x+1) 转换\n")
  tcga_sub <- log2(tcga_sub + 1)
}
if (max(normal_sub, na.rm = TRUE) > 50) {
  cat("正常对照数据较大，进行 log2(x+1) 转换\n")
  normal_sub <- log2(normal_sub + 1)
}

# 合并表达矩阵（用于差异分析）
combined_expr <- cbind(tcga_sub, normal_sub)
group <- factor(c(rep("AML", ncol(tcga_sub)), rep("Normal", ncol(normal_sub))),
                levels = c("Normal", "AML"))

# ============================================================================
# 3. 步骤一：差异表达筛选
# ============================================================================
step_header("一", "差异表达筛选", "|log2FC| > 1 且 FDR < 0.05")

design <- model.matrix(~ group)
fit <- eBayes(lmFit(combined_expr, design))
deg_results <- topTable(fit, coef = 2, number = Inf, adjust.method = "fdr")
deg_results$Gene <- rownames(deg_results)
deg_results$Category <- ifelse(deg_results$Gene %in% lact_genes, "Lactylation",
                               ifelse(deg_results$Gene %in% pcd_genes, "PCD", "Other"))

sig_mask <- abs(deg_results$logFC) > 1 & deg_results$adj.P.Val < 0.05
deg_sig <- deg_results[sig_mask, ]
candidates_s1 <- deg_sig$Gene

cat(sprintf("\n✅ 步骤一结果: %d 个候选基因\n", length(candidates_s1)))
cat(sprintf("  乳酸化: %d  |  PCD: %d\n",
            sum(candidates_s1 %in% lact_genes), sum(candidates_s1 %in% pcd_genes)))
cat(sprintf("  上调: %d  |  下调: %d\n",
            sum(deg_sig$logFC > 0, na.rm = TRUE), sum(deg_sig$logFC < 0, na.rm = TRUE)))

# 保存
saveRDS(deg_results, "data/processed/gene_sets/filtered/deg_results_all.rds")
write.csv(deg_results, "results/tables/deg_results_all.csv", row.names = FALSE)

# 火山图
vdata <- deg_results
vdata$Sig2 <- "NS"
vdata$Sig2[vdata$logFC > 1 & vdata$adj.P.Val < 0.05] <- "Up"
vdata$Sig2[vdata$logFC < -1 & vdata$adj.P.Val < 0.05] <- "Down"
vdata$Label <- ifelse(vdata$Gene %in% c("MPO","SIRT2","HDAC1","BAK1","GPX4","BCL2"), vdata$Gene, NA)

p_vol <- ggplot(vdata, aes(logFC, -log10(adj.P.Val))) +
  geom_point(aes(color = Sig2), alpha = 0.6, size = 1.5) +
  scale_color_manual(values = c(Up = "#E41A1C", Down = "#377EB8", NS = "gray70")) +
  geom_hline(yintercept = -log10(0.05), linetype = "dashed") +
  geom_vline(xintercept = c(-1, 1), linetype = "dashed") +
  geom_text_repel(aes(label = Label), size = 3.5, max.overlaps = 20, na.rm = TRUE) +
  labs(title = "TCGA-AML vs GSE42519 CD34+ 干/祖细胞", x = "log2 Fold Change", y = "-log10(FDR)") +
  theme_minimal() + theme(legend.position = "bottom", plot.title = element_text(hjust = 0.5))
ggsave("results/figures/diff_analysis/volcano.pdf", p_vol, width = 10, height = 7)
cat("✅ 火山图已保存\n")

# ============================================================================
# 4. 步骤二：单变量 Cox 预后筛选
# ============================================================================
step_header("二", "单变量 Cox 预后筛选", "P < 0.05")

# 处理 TCGA 生存数据
expr_pid <- substr(colnames(tcga_sub), 1, 12)
surv_pid <- tcga_survival_raw$patient_id
match_idx <- match(expr_pid, surv_pid)
valid <- !is.na(match_idx)

tcga_expr_matched <- tcga_sub[, valid, drop = FALSE]
tcga_surv_matched <- tcga_survival_raw[match_idx[valid], ]

# 过滤生存时间 <= 0 的样本
valid_time <- tcga_surv_matched$time_days > 0 & !is.na(tcga_surv_matched$time_days)
tcga_expr_matched <- tcga_expr_matched[, valid_time, drop = FALSE]
tcga_surv_matched <- tcga_surv_matched[valid_time, ]

# 转换为月
tcga_time <- tcga_surv_matched$time_days / 30.44
tcga_status <- tcga_surv_matched$status
tcga_surv_obj <- Surv(tcga_time, tcga_status)

cat(sprintf("TCGA 有效样本: %d 例（死亡: %d）\n", length(tcga_time), sum(tcga_status)))
cat(sprintf("生存时间范围: %.1f - %.1f 月\n", min(tcga_time), max(tcga_time)))

# 单变量 Cox
cox_genes <- intersect(candidates_s1, rownames(tcga_expr_matched))
cox_results <- data.frame()

for (gene in cox_genes) {
  expr <- as.numeric(tcga_expr_matched[gene, ])
  if (max(expr, na.rm = TRUE) > 50) expr <- log2(expr + 1)
  
  cox_obj <- tryCatch({
    coxph(tcga_surv_obj ~ expr)
  }, error = function(e) NULL)
  
  if (!is.null(cox_obj)) {
    cox_sum <- summary(cox_obj)
    cox_results <- rbind(cox_results, data.frame(
      Gene = gene,
      HR = exp(coef(cox_obj)),
      HR_lower = exp(confint(cox_obj)[1]),
      HR_upper = exp(confint(cox_obj)[2]),
      P_value = cox_sum$coefficients[5],
      Risk = ifelse(exp(coef(cox_obj)) > 1, "High", "Low")
    ))
  }
}

cox_results <- cox_results[order(cox_results$P_value), ]
candidates_s2 <- cox_results$Gene[cox_results$P_value < 0.05]

cat(sprintf("\n✅ 步骤二结果: %d / %d 个候选基因（P < 0.05）\n", 
            length(candidates_s2), length(cox_genes)))
cat("\nTop 10 Cox 结果:\n")
print(head(cox_results, 10))

saveRDS(cox_results, "data/processed/survival/univariate_cox_results.rds")
write.csv(cox_results, "results/tables/survival/univariate_cox_results.csv", row.names = FALSE)

# ============================================================================
# 5. 步骤三：共表达分析
# ============================================================================
step_header("三", "共表达分析", "|R| > 0.6, P < 0.05（在正常样本中计算）")

lact_s2 <- intersect(candidates_s2, lact_genes)
pcd_s2 <- intersect(candidates_s2, pcd_genes)

lact_in <- intersect(lact_s2, rownames(normal_sub))
pcd_in <- intersect(pcd_s2, rownames(normal_sub))

cat(sprintf("步骤二候选中乳酸化基因: %d  |  PCD基因: %d\n", length(lact_in), length(pcd_in)))

sig_pairs <- data.frame()
pcd_correlated <- character()
lact_correlated <- character()
candidates_s3 <- candidates_s2  # 默认沿用

if (length(lact_in) > 0 && length(pcd_in) > 0) {
  lact_t <- t(normal_sub[lact_in, , drop = FALSE])
  pcd_t <- t(normal_sub[pcd_in, , drop = FALSE])
  n_samp <- nrow(lact_t)
  
  cor_mat <- cor(lact_t, pcd_t, method = "pearson", use = "pairwise.complete.obs")
  t_mat <- cor_mat * sqrt(n_samp - 2) / sqrt(pmax(1 - cor_mat^2, 1e-10))
  p_mat <- 2 * pt(-abs(t_mat), df = n_samp - 2)
  
  mask <- !is.na(cor_mat) & abs(cor_mat) > 0.6 & p_mat < 0.05
  idx <- which(mask, arr.ind = TRUE)
  
  if (nrow(idx) > 0) {
    sig_pairs <- data.frame(
      Lact_Gene = rownames(cor_mat)[idx[, 1]],
      PCD_Gene = colnames(cor_mat)[idx[, 2]],
      Correlation = cor_mat[idx],
      P_value = p_mat[idx]
    )
    sig_pairs <- sig_pairs[order(-abs(sig_pairs$Correlation)), ]
  }
  
  pcd_correlated <- unique(sig_pairs$PCD_Gene)
  lact_correlated <- unique(sig_pairs$Lact_Gene)
  
  # 乳酸化基因全保留，PCD 基因需有共表达对
  lact_pass <- intersect(candidates_s2, lact_genes)
  pcd_pass <- intersect(pcd_correlated, candidates_s2)
  candidates_s3 <- unique(c(lact_pass, pcd_pass))
  
  cat(sprintf("\n✅ 步骤三结果: %d 个候选基因\n", length(candidates_s3)))
  cat(sprintf("  显著共表达对: %d\n", nrow(sig_pairs)))
  if (nrow(sig_pairs) > 0) {
    cat("Top 5 共表达对:\n")
    for (i in seq_len(min(5, nrow(sig_pairs)))) {
      r <- sig_pairs[i, ]
      cat(sprintf("  %-12s ~ %-12s  R=%.3f\n", r$Lact_Gene, r$PCD_Gene, r$Correlation))
    }
  }
  
  saveRDS(sig_pairs, "data/processed/coexpression/significant_correlation_pairs.rds")
  write.csv(sig_pairs, "results/tables/coexpression/significant_correlation_pairs.csv", row.names = FALSE)
  
} else {
  cat("⚠️ 共表达分析跳过，沿用步骤二候选\n")
}

# ============================================================================
# 6. 步骤四：LASSO-Cox 筛选
# ============================================================================
step_header("四", "LASSO-Cox 筛选", "10 折交叉验证，筛选非零系数基因")

# 保存训练集的均值和标准差（用于计算风险评分）
train_center <- NULL
train_scale <- NULL
lasso_coefs <- NULL

if (length(candidates_s3) >= 3) {
  
  # 准备 LASSO 输入数据
  lasso_genes <- intersect(candidates_s3, rownames(tcga_expr_matched))
  lasso_expr <- t(tcga_expr_matched[lasso_genes, , drop = FALSE])
  
  # 标准化
  train_center <- colMeans(lasso_expr, na.rm = TRUE)
  train_scale <- apply(lasso_expr, 2, sd, na.rm = TRUE)
  train_scale[train_scale == 0] <- 1
  lasso_expr_sc <- scale(lasso_expr, center = train_center, scale = train_scale)
  lasso_expr_sc[is.na(lasso_expr_sc)] <- 0
  
  x_mat <- as.matrix(lasso_expr_sc)
  y_obj <- tcga_surv_obj
  
  cat(sprintf("LASSO 输入: %d 样本 × %d 基因\n", nrow(x_mat), ncol(x_mat)))
  
  # 10 折交叉验证
  set.seed(123)
  cv_fit <- cv.glmnet(x_mat, y_obj, family = "cox", alpha = 1, nfolds = 10)
  
  # 可视化
  pdf("results/figures/lasso_cv_curve.pdf", width = 8, height = 6)
  plot(cv_fit)
  dev.off()
  cat("✅ LASSO 交叉验证曲线已保存\n")
  
  # 提取非零系数的基因
  coef_min <- coef(cv_fit, s = "lambda.min")
  lasso_selected <- rownames(coef_min)[coef_min[, 1] != 0]
  lasso_selected <- lasso_selected[lasso_selected != "(Intercept)"]
  
  coef_1se <- coef(cv_fit, s = "lambda.1se")
  lasso_selected_1se <- rownames(coef_1se)[coef_1se[, 1] != 0]
  lasso_selected_1se <- lasso_selected_1se[lasso_selected_1se != "(Intercept)"]
  
  cat(sprintf("\nlambda.min 筛选: %d 个特征基因\n", length(lasso_selected)))
  if (length(lasso_selected) > 0) {
    cat(paste(lasso_selected, collapse = ", "), "\n")
  }
  
  cat(sprintf("\nlambda.1se 筛选: %d 个特征基因\n", length(lasso_selected_1se)))
  if (length(lasso_selected_1se) > 0) {
    cat(paste(lasso_selected_1se, collapse = ", "), "\n")
  }
  
  # 使用 lambda.min
  if (length(lasso_selected) >= 2) {
    candidates_s4 <- lasso_selected
    lasso_coefs <- coef_min[lasso_selected, 1]
    names(lasso_coefs) <- lasso_selected
  } else if (length(lasso_selected_1se) >= 2) {
    candidates_s4 <- lasso_selected_1se
    lasso_coefs <- coef_1se[lasso_selected_1se, 1]
    names(lasso_coefs) <- lasso_selected_1se
    cat("\n⚠️ lambda.min 筛选基因不足，使用 lambda.1se\n")
  } else {
    candidates_s4 <- candidates_s3
    cat("\n⚠️ LASSO 未筛选出足够基因，沿用步骤三候选\n")
  }
  
  # 系数表
  coef_df <- data.frame(
    Gene = rownames(coef_min)[coef_min[, 1] != 0],
    Coefficient = coef_min[coef_min[, 1] != 0, 1]
  )
  if (nrow(coef_df) > 0) {
    coef_df <- coef_df[order(-abs(coef_df$Coefficient)), ]
    coef_df$Risk <- ifelse(coef_df$Coefficient > 0, "High", "Low")
    cat("\nLASSO 系数:\n")
    print(coef_df)
    saveRDS(coef_df, "data/processed/survival/lasso_coefficients.rds")
    write.csv(coef_df, "results/tables/survival/lasso_coefficients.csv", row.names = FALSE)
  }
  
  # 保存 LASSO 模型
  saveRDS(cv_fit, "data/processed/survival/lasso_cv_fit.rds")
  
} else {
  cat("⚠️ 步骤三候选基因不足 3 个，跳过 LASSO 筛选\n")
  candidates_s4 <- candidates_s3
}

cat(sprintf("\n✅ 步骤四结果: %d 个候选基因\n", length(candidates_s4)))

# ============================================================================
# 7. 步骤五：湿实验候选精选
# ============================================================================
step_header("五", "湿实验候选基因精选", "候选池内 |logFC| 前5% + FDR < 0.01")

final_genes <- character()

if (length(candidates_s4) > 0) {
  cand_info <- deg_results[deg_results$Gene %in% candidates_s4, ]
  
  if (nrow(cand_info) > 0) {
    # 在候选池内计算分位数
    fc_cut <- quantile(abs(cand_info$logFC), 0.95, na.rm = TRUE)
    cat(sprintf("|logFC| 前5%% 阈值（候选池 %d 个基因内）: %.3f\n", nrow(cand_info), fc_cut))
    
    strict <- cand_info[abs(cand_info$logFC) >= fc_cut & cand_info$adj.P.Val < 0.01, ]
    strict <- strict[order(-abs(strict$logFC)), ]
    
    if (nrow(strict) >= 4) {
      final_genes <- head(strict$Gene, 4)
      cat("✅ 严格条件满足，选出 4 个基因\n")
    } else if (nrow(strict) > 0) {
      remaining <- cand_info[!cand_info$Gene %in% strict$Gene, ]
      remaining <- remaining[order(remaining$adj.P.Val), ]
      final_genes <- head(unique(c(strict$Gene, remaining$Gene)), 4)
      cat("⚠️ 严格条件不足，补充 FDR 排序\n")
    } else {
      cand_info <- cand_info[order(cand_info$adj.P.Val), ]
      final_genes <- head(cand_info$Gene, 4)
      cat("⚠️ 无严格条件基因，按 FDR 排序取 Top 4\n")
    }
  } else {
    cat("⚠️ 候选基因无差异表达信息，取前 4 个\n")
    final_genes <- head(candidates_s4, 4)
  }
} else {
  cat("❌ 步骤四无候选基因\n")
  final_genes <- head(candidates_s3, 4)
}

final_genes <- head(unique(final_genes), 4)
cat(sprintf("\n✅ 最终候选基因: %d 个\n", length(final_genes)))
for (i in seq_along(final_genes)) {
  cat(sprintf("  %d. %s\n", i, final_genes[i]))
}

# ============================================================================
# 8. 步骤六：KM 曲线和风险评分分布（修复版）
# ============================================================================
step_header("六", "KM 曲线和风险评分分布", "基于最终 LASSO 模型")

if (length(final_genes) >= 2 && !is.null(lasso_coefs) && !is.null(train_center)) {
  
  # 准备最终表达数据
  final_expr <- t(tcga_expr_matched[final_genes, , drop = FALSE])
  final_expr_sc <- scale(final_expr, center = train_center[final_genes], 
                         scale = train_scale[final_genes])
  final_expr_sc[is.na(final_expr_sc)] <- 0
  
  # 计算风险评分
  final_risk <- as.matrix(final_expr_sc) %*% lasso_coefs[final_genes]
  final_risk <- as.numeric(final_risk)
  
  # 按中位数分组
  median_risk <- median(final_risk, na.rm = TRUE)
  high_risk <- final_risk > median_risk
  low_risk <- final_risk <= median_risk
  
  cat(sprintf("\n风险评分统计:\n"))
  cat(sprintf("  风险评分范围: [%.4f, %.4f]\n", min(final_risk), max(final_risk)))
  cat(sprintf("  中位数: %.4f\n", median_risk))
  cat(sprintf("  高风险组: %d 样本, 低风险组: %d 样本\n", sum(high_risk), sum(low_risk)))
  
  # ========== 8.1 KM 曲线（使用已定义的 tcga_time 和 tcga_status） ==========
  fit_km <- survfit(tcga_surv_obj ~ high_risk)
  
  # 计算 log-rank P 值
  surv_diff <- survdiff(tcga_surv_obj ~ high_risk)
  p_value <- 1 - pchisq(surv_diff$chisq, df = 1)
  
  cat(sprintf("  Log-rank P 值: %.2e\n", p_value))
  
  # 绘制 KM 曲线（基础版）
  pdf("results/figures/survival/km_curve_final.pdf", width = 8, height = 7)
  
  plot(fit_km, col = c("#377EB8", "#E41A1C"), lwd = 2,
       xlab = "Time (months)", ylab = "Survival Probability",
       main = "Kaplan-Meier Curve (LASSO Risk Score)",
       conf.int = FALSE)
  
  legend("topright", legend = c("Low Risk", "High Risk"), 
         col = c("#377EB8", "#E41A1C"), lwd = 2, bty = "n")
  legend("bottomleft", legend = paste("Log-rank P =", format(p_value, scientific = TRUE, digits = 3)), 
         bty = "n", text.col = "black")
  
  # 添加风险表
  risk_table <- table(high_risk)
  mtext(sprintf("Low risk: %d, High risk: %d", risk_table[1], risk_table[2]), 
        side = 1, line = 4, cex = 0.8)
  
  dev.off()
  cat("✅ KM 曲线已保存: results/figures/survival/km_curve_final.pdf\n")
  
  # ========== 8.2 风险评分分布图 ==========
  risk_df <- data.frame(
    Risk_Score = final_risk,
    Group = ifelse(high_risk, "High Risk", "Low Risk")
  )
  
  p_hist <- ggplot(risk_df, aes(x = Risk_Score, fill = Group)) +
    geom_histogram(bins = 30, alpha = 0.7, position = "identity") +
    scale_fill_manual(values = c("High Risk" = "#E41A1C", "Low Risk" = "#377EB8")) +
    geom_vline(xintercept = median_risk, linetype = "dashed", color = "gray30", linewidth = 0.8) +
    annotate("text", x = median_risk + 0.05, y = max(table(cut(final_risk, breaks = 30))) * 0.9,
             label = paste("Median =", round(median_risk, 3)), hjust = 0, size = 3.5) +
    labs(title = "Risk Score Distribution",
         x = "Risk Score", y = "Count") +
    theme_minimal() +
    theme(legend.position = "bottom",
          plot.title = element_text(hjust = 0.5, face = "bold"))
  
  ggsave("results/figures/survival/risk_score_distribution.pdf", p_hist, width = 8, height = 6)
  cat("✅ 风险评分分布图已保存\n")
  
  # ========== 8.3 风险评分箱线图 ==========
  p_box <- ggplot(risk_df, aes(x = Group, y = Risk_Score, fill = Group)) +
    geom_boxplot(alpha = 0.7, outlier.size = 1.5) +
    geom_jitter(width = 0.2, alpha = 0.3, size = 0.8) +
    scale_fill_manual(values = c("High Risk" = "#E41A1C", "Low Risk" = "#377EB8")) +
    labs(title = "Risk Score Comparison", x = "", y = "Risk Score") +
    theme_minimal() +
    theme(legend.position = "none",
          plot.title = element_text(hjust = 0.5, face = "bold"))
  
  ggsave("results/figures/survival/risk_score_boxplot.pdf", p_box, width = 5, height = 6)
  cat("✅ 风险评分箱线图已保存\n")
  
  # 保存风险评分数据
  risk_results <- data.frame(
    sample = colnames(tcga_expr_matched),
    risk_score = final_risk,
    risk_group = ifelse(high_risk, "High", "Low"),
    time = tcga_time,
    status = tcga_status
  )
  write.csv(risk_results, "results/tables/risk_scores.csv", row.names = FALSE)
  cat("✅ 风险评分数据已保存\n")
  
} else {
  cat("⚠️ 最终基因不足 2 个或 LASSO 系数缺失，无法绘制 KM 曲线\n")
  if (length(final_genes) < 2) cat("  原因: 最终基因数 =", length(final_genes), "\n")
  if (is.null(lasso_coefs)) cat("  原因: LASSO 系数缺失\n")
}

# ============================================================================
# 9. 最终结果汇总
# ============================================================================
step_header("汇总", "最终候选基因详情")

candidates_detail <- do.call(rbind, lapply(final_genes, function(g) {
  dinfo <- deg_results[deg_results$Gene == g, ]
  cinfo <- if (nrow(cox_results) > 0) cox_results[cox_results$Gene == g, ] else data.frame()
  
  data.frame(
    Gene = g,
    Category = ifelse(g %in% lact_genes & g %in% pcd_genes, "Lactylation+PCD",
                      ifelse(g %in% lact_genes, "Lactylation", ifelse(g %in% pcd_genes, "PCD", "Other"))),
    logFC = ifelse(nrow(dinfo) > 0, dinfo$logFC, NA),
    FDR = ifelse(nrow(dinfo) > 0, dinfo$adj.P.Val, NA),
    Cox_P = ifelse(nrow(cinfo) > 0, cinfo$P_value, NA),
    HR = ifelse(nrow(cinfo) > 0, cinfo$HR, NA),
    Risk = ifelse(nrow(cinfo) > 0, cinfo$Risk, NA),
    InLASSO = ifelse(g %in% candidates_s4, "Yes", "No")
  )
}))

cat("\n最终推荐湿实验验证基因:\n")
cat(strrep("=", 90), "\n")
print(candidates_detail)
cat(strrep("=", 90), "\n")

# 保存
saveRDS(final_genes, "data/processed/gene_sets/filtered/final_genes.rds")
writeLines(final_genes, "results/tables/final_genes.txt")
write.csv(candidates_detail, "results/tables/candidates_detail.csv", row.names = FALSE)
saveRDS(candidates_detail, "data/processed/gene_sets/filtered/candidates_detail.rds")
saveRDS(list(s1 = candidates_s1, s2 = candidates_s2, s3 = candidates_s3, 
             s4 = candidates_s4, final = final_genes),
        "data/processed/gene_sets/filtered/stepwise_results.rds")

# ============================================================================
# 10. 完成
# ============================================================================
cat("\n============================================================\n")
cat("✅ 完整流程运行完成\n")
cat(sprintf("筛选漏斗: %d → %d → %d → %d → %d (最终)\n",
            length(candidates_s1), length(candidates_s2), 
            length(candidates_s3), length(candidates_s4), length(final_genes)))
cat("最终推荐验证基因:\n")
for (i in seq_along(final_genes)) cat(sprintf("  %d. %s\n", i, final_genes[i]))
cat("日志已保存到:", log_file, "\n")
cat("============================================================\n")

sink()
cat("✅ 全流程完成！\n")
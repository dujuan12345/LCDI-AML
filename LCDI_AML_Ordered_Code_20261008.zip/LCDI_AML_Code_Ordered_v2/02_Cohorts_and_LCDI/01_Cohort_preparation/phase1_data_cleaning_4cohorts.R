# ============================================================================
# Phase 1 (修订版 v2): 
#   四队列架构，GSE10358 独立验证不参与跨队列 ComBat
#
# 设计:
#   训练集:    GPL96 (GSE37642+GSE12417, 585样本)
#   验证集 1:  GPL570 (GSE37642+GSE12417, 219样本) ← 参与 ComBat
#   验证集 2:  GSE10358 (304样本)   ← 独立
#   验证集 3:  TCGA (149样本)       ← 独立
#
# ComBat 策略:
#   - 主 ComBat: GPL96 + GPL570 (共 804 样本)
#     batch = 平台, mod = ~OS  (新参数)
#   - GSE10358: 仅做 log2 变换，不参与 ComBat
#   - TCGA: 独立，不参与 ComBat
#
# 输出:
#   data/processed/clean/clean_train_val.rds   ← 主对: GPL96 训练 + GPL570 验证
#   data/processed/clean/clean_gse10358.rds    ← GSE10358 独立
#   data/processed/clean/clean_tcga.rds        ← TCGA 独立（可选）
# ============================================================================

rm(list = ls()); gc()
while (sink.number() > 0) sink()

user_lib <- file.path(Sys.getenv("USERPROFILE"), "R", "win-library", "4.5")
if (dir.exists(user_lib)) .libPaths(c(user_lib, .libPaths()))

setwd("D:/26_01_AML/AML_Lactylation_PCD")

dir.create("data/processed/clean",    recursive = TRUE, showWarnings = FALSE)
dir.create("data/processed/clean/qc", recursive = TRUE, showWarnings = FALSE)
dir.create("data/logs",               recursive = TRUE, showWarnings = FALSE)

log_file <- file.path("data/logs",
                      paste0("clean_phase1_v2_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt"))
sink(log_file, split = TRUE)

cat("============================================================\n")
cat("Phase 1 v2: 四队列架构，GSE10358 独立\n")
cat("开始时间:", date(), "\n")
cat("============================================================\n\n")

suppressPackageStartupMessages({
  library(Biobase)
  library(hgu133a.db)
  library(hgu133plus2.db)
  library(AnnotationDbi)
  library(sva)
  library(dplyr)
})

# ============================================================================
# 辅助函数
# ============================================================================

probe_to_symbol <- function(expr_mat, platform) {
  cat(sprintf("    探针→符号映射 (%s)...\n", platform))
  probe_ids <- rownames(expr_mat)
  db <- switch(platform, "GPL96" = hgu133a.db, "GPL570" = hgu133plus2.db, NULL)
  if (is.null(db)) return(NULL)
  
  mapping <- suppressMessages(AnnotationDbi::select(db, keys = probe_ids,
                                       columns = c("SYMBOL"),
                                       keytype = "PROBEID"))
  mapping <- mapping[!is.na(mapping$SYMBOL), ]
  mapping <- mapping[!duplicated(mapping$PROBEID), ]
  
  keep_probes <- intersect(rownames(expr_mat), mapping$PROBEID)
  expr_sub <- expr_mat[keep_probes, , drop = FALSE]
  mapping <- mapping[match(keep_probes, mapping$PROBEID), ]
  
  gene_mat <- aggregate(expr_sub, by = list(SYMBOL = mapping$SYMBOL), 
                         FUN = mean, na.rm = TRUE)
  rownames(gene_mat) <- gene_mat$SYMBOL
  gene_mat$SYMBOL <- NULL
  gene_mat <- as.matrix(gene_mat)
  
  cat(sprintf("    ✅ %d 探针 → %d 基因\n", nrow(expr_mat), nrow(gene_mat)))
  gene_mat
}

check_sanity <- function(mat, name, min_sd = 0.3, max_range = 20) {
  range_val <- diff(range(mat, na.rm = TRUE))
  sd_val    <- sd(mat, na.rm = TRUE)
  median_val <- median(mat, na.rm = TRUE)
  msg <- sprintf("  %s: range=%.2f, median=%.2f, SD=%.3f", name, range_val, median_val, sd_val)
  if (sd_val < min_sd) { cat(msg, " 🚨 SD 过低\n"); return(FALSE) }
  if (range_val > max_range) { cat(msg, " 🚨 range 过大\n"); return(FALSE) }
  cat(msg, " ✅\n")
  return(TRUE)
}

# ============================================================================
# Step 1: 加载 + 映射 (GSE37642, GSE12417)
# ============================================================================
cat("──── Step 1: GSE37642 + GSE12417 探针→基因 ────\n\n")

gse37642 <- readRDS("data/GSE37642/GSE37642_raw.rds")
gse12417 <- readRDS("data/GSE12417/GSE12417_raw.rds")

# GSE37642
cat("GSE37642-GPL96:\n")
mat_37642_gpl96 <- probe_to_symbol(
  exprs(gse37642[[grep("GPL96", names(gse37642))[1]]]), "GPL96")
check_sanity(mat_37642_gpl96, "映射后")

cat("\nGSE37642-GPL570:\n")
mat_37642_gpl570 <- probe_to_symbol(
  exprs(gse37642[[grep("GPL570", names(gse37642))[1]]]), "GPL570")
check_sanity(mat_37642_gpl570, "映射后")

# GSE12417
cat("\nGSE12417-GPL96:\n")
mat_12417_gpl96 <- probe_to_symbol(
  exprs(gse12417[[grep("GPL96", names(gse12417))[1]]]), "GPL96")
check_sanity(mat_12417_gpl96, "映射后")

cat("\nGSE12417-GPL570:\n")
mat_12417_gpl570 <- probe_to_symbol(
  exprs(gse12417[[grep("GPL570", names(gse12417))[1]]]), "GPL570")
check_sanity(mat_12417_gpl570, "映射后")

# ============================================================================
# Step 2: 合并训练集 (GPL96) + 验证集1 (GPL570)
# ============================================================================
cat("\n──── Step 2: 合并训练 + 验证1 ────\n")

gpl96_genes <- intersect(rownames(mat_37642_gpl96), rownames(mat_12417_gpl96))
gpl570_genes <- intersect(rownames(mat_37642_gpl570), rownames(mat_12417_gpl570))

cat(sprintf("GPL96 共同基因: %d\n", length(gpl96_genes)))
cat(sprintf("GPL570 共同基因 (不含 GSE10358): %d\n", length(gpl570_genes)))

gpl96_expr <- cbind(
  mat_37642_gpl96[gpl96_genes, , drop = FALSE],
  mat_12417_gpl96[gpl96_genes, , drop = FALSE]
)
gpl96_dataset <- c(rep("GSE37642", ncol(mat_37642_gpl96)),
                    rep("GSE12417", ncol(mat_12417_gpl96)))

gpl570_expr <- cbind(
  mat_37642_gpl570[gpl570_genes, , drop = FALSE],
  mat_12417_gpl570[gpl570_genes, , drop = FALSE]
)
gpl570_dataset <- c(rep("GSE37642", ncol(mat_37642_gpl570)),
                     rep("GSE12417", ncol(mat_12417_gpl570)))

cat(sprintf("\n✅ GPL96 训练: %d 基因 × %d 样本\n", nrow(gpl96_expr), ncol(gpl96_expr)))
check_sanity(gpl96_expr, "GPL96 合并")
cat(sprintf("✅ GPL570 验证1: %d 基因 × %d 样本\n", nrow(gpl570_expr), ncol(gpl570_expr)))
check_sanity(gpl570_expr, "GPL570 合并")

# 跨平台共同基因（用于 ComBat）
cross_genes <- intersect(gpl96_genes, gpl570_genes)
cat(sprintf("\n跨平台 (GPL96 ∩ GPL570) 共同基因: %d\n", length(cross_genes)))

gpl96_expr <- gpl96_expr[cross_genes, , drop = FALSE]
gpl570_expr <- gpl570_expr[cross_genes, , drop = FALSE]

# ============================================================================
# Step 3: 加载临床数据
# ============================================================================
cat("\n──── Step 3: 加载临床数据 ────\n")

geo_surv <- readRDS("data/processed/geo_survival/geo_train_val_with_survival.rds")
train_surv <- geo_surv$train_survival
val_surv   <- geo_surv$val_survival

cat("train_surv 列:", paste(colnames(train_surv), collapse = ", "), "\n")
cat("val_surv   列:", paste(colnames(val_surv), collapse = ", "), "\n")

# 根据 notes:
#   full_id 对应表达矩阵列名
#   os_days (天)  
#   os_status (1=死亡)
# val_survival 包含 GSE10358 + GSE37642-GPL570 + GSE12417-GPL570

# 合并 + 提取字段
surv_all <- rbind(train_surv, val_surv)
cat(sprintf("\n合并临床表: %d 行\n", nrow(surv_all)))

# 匹配函数 —— 用 gsm_id（表达矩阵列名是纯 GSM ID）
match_survival <- function(sample_ids, surv_df) {
  idx <- match(sample_ids, surv_df$gsm_id)
  list(
    time   = as.numeric(surv_df$os_days[idx]),
    status = as.numeric(surv_df$os_status[idx]),
    n_matched = sum(!is.na(idx))
  )
}

gpl96_s <- match_survival(colnames(gpl96_expr), surv_all)
cat(sprintf("\nGPL96: %d/%d 样本匹配上临床\n", gpl96_s$n_matched, ncol(gpl96_expr)))

gpl570_s <- match_survival(colnames(gpl570_expr), surv_all)
cat(sprintf("GPL570 (不含 GSE10358): %d/%d 样本匹配上临床\n",
            gpl570_s$n_matched, ncol(gpl570_expr)))

# 筛选匹配上且 time>0 的样本
keep_gpl96 <- !is.na(gpl96_s$time) & !is.na(gpl96_s$status) & gpl96_s$time > 0
gpl96_expr   <- gpl96_expr[, keep_gpl96, drop = FALSE]
gpl96_dataset <- gpl96_dataset[keep_gpl96]
gpl96_time   <- gpl96_s$time[keep_gpl96]
gpl96_status <- gpl96_s$status[keep_gpl96]

keep_gpl570 <- !is.na(gpl570_s$time) & !is.na(gpl570_s$status) & gpl570_s$time > 0
gpl570_expr   <- gpl570_expr[, keep_gpl570, drop = FALSE]
gpl570_dataset <- gpl570_dataset[keep_gpl570]
gpl570_time   <- gpl570_s$time[keep_gpl570]
gpl570_status <- gpl570_s$status[keep_gpl570]

cat(sprintf("\n对齐后最终:\n"))
cat(sprintf("  GPL96 训练:  %d 样本 (死亡 %d, %.1f%%)\n",
            ncol(gpl96_expr), sum(gpl96_status), 100*mean(gpl96_status)))
cat(sprintf("  GPL570 验证1: %d 样本 (死亡 %d, %.1f%%)\n",
            ncol(gpl570_expr), sum(gpl570_status), 100*mean(gpl570_status)))

# ============================================================================
# Step 4: 主 ComBat (GPL96 + GPL570)
# ============================================================================
cat("\n──── Step 4: 主 ComBat (GPL96 + GPL570) ────\n")

combined_expr <- cbind(gpl96_expr, gpl570_expr)
combined_platform <- c(rep("GPL96",  ncol(gpl96_expr)),
                        rep("GPL570", ncol(gpl570_expr)))
combined_os <- c(gpl96_status, gpl570_status)

cat(sprintf("主合并: %d 基因 × %d 样本 (GPL96=%d, GPL570=%d)\n",
            nrow(combined_expr), ncol(combined_expr),
            sum(combined_platform == "GPL96"),
            sum(combined_platform == "GPL570")))

# NA 填补
na_frac <- rowSums(is.na(combined_expr)) / ncol(combined_expr)
combined_expr <- combined_expr[na_frac < 0.3, , drop = FALSE]
for (i in seq_len(nrow(combined_expr))) {
  r <- combined_expr[i, ]
  if (any(is.na(r))) combined_expr[i, is.na(r)] <- median(r, na.rm = TRUE)
}

# 移除 SD=0
sd_genes <- apply(combined_expr, 1, sd, na.rm = TRUE)
combined_expr <- combined_expr[sd_genes > 0.01, , drop = FALSE]

cat(sprintf("清洗后: %d 基因\n", nrow(combined_expr)))
cat("\nComBat 前:\n")
check_sanity(combined_expr, "Before ComBat")

cat("\n执行 ComBat: batch=平台, mod=~OS\n")
mod_matrix <- model.matrix(~ combined_os)
combat_result <- ComBat(dat = combined_expr,
                          batch = as.factor(combined_platform),
                          mod = mod_matrix,
                          par.prior = TRUE,
                          mean.only = FALSE)

cat("\nComBat 后:\n")
check_sanity(combat_result, "After ComBat")

# 关键基因对比
cat("\n关键基因 SD 对比 (ComBat 前后):\n")
for (g in c("MPO", "SIRT6", "CREB1", "GPX4", "CASP1", "SLC16A4")) {
  if (g %in% rownames(combat_result)) {
    b_sd <- sd(combined_expr[g, ], na.rm = TRUE)
    a_sd <- sd(combat_result[g, ], na.rm = TRUE)
    b_mean <- mean(combined_expr[g, ], na.rm = TRUE)
    a_mean <- mean(combat_result[g, ], na.rm = TRUE)
    cat(sprintf("  %-10s Before: mean=%.2f SD=%.3f | After: mean=%.2f SD=%.3f\n",
                g, b_mean, b_sd, a_mean, a_sd))
  }
}

# 拆分回 GPL96 / GPL570
n_gpl96 <- ncol(gpl96_expr)
gpl96_clean  <- combat_result[, 1:n_gpl96, drop = FALSE]
gpl570_clean <- combat_result[, (n_gpl96+1):ncol(combat_result), drop = FALSE]

# ============================================================================
# Step 5: GSE10358 独立处理
# ============================================================================
cat("\n──── Step 5: GSE10358 独立处理 (不参与 ComBat) ────\n")

gse10358_raw <- readRDS("data/processed/gse10358_processed.rds")
gse10358_exprs <- gse10358_raw$exprs  # 21358 基因 × 304 样本 (原始线性值)

cat(sprintf("GSE10358 原始: %d 基因 × %d 样本\n",
            nrow(gse10358_exprs), ncol(gse10358_exprs)))

# 保护性处理：去除或替换 <=0 的值
gse10358_exprs[gse10358_exprs < 0.01] <- 0.01

# log2 变换
gse10358_log2 <- log2(gse10358_exprs + 1)
cat("log2(x+1) 后:\n")
check_sanity(gse10358_log2, "GSE10358 log2", min_sd = 1, max_range = 22)

# 对齐临床（GSE10358 在 val_surv 里）
gse10358_s <- match_survival(colnames(gse10358_log2), surv_all)
cat(sprintf("\nGSE10358: %d/%d 样本匹配上临床\n",
            gse10358_s$n_matched, ncol(gse10358_log2)))

keep_10358 <- !is.na(gse10358_s$time) & !is.na(gse10358_s$status) & gse10358_s$time > 0
gse10358_log2 <- gse10358_log2[, keep_10358, drop = FALSE]
gse10358_time <- gse10358_s$time[keep_10358]
gse10358_status <- gse10358_s$status[keep_10358]

cat(sprintf("对齐后 GSE10358: %d 样本 (死亡 %d, %.1f%%)\n",
            ncol(gse10358_log2), sum(gse10358_status),
            100 * mean(gse10358_status)))

# GSE10358 用自己的基因名范围（不强制匹配 cross_genes）
# 但我们主要关心 17 基因 / 5 基因，这些应该都在
gene_set <- readRDS("data/processed/mime/B_gene_set.rds")
key_genes <- unique(c(gene_set$genes_final, gene_set$genes_5))
missing_10358 <- setdiff(key_genes, rownames(gse10358_log2))
if (length(missing_10358) > 0) {
  cat(sprintf("⚠️ GSE10358 中缺失: %s\n", paste(missing_10358, collapse = ", ")))
} else {
  cat("✅ 17 基因和 5 基因在 GSE10358 中都有\n")
}

# ============================================================================
# Step 6: 保存
# ============================================================================
cat("\n──── Step 6: 保存产物 ────\n")

# 主对（GPL96 训练 + GPL570 验证1）
train_val_bundle <- list(
  GPL96_Train = list(
    expr      = gpl96_clean,
    OS.time   = gpl96_time,
    OS        = gpl96_status,
    dataset   = gpl96_dataset,
    sample_id = colnames(gpl96_clean),
    platform  = "GPL96"
  ),
  GPL570_Val1 = list(
    expr      = gpl570_clean,
    OS.time   = gpl570_time,
    OS        = gpl570_status,
    dataset   = gpl570_dataset,
    sample_id = colnames(gpl570_clean),
    platform  = "GPL570"
  ),
  metadata = list(
    n_genes        = nrow(combat_result),
    n_gpl96        = ncol(gpl96_clean),
    n_gpl570       = ncol(gpl570_clean),
    common_genes   = rownames(combat_result),
    combat_batch   = "platform",
    combat_mod     = "~ OS_status",
    combat_notes   = "GSE10358 不参与 ComBat，独立保存",
    created_at     = date()
  )
)
saveRDS(train_val_bundle, "data/processed/clean/clean_train_val.rds")
cat("✅ data/processed/clean/clean_train_val.rds\n")

# GSE10358 独立
gse10358_bundle <- list(
  expr      = gse10358_log2,
  OS.time   = gse10358_time,
  OS        = gse10358_status,
  sample_id = colnames(gse10358_log2),
  platform  = "GPL570",
  dataset   = "GSE10358",
  preprocessing = "log2(x+1); no ComBat",
  notes     = "原始数据是 'scaled to array mean of 1500'，与其他 GPL570 数据尺度不一致，独立验证",
  created_at = date()
)
saveRDS(gse10358_bundle, "data/processed/clean/clean_gse10358.rds")
cat("✅ data/processed/clean/clean_gse10358.rds\n")

# ============================================================================
# Step 7: 质量报告
# ============================================================================
cat("\n============================================================\n")
cat("【质量报告 —— 新 vs 旧】\n")
cat("============================================================\n\n")

old_scaling <- NULL
if (file.exists("data/processed/mime/E_scaling_params.rds")) {
  old_scaling <- readRDS("data/processed/mime/E_scaling_params.rds")
}

cat("GPL96 训练集关键基因 SD 对比:\n")
for (g in c("MPO", "SIRT6", "CREB1", "GPX4", "CASP1", "SLC16A4")) {
  if (g %in% rownames(gpl96_clean)) {
    new_sd <- sd(gpl96_clean[g, ])
    new_mean <- mean(gpl96_clean[g, ])
    
    old_mean <- NA; old_sd <- NA
    if (!is.null(old_scaling) && g %in% old_scaling$Gene) {
      old_mean <- old_scaling$Mean[old_scaling$Gene == g]
      old_sd   <- old_scaling$SD[old_scaling$Gene == g]
    }
    
    imp <- ""
    if (!is.na(old_sd)) {
      r <- new_sd / old_sd
      if (r > 2)      imp <- " ✅ SD 大幅提升"
      else if (r > 1.3) imp <- " ✅ SD 有改善"
      else if (r < 0.8) imp <- " ⚠️ SD 下降"
    }
    cat(sprintf("  %-10s 新: mean=%.2f SD=%.3f | 旧: mean=%.2f SD=%.3f%s\n",
                g, new_mean, new_sd, old_mean, old_sd, imp))
  }
}

# GSE10358 独立对比
cat("\nGSE10358 关键基因 SD (独立处理):\n")
for (g in c("MPO", "SIRT6", "CREB1", "GPX4", "CASP1", "SLC16A4")) {
  if (g %in% rownames(gse10358_log2)) {
    cat(sprintf("  %-10s  mean=%.2f  SD=%.3f\n",
                g, mean(gse10358_log2[g, ]), sd(gse10358_log2[g, ])))
  }
}

# GO/NO-GO
cat("\n【Go/No-Go 决策】\n")
mpo_sd_new <- sd(gpl96_clean["MPO", ])
sirt6_sd_new <- sd(gpl96_clean["SIRT6", ])
cat(sprintf("GPL96 MPO SD = %.3f (旧=1.240)\n", mpo_sd_new))
cat(sprintf("GPL96 SIRT6 SD = %.3f (旧=0.198)\n", sirt6_sd_new))

if (mpo_sd_new > 1.2 && sirt6_sd_new > 0.5) {
  cat("✅ GO: 数据质量显著改善，强烈建议进入下一步\n")
  cat("   下一步: 重新建模（新 Cox），看 C-index 是否真的提升到 0.60+\n")
} else if (mpo_sd_new > 0.8) {
  cat("⚠️ 部分改善，可继续尝试\n")
} else {
  cat("🚨 NO-GO: 数据仍然不正常\n")
}

cat("\n\n文件清单:\n")
cat("  data/processed/clean/clean_train_val.rds  (主对)\n")
cat("  data/processed/clean/clean_gse10358.rds   (独立验证)\n")
cat("\n日志:", log_file, "\n")
cat("============================================================\n")

sink()
cat("✅ Phase 1 v2 完成\n")

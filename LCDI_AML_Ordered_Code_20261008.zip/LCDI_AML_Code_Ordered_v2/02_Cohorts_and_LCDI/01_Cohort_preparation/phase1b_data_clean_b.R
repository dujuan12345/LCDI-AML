# ============================================================================
# 新 B 段（clean 版本）: 基于 Phase 1 v2 的 clean 数据构建 4 队列
#
# 输入:
#   data/processed/clean/clean_train_val.rds   (GPL96 + GPL570, ComBat 后)
#   data/processed/clean/clean_gse10358.rds    (GSE10358, 仅 log2)
#   data/TCGA/TCGAbiolinks/processed/TCGA_LAML_PanCancer.rds
#   data/processed/mime/B_gene_set.rds         (基因列表 - 保留旧)
#
# 产出（clean 命名空间下）:
#   data/processed/mime/clean/B_cohort_data.rds          ← 新版本
#   data/processed/mime/clean/B_scaling_params.rds
#   data/processed/mime/clean/B_mime_input_days.rds
#   data/processed/mime/clean/B_gene_set.rds (copy)
#
# 不覆盖旧 B 段产物！！
# ============================================================================

rm(list = ls()); gc()
while (sink.number() > 0) sink()

user_lib <- file.path(Sys.getenv("USERPROFILE"), "R", "win-library", "4.5")
if (dir.exists(user_lib)) .libPaths(c(user_lib, .libPaths()))

setwd("D:/26_01_AML/AML_Lactylation_PCD")

dir.create("data/processed/mime/clean", recursive = TRUE, showWarnings = FALSE)
dir.create("data/logs",                  recursive = TRUE, showWarnings = FALSE)

log_file <- file.path("data/logs",
                       paste0("B_clean_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt"))
sink(log_file, split = TRUE)

cat("============================================================\n")
cat("新 B 段 (clean): 基于 Phase 1 v2 干净数据构建队列\n")
cat("开始时间:", date(), "\n")
cat("============================================================\n\n")

suppressPackageStartupMessages({
  library(dplyr)
})

# ============================================================================
# Step 1: 加载输入
# ============================================================================
cat("──── Step 1: 加载输入数据 ────\n")

# Phase 1 v2 产物
tv <- readRDS("data/processed/clean/clean_train_val.rds")
gse10358 <- readRDS("data/processed/clean/clean_gse10358.rds")

cat(sprintf("  GPL96 训练:  %d 基因 × %d 样本\n",
            nrow(tv$GPL96_Train$expr), ncol(tv$GPL96_Train$expr)))
cat(sprintf("  GPL570 验证1: %d 基因 × %d 样本\n",
            nrow(tv$GPL570_Val1$expr), ncol(tv$GPL570_Val1$expr)))
cat(sprintf("  GSE10358 验证2: %d 基因 × %d 样本\n",
            nrow(gse10358$expr), ncol(gse10358$expr)))

# TCGA（保持旧做法：独立归一化 log2 TPM+1）
tcga <- readRDS("data/TCGA/TCGAbiolinks/processed/TCGA_LAML_PanCancer.rds")
cat("  TCGA 结构:", paste(names(tcga), collapse = ", "), "\n")

# 基因列表
gene_set <- readRDS("data/processed/mime/B_gene_set.rds")
genes_5    <- gene_set$genes_5
genes_17   <- gene_set$genes_final

cat(sprintf("\n基因集:\n"))
cat(sprintf("  5 基因:  %s\n", paste(genes_5, collapse = ", ")))
cat(sprintf("  17 基因: %s\n", paste(genes_17, collapse = ", ")))

# ============================================================================
# Step 2: 提取 TCGA 表达 + 临床
# ============================================================================
cat("\n──── Step 2: 处理 TCGA ────\n")

# TCGA 结构（已确认）:
#   $expr_matrix   : matrix 20512 × 161
#   $survival_data : data.frame (patient_id, status, time_days)
#   $sample_mapping: data.frame (sample_id, patient_id)

tcga_expr <- tcga$expr_matrix
tcga_surv <- tcga$survival_data
tcga_map  <- tcga$sample_mapping

cat(sprintf("  expr_matrix: %d × %d (范围 [%.2f, %.2f])\n",
            nrow(tcga_expr), ncol(tcga_expr),
            min(tcga_expr, na.rm = TRUE), max(tcga_expr, na.rm = TRUE)))
cat(sprintf("  survival_data: %d 行 × %d 列\n", nrow(tcga_surv), ncol(tcga_surv)))
cat(sprintf("  sample_mapping: %d 行 × %d 列\n", nrow(tcga_map), ncol(tcga_map)))

# 字段（已知）
time_col <- "time_days"
os_col   <- "status"

cat(sprintf("\n  用字段: time='%s', status='%s'\n", time_col, os_col))

# 通过 sample_mapping 把 expr 的 sample_id 映射到 survival 的 patient_id
# 首先查看 expr 的列名长什么样
cat(sprintf("\n  expr 列名示例: %s\n",
            paste(head(colnames(tcga_expr), 3), collapse = ", ")))
cat(sprintf("  sample_mapping 的 sample_id: %s\n",
            paste(head(tcga_map$sample_id, 3), collapse = ", ")))
cat(sprintf("  survival 的 patient_id: %s\n",
            paste(head(tcga_surv$patient_id, 3), collapse = ", ")))

# 两步匹配: expr列名 → sample_id → patient_id → survival
# 第一步: expr的 sample_id (colnames) 查 sample_mapping
map_idx <- match(colnames(tcga_expr), tcga_map$sample_id)
cat(sprintf("\n  步骤1: expr sample_id → sample_mapping 匹配: %d/%d\n",
            sum(!is.na(map_idx)), length(map_idx)))

# 如果匹配率低，试试 substring（某些 TCGA 使用完整 barcode，mapping 可能是短 ID）
if (sum(!is.na(map_idx)) < length(map_idx) * 0.5) {
  # 尝试多种短 ID 形式
  for (n_char in c(12, 15, 16, 19)) {
    short_ids <- substr(colnames(tcga_expr), 1, n_char)
    mm <- match(short_ids, tcga_map$sample_id)
    if (sum(!is.na(mm)) > sum(!is.na(map_idx))) {
      cat(sprintf("  尝试前 %d 字符: %d 匹配\n", n_char, sum(!is.na(mm))))
      map_idx <- mm
    }
  }
}

patient_ids_from_expr <- tcga_map$patient_id[map_idx]

# 第二步: patient_id → survival
surv_idx <- match(patient_ids_from_expr, tcga_surv$patient_id)
cat(sprintf("  步骤2: patient_id → survival 匹配: %d/%d\n",
            sum(!is.na(surv_idx)), length(surv_idx)))

if (sum(!is.na(surv_idx)) < 50) {
  cat("\n⚠️ TCGA 匹配率过低，打印前几个 ID 对比:\n")
  cat("  expr colnames:", paste(head(colnames(tcga_expr), 5), collapse = ", "), "\n")
  cat("  mapping sample_id:", paste(head(tcga_map$sample_id, 5), collapse = ", "), "\n")
  cat("  mapping patient_id:", paste(head(tcga_map$patient_id, 5), collapse = ", "), "\n")
  cat("  survival patient_id:", paste(head(tcga_surv$patient_id, 5), collapse = ", "), "\n")
  stop("TCGA 匹配失败")
}

# 提取生存信息
tcga_time   <- as.numeric(tcga_surv[[time_col]][surv_idx])
tcga_status <- as.numeric(tcga_surv[[os_col]][surv_idx])

keep_tcga <- !is.na(tcga_time) & !is.na(tcga_status) & tcga_time > 0
tcga_expr   <- tcga_expr[, keep_tcga, drop = FALSE]
tcga_time   <- tcga_time[keep_tcga]
tcga_status <- tcga_status[keep_tcga]

cat(sprintf("\n  TCGA 对齐后: %d 样本 (死亡 %d, %.1f%%)\n",
            ncol(tcga_expr), sum(tcga_status),
            100 * mean(tcga_status)))

# 检查并做 log2 变换（如果需要）
tcga_max <- max(tcga_expr, na.rm = TRUE)
cat(sprintf("  TCGA 数值最大值: %.2f\n", tcga_max))
if (tcga_max > 50) {
  cat("  检测到 TCGA 未 log2，执行 log2(x+1) 变换\n")
  # 处理负值（某些 TCGA 数据归一化后有微小负值）
  tcga_expr[tcga_expr < 0] <- 0
  tcga_expr <- log2(tcga_expr + 1)
  cat(sprintf("  log2 后范围: [%.2f, %.2f], 中位数: %.2f, SD: %.3f\n",
              min(tcga_expr, na.rm = TRUE),
              max(tcga_expr, na.rm = TRUE),
              median(tcga_expr, na.rm = TRUE),
              sd(tcga_expr, na.rm = TRUE)))
} else {
  cat("  TCGA 已是 log 值，不做变换\n")
}

# ============================================================================
# Step 3: 构建 4 队列结构
# ============================================================================
cat("\n──── Step 3: 构建队列结构 ────\n")

extract_genes <- function(expr, genes) {
  available <- intersect(genes, rownames(expr))
  missing <- setdiff(genes, rownames(expr))
  if (length(missing) > 0) {
    cat(sprintf("    ⚠️ 缺失: %s\n", paste(missing, collapse = ", ")))
  }
  expr[available, , drop = FALSE]
}

# 4 队列
cat("GPL96 训练:\n")
gpl96_expr17 <- extract_genes(tv$GPL96_Train$expr, genes_17)
cat(sprintf("    17 基因: %d / %d\n", nrow(gpl96_expr17), length(genes_17)))

cat("GPL570 验证1:\n")
gpl570_expr17 <- extract_genes(tv$GPL570_Val1$expr, genes_17)
cat(sprintf("    17 基因: %d / %d\n", nrow(gpl570_expr17), length(genes_17)))

cat("GSE10358 验证2:\n")
gse10358_expr17 <- extract_genes(gse10358$expr, genes_17)
cat(sprintf("    17 基因: %d / %d\n", nrow(gse10358_expr17), length(genes_17)))

cat("TCGA 验证3:\n")
tcga_expr17 <- extract_genes(tcga_expr, genes_17)
cat(sprintf("    17 基因: %d / %d\n", nrow(tcga_expr17), length(genes_17)))

# 构建 cohort_data 结构（与旧 B 段兼容）
cohort_data <- list(
  GPL96_Train = list(
    expr_raw = gpl96_expr17,
    surv     = data.frame(
      row.names = colnames(gpl96_expr17),
      OS.time   = tv$GPL96_Train$OS.time,
      OS        = tv$GPL96_Train$OS
    ),
    n = ncol(gpl96_expr17)
  ),
  GPL570_Val1 = list(
    expr_raw = gpl570_expr17,
    surv     = data.frame(
      row.names = colnames(gpl570_expr17),
      OS.time   = tv$GPL570_Val1$OS.time,
      OS        = tv$GPL570_Val1$OS
    ),
    n = ncol(gpl570_expr17)
  ),
  GSE10358_Val2 = list(
    expr_raw = gse10358_expr17,
    surv     = data.frame(
      row.names = colnames(gse10358_expr17),
      OS.time   = gse10358$OS.time,
      OS        = gse10358$OS
    ),
    n = ncol(gse10358_expr17)
  ),
  TCGA_Val3 = list(
    expr_raw = tcga_expr17,
    surv     = data.frame(
      row.names = colnames(tcga_expr17),
      OS.time   = tcga_time,
      OS        = tcga_status
    ),
    n = ncol(tcga_expr17)
  )
)

# 打印队列摘要
cat("\n【队列摘要】\n")
for (coh in names(cohort_data)) {
  d <- cohort_data[[coh]]
  cat(sprintf("  %s: %d 样本 (死亡 %d, %.1f%%)  [%d 基因]\n",
              coh, d$n, sum(d$surv$OS, na.rm = TRUE),
              100 * mean(d$surv$OS, na.rm = TRUE),
              nrow(d$expr_raw)))
}

# ============================================================================
# Step 4: 计算 scaling_params（每队列自己的 μ/σ）
# ============================================================================
cat("\n──── Step 4: scaling_params ────\n")

scaling_params <- list()
for (coh in names(cohort_data)) {
  e <- cohort_data[[coh]]$expr_raw
  mu    <- rowMeans(e, na.rm = TRUE)
  sigma <- apply(e, 1, sd, na.rm = TRUE)
  sigma[sigma == 0] <- 1
  scaling_params[[coh]] <- list(center = mu, scale = sigma)
  cat(sprintf("  %s: MPO μ=%.2f σ=%.3f | SIRT6 μ=%.2f σ=%.3f\n",
              coh, mu["MPO"], sigma["MPO"], mu["SIRT6"], sigma["SIRT6"]))
}

# ============================================================================
# Step 5: 生成 Mime 输入（用于 C 段如果重新需要跑）
# ============================================================================
cat("\n──── Step 5: Mime 输入（可选） ────\n")

# Mime 要求格式: list of cohorts, each with "Cohort" + sample × (OS, OS.time, gene1, gene2, ...)
make_mime_input <- function(cohort_list) {
  out <- list()
  for (coh_name in names(cohort_list)) {
    d <- cohort_list[[coh_name]]
    # Mime wants samples × (OS.time, OS, genes)
    df <- data.frame(
      ID      = colnames(d$expr_raw),
      OS.time = d$surv$OS.time,
      OS      = d$surv$OS,
      t(d$expr_raw),
      check.names = FALSE
    )
    # 某些 Mime 版本要求列名首字母大写或固定
    out[[coh_name]] <- df
  }
  out
}

mime_input_days <- make_mime_input(cohort_data)

cat(sprintf("  产生 %d 个队列的 Mime 输入\n", length(mime_input_days)))
for (coh in names(mime_input_days)) {
  df <- mime_input_days[[coh]]
  cat(sprintf("    %s: %d 样本 × %d 列 (前 5 列: %s)\n",
              coh, nrow(df), ncol(df),
              paste(colnames(df)[1:5], collapse = ", ")))
}

# ============================================================================
# Step 6: 保存所有产物（clean 命名空间）
# ============================================================================
cat("\n──── Step 6: 保存 ────\n")

saveRDS(cohort_data,    "data/processed/mime/clean/B_cohort_data.rds")
saveRDS(scaling_params, "data/processed/mime/clean/B_scaling_params.rds")
saveRDS(mime_input_days,"data/processed/mime/clean/B_mime_input_days.rds")
saveRDS(gene_set,       "data/processed/mime/clean/B_gene_set.rds")

cat("✅ data/processed/mime/clean/B_cohort_data.rds\n")
cat("✅ data/processed/mime/clean/B_scaling_params.rds\n")
cat("✅ data/processed/mime/clean/B_mime_input_days.rds\n")
cat("✅ data/processed/mime/clean/B_gene_set.rds\n")

# ============================================================================
# Step 7: 新旧对比报告
# ============================================================================
cat("\n\n============================================================\n")
cat("【新旧 B 段 scaling_params 对比】\n")
cat("============================================================\n\n")

if (file.exists("data/processed/mime/B_scaling_params.rds")) {
  old_sp <- readRDS("data/processed/mime/B_scaling_params.rds")
  
  for (coh in intersect(names(old_sp), names(scaling_params))) {
    cat(sprintf("\n---- %s ----\n", coh))
    old_p <- old_sp[[coh]]
    new_p <- scaling_params[[coh]]
    for (g in c("MPO", "SIRT6", "CREB1", "GPX4", "CASP1", "SLC16A4")) {
      if (g %in% names(new_p$center) && g %in% names(old_p$center)) {
        cat(sprintf("  %-10s 旧 μ=%.2f σ=%.3f | 新 μ=%.2f σ=%.3f\n",
                    g, old_p$center[g], old_p$scale[g],
                    new_p$center[g], new_p$scale[g]))
      }
    }
  }
}

cat("\n============================================================\n")
cat("✅ 新 B 段完成\n")
cat("日志:", log_file, "\n")
cat("============================================================\n")

sink()
cat("✅ 新 B 段保存完毕，可以跑新 E 段了\n")

# ============================================================
# phase2_add_target.R  v2 (修正版)
# 修复:
#   1) 字段名 gene_5 → genes_5, gene_17 → genes_17
#   2) TPM 列名 = case_id (不是 sample_id)
# ============================================================

setwd("D:/26_01_AML/AML_Lactylation_PCD")

suppressPackageStartupMessages({
  library(survival)
  library(survminer)
})

cat("============================================================\n")
cat("Phase 2 Step 1: 加入 TARGET-AML 作为第 5 队列 (v2)\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

# ─────────────────────────────────────────────
# 【0】路径配置
# ─────────────────────────────────────────────
out_data_dir <- "data/processed/mime/clean"
out_fig_dir  <- "results/figures/mime/clean"
out_tab_dir  <- "results/tables/mime/clean"
dir.create(out_data_dir, recursive = TRUE, showWarnings = FALSE)
dir.create(out_fig_dir,  recursive = TRUE, showWarnings = FALSE)
dir.create(out_tab_dir,  recursive = TRUE, showWarnings = FALSE)

# ─────────────────────────────────────────────
# 【1】加载已有数据
# ─────────────────────────────────────────────
cat("─── 【1】加载已有数据 ───\n")

B_data    <- readRDS(file.path(out_data_dir, "B_cohort_data.rds"))
gene_set  <- readRDS(file.path(out_data_dir, "B_gene_set.rds"))
fit5      <- readRDS(file.path(out_data_dir, "E_cox_5gene_fit.rds"))

# *** 修复 1: 用真实字段名 ***
genes_5  <- gene_set$genes_5
genes_17 <- gene_set$genes_17

cat(sprintf("  ✓ B_cohort_data: %d 个队列\n", length(B_data)))
cat(sprintf("    队列名: %s\n", paste(names(B_data), collapse = ", ")))
cat(sprintf("  ✓ 5 基因: %s\n", paste(genes_5, collapse = ", ")))
cat(sprintf("  ✓ 17 基因: %d 个\n", length(genes_17)))

# ─────────────────────────────────────────────
# 【2】加载 TARGET 数据
# ─────────────────────────────────────────────
cat("\n─── 【2】加载 TARGET-AML 数据 ───\n")

target_full <- readRDS("data/TARGET/processed_v3/target_expr_full.rds")
cat(sprintf("  ✓ 字段: %s\n", paste(names(target_full), collapse = ", ")))

target_tpm    <- target_full$tpm
target_sample <- target_full$sample_info

cat(sprintf("  ✓ TPM 矩阵: %d × %d\n", nrow(target_tpm), ncol(target_tpm)))
cat(sprintf("  ✓ sample_info: %d × %d\n", nrow(target_sample), ncol(target_sample)))

# *** 修复 2: TPM 列名 = case_id, 用 case_id 对齐 ***
# 验证
n_match <- sum(colnames(target_tpm) %in% target_sample$case_id)
cat(sprintf("  ✓ TPM 列 ∈ case_id: %d / %d\n", n_match, ncol(target_tpm)))
stopifnot(n_match == ncol(target_tpm))

# 重排 sample_info 与 TPM 列对齐
target_sample <- target_sample[match(colnames(target_tpm), target_sample$case_id), ]
cat(sprintf("  ✓ sample_info 已按 TPM 列顺序重排, 新维度: %d × %d\n",
            nrow(target_sample), ncol(target_sample)))

# ─────────────────────────────────────────────
# 【3】检查 5/17 基因在 TARGET 中是否齐全
# ─────────────────────────────────────────────
cat("\n─── 【3】检查目标基因覆盖 ───\n")

found_5  <- intersect(genes_5,  rownames(target_tpm))
found_17 <- intersect(genes_17, rownames(target_tpm))

cat(sprintf("  5 基因: %d/%d 找到\n", length(found_5), length(genes_5)))
if (length(found_5) < length(genes_5)) {
  cat(sprintf("    ⚠️  缺失: %s\n", paste(setdiff(genes_5, found_5), collapse = ", ")))
}

cat(sprintf("  17 基因: %d/%d 找到\n", length(found_17), length(genes_17)))
if (length(found_17) < length(genes_17)) {
  cat(sprintf("    ⚠️  缺失: %s\n", paste(setdiff(genes_17, found_17), collapse = ", ")))
}

if (length(found_5) < length(genes_5)) {
  stop("❌ 5 基因不齐全, 无法计算 LCDI")
}

# ─────────────────────────────────────────────
# 【4】TPM → log2 + z-score
# ─────────────────────────────────────────────
cat("\n─── 【4】TPM → log2 + z-score (跨队列对齐) ───\n")

expr_5_target  <- target_tpm[found_5, , drop = FALSE]
expr_17_target <- target_tpm[found_17, , drop = FALSE]

expr_5_log  <- log2(expr_5_target + 1)
expr_17_log <- log2(expr_17_target + 1)

cat("  log2(TPM+1) 转换后:\n")
for (g in rownames(expr_5_log)) {
  cat(sprintf("    %-10s mean=%.3f sd=%.3f range=[%.3f, %.3f]\n",
              g, mean(expr_5_log[g, ]), sd(expr_5_log[g, ]),
              min(expr_5_log[g, ]), max(expr_5_log[g, ])))
}

# 与 GPL96 对比（参考）
gpl96_expr <- B_data$GPL96_Train$expr_full
cat("\n  GPL96 (microarray) vs TARGET (TPM-log) 同基因均值方差:\n")
for (g in intersect(rownames(expr_5_log), rownames(gpl96_expr))) {
  cat(sprintf("    %-10s GPL96 m=%.3f s=%.3f | TARGET m=%.3f s=%.3f\n",
              g, mean(gpl96_expr[g, ]), sd(gpl96_expr[g, ]),
              mean(expr_5_log[g, ]), sd(expr_5_log[g, ])))
}

# 内部 z-score
cat("\n  ▸ 策略: TARGET 内部 z-score 标准化 (与 GPL96 系数兼容)\n")
expr_5_z  <- t(scale(t(expr_5_log)))
expr_17_z <- t(scale(t(expr_17_log)))

cat("  z-score 后 (mean=0, sd=1, 验证):\n")
for (g in rownames(expr_5_z)) {
  cat(sprintf("    %-10s mean=%.3f sd=%.3f\n",
              g, mean(expr_5_z[g, ]), sd(expr_5_z[g, ])))
}

# ─────────────────────────────────────────────
# 【5】整理 TARGET 生存数据
# ─────────────────────────────────────────────
cat("\n─── 【5】整理 TARGET 生存数据 ───\n")

# 检查关键列
key_cols <- c("case_id", "OS_time", "OS_status", "age_years", "gender",
              "sample_type", "tissue_source")
for (cn in key_cols) {
  if (cn %in% colnames(target_sample)) {
    x <- target_sample[[cn]]
    cat(sprintf("    %-15s %s, NA=%d\n", cn, class(x)[1], sum(is.na(x))))
  } else {
    cat(sprintf("    %-15s ❌ 缺失\n", cn))
  }
}

# 取建模用列
surv_target <- target_sample[, c("case_id", "OS_time", "OS_status",
                                 "age_years", "gender", "sample_type"),
                             drop = FALSE]

cat(sprintf("\n  原始样本: %d\n", nrow(surv_target)))

# 过滤 NA OS
ok1 <- !is.na(surv_target$OS_time) & !is.na(surv_target$OS_status)
cat(sprintf("  OS 完整: %d (剔除 %d)\n", sum(ok1), sum(!ok1)))
surv_target <- surv_target[ok1, ]

# OS_time > 0
ok2 <- surv_target$OS_time > 0
cat(sprintf("  OS_time > 0: %d (剔除 %d)\n", sum(ok2), sum(!ok2)))
surv_target <- surv_target[ok2, ]

# OS_status 分布
cat(sprintf("  OS_status 分布: %s\n",
            paste(names(table(surv_target$OS_status)),
                  table(surv_target$OS_status), sep = "=", collapse = ", ")))

death_rate <- mean(surv_target$OS_status == 1)
cat(sprintf("  死亡率: %.1f%%\n", death_rate * 100))

median_fu <- median(surv_target$OS_time)
cat(sprintf("  中位随访: %.0f 天 (≈ %.1f 年)\n", median_fu, median_fu / 365.25))
cat(sprintf("  OS_time 范围: [%.0f, %.0f]\n",
            min(surv_target$OS_time), max(surv_target$OS_time)))

if (median_fu < 100) {
  warning("OS_time 中位数 < 100, 可能单位是 months/years!")
}

# 对齐表达
common_id <- intersect(surv_target$case_id, colnames(expr_5_z))
cat(sprintf("\n  表达 ∩ 生存 共有 case: %d\n", length(common_id)))

surv_target <- surv_target[match(common_id, surv_target$case_id), ]
expr_5_z    <- expr_5_z[, common_id, drop = FALSE]
expr_17_z   <- expr_17_z[, common_id, drop = FALSE]

cat(sprintf("  最终 TARGET 队列: N = %d\n", length(common_id)))

# ─────────────────────────────────────────────
# 【6】计算 LCDI 评分
# ─────────────────────────────────────────────
cat("\n─── 【6】计算 LCDI 评分 ───\n")

coef5 <- coef(fit5)
cat("  5 基因 Cox 系数 (来自 GPL96 训练):\n")
for (g in names(coef5)) {
  cat(sprintf("    %-10s β = %+.4f\n", g, coef5[g]))
}

# 按系数顺序排表达
expr_5_z_ordered <- expr_5_z[names(coef5), , drop = FALSE]
LCDI_target <- as.numeric(t(expr_5_z_ordered) %*% as.matrix(coef5))
names(LCDI_target) <- colnames(expr_5_z_ordered)

cat(sprintf("\n  LCDI 评分 (TARGET): N=%d\n", length(LCDI_target)))
cat(sprintf("    range=[%.3f, %.3f], mean=%.3f, sd=%.3f\n",
            min(LCDI_target), max(LCDI_target),
            mean(LCDI_target), sd(LCDI_target)))

# ─────────────────────────────────────────────
# 【7】TARGET 评估: C-index + KM
# ─────────────────────────────────────────────
cat("\n─── 【7】TARGET 上 LCDI 性能评估 ───\n")

df_eval <- data.frame(
  time   = surv_target$OS_time,
  status = surv_target$OS_status,
  LCDI   = LCDI_target
)

# 5 基因 LCDI C-index
ci_5 <- survival::concordance(Surv(time, status) ~ LCDI, data = df_eval, reverse = FALSE)
cat(sprintf("\n  ▸ 5 基因 LCDI: C-index = %.3f [95%% CI: %.3f - %.3f]\n",
            ci_5$concordance,
            ci_5$concordance - 1.96 * sqrt(ci_5$var),
            ci_5$concordance + 1.96 * sqrt(ci_5$var)))

# MPO 单基因
ci_mpo <- NULL
hr_mpo_str <- "NA"
if ("MPO" %in% rownames(expr_5_z)) {
  df_mpo <- data.frame(
    time   = surv_target$OS_time,
    status = surv_target$OS_status,
    MPO    = expr_5_z["MPO", ]
  )
  ci_mpo <- survival::concordance(Surv(time, status) ~ MPO, data = df_mpo, reverse = FALSE)
  cat(sprintf("  ▸ 单基因 MPO:  C-index = %.3f [95%% CI: %.3f - %.3f]\n",
              ci_mpo$concordance,
              ci_mpo$concordance - 1.96 * sqrt(ci_mpo$var),
              ci_mpo$concordance + 1.96 * sqrt(ci_mpo$var)))
  
  cox_mpo <- coxph(Surv(time, status) ~ MPO, data = df_mpo)
  hr_mpo <- exp(coef(cox_mpo))
  hr_mpo_ci <- exp(confint(cox_mpo))
  p_mpo <- summary(cox_mpo)$coefficients[, "Pr(>|z|)"]
  cat(sprintf("  ▸ MPO 单变量 Cox: HR=%.3f [%.3f-%.3f], P=%.3e\n",
              hr_mpo, hr_mpo_ci[1], hr_mpo_ci[2], p_mpo))
  hr_mpo_str <- sprintf("%.2f [%.2f-%.2f] P=%.2e", hr_mpo, hr_mpo_ci[1], hr_mpo_ci[2], p_mpo)
}

# KM 中位数分组
df_eval$risk <- ifelse(LCDI_target > median(LCDI_target), "High", "Low")
df_eval$risk <- factor(df_eval$risk, levels = c("Low", "High"))

surv_obj <- Surv(df_eval$time, df_eval$status)
fit_km <- survfit(surv_obj ~ risk, data = df_eval)
sd_test <- survdiff(surv_obj ~ risk, data = df_eval)
p_lr <- 1 - pchisq(sd_test$chisq, df = length(sd_test$n) - 1)

cox_lcdi <- coxph(Surv(time, status) ~ risk, data = df_eval)
hr_lcdi  <- exp(coef(cox_lcdi))
hr_ci    <- exp(confint(cox_lcdi))

cat(sprintf("\n  ▸ KM 分组 (按 LCDI 中位数):\n"))
cat(sprintf("    logrank P = %.3e\n", p_lr))
cat(sprintf("    HR(High vs Low) = %.2f [%.2f-%.2f]\n", hr_lcdi, hr_ci[1], hr_ci[2]))

# 保存 KM 图
tryCatch({
  pdf(file.path(out_fig_dir, "phase2_km_TARGET.pdf"), width = 7, height = 6)
  print(ggsurvplot(
    fit_km, data = df_eval,
    pval = sprintf("logrank P = %.3e\nHR = %.2f [%.2f-%.2f]",
                   p_lr, hr_lcdi, hr_ci[1], hr_ci[2]),
    pval.coord = c(max(df_eval$time) * 0.05, 0.05),
    conf.int = TRUE,
    risk.table = TRUE,
    risk.table.height = 0.25,
    palette = c("#3498DB", "#E74C3C"),
    legend.labs = c("Low LCDI", "High LCDI"),
    xlab = "Time (days)",
    ylab = "Overall Survival",
    title = sprintf("TARGET-AML (N=%d, deaths=%d)",
                    nrow(df_eval), sum(df_eval$status == 1)),
    ggtheme = theme_minimal()
  ))
  dev.off()
  cat(sprintf("\n  ✓ KM 图: %s\n", file.path(out_fig_dir, "phase2_km_TARGET.pdf")))
}, error = function(e) {
  cat(sprintf("  ⚠️  KM 图生成失败: %s\n", e$message))
})

# ─────────────────────────────────────────────
# 【8】构建 TARGET_Val4 队列对象
# ─────────────────────────────────────────────
cat("\n─── 【8】构建 TARGET_Val4 队列对象 ───\n")

TARGET_cohort <- list(
  expr_full = expr_17_z,
  expr_5    = expr_5_z_ordered,
  surv      = data.frame(
    sample_id   = common_id,        # 这里 sample_id 实际是 case_id
    case_id     = surv_target$case_id,
    os_days     = surv_target$OS_time,
    os_status   = surv_target$OS_status,
    age         = surv_target$age_years,
    gender      = surv_target$gender,
    sample_type = surv_target$sample_type,
    LCDI        = LCDI_target,
    stringsAsFactors = FALSE
  ),
  N         = length(common_id),
  notes     = "TARGET-AML, TPM->log2->内部z-score, 用 GPL96 训练 Cox 系数计算 LCDI"
)

B_data$TARGET_Val4 <- TARGET_cohort

cat(sprintf("  ✓ TARGET_Val4 已加入, 现共 %d 个队列\n", length(B_data)))
cat("\n  5 队列汇总:\n")
for (cn in names(B_data)) {
  N_ <- B_data[[cn]]$N
  if (is.null(N_)) N_ <- nrow(B_data[[cn]]$surv)
  death_rate_ <- mean(B_data[[cn]]$surv$os_status == 1, na.rm = TRUE)
  cat(sprintf("    %s: N=%d, 死亡率=%.1f%%\n", cn, N_, death_rate_ * 100))
}

# ─────────────────────────────────────────────
# 【9】保存
# ─────────────────────────────────────────────
cat("\n─── 【9】保存 5 队列数据 ───\n")

saveRDS(B_data, file.path(out_data_dir, "B_cohort_data_5cohorts.rds"))
cat(sprintf("  ✓ B_cohort_data_5cohorts.rds 已保存\n"))

saveRDS(TARGET_cohort, file.path(out_data_dir, "TARGET_Val4_cohort.rds"))
cat(sprintf("  ✓ TARGET_Val4_cohort.rds 已保存\n"))

# 评估摘要
cindex_mpo_ci <- if (!is.null(ci_mpo))
  sprintf("[%.3f-%.3f]",
          ci_mpo$concordance - 1.96 * sqrt(ci_mpo$var),
          ci_mpo$concordance + 1.96 * sqrt(ci_mpo$var)) else "NA"
cindex_mpo_val <- if (!is.null(ci_mpo)) round(ci_mpo$concordance, 3) else NA

result_summary <- data.frame(
  cohort   = "TARGET_Val4",
  N        = nrow(df_eval),
  deaths   = sum(df_eval$status == 1),
  death_pct = round(mean(df_eval$status == 1) * 100, 1),
  median_fu_days = round(median(df_eval$time)),
  cindex_5gene   = round(ci_5$concordance, 3),
  cindex_5gene_ci = sprintf("[%.3f-%.3f]",
                            ci_5$concordance - 1.96 * sqrt(ci_5$var),
                            ci_5$concordance + 1.96 * sqrt(ci_5$var)),
  cindex_MPO     = cindex_mpo_val,
  cindex_MPO_ci  = cindex_mpo_ci,
  km_logrank_p   = formatC(p_lr, format = "e", digits = 2),
  km_hr          = round(hr_lcdi, 2),
  km_hr_ci       = sprintf("[%.2f-%.2f]", hr_ci[1], hr_ci[2]),
  stringsAsFactors = FALSE
)
write.csv(result_summary,
          file.path(out_tab_dir, "phase2_TARGET_summary.csv"),
          row.names = FALSE)
cat(sprintf("  ✓ phase2_TARGET_summary.csv 已保存\n"))

cat("\n  ▸ 评估摘要:\n")
print(result_summary)

cat("\n============================================================\n")
cat("✅ Phase 2 Step 1 完成\n\n")
cat("下一步 (待用户确认结果后):\n")
cat("  • 5 队列 C-index 汇总图 (phase2_eval_5cohorts.R)\n")
cat("  • 临床变量提取 (extract_clinical_vars.R)\n")
cat("  • Nomogram 构建 (phase3_nomogram.R)\n")
cat("============================================================\n")

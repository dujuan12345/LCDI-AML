# ============================================================================
# 新 E 段 (clean): 基于 clean B 段数据构建正式 LCDI
#
# 输入:
#   data/processed/mime/clean/B_cohort_data.rds    (4 队列)
#   data/processed/mime/clean/B_gene_set.rds       (基因集)
#
# 设计:
#   - 训练:  GPL96 (580) → 基因方向 z-score → 5 基因 Cox
#   - 验证1: GPL570 (215) → 用 GPL96 的 μ/σ 外推 → 应用 Cox 系数
#   - 验证2: GSE10358 (91) → 同上（但尺度不同，可能 C-index 偏低）
#   - 验证3: TCGA (149) → 同上（跨平台）
#
# 分组策略 (新):
#   - 每队列用自己的 LCDI 中位数分组（避免 TCGA KM 崩盘）
#   - 训练集中位数作为参考保留
#
# 产出（clean 命名空间）:
#   data/processed/mime/clean/E_cox_5gene_fit.rds
#   data/processed/mime/clean/E_cox_17gene_fit.rds
#   data/processed/mime/clean/E_risk_scores.rds
#   results/tables/mime/clean/E_LCDI_formula.csv
#   results/tables/mime/clean/E_cindex_comparison.csv
#   results/tables/mime/clean/E_logrank_summary.csv
#   results/figures/mime/clean/E_cindex_barplot.pdf/png
#   results/figures/mime/clean/E_forest_5gene.pdf/png
#   results/figures/mime/clean/E_km_{cohort}.pdf/png × 4
# ============================================================================

rm(list = ls()); gc()
while (sink.number() > 0) sink()

user_lib <- file.path(Sys.getenv("USERPROFILE"), "R", "win-library", "4.5")
if (dir.exists(user_lib)) .libPaths(c(user_lib, .libPaths()))

setwd("D:/26_01_AML/AML_Lactylation_PCD")

dir.create("data/processed/mime/clean",   recursive = TRUE, showWarnings = FALSE)
dir.create("results/tables/mime/clean",   recursive = TRUE, showWarnings = FALSE)
dir.create("results/figures/mime/clean",  recursive = TRUE, showWarnings = FALSE)
dir.create("data/logs",                   recursive = TRUE, showWarnings = FALSE)

log_file <- file.path("data/logs",
                      paste0("mime_E_clean_", format(Sys.time(), "%Y%m%d_%H%M%S"), ".txt"))
sink(log_file, split = TRUE)

cat("============================================================\n")
cat("新 E 段 (clean)：基于干净数据的 LCDI 建模\n")
cat("开始时间:", date(), "\n")
cat("============================================================\n\n")

suppressPackageStartupMessages({
  library(survival)
  library(survminer)
  library(dplyr)
  library(ggplot2)
  library(ggpubr)
  library(forestplot)
})

# ============================================================================
# Step 1: 加载 clean 数据
# ============================================================================
cat("──── 【1】加载 clean B 段数据 ────\n")

cohort_full <- readRDS("data/processed/mime/clean/B_cohort_data.rds")
gene_set    <- readRDS("data/processed/mime/clean/B_gene_set.rds")

genes_5  <- gene_set$genes_5
genes_17 <- gene_set$genes_final

cat("5 基因: ", paste(genes_5, collapse = ", "), "\n")
cat("17 基因:", paste(genes_17, collapse = ", "), "\n\n")

cohort_names <- names(cohort_full)
for (coh in cohort_names) {
  d <- cohort_full[[coh]]
  cat(sprintf("%s: %d 样本, %d 死亡 (%.1f%%)\n",
              coh, d$n, sum(d$surv$OS, na.rm = TRUE),
              100 * mean(d$surv$OS, na.rm = TRUE)))
}

# EPV
n_events_train <- sum(cohort_full$GPL96_Train$surv$OS, na.rm = TRUE)
cat(sprintf("\nEPV (训练集 events per variable):\n"))
cat(sprintf("  5 基因: %.1f (%s)\n", n_events_train / 5,
            ifelse(n_events_train / 5 >= 10, "✅", "⚠️")))
cat(sprintf("  17 基因: %.1f (%s)\n", n_events_train / 17,
            ifelse(n_events_train / 17 >= 10, "✅", "⚠️")))

# ============================================================================
# Step 2: 辅助函数
# ============================================================================

# 提取队列：返回 list(expr_gene_x_sample, time, status)
extract_cohort <- function(coh_name, genes) {
  co <- cohort_full[[coh_name]]
  expr_sub <- co$expr_raw[intersect(genes, rownames(co$expr_raw)), , drop = FALSE]
  list(expr = expr_sub, time = co$surv$OS.time, status = co$surv$OS)
}

# 用训练集 μ/σ 外推 z-score
apply_scaling <- function(expr, mu, sigma) {
  g <- intersect(rownames(expr), names(mu))
  expr_sub <- expr[g, , drop = FALSE]
  mu_g    <- mu[g]
  sigma_g <- sigma[g]
  sigma_g[sigma_g == 0] <- 1
  
  out <- sweep(expr_sub, 1, mu_g, "-")
  out <- sweep(out,      1, sigma_g, "/")
  out[is.na(out)] <- 0
  t(out)  # 返回 样本 × 基因
}

# C-index (用 data.frame 方式，避开 survival concordance 的 bug)
calc_cindex <- function(rs, time, status) {
  df <- data.frame(time = time, status = status, neg_rs = -rs)
  res <- concordance(Surv(time, status) ~ neg_rs, data = df)
  C_val  <- as.numeric(res$concordance)[1]
  var_val <- res$var
  if (length(var_val) > 1) var_val <- var_val[1, 1]
  SE_val <- sqrt(as.numeric(var_val))[1]
  c(C = C_val, SE = SE_val)
}

# ============================================================================
# Step 3: 5 基因 Cox 主模型 (GPL96 训练)
# ============================================================================
cat("\n──── 【3】5 基因 Cox 主模型 ────\n")

d_gpl96_5 <- extract_cohort("GPL96_Train", genes_5)
cat(sprintf("GPL96 5 基因矩阵: %d 基因 × %d 样本\n",
            nrow(d_gpl96_5$expr), ncol(d_gpl96_5$expr)))

# 计算 GPL96 训练集 μ/σ
mu_5    <- rowMeans(d_gpl96_5$expr, na.rm = TRUE)
sigma_5 <- apply(d_gpl96_5$expr, 1, sd, na.rm = TRUE)
cat("GPL96 5 基因 μ/σ:\n")
print(data.frame(Gene = names(mu_5),
                  Mean = round(mu_5, 3),
                  SD   = round(sigma_5, 3), row.names = NULL))

# z-score
gpl96_5_z <- apply_scaling(d_gpl96_5$expr, mu_5, sigma_5)

# 拟合 Cox
train_df_5 <- data.frame(OS.time = d_gpl96_5$time, OS = d_gpl96_5$status, gpl96_5_z)
cox_5 <- coxph(Surv(OS.time, OS) ~ ., data = train_df_5)
cox_5_sum <- summary(cox_5)

cat("\n5 基因 Cox 结果:\n")
print(cox_5_sum$coefficients)

saveRDS(cox_5, "data/processed/mime/clean/E_cox_5gene_fit.rds")

coef_5 <- coef(cox_5)

# LCDI 公式
cat("\n【正式 LCDI 公式 (clean)】\n")
for (g in names(coef_5)) {
  sign_s <- ifelse(coef_5[g] >= 0, "+", "-")
  cat(sprintf("  %s %.4f × (%s - %.2f) / %.2f\n",
              sign_s, abs(coef_5[g]), g, mu_5[g], sigma_5[g]))
}

formula_df <- data.frame(
  Gene        = names(coef_5),
  Coefficient = round(coef_5, 4),
  HR          = round(exp(coef_5), 3),
  P_value     = signif(cox_5_sum$coefficients[, "Pr(>|z|)"], 3),
  Mean_GPL96  = round(mu_5[names(coef_5)], 3),
  SD_GPL96    = round(sigma_5[names(coef_5)], 3),
  Significant = ifelse(cox_5_sum$coefficients[, "Pr(>|z|)"] < 0.05, "*", "")
)
write.csv(formula_df, "results/tables/mime/clean/E_LCDI_formula.csv", row.names = FALSE)

# ============================================================================
# Step 4: 17 基因 Cox 敏感性分析
# ============================================================================
cat("\n──── 【4】17 基因 Cox 敏感性分析 ────\n")

d_gpl96_17 <- extract_cohort("GPL96_Train", genes_17)
mu_17    <- rowMeans(d_gpl96_17$expr, na.rm = TRUE)
sigma_17 <- apply(d_gpl96_17$expr, 1, sd, na.rm = TRUE)
gpl96_17_z <- apply_scaling(d_gpl96_17$expr, mu_17, sigma_17)

train_df_17 <- data.frame(OS.time = d_gpl96_17$time, OS = d_gpl96_17$status, gpl96_17_z)
cox_17 <- coxph(Surv(OS.time, OS) ~ ., data = train_df_17)
cox_17_sum <- summary(cox_17)

cat("17 基因 Cox (前 10 行):\n")
print(head(cox_17_sum$coefficients, 10))

saveRDS(cox_17, "data/processed/mime/clean/E_cox_17gene_fit.rds")
coef_17 <- coef(cox_17)

# ============================================================================
# Step 5: 风险评分计算（所有队列）
# ============================================================================
cat("\n──── 【5】风险评分计算 ────\n")

compute_rs <- function(cohort_nm, genes, coef_vec, mu, sigma) {
  d <- extract_cohort(cohort_nm, genes)
  z <- apply_scaling(d$expr, mu, sigma)
  # 确保列顺序与 coef 一致
  z <- z[, intersect(names(coef_vec), colnames(z)), drop = FALSE]
  coef_sub <- coef_vec[intersect(names(coef_vec), colnames(z))]
  as.numeric(z %*% coef_sub)
}

# 5 基因风险评分
rs_list_5 <- list()
for (coh in cohort_names) {
  rs_list_5[[coh]] <- compute_rs(coh, genes_5, coef_5, mu_5, sigma_5)
}

# 17 基因风险评分
rs_list_17 <- list()
for (coh in cohort_names) {
  rs_list_17[[coh]] <- compute_rs(coh, genes_17, coef_17, mu_17, sigma_17)
}

# 存风险评分
risk_scores_all <- list(
  rs_5  = rs_list_5,
  rs_17 = rs_list_17,
  sample_id = lapply(cohort_names, function(c) colnames(cohort_full[[c]]$expr_raw))
)
names(risk_scores_all$sample_id) <- cohort_names
saveRDS(risk_scores_all, "data/processed/mime/clean/E_risk_scores.rds")

# ============================================================================
# Step 6: C-index 对比
# ============================================================================
cat("\n──── 【6】C-index 计算 ────\n")

cindex_rows <- list()
for (coh in cohort_names) {
  d <- cohort_full[[coh]]
  # 5 基因
  c5 <- calc_cindex(rs_list_5[[coh]], d$surv$OS.time, d$surv$OS)
  cindex_rows[[length(cindex_rows) + 1]] <- data.frame(
    Cohort = coh, Model = "LCDI_5gene",
    Cindex = c5["C"], SE = c5["SE"]
  )
  # 17 基因
  c17 <- calc_cindex(rs_list_17[[coh]], d$surv$OS.time, d$surv$OS)
  cindex_rows[[length(cindex_rows) + 1]] <- data.frame(
    Cohort = coh, Model = "Cox_17gene",
    Cindex = c17["C"], SE = c17["SE"]
  )
}
cindex_df <- do.call(rbind, cindex_rows)
rownames(cindex_df) <- NULL
cindex_df$CI95_L <- round(cindex_df$Cindex - 1.96 * cindex_df$SE, 3)
cindex_df$CI95_U <- round(cindex_df$Cindex + 1.96 * cindex_df$SE, 3)
cindex_df$Cindex <- round(cindex_df$Cindex, 3)
cindex_df$SE     <- round(cindex_df$SE, 3)

cat("\nC-index 对比表:\n")
print(cindex_df)

write.csv(cindex_df, "results/tables/mime/clean/E_cindex_comparison.csv", row.names = FALSE)
saveRDS(cindex_df, "data/processed/mime/clean/E_cindex_df.rds")

# 5 vs 17 基因差异
cat("\n5 基因 - 17 基因 C-index 差异:\n")
for (coh in cohort_names) {
  c5  <- cindex_df$Cindex[cindex_df$Cohort == coh & cindex_df$Model == "LCDI_5gene"]
  c17 <- cindex_df$Cindex[cindex_df$Cohort == coh & cindex_df$Model == "Cox_17gene"]
  cat(sprintf("  %s: 5基因=%.3f, 17基因=%.3f, 差=%+.3f\n",
              coh, c5, c17, c5 - c17))
}

# ============================================================================
# Step 7: KM 分组（每队列自己的中位数）
# ============================================================================
cat("\n──── 【7】KM 曲线 ────\n")

km_results <- list()
logrank_rows <- list()

for (coh in cohort_names) {
  d <- cohort_full[[coh]]
  rs <- rs_list_5[[coh]]
  
  # 每队列自己的中位数分组
  thr <- median(rs, na.rm = TRUE)
  grp <- ifelse(rs > thr, "High", "Low")
  
  n_high <- sum(grp == "High")
  n_low  <- sum(grp == "Low")
  
  # log-rank
  surv_df <- data.frame(time = d$surv$OS.time, status = d$surv$OS, grp = factor(grp, levels = c("Low", "High")))
  sf <- survdiff(Surv(time, status) ~ grp, data = surv_df)
  p_val <- 1 - pchisq(sf$chisq, df = 1)
  
  logrank_rows[[coh]] <- data.frame(
    Cohort = coh,
    N = nrow(surv_df),
    N_High = n_high,
    N_Low  = n_low,
    P_value = signif(p_val, 3),
    Chi_sq  = round(sf$chisq, 2)
  )
  
  # KM 图
  fit <- survfit(Surv(time, status) ~ grp, data = surv_df)
  p <- ggsurvplot(fit, data = surv_df,
                   pval = TRUE,
                   conf.int = FALSE,
                   risk.table = TRUE,
                   palette = c("#2E86AB", "#E63946"),
                   legend.title = "LCDI Group",
                   legend.labs = c("Low", "High"),
                   xlab = "Time (days)",
                   ylab = "Overall Survival",
                   title = sprintf("%s  (n=%d, deaths=%d)",
                                   coh, nrow(surv_df), sum(d$surv$OS)))
  
  ggsave(sprintf("results/figures/mime/clean/E_km_%s.pdf", coh),
         print(p), width = 7, height = 7)
  ggsave(sprintf("results/figures/mime/clean/E_km_%s.png", coh),
         print(p), width = 7, height = 7, dpi = 150)
  cat(sprintf("  ✅ %s KM 图保存 (P=%.3g)\n", coh, p_val))
}

logrank_df <- do.call(rbind, logrank_rows)
rownames(logrank_df) <- NULL

cat("\nLog-rank 检验汇总:\n")
print(logrank_df)
write.csv(logrank_df, "results/tables/mime/clean/E_logrank_summary.csv", row.names = FALSE)

# ============================================================================
# Step 8: C-index 条形图
# ============================================================================
cat("\n──── 【8】C-index 条形图 ────\n")

p_cindex <- ggplot(cindex_df, aes(x = Cohort, y = Cindex, fill = Model)) +
  geom_bar(stat = "identity", position = position_dodge(0.8), width = 0.7) +
  geom_errorbar(aes(ymin = CI95_L, ymax = CI95_U),
                position = position_dodge(0.8), width = 0.2) +
  geom_hline(yintercept = 0.5, linetype = "dashed", color = "gray") +
  geom_hline(yintercept = 0.6, linetype = "dotted", color = "darkgreen") +
  scale_y_continuous(limits = c(0.4, 0.8), breaks = seq(0.4, 0.8, 0.05)) +
  scale_fill_manual(values = c("LCDI_5gene" = "#E63946", "Cox_17gene" = "#457B9D")) +
  labs(title = "C-index 四队列对比 (clean)",
       y = "Concordance Index (95% CI)", x = "") +
  theme_minimal() +
  theme(axis.text.x = element_text(angle = 0, hjust = 0.5))

ggsave("results/figures/mime/clean/E_cindex_barplot.pdf", p_cindex, width = 9, height = 5)
ggsave("results/figures/mime/clean/E_cindex_barplot.png", p_cindex, width = 9, height = 5, dpi = 150)
cat("  ✅ C-index 条形图保存\n")

# ============================================================================
# Step 9: 5 基因 HR 森林图
# ============================================================================
cat("\n──── 【9】5 基因 HR 森林图 ────\n")

forest_df <- data.frame(
  Gene    = names(coef_5),
  HR      = round(exp(coef_5), 3),
  HR_low  = round(exp(coef_5 - 1.96 * cox_5_sum$coefficients[, "se(coef)"]), 3),
  HR_high = round(exp(coef_5 + 1.96 * cox_5_sum$coefficients[, "se(coef)"]), 3),
  P       = signif(cox_5_sum$coefficients[, "Pr(>|z|)"], 3)
)

p_forest <- ggplot(forest_df, aes(x = HR, y = reorder(Gene, HR))) +
  geom_point(aes(size = -log10(P)), color = "#E63946") +
  geom_errorbarh(aes(xmin = HR_low, xmax = HR_high), height = 0.2, color = "#457B9D") +
  geom_vline(xintercept = 1, linetype = "dashed", color = "gray") +
  scale_size(range = c(3, 8), name = "-log10(P)") +
  scale_x_log10() +
  labs(title = "5 基因 HR (GPL96 训练集, clean)",
       x = "HR (95% CI) [log scale]", y = "") +
  theme_minimal() +
  geom_text(aes(label = sprintf("HR=%.2f\nP=%.3f", HR, P)),
            hjust = -0.3, size = 3.5)

ggsave("results/figures/mime/clean/E_forest_5gene.pdf", p_forest, width = 8, height = 5)
ggsave("results/figures/mime/clean/E_forest_5gene.png", p_forest, width = 8, height = 5, dpi = 150)
cat("  ✅ 森林图保存\n")

# ============================================================================
# Step 10: 最终汇总
# ============================================================================
cat("\n============================================================\n")
cat("✅ 新 E 段完成\n")
cat("============================================================\n\n")

cat("【关键结果】\n\n")

cat("1. 正式 LCDI 公式 (5 基因):\n")
for (i in seq_along(coef_5)) {
  g <- names(coef_5)[i]
  cat(sprintf("   %s%.4f × (%s - %.2f) / %.2f  [HR=%.2f, P=%.3g]\n",
              ifelse(coef_5[i] >= 0, "+", "-"),
              abs(coef_5[i]), g, mu_5[g], sigma_5[g],
              exp(coef_5[i]),
              cox_5_sum$coefficients[g, "Pr(>|z|)"]))
}

cat("\n2. 四队列性能:\n")
for (coh in cohort_names) {
  c5 <- cindex_df$Cindex[cindex_df$Cohort == coh & cindex_df$Model == "LCDI_5gene"]
  cl <- cindex_df$CI95_L[cindex_df$Cohort == coh & cindex_df$Model == "LCDI_5gene"]
  cu <- cindex_df$CI95_U[cindex_df$Cohort == coh & cindex_df$Model == "LCDI_5gene"]
  p_km <- logrank_df$P_value[logrank_df$Cohort == coh]
  cat(sprintf("   %-16s C-index = %.3f [%.3f-%.3f]   log-rank P = %.3g\n",
              coh, c5, cl, cu, p_km))
}

cat("\n3. 新旧 E 段对比 (5 基因 GPL96):\n")
if (file.exists("data/processed/mime/E_cindex_df.rds")) {
  old_df <- readRDS("data/processed/mime/E_cindex_df.rds")
  old_c_gpl96  <- old_df$Cindex[old_df$Cohort == "GPL96_Train" & old_df$Model == "LCDI_5gene"]
  old_c_gpl570 <- old_df$Cindex[old_df$Cohort == "GPL570_Val1" & old_df$Model == "LCDI_5gene"]
  old_c_tcga   <- old_df$Cindex[old_df$Cohort == "TCGA_Val2" & old_df$Model == "LCDI_5gene"]
  
  new_c_gpl96  <- cindex_df$Cindex[cindex_df$Cohort == "GPL96_Train" & cindex_df$Model == "LCDI_5gene"]
  new_c_gpl570 <- cindex_df$Cindex[cindex_df$Cohort == "GPL570_Val1" & cindex_df$Model == "LCDI_5gene"]
  new_c_tcga   <- cindex_df$Cindex[cindex_df$Cohort == "TCGA_Val3" & cindex_df$Model == "LCDI_5gene"]
  
  cat(sprintf("   GPL96_Train:  旧 %.3f → 新 %.3f (%+.3f)\n",
              old_c_gpl96, new_c_gpl96, new_c_gpl96 - old_c_gpl96))
  cat(sprintf("   GPL570_Val1:  旧 %.3f → 新 %.3f (%+.3f)\n",
              old_c_gpl570, new_c_gpl570, new_c_gpl570 - old_c_gpl570))
  cat(sprintf("   TCGA:         旧 %.3f → 新 %.3f (%+.3f)\n",
              old_c_tcga, new_c_tcga, new_c_tcga - old_c_tcga))
}

# 总体判断
cat("\n【总体判断】\n")
c_train <- cindex_df$Cindex[cindex_df$Cohort == "GPL96_Train" & cindex_df$Model == "LCDI_5gene"]
c_val1  <- cindex_df$Cindex[cindex_df$Cohort == "GPL570_Val1" & cindex_df$Model == "LCDI_5gene"]
all_km_p <- logrank_df$P_value

if (c_train >= 0.65 && c_val1 >= 0.60 && all(all_km_p < 0.05)) {
  cat("🎉 优秀: C-index ≥ 0.60 且所有队列 KM 显著\n")
  cat("   → 可直接进入 F 段 (timeROC + Nomogram + DCA)\n")
} else if (c_train >= 0.60 && c_val1 >= 0.55 && all(all_km_p < 0.1)) {
  cat("✅ 良好: C-index 改善明显\n")
  cat("   → 可进入 F 段\n")
} else if (c_train > 0.56 || c_val1 > 0.52) {
  cat("⚠️ 部分改善: 比旧版有进步但未达理想\n")
  cat("   → 建议尝试 17 基因模型 或加入临床变量的 Nomogram\n")
} else {
  cat("🚨 改善不明显\n")
  cat("   → 需要再深入检查\n")
}

cat("\n文件清单:\n")
cat("  data/processed/mime/clean/E_cox_5gene_fit.rds\n")
cat("  data/processed/mime/clean/E_cox_17gene_fit.rds\n")
cat("  data/processed/mime/clean/E_risk_scores.rds\n")
cat("  data/processed/mime/clean/E_cindex_df.rds\n")
cat("  results/tables/mime/clean/E_LCDI_formula.csv\n")
cat("  results/tables/mime/clean/E_cindex_comparison.csv\n")
cat("  results/tables/mime/clean/E_logrank_summary.csv\n")
cat("  results/figures/mime/clean/E_km_*.pdf × 4\n")
cat("  results/figures/mime/clean/E_cindex_barplot.pdf\n")
cat("  results/figures/mime/clean/E_forest_5gene.pdf\n")
cat("\n日志:", log_file, "\n")
cat("============================================================\n")

sink()
cat("✅ 新 E 段完成\n")

# ============================================================
# phase2_fix_direction_v2.R
# 修复:
#   v1 -> v2: 适配队列异构
#     - GPL96/GPL570/GSE10358/TCGA: expr_raw + surv(OS.time, OS)
#     - TARGET_Val4:                 expr_5/expr_full + surv(os_days, os_status)
# ============================================================

setwd("D:/26_01_AML/AML_Lactylation_PCD")

suppressPackageStartupMessages({
  library(survival)
  library(survminer)
})

cat("============================================================\n")
cat("修复 KM/Cindex 方向问题 + 重新评估 5 队列 (v2)\n")
cat("============================================================\n\n")

out_data_dir <- "data/processed/mime/clean"
out_fig_dir  <- "results/figures/mime/clean"
out_tab_dir  <- "results/tables/mime/clean"

B_data <- readRDS(file.path(out_data_dir, "B_cohort_data_5cohorts.rds"))
fit5   <- readRDS(file.path(out_data_dir, "E_cox_5gene_fit.rds"))
gene_set <- readRDS(file.path(out_data_dir, "B_gene_set.rds"))
genes_5  <- gene_set$genes_5
coef5    <- coef(fit5)

cat("Cox 系数 (训练于 GPL96):\n")
print(round(coef5, 4))
cat("\n")

`%||%` <- function(a, b) if (!is.null(a)) a else b

# ─────────────────────────────────────────────
# 工具: 从队列拿到表达矩阵 (5 基因)
# ─────────────────────────────────────────────
get_expr_5 <- function(cohort, genes_5) {
  # 优先级: expr_5 > expr_full > expr_raw
  if (!is.null(cohort$expr_5)) {
    expr <- cohort$expr_5
  } else if (!is.null(cohort$expr_full)) {
    expr <- cohort$expr_full
  } else if (!is.null(cohort$expr_raw)) {
    expr <- cohort$expr_raw
  } else {
    stop("找不到 expr_* 字段")
  }
  
  # 取 5 基因子集
  miss <- setdiff(genes_5, rownames(expr))
  if (length(miss) > 0) {
    stop(sprintf("缺失基因: %s", paste(miss, collapse = ", ")))
  }
  
  # drop = FALSE 防止单行被退化为 vector
  expr[genes_5, , drop = FALSE]
}

# ─────────────────────────────────────────────
# 工具: 从 surv 提取 time/status (统一字段名)
# ─────────────────────────────────────────────
get_surv <- function(cohort) {
  s <- cohort$surv
  
  # time
  time_col <- intersect(c("os_days", "OS_time", "OS.time", "time", "os_time"), colnames(s))[1]
  if (is.na(time_col)) stop(sprintf("找不到时间列, 现有: %s",
                                    paste(colnames(s), collapse = ", ")))
  
  # status
  status_col <- intersect(c("os_status", "OS_status", "OS", "status"), colnames(s))[1]
  if (is.na(status_col)) stop(sprintf("找不到状态列, 现有: %s",
                                      paste(colnames(s), collapse = ", ")))
  
  data.frame(
    time   = s[[time_col]],
    status = s[[status_col]],
    stringsAsFactors = FALSE
  )
}

# ─────────────────────────────────────────────
# 评估函数
# ─────────────────────────────────────────────
eval_cohort <- function(cname, cohort) {
  cat(sprintf("\n══ %s ══\n", cname))
  
  # 1. 取表达
  expr_5 <- get_expr_5(cohort, genes_5)
  cat(sprintf("  expr_5: %d × %d\n", nrow(expr_5), ncol(expr_5)))
  
  # 2. 取生存
  surv_df <- get_surv(cohort)
  cat(sprintf("  surv: N=%d (time列示例 %s, status列示例 %s)\n",
              nrow(surv_df),
              paste(head(surv_df$time, 3), collapse = ","),
              paste(head(surv_df$status, 3), collapse = ",")))
  
  # 3. 计算 LCDI = β·expr (按 coef 顺序排)
  expr_ord <- expr_5[names(coef5), , drop = FALSE]
  
  # 维度对齐检查
  if (ncol(expr_ord) != nrow(surv_df)) {
    cat(sprintf("  ⚠️  维度不匹配 expr=%d surv=%d\n",
                ncol(expr_ord), nrow(surv_df)))
    n_min <- min(ncol(expr_ord), nrow(surv_df))
    expr_ord <- expr_ord[, 1:n_min, drop = FALSE]
    surv_df <- surv_df[1:n_min, ]
  }
  
  LCDI <- as.numeric(t(expr_ord) %*% as.matrix(coef5))
  
  # 4. 整理 + 过滤
  df <- data.frame(
    time   = surv_df$time,
    status = surv_df$status,
    LCDI   = LCDI
  )
  ok <- !is.na(df$time) & !is.na(df$status) & !is.na(df$LCDI) & df$time > 0
  df <- df[ok, ]
  cat(sprintf("  过滤后: N=%d, deaths=%d (%.1f%%)\n",
              nrow(df), sum(df$status == 1), mean(df$status == 1) * 100))
  
  if (nrow(df) < 10 || sum(df$status == 1) < 5) {
    cat("  ⚠️  样本量不足, 跳过\n")
    return(NULL)
  }
  
  # 5. Cox 连续
  cox <- coxph(Surv(time, status) ~ LCDI, data = df)
  hr  <- exp(coef(cox))
  hr_ci <- exp(confint(cox))
  p_cox <- summary(cox)$coefficients[, "Pr(>|z|)"]
  
  # 6. C-index (LCDI = 风险 → reverse=TRUE)
  ci <- concordance(Surv(time, status) ~ LCDI, data = df, reverse = TRUE)
  
  # 7. KM
  df$risk <- factor(ifelse(df$LCDI > median(df$LCDI), "High", "Low"),
                    levels = c("Low", "High"))
  fit_km  <- survfit(Surv(time, status) ~ risk, data = df)
  sd_test <- survdiff(Surv(time, status) ~ risk, data = df)
  p_lr <- 1 - pchisq(sd_test$chisq, df = length(sd_test$n) - 1)
  
  cox_grp <- coxph(Surv(time, status) ~ risk, data = df)
  hr_grp  <- exp(coef(cox_grp))
  hr_grp_ci <- exp(confint(cox_grp))
  
  death_high <- mean(df$status[df$risk == "High"] == 1)
  death_low  <- mean(df$status[df$risk == "Low"]  == 1)
  
  cat(sprintf("  Cox 连续: HR=%.2f [%.2f-%.2f], P=%.2e\n",
              hr, hr_ci[1], hr_ci[2], p_cox))
  cat(sprintf("  C-index: %.3f [%.3f-%.3f]\n",
              ci$concordance,
              ci$concordance - 1.96 * sqrt(ci$var),
              ci$concordance + 1.96 * sqrt(ci$var)))
  cat(sprintf("  KM logrank P=%.2e, HR(High vs Low)=%.2f [%.2f-%.2f]\n",
              p_lr, hr_grp, hr_grp_ci[1], hr_grp_ci[2]))
  cat(sprintf("  死亡率: High %.1f%% vs Low %.1f%% %s\n",
              death_high * 100, death_low * 100,
              ifelse(death_high > death_low, "✓方向对", "✗方向反!")))
  
  list(
    cohort = cname,
    N = nrow(df),
    deaths = sum(df$status == 1),
    death_pct = round(mean(df$status == 1) * 100, 1),
    cindex = round(ci$concordance, 3),
    cindex_lo = ci$concordance - 1.96 * sqrt(ci$var),
    cindex_hi = ci$concordance + 1.96 * sqrt(ci$var),
    cindex_ci_str = sprintf("[%.3f-%.3f]",
                            ci$concordance - 1.96 * sqrt(ci$var),
                            ci$concordance + 1.96 * sqrt(ci$var)),
    cox_hr = round(hr, 2),
    cox_hr_ci = sprintf("[%.2f-%.2f]", hr_ci[1], hr_ci[2]),
    cox_p  = formatC(p_cox, format = "e", digits = 2),
    km_logrank_p = formatC(p_lr, format = "e", digits = 2),
    km_hr = round(hr_grp, 2),
    km_hr_ci = sprintf("[%.2f-%.2f]", hr_grp_ci[1], hr_grp_ci[2]),
    df = df,
    fit_km = fit_km
  )
}

# ─────────────────────────────────────────────
# 评估全部 5 队列
# ─────────────────────────────────────────────
results <- list()
for (cn in names(B_data)) {
  results[[cn]] <- tryCatch(
    eval_cohort(cn, B_data[[cn]]),
    error = function(e) {
      cat(sprintf("\n[%s] ❌ 错误: %s\n", cn, e$message))
      NULL
    }
  )
}

results <- results[!sapply(results, is.null)]

# ─────────────────────────────────────────────
# 汇总
# ─────────────────────────────────────────────
cat("\n\n══════════════════════════════════════════════════\n")
cat("5 队列 LCDI 评估汇总 (修正方向后)\n")
cat("══════════════════════════════════════════════════\n\n")

summary_df <- do.call(rbind, lapply(results, function(r) {
  data.frame(
    cohort = r$cohort, N = r$N, deaths = r$deaths, death_pct = r$death_pct,
    cindex = r$cindex, cindex_ci = r$cindex_ci_str,
    cox_hr = r$cox_hr, cox_hr_ci = r$cox_hr_ci, cox_p = r$cox_p,
    km_logrank_p = r$km_logrank_p,
    km_hr = r$km_hr, km_hr_ci = r$km_hr_ci,
    stringsAsFactors = FALSE
  )
}))
print(summary_df, row.names = FALSE)

write.csv(summary_df,
          file.path(out_tab_dir, "phase2_5cohorts_summary.csv"),
          row.names = FALSE)
cat(sprintf("\n  ✓ phase2_5cohorts_summary.csv 已保存\n"))

# ─────────────────────────────────────────────
# 重画 5 队列 KM (修正版)
# ─────────────────────────────────────────────
cat("\n─── 重新生成 KM 图 ───\n")
for (cn in names(results)) {
  r <- results[[cn]]
  pdf(file.path(out_fig_dir, sprintf("phase2_km_FIXED_%s.pdf", cn)),
      width = 7, height = 6)
  tryCatch({
    print(ggsurvplot(
      r$fit_km, data = r$df,
      pval = sprintf("logrank P = %s\nHR = %s %s\nC-index = %.3f",
                     r$km_logrank_p, r$km_hr, r$km_hr_ci, r$cindex),
      pval.coord = c(max(r$df$time) * 0.05, 0.10),
      conf.int = TRUE,
      risk.table = TRUE,
      risk.table.height = 0.25,
      palette = c("#3498DB", "#E74C3C"),
      legend.labs = c("Low LCDI", "High LCDI"),
      xlab = "Time (days)",
      ylab = "Overall Survival",
      title = sprintf("%s (N=%d, deaths=%d)", cn, r$N, r$deaths),
      ggtheme = theme_minimal()
    ))
  }, error = function(e) {
    cat(sprintf("  ⚠️  %s KM 图错误: %s\n", cn, e$message))
  })
  dev.off()
  cat(sprintf("  ✓ %s\n", file.path(out_fig_dir, sprintf("phase2_km_FIXED_%s.pdf", cn))))
}

# ─────────────────────────────────────────────
# 5 队列 C-index 森林图
# ─────────────────────────────────────────────
cat("\n─── 5 队列 C-index 森林图 ───\n")
forest_df <- data.frame(
  cohort = sapply(results, function(r) r$cohort),
  cindex = sapply(results, function(r) r$cindex),
  lower  = sapply(results, function(r) r$cindex_lo),
  upper  = sapply(results, function(r) r$cindex_hi),
  N      = sapply(results, function(r) r$N)
)

pdf(file.path(out_fig_dir, "phase2_5cohorts_cindex_forest.pdf"),
    width = 8, height = 5)
op <- par(mar = c(5, 12, 4, 2))
plot(forest_df$cindex, seq_len(nrow(forest_df)),
     xlim = c(0.4, 0.8), ylim = c(0.5, nrow(forest_df) + 0.5),
     pch = 19, cex = 1.5, col = "#2C3E50",
     yaxt = "n", xlab = "C-index (95% CI)", ylab = "",
     main = "5基因 LCDI 跨5队列 C-index")
axis(2, at = seq_len(nrow(forest_df)),
     labels = sprintf("%s (N=%d)", forest_df$cohort, forest_df$N),
     las = 2)
arrows(forest_df$lower, seq_len(nrow(forest_df)),
       forest_df$upper, seq_len(nrow(forest_df)),
       angle = 90, code = 3, length = 0.05, col = "#2C3E50")
abline(v = 0.5, lty = 2, col = "red")
text(forest_df$cindex, seq_len(nrow(forest_df)) + 0.25,
     sprintf("%.3f", forest_df$cindex), cex = 0.85)
par(op)
dev.off()
cat(sprintf("  ✓ %s\n", file.path(out_fig_dir, "phase2_5cohorts_cindex_forest.pdf")))

# ─────────────────────────────────────────────
# 给 4 个老队列也加 LCDI 字段，方便后续 Nomogram
# ─────────────────────────────────────────────
cat("\n─── 给所有队列保存 LCDI 字段 ───\n")
for (cn in names(B_data)) {
  if (cn %in% names(results)) {
    co <- B_data[[cn]]
    expr_5 <- get_expr_5(co, genes_5)
    expr_ord <- expr_5[names(coef5), , drop = FALSE]
    LCDI <- as.numeric(t(expr_ord) %*% as.matrix(coef5))
    
    if (length(LCDI) == nrow(co$surv)) {
      co$surv$LCDI <- LCDI
      co$surv$risk_group <- factor(
        ifelse(LCDI > median(LCDI), "High", "Low"),
        levels = c("Low", "High")
      )
      B_data[[cn]] <- co
      cat(sprintf("  ✓ %s: LCDI + risk_group 已加入 surv\n", cn))
    } else {
      cat(sprintf("  ⚠️ %s: LCDI(%d) ≠ surv(%d), 跳过\n",
                  cn, length(LCDI), nrow(co$surv)))
    }
  }
}

saveRDS(B_data, file.path(out_data_dir, "B_cohort_data_5cohorts.rds"))
cat("  ✓ B_cohort_data_5cohorts.rds 已更新 (含 LCDI)\n")

# ─────────────────────────────────────────────
# 最终汇总打印
# ─────────────────────────────────────────────
cat("\n============================================================\n")
cat("✅ 修复完成\n\n")
cat("5 队列 LCDI 真实战绩:\n")
cat(sprintf("%-15s %5s %8s %15s %12s %12s\n",
            "Cohort", "N", "Deaths", "C-index(CI)", "Cox HR(P)", "KM HR(P)"))
cat(strrep("-", 90), "\n")
for (i in seq_len(nrow(summary_df))) {
  cat(sprintf("%-15s %5d %8d %15s %5.2f %s %5.2f %s\n",
              summary_df$cohort[i], summary_df$N[i], summary_df$deaths[i],
              paste0(summary_df$cindex[i], summary_df$cindex_ci[i]),
              summary_df$cox_hr[i], summary_df$cox_p[i],
              summary_df$km_hr[i], summary_df$km_logrank_p[i]))
}
cat("\n============================================================\n")

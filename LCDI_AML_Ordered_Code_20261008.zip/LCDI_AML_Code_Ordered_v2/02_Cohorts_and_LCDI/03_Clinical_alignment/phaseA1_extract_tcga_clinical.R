# ============================================================
# phaseA_extract_clinical_v2.R
# Phase A Step 2 (v2): 修复 bug + 适配 GDC 真实字段
#
# 关键修复:
#   1) norm_fab() 防 NA 崩溃
#   2) TARGET case 列 = cases.submitter_id (不是 cases.case_id)
#   3) TARGET 没有 FAB → 走 LCDI + age + cyto_risk + gender 路线
#   4) GEO ESet 列名扫描 (preview)
# ============================================================

setwd("D:/26_01_AML/AML_Lactylation_PCD")
suppressPackageStartupMessages(library(Biobase))

cat("============================================================\n")
cat("Phase A Step 2 (v2)\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

out_data_dir <- "data/processed/mime/clean"
clinical_results <- list()

# ─────────────────────────────────────────────
# 工具函数 (修复版)
# ─────────────────────────────────────────────

norm_fab <- function(x) {
  result <- rep(NA_character_, length(x))
  if (length(x) == 0) return(result)
  for (i in seq_along(x)) {
    if (is.na(x[i]) || x[i] == "") next
    s <- toupper(as.character(x[i]))
    m <- regexpr("M[0-7]", s)
    if (!is.na(m) && length(m) == 1 && m > 0) {
      result[i] <- regmatches(s, m)
    }
  }
  result
}

norm_gender <- function(x) {
  out <- rep(NA_character_, length(x))
  out[x %in% c("M", "Male", "MALE", "male", "m")] <- "M"
  out[x %in% c("F", "Female", "FEMALE", "female", "f")] <- "F"
  out
}

classify_cyto_risk <- function(s) {
  if (is.na(s) || s == "") return(NA_character_)
  s <- toupper(s)
  if (grepl("T\\(15.*17\\)|T\\(8.*21\\)|INV\\(16\\)|INV16|T\\(16.*16\\)|FAVOR|GOOD|LOW|RBM15", s)) {
    return("Favorable")
  }
  if (grepl("-5|DEL\\(5|-7|DEL\\(7|MLL|T\\(6.*9\\)|INV\\(3\\)|COMPLEX|MONOSOMY|ADVER|POOR|HIGH|UNFAVOR", s)) {
    return("Adverse")
  }
  if (grepl("NORMAL|46.*XX|46.*XY|NK|INTERM|STANDARD", s)) {
    return("Intermediate")
  }
  return("Intermediate")
}

# ═══════════════════════════════════════════════════════
# 【1】TARGET_Val4
# ═══════════════════════════════════════════════════════
cat("─── 【1】TARGET_Val4 ───\n")

target_full <- readRDS("data/TARGET/processed_v3/target_expr_full.rds")
target_sample <- target_full$sample_info

# 1.1 age + gender
target_clin <- data.frame(
  sample_id = target_sample$case_id,  # case_id 与 TPM 列一致 = TARGET-20-XXX
  age       = target_sample$age_years,
  gender    = norm_gender(target_sample$gender),
  stringsAsFactors = FALSE
)
cat(sprintf("  ✓ age (NA=%d), gender (NA=%d)\n",
            sum(is.na(target_clin$age)),
            sum(is.na(target_clin$gender))))

# 1.2 FAB: GDC 全空, 标记 NA
target_clin$FAB <- NA_character_
cat("  ⚠️  FAB: GDC 上 TARGET-AML 全空 (儿童AML cohort 不记录 FAB), 设为 NA\n")
cat("       → TARGET Nomogram 不纳入 FAB\n")

# 1.3 cyto_risk: 用易位标记构建
fav_mask <- (!is.na(target_sample$t_8_21) & target_sample$t_8_21 == 1) |
            (!is.na(target_sample$t_15_17) & target_sample$t_15_17 == 1) |
            (target_sample$CBFB_known_positive == 1)
adv_mask <- (!is.na(target_sample$any_kmt2a_translocation) &
             target_sample$any_kmt2a_translocation == 1) |
            (!is.na(target_sample$t_6_9) & target_sample$t_6_9 == 1)
cyto_risk <- rep("Intermediate", nrow(target_sample))
cyto_risk[fav_mask] <- "Favorable"
cyto_risk[adv_mask] <- "Adverse"
cyto_risk[fav_mask & adv_mask] <- "Adverse"
target_clin$cyto_risk <- cyto_risk

cat("  ✓ cyto_risk 分布 (从易位标记构建):\n")
print(table(target_clin$cyto_risk, useNA = "always"))

# 1.4 突变 (额外, 备用)
target_clin$FLT3   <- ifelse(target_sample$FLT3_status == "Positive", 1,
                       ifelse(target_sample$FLT3_status == "Negative", 0, NA))
target_clin$NPM1   <- ifelse(target_sample$NPM1_status == "Positive", 1,
                       ifelse(target_sample$NPM1_status == "Negative", 0, NA))
target_clin$CEBPA  <- ifelse(target_sample$CEBPA_status == "Positive", 1,
                       ifelse(target_sample$CEBPA_status == "Negative", 0, NA))
cat(sprintf("  ✓ FLT3 (avail %d), NPM1 (avail %d), CEBPA (avail %d) [额外字段]\n",
            sum(!is.na(target_clin$FLT3)),
            sum(!is.na(target_clin$NPM1)),
            sum(!is.na(target_clin$CEBPA))))

clinical_results$TARGET_Val4 <- target_clin
cat("\n  TARGET_Val4 临床表前 5 行:\n")
print(head(target_clin, 5))

# ═══════════════════════════════════════════════════════
# 【2】TCGA_Val3
# ═══════════════════════════════════════════════════════
cat("\n─── 【2】TCGA_Val3 ───\n")

tcga_path <- "data/TCGA/TCGAbiolinks/raw/TCGA-LAML/Clinical/Clinical_Supplement/c07a64a0-7588-4653-95ef-982b41a1a804/nationwidechildrens.org_clinical_patient_laml.txt"

if (!file.exists(tcga_path)) {
  cat(sprintf("  ❌ 文件不存在: %s\n", tcga_path))
} else {
  raw <- readLines(tcga_path)
  cat(sprintf("  原始行数: %d\n", length(raw)))
  
  # TCGA 临床表前 3 行: 列名 / CDE_ID / CDE_NAME, 数据从第 4 行开始
  header <- strsplit(raw[1], "\t")[[1]]
  data_lines <- raw[4:length(raw)]
  
  # 写到临时文件再读
  tmp_path <- tempfile(fileext = ".tsv")
  writeLines(c(raw[1], data_lines), tmp_path)
  tcga_full <- read.delim(tmp_path, stringsAsFactors = FALSE,
                          check.names = FALSE,
                          na.strings = c("", "NA", "[Not Available]",
                                         "[Not Applicable]", "[Discrepancy]",
                                         "[Unknown]"))
  unlink(tmp_path)
  cat(sprintf("  TCGA 临床表: %d × %d\n", nrow(tcga_full), ncol(tcga_full)))
  
  # 找关键列 (TCGA 列名相对固定)
  cat("\n  搜索 age 列:\n")
  age_candidates <- grep("age", colnames(tcga_full), ignore.case = TRUE, value = TRUE)
  for (c in head(age_candidates, 5)) cat(sprintf("    %s\n", c))
  age_col <- intersect(c("age_at_initial_pathologic_diagnosis", "age_at_diagnosis",
                         "age_began_smoking_in_years"), age_candidates)[1]
  if (is.na(age_col)) age_col <- age_candidates[1]
  cat(sprintf("  ▶ 用 age 列: %s\n", age_col))
  
  cat("\n  搜索 gender 列:\n")
  gender_candidates <- grep("gender|sex", colnames(tcga_full), ignore.case = TRUE, value = TRUE)
  for (c in head(gender_candidates, 3)) cat(sprintf("    %s\n", c))
  gender_col <- gender_candidates[1]
  cat(sprintf("  ▶ 用 gender 列: %s\n", gender_col))
  
  cat("\n  搜索 FAB 列:\n")
  fab_candidates <- grep("french|fab|leukemia.*morpho", colnames(tcga_full),
                         ignore.case = TRUE, value = TRUE)
  for (c in head(fab_candidates, 5)) cat(sprintf("    %s\n", c))
  fab_col <- fab_candidates[1]
  if (!is.na(fab_col)) {
    cat(sprintf("  ▶ 用 FAB 列: %s\n", fab_col))
    cat(sprintf("    原始分布:\n"))
    print(table(tcga_full[[fab_col]], useNA = "always"))
  }
  
  cat("\n  搜索 cyto_risk 列:\n")
  risk_candidates <- grep("cytogenet.*risk|risk.*cytogenet|calgb|risk_category|risk_group",
                          colnames(tcga_full), ignore.case = TRUE, value = TRUE)
  for (c in head(risk_candidates, 5)) cat(sprintf("    %s\n", c))
  risk_col <- risk_candidates[1]
  if (!is.na(risk_col)) {
    cat(sprintf("  ▶ 用 cyto_risk 列: %s\n", risk_col))
    cat(sprintf("    原始分布:\n"))
    print(table(tcga_full[[risk_col]], useNA = "always"))
  }
  
  cat("\n  搜索 case_id 列:\n")
  case_candidates <- grep("bcr_patient_barcode|patient_barcode|patient_id",
                          colnames(tcga_full), ignore.case = TRUE, value = TRUE)
  for (c in head(case_candidates, 3)) cat(sprintf("    %s\n", c))
  case_col <- case_candidates[1]
  cat(sprintf("  ▶ 用 case 列: %s\n", case_col))
  
  if (!is.na(case_col)) {
    tcga_clin <- data.frame(
      sample_id = tcga_full[[case_col]],  # TCGA-AB-XXXX
      age       = if (!is.na(age_col))    suppressWarnings(as.numeric(tcga_full[[age_col]]))    else NA_real_,
      gender    = if (!is.na(gender_col)) norm_gender(tcga_full[[gender_col]])                  else NA_character_,
      FAB       = if (!is.na(fab_col))    norm_fab(tcga_full[[fab_col]])                        else NA_character_,
      cyto_risk = if (!is.na(risk_col))   sapply(tcga_full[[risk_col]], classify_cyto_risk)     else NA_character_,
      stringsAsFactors = FALSE
    )
    
    cat(sprintf("\n  ✓ TCGA 临床: %d 例\n", nrow(tcga_clin)))
    cat(sprintf("    age:       NA=%d (avail %d)\n", sum(is.na(tcga_clin$age)), sum(!is.na(tcga_clin$age))))
    cat(sprintf("    gender:    NA=%d (avail %d)\n", sum(is.na(tcga_clin$gender)), sum(!is.na(tcga_clin$gender))))
    cat(sprintf("    FAB:       NA=%d (avail %d)\n", sum(is.na(tcga_clin$FAB)), sum(!is.na(tcga_clin$FAB))))
    cat("    FAB 分布:\n"); print(table(tcga_clin$FAB, useNA = "always"))
    cat(sprintf("    cyto_risk: NA=%d (avail %d)\n", sum(is.na(tcga_clin$cyto_risk)), sum(!is.na(tcga_clin$cyto_risk))))
    cat("    cyto_risk 分布:\n"); print(table(tcga_clin$cyto_risk, useNA = "always"))
    
    # 4 变量都齐全的样本
    n_complete <- sum(complete.cases(tcga_clin[, c("age", "gender", "FAB", "cyto_risk")]))
    cat(sprintf("    4变量全齐: %d / %d\n", n_complete, nrow(tcga_clin)))
    
    clinical_results$TCGA_Val3 <- tcga_clin
    cat("\n  TCGA_Val3 临床表前 5 行:\n")
    print(head(tcga_clin, 5))
  }
}

# ═══════════════════════════════════════════════════════
# 【3-5】GEO 队列: 扫描 phenoData 列名 (后续脚本 parse)
# ═══════════════════════════════════════════════════════
cat("\n─── 【3-5】GEO 队列 phenoData 扫描 ───\n")

scan_eset_pheno <- function(gse_id, raw_path) {
  cat(sprintf("\n  ▶ %s\n", gse_id))
  if (!file.exists(raw_path)) {
    cat(sprintf("    ❌ 不存在: %s\n", raw_path))
    return(NULL)
  }
  
  gse <- readRDS(raw_path)
  
  if (is.list(gse) && length(gse) > 0 && inherits(gse[[1]], "ExpressionSet")) {
    esets <- gse
  } else if (inherits(gse, "ExpressionSet")) {
    esets <- list(gse)
  } else {
    cat(sprintf("    ⚠️ 非 ESet, class: %s\n", paste(class(gse), collapse = ",")))
    return(NULL)
  }
  
  cat(sprintf("    %d 个 ESet\n", length(esets)))
  pheno_list <- list()
  for (i in seq_along(esets)) {
    e <- esets[[i]]
    pl <- annotation(e)
    cat(sprintf("    ESet %d: %d 样本, 平台 %s\n", i, ncol(e), pl))
    
    pheno <- pData(e)
    pheno_list[[i]] <- pheno
    
    # 重点: 找 :ch1 列 (GEO 标准临床字段)
    ch1_cols <- grep(":ch1$", colnames(pheno), value = TRUE)
    cat(sprintf("      :ch1 列 (%d):\n", length(ch1_cols)))
    for (cc in head(ch1_cols, 20)) {
      vals <- na.omit(pheno[[cc]])
      n_uniq <- length(unique(vals))
      cat(sprintf("        %-40s [%d uniq] e.g. %s\n", cc, n_uniq,
                  paste(head(unique(vals), 2), collapse = " | ")))
    }
    
    # geo_accession 列 (用于 sample_id 对齐)
    geo_col <- intersect(c("geo_accession", "geo_id", "title"), colnames(pheno))
    cat(sprintf("      ID 列: %s\n", paste(geo_col, collapse = ", ")))
    if (length(geo_col) > 0) {
      cat(sprintf("        示例: %s\n",
                  paste(head(pheno[[geo_col[1]]], 3), collapse = ", ")))
    }
  }
  pheno_list
}

clinical_results$GSE10358_pheno <- scan_eset_pheno("GSE10358", "data/GSE10358/GSE10358_raw.rds")
clinical_results$GSE37642_pheno <- scan_eset_pheno("GSE37642", "data/GSE37642/GSE37642_raw.rds")
clinical_results$GSE12417_pheno <- scan_eset_pheno("GSE12417", "data/GSE12417/GSE12417_raw.rds")

# ═══════════════════════════════════════════════════════
# 保存
# ═══════════════════════════════════════════════════════
cat("\n─── 保存中间结果 ───\n")
saveRDS(clinical_results,
        file.path(out_data_dir, "phaseA_clinical_intermediate.rds"))
cat(sprintf("  ✓ phaseA_clinical_intermediate.rds 保存\n"))

cat("\n============================================================\n")
cat("✅ Phase A Step 2 (v2) 完成\n\n")
cat("已完成:\n")
cat("  ✓ TARGET_Val4: age, gender, cyto_risk (无 FAB)\n")
cat("  ✓ TCGA_Val3:   age, gender, FAB, cyto_risk\n")
cat("  ⏳ GEO 3队列:  pheno 已扫描, 待写 parse 规则\n\n")
cat("下一步: 看 GEO :ch1 列输出, 写 phaseA_extract_geo.R 解析\n")
cat("============================================================\n")

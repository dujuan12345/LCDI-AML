# ============================================================
# phaseA_extract_geo_v2.R
# 修复:
#   GSE37642 ESet3 (GPL97) 缺 runx1 相关列 -> data.frame 行数不一致
#   用 safe_get() 兜底返回 NA 向量
# ============================================================

setwd("D:/26_01_AML/AML_Lactylation_PCD")
suppressPackageStartupMessages(library(Biobase))

cat("============================================================\n")
cat("Phase A Step 3 (v2): GEO 队列临床解析\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

out_data_dir <- "data/processed/mime/clean"

# ─────────────────────────────────────────────
# 工具
# ─────────────────────────────────────────────

# 安全取列: 如果列不存在, 返回 NA 长度=n 的向量
safe_get <- function(df, col, n = nrow(df), default = NA) {
  if (col %in% colnames(df)) {
    return(df[[col]])
  }
  return(rep(default, n))
}

norm_fab <- function(x) {
  result <- rep(NA_character_, length(x))
  if (length(x) == 0) return(result)
  for (i in seq_along(x)) {
    if (is.na(x[i]) || x[i] == "") next
    s <- toupper(as.character(x[i]))
    m <- regexpr("M[0-7]", s)
    if (!is.na(m) && length(m) == 1 && m > 0) {
      result[i] <- regmatches(s, m); next
    }
    if (grepl("^[0-7]$", s)) {
      result[i] <- paste0("M", s); next
    }
  }
  result
}

classify_karyo <- function(s) {
  if (is.na(s) || s == "") return(NA_character_)
  s <- toupper(s)
  if (grepl("T\\(15.*17\\)|T\\(8.*21\\)|INV\\(16\\)|T\\(16.*16\\)|FAVOR|GOOD|LOW", s)) return("Favorable")
  if (grepl("-5|DEL\\(5|-7|DEL\\(7|MLL|T\\(6.*9\\)|INV\\(3\\)|COMPLEX|MONOSOMY|ADVER|POOR|HIGH|UNFAV", s)) return("Adverse")
  if (grepl("NORMAL|46.*XX|46.*XY|^NK$", s)) return("Intermediate")
  return("Intermediate")
}

# ═══════════════════════════════════════════════════════
# 【1】GSE10358
# ═══════════════════════════════════════════════════════
cat("─── 【1】GSE10358 (GPL570, 304 样本) ───\n")

gse <- readRDS("data/GSE10358/GSE10358_raw.rds")
eset <- if (is.list(gse) && length(gse) > 0) gse[[1]] else gse
pheno <- pData(eset)
n <- nrow(pheno)

g10358 <- data.frame(
  sample_id = safe_get(pheno, "geo_accession", n),
  age       = suppressWarnings(as.numeric(safe_get(pheno, "age:ch1", n))),
  gender    = NA_character_,
  FAB       = norm_fab(safe_get(pheno, "fab:ch1", n)),
  karyotype = safe_get(pheno, "karyotype:ch1", n),
  WBC       = suppressWarnings(as.numeric(safe_get(pheno, "pb wbc@ presentation:ch1", n))),
  bm_blast  = suppressWarnings(as.numeric(safe_get(pheno, "%bm blast:ch1", n))),
  flt3_itd  = safe_get(pheno, "flt3 itd:ch1", n),
  npm1      = safe_get(pheno, "npm1:ch1", n),
  stringsAsFactors = FALSE
)
g10358$cyto_risk <- sapply(g10358$karyotype, classify_karyo)

cat(sprintf("  ✓ age (NA=%d), FAB (NA=%d), karyotype (NA=%d), WBC (NA=%d)\n",
            sum(is.na(g10358$age)), sum(is.na(g10358$FAB)),
            sum(is.na(g10358$karyotype)), sum(is.na(g10358$WBC))))
cat(sprintf("  age 有值 N=%d, FAB 有值 N=%d, karyotype 有值 N=%d\n",
            sum(!is.na(g10358$age)), sum(!is.na(g10358$FAB)),
            sum(!is.na(g10358$karyotype))))
cat("  FAB 分布:\n"); print(table(g10358$FAB, useNA = "ifany"))
cat("  cyto_risk 分布 (从 karyotype):\n")
print(table(g10358$cyto_risk, useNA = "ifany"))

# ═══════════════════════════════════════════════════════
# 【2】GSE37642 (3 ESet)
# ═══════════════════════════════════════════════════════
cat("\n─── 【2】GSE37642 (3 ESet) ───\n")

gse <- readRDS("data/GSE37642/GSE37642_raw.rds")
g37642_list <- list()

for (i in seq_along(gse)) {
  e <- gse[[i]]
  pheno <- pData(e)
  pl <- annotation(e)
  n <- nrow(pheno)
  cat(sprintf("\n  ESet %d (%s, %d 样本):\n", i, pl, n))
  cat(sprintf("    可用 :ch1 列: %s\n",
              paste(grep(":ch1$", colnames(pheno), value = TRUE), collapse = ", ")))
  
  # 用 safe_get 兜底
  df <- data.frame(
    sample_id     = safe_get(pheno, "geo_accession", n),
    age           = suppressWarnings(as.numeric(safe_get(pheno, "age:ch1", n))),
    gender        = NA_character_,
    FAB           = norm_fab(safe_get(pheno, "fab:ch1", n)),
    cyto_risk     = NA_character_,
    runx1_runx1t1 = safe_get(pheno, "runx1-runx1t1_fusion:ch1", n),
    runx1_mut     = safe_get(pheno, "runx1_mutation:ch1", n),
    OS_days       = suppressWarnings(as.numeric(safe_get(pheno, "overall survival (days):ch1", n))),
    OS_status     = NA_integer_,
    platform      = pl,
    stringsAsFactors = FALSE
  )
  
  # life status: dead=1, alive=0
  life_status <- safe_get(pheno, "life status:ch1", n)
  df$OS_status <- ifelse(tolower(life_status) == "dead", 1L,
                  ifelse(tolower(life_status) == "alive", 0L, NA_integer_))
  
  # cyto_risk: 只能从 t(8;21) 推 Favorable
  df$cyto_risk[!is.na(df$runx1_runx1t1) & df$runx1_runx1t1 == "Yes"] <- "Favorable"
  
  cat(sprintf("    age NA=%d / 有值=%d\n",
              sum(is.na(df$age)), sum(!is.na(df$age))))
  cat(sprintf("    FAB NA=%d / 有值=%d\n",
              sum(is.na(df$FAB)), sum(!is.na(df$FAB))))
  cat(sprintf("    OS NA=%d / 有值=%d\n",
              sum(is.na(df$OS_days)), sum(!is.na(df$OS_days))))
  cat(sprintf("    RUNX1-RUNX1T1 = Yes: %d\n",
              sum(df$runx1_runx1t1 == "Yes", na.rm = TRUE)))
  
  g37642_list[[paste0("ESet", i, "_", pl)]] <- df
}

g37642_all <- do.call(rbind, lapply(g37642_list, function(x) {
  x[, c("sample_id", "age", "gender", "FAB", "cyto_risk")]
}))
g37642_all <- g37642_all[!duplicated(g37642_all$sample_id), ]
cat(sprintf("\n  GSE37642 合并去重: %d 例 (3 ESet 取并集)\n", nrow(g37642_all)))

# ═══════════════════════════════════════════════════════
# 【3】GSE12417 - parse from column names
# ═══════════════════════════════════════════════════════
cat("\n─── 【3】GSE12417 (NK only, 3 ESet) ───\n")

gse <- readRDS("data/GSE12417/GSE12417_raw.rds")

parse_gse12417 <- function(pheno) {
  n <- nrow(pheno)
  result <- data.frame(
    sample_id = safe_get(pheno, "geo_accession", n),
    age       = NA_real_,
    gender    = NA_character_,
    FAB       = NA_character_,
    cyto_risk = "Intermediate",  # 全 NK
    OS_days   = NA_real_,
    OS_status = NA_integer_,
    stringsAsFactors = FALSE
  )
  
  # GSE12417 关键: characteristics_ch1 列里通常含 'normal karyotype (xxx) FAB Mx; age =yy years; OS = zz days; status (0=alive/1=dead) = ?'
  # 或者 :ch1 列名本身带信息
  
  text_cols <- intersect(c("title", "source_name_ch1", "description",
                           "characteristics_ch1"),
                         colnames(pheno))
  ch_cols <- grep(":ch1$", colnames(pheno), value = TRUE)
  
  for (i in seq_len(n)) {
    parts <- character(0)
    
    # 拼所有 text 列
    for (cn in text_cols) {
      v <- pheno[i, cn]
      if (!is.na(v) && v != "") parts <- c(parts, as.character(v))
    }
    
    # 加上 :ch1 列名 + 值
    for (cn in ch_cols) {
      v <- pheno[i, cn]
      if (!is.na(v) && v != "") {
        parts <- c(parts, paste0(cn, "=", v))
      }
    }
    
    s <- paste(parts, collapse = " | ")
    
    # FAB
    m <- regmatches(s, regexpr("FAB\\s+M[0-7]", s, ignore.case = TRUE))
    if (length(m) > 0) {
      result$FAB[i] <- regmatches(m, regexpr("M[0-7]", m, ignore.case = TRUE))
    }
    
    # age
    m <- regmatches(s, regexpr("age\\s*=\\s*\\d+\\s*years", s, ignore.case = TRUE))
    if (length(m) > 0) {
      a <- regmatches(m, regexpr("\\d+", m))
      if (length(a) > 0) result$age[i] <- as.numeric(a)
    }
    
    # OS days
    m <- regmatches(s, regexpr("OS\\s*=\\s*\\d+\\s*days", s, ignore.case = TRUE))
    if (length(m) > 0) {
      o <- regmatches(m, regexpr("\\d+", m))
      if (length(o) > 0) result$OS_days[i] <- as.numeric(o)
    }
    
    # status (0=alive/1=dead)
    m <- regmatches(s, regexpr("status[^=|]*=\\s*[01]", s, ignore.case = TRUE))
    if (length(m) > 0) {
      st <- regmatches(m[1], regexpr("[01]\\s*$", m[1]))
      if (length(st) > 0) result$OS_status[i] <- as.integer(trimws(st))
    }
  }
  
  return(result)
}

g12417_list <- list()
for (i in seq_along(gse)) {
  e <- gse[[i]]
  pheno <- pData(e)
  pl <- annotation(e)
  cat(sprintf("\n  ESet %d (%s, %d 样本):\n", i, pl, nrow(pheno)))
  
  df <- parse_gse12417(pheno)
  df$platform <- pl
  
  cat(sprintf("    age NA=%d / 有值=%d\n",
              sum(is.na(df$age)), sum(!is.na(df$age))))
  cat(sprintf("    FAB NA=%d / 有值=%d\n",
              sum(is.na(df$FAB)), sum(!is.na(df$FAB))))
  cat(sprintf("    OS NA=%d / 有值=%d\n",
              sum(is.na(df$OS_days)), sum(!is.na(df$OS_days))))
  cat("    FAB 分布:\n")
  print(table(df$FAB, useNA = "ifany"))
  
  g12417_list[[paste0("ESet", i, "_", pl)]] <- df
}

g12417_all <- do.call(rbind, lapply(g12417_list, function(x) {
  x[, c("sample_id", "age", "gender", "FAB", "cyto_risk")]
}))
g12417_all <- g12417_all[!duplicated(g12417_all$sample_id), ]
cat(sprintf("\n  GSE12417 合并去重: %d 例\n", nrow(g12417_all)))

# ═══════════════════════════════════════════════════════
# 【4】保存
# ═══════════════════════════════════════════════════════
cat("\n─── 【4】保存 ───\n")

geo_clinical <- list(
  GSE10358 = g10358,
  GSE37642 = g37642_all,
  GSE12417 = g12417_all
)

saveRDS(geo_clinical, file.path(out_data_dir, "phaseA_geo_clinical.rds"))
cat(sprintf("  ✓ phaseA_geo_clinical.rds 保存\n"))

# ═══════════════════════════════════════════════════════
# 总览
# ═══════════════════════════════════════════════════════
cat("\n════════════════════════════════════════════\n")
cat("✅ Phase A Step 3 (v2) 完成 - 临床变量提取总览\n")
cat("════════════════════════════════════════════\n\n")

prev <- readRDS(file.path(out_data_dir, "phaseA_clinical_intermediate.rds"))
target <- prev$TARGET_Val4
tcga   <- prev$TCGA_Val3

cat(sprintf("%-12s %5s %5s %5s %5s    %s\n",
            "Cohort", "N", "age", "FAB", "cyto", "备注"))
cat(strrep("-", 75), "\n")
cat(sprintf("%-12s %5d %5d %5d %5d    %s\n",
            "TARGET_Val4", nrow(target),
            sum(!is.na(target$age)), sum(!is.na(target$FAB)),
            sum(!is.na(target$cyto_risk)),
            "无 FAB (儿童AML)"))
cat(sprintf("%-12s %5d %5d %5d %5d    %s\n",
            "TCGA_Val3", nrow(tcga),
            sum(!is.na(tcga$age)), sum(!is.na(tcga$FAB)),
            sum(!is.na(tcga$cyto_risk)),
            "FAB+cyto 都有"))
cat(sprintf("%-12s %5d %5d %5d %5d    %s\n",
            "GSE10358", nrow(g10358),
            sum(!is.na(g10358$age)), sum(!is.na(g10358$FAB)),
            sum(!is.na(g10358$cyto_risk)),
            "FAB全, karyo少 (304样本中只 24 有 karyo)"))
cat(sprintf("%-12s %5d %5d %5d %5d    %s\n",
            "GSE37642", nrow(g37642_all),
            sum(!is.na(g37642_all$age)), sum(!is.na(g37642_all$FAB)),
            sum(!is.na(g37642_all$cyto_risk)),
            "FAB全, cyto 仅 t(8;21)"))
cat(sprintf("%-12s %5d %5d %5d %5d    %s\n",
            "GSE12417", nrow(g12417_all),
            sum(!is.na(g12417_all$age)), sum(!is.na(g12417_all$FAB)),
            sum(!is.na(g12417_all$cyto_risk)),
            "全 NK karyotype"))

cat("\n下一步: phaseA_align_to_cohorts.R\n")
cat("        把 GSE10358/GSE37642/GSE12417 临床表对齐到 5 队列 sample_id\n")
cat("============================================================\n")

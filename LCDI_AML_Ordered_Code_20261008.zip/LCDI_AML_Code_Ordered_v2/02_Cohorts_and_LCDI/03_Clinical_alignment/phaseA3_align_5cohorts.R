# ============================================================
# phaseA_align_to_cohorts.R
# Phase A Step 4: 把临床变量对齐到 5 队列的 sample_id
#
# 5 队列 sample_id 格式:
#   GPL96_Train     - GSE37642/GSE12417 合并, sample_id = GSMxxxxxx
#   GPL570_Val1     - GSE37642 GPL570 + GSE10358 GPL570, sample_id = GSMxxxxxx
#   GSE10358_Val2   - GSE10358 子集, sample_id = GSMxxxxxx
#   TCGA_Val3       - sample_id = TCGA-AB-XXXX (12位?)
#   TARGET_Val4     - sample_id = TARGET-20-XXXXXX
#
# 临床源:
#   phaseA_geo_clinical.rds      (GSE10358, GSE37642, GSE12417)
#   phaseA_clinical_intermediate.rds (TARGET_Val4, TCGA_Val3)
#
# 输出: 每个队列的 surv 表新增 age/gender/FAB/cyto_risk 字段
#       保存 B_cohort_data_5cohorts_clinical.rds
# ============================================================

setwd("D:/26_01_AML/AML_Lactylation_PCD")

cat("============================================================\n")
cat("Phase A Step 4: 临床变量对齐到 5 队列\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

out_data_dir <- "data/processed/mime/clean"

# ─────────────────────────────────────────────
# 加载数据
# ─────────────────────────────────────────────
B_data <- readRDS(file.path(out_data_dir, "B_cohort_data_5cohorts.rds"))
geo_clin <- readRDS(file.path(out_data_dir, "phaseA_geo_clinical.rds"))
prev <- readRDS(file.path(out_data_dir, "phaseA_clinical_intermediate.rds"))

cat("── 已加载\n")
cat(sprintf("  B_data: %d 队列\n", length(B_data)))
cat(sprintf("  GEO 临床: %s\n", paste(names(geo_clin), collapse = ", ")))
cat(sprintf("  其他: %s\n",
            paste(names(prev)[sapply(prev, is.data.frame)], collapse = ", ")))

# ─────────────────────────────────────────────
# 诊断: 看 5 队列的 surv 表 sample_id 格式
# ─────────────────────────────────────────────
cat("\n── 5 队列 sample_id 格式诊断 ──\n")
for (cn in names(B_data)) {
  s <- B_data[[cn]]$surv
  id_cols <- intersect(c("sample_id", "geo_accession", "case_id", "patient_id"),
                       colnames(s))
  
  cat(sprintf("\n  %s (N=%d):\n", cn, nrow(s)))
  cat(sprintf("    surv 列: %s\n", paste(colnames(s), collapse = ", ")))
  if (length(id_cols) > 0) {
    for (ic in id_cols) {
      cat(sprintf("    %s 示例: %s\n", ic,
                  paste(head(s[[ic]], 3), collapse = ", ")))
    }
  } else {
    cat(sprintf("    行名示例: %s\n",
                paste(head(rownames(s), 3), collapse = ", ")))
  }
}

# ─────────────────────────────────────────────
# 同时看 expr 矩阵列名 (有时 sample_id 在列名不在 surv)
# ─────────────────────────────────────────────
cat("\n── 5 队列 expr 矩阵列名格式 ──\n")
for (cn in names(B_data)) {
  co <- B_data[[cn]]
  expr <- co$expr_full %||% co$expr_raw %||% co$expr_5
  if (!is.null(expr)) {
    cat(sprintf("  %s expr 列名示例: %s\n", cn,
                paste(head(colnames(expr), 3), collapse = ", ")))
  }
}

`%||%` <- function(a, b) if (!is.null(a)) a else b

# ─────────────────────────────────────────────
# 对齐策略:
#   TARGET_Val4: surv 已有 sample_id (case_id格式)
#   TCGA_Val3: sample_id = TCGA-AB-XXXX
#   GSE10358_Val2 / GPL570_Val1 / GPL96_Train: GSMxxxx
# ─────────────────────────────────────────────

cat("\n\n══════════════════════════════════════════════\n")
cat("开始对齐\n")
cat("══════════════════════════════════════════════\n")

# 辅助: 合并临床到 surv 表
merge_clinical <- function(surv_df, clin_df, id_col_surv, id_col_clin,
                           vars = c("age", "gender", "FAB", "cyto_risk")) {
  # 对齐
  ids_surv <- surv_df[[id_col_surv]]
  matched <- match(ids_surv, clin_df[[id_col_clin]])
  
  for (v in vars) {
    if (v %in% colnames(clin_df)) {
      surv_df[[v]] <- clin_df[[v]][matched]
    } else {
      surv_df[[v]] <- NA
    }
  }
  
  n_matched <- sum(!is.na(matched))
  list(df = surv_df, n_matched = n_matched, n_total = length(ids_surv))
}

# ═══════════════════════════════════════════════════════
# 【1】TARGET_Val4 - 直接从 intermediate 取
# ═══════════════════════════════════════════════════════
cat("\n── 【1】TARGET_Val4 ──\n")
target_clin <- prev$TARGET_Val4
surv <- B_data$TARGET_Val4$surv

cat(sprintf("  surv N=%d, 临床 N=%d\n", nrow(surv), nrow(target_clin)))
cat(sprintf("  surv sample_id 示例: %s\n",
            paste(head(surv$sample_id, 3), collapse = ", ")))
cat(sprintf("  临床 sample_id 示例: %s\n",
            paste(head(target_clin$sample_id, 3), collapse = ", ")))

res <- merge_clinical(surv, target_clin, "sample_id", "sample_id",
                      vars = c("age", "gender", "FAB", "cyto_risk",
                               "FLT3", "NPM1", "CEBPA"))
cat(sprintf("  ✓ 匹配 %d / %d\n", res$n_matched, res$n_total))

# 覆盖原 age/gender (之前已有, 但用 target_clin 更规范)
new_surv <- res$df
cat(sprintf("  新 surv 列: %s\n", paste(colnames(new_surv), collapse = ", ")))
B_data$TARGET_Val4$surv <- new_surv

cat("  age 分布:\n")
print(summary(new_surv$age))
cat("  cyto_risk 分布:\n")
print(table(new_surv$cyto_risk, useNA = "ifany"))

# ═══════════════════════════════════════════════════════
# 【2】TCGA_Val3 - TCGA-AB-XXXX
# ═══════════════════════════════════════════════════════
cat("\n── 【2】TCGA_Val3 ──\n")
tcga_clin <- prev$TCGA_Val3
surv <- B_data$TCGA_Val3$surv

cat(sprintf("  surv N=%d, 临床 N=%d\n", nrow(surv), nrow(tcga_clin)))

# TCGA surv 表可能没 sample_id 列, 要看怎么存的
if (!"sample_id" %in% colnames(surv)) {
  # 从 rownames 取
  if (!is.null(rownames(surv)) && !all(grepl("^\\d+$", rownames(surv)))) {
    surv$sample_id <- rownames(surv)
    cat("    从 rownames 取 sample_id\n")
  } else {
    # 从 expr 列名取
    expr <- B_data$TCGA_Val3$expr_raw %||% B_data$TCGA_Val3$expr_full
    if (!is.null(expr) && ncol(expr) == nrow(surv)) {
      surv$sample_id <- colnames(expr)
      cat("    从 expr 列名取 sample_id\n")
    }
  }
}

if ("sample_id" %in% colnames(surv)) {
  cat(sprintf("  surv sample_id 示例: %s\n",
              paste(head(surv$sample_id, 3), collapse = ", ")))
  cat(sprintf("  临床 sample_id 示例: %s\n",
              paste(head(tcga_clin$sample_id, 3), collapse = ", ")))
  
  # TCGA 常见: surv 是 TCGA-AB-XXXX-03A-XX-XX 全格式, 临床只到 TCGA-AB-XXXX 12位
  # 需要截断
  surv$sample_id_short <- substr(surv$sample_id, 1, 12)
  
  res <- merge_clinical(surv, tcga_clin, "sample_id_short", "sample_id",
                        vars = c("age", "gender", "FAB", "cyto_risk"))
  n_match_short <- res$n_matched
  cat(sprintf("  ✓ 12位截断匹配: %d / %d\n", n_match_short, res$n_total))
  
  if (n_match_short == 0) {
    # 尝试不截断
    res <- merge_clinical(surv, tcga_clin, "sample_id", "sample_id",
                          vars = c("age", "gender", "FAB", "cyto_risk"))
    cat(sprintf("  ✓ 全长匹配: %d / %d\n", res$n_matched, res$n_total))
  }
  
  new_surv <- res$df
  if ("sample_id_short" %in% colnames(new_surv)) {
    new_surv$sample_id_short <- NULL
  }
  B_data$TCGA_Val3$surv <- new_surv
  
  cat(sprintf("  age 有值 %d, FAB 有值 %d, cyto_risk 有值 %d\n",
              sum(!is.na(new_surv$age)),
              sum(!is.na(new_surv$FAB)),
              sum(!is.na(new_surv$cyto_risk))))
} else {
  cat("  ❌ 没找到 sample_id 列, 跳过\n")
}

# ═══════════════════════════════════════════════════════
# 【3】GSE10358_Val2 (GSM 直接对齐)
# ═══════════════════════════════════════════════════════
cat("\n── 【3】GSE10358_Val2 ──\n")

g10358 <- geo_clin$GSE10358
surv <- B_data$GSE10358_Val2$surv

cat(sprintf("  surv N=%d, 临床 N=%d\n", nrow(surv), nrow(g10358)))

if (!"sample_id" %in% colnames(surv)) {
  expr <- B_data$GSE10358_Val2$expr_raw %||% B_data$GSE10358_Val2$expr_full
  if (!is.null(expr) && ncol(expr) == nrow(surv)) {
    surv$sample_id <- colnames(expr)
    cat("    从 expr 列名取 sample_id\n")
  } else if (!is.null(rownames(surv)) && any(grepl("^GSM", rownames(surv)))) {
    surv$sample_id <- rownames(surv)
  }
}

if ("sample_id" %in% colnames(surv)) {
  cat(sprintf("  surv sample_id 示例: %s\n",
              paste(head(surv$sample_id, 3), collapse = ", ")))
  
  res <- merge_clinical(surv, g10358, "sample_id", "sample_id",
                        vars = c("age", "gender", "FAB", "cyto_risk",
                                 "karyotype", "WBC", "bm_blast"))
  cat(sprintf("  ✓ 匹配 %d / %d\n", res$n_matched, res$n_total))
  B_data$GSE10358_Val2$surv <- res$df
  
  cat(sprintf("  age 有值 %d, FAB 有值 %d, cyto_risk 有值 %d, WBC 有值 %d\n",
              sum(!is.na(res$df$age)),
              sum(!is.na(res$df$FAB)),
              sum(!is.na(res$df$cyto_risk)),
              sum(!is.na(res$df$WBC))))
} else {
  cat("  ❌ 没找到 sample_id, 跳过\n")
}

# ═══════════════════════════════════════════════════════
# 【4】GPL96_Train - GSE37642 + GSE12417 合并队列
# ═══════════════════════════════════════════════════════
cat("\n── 【4】GPL96_Train ──\n")

# 合并 GSE37642 + GSE12417 临床
combined_clin <- rbind(
  geo_clin$GSE37642[, c("sample_id", "age", "gender", "FAB", "cyto_risk")],
  geo_clin$GSE12417[, c("sample_id", "age", "gender", "FAB", "cyto_risk")]
)
combined_clin <- combined_clin[!duplicated(combined_clin$sample_id), ]
cat(sprintf("  合并 GSE37642+GSE12417: %d 例\n", nrow(combined_clin)))

surv <- B_data$GPL96_Train$surv
cat(sprintf("  surv N=%d\n", nrow(surv)))

if (!"sample_id" %in% colnames(surv)) {
  expr <- B_data$GPL96_Train$expr_raw %||% B_data$GPL96_Train$expr_full
  if (!is.null(expr) && ncol(expr) == nrow(surv)) {
    surv$sample_id <- colnames(expr)
    cat("    从 expr 列名取 sample_id\n")
  } else if (!is.null(rownames(surv)) && any(grepl("^GSM", rownames(surv)))) {
    surv$sample_id <- rownames(surv)
  }
}

if ("sample_id" %in% colnames(surv)) {
  cat(sprintf("  surv sample_id 示例: %s\n",
              paste(head(surv$sample_id, 3), collapse = ", ")))
  
  res <- merge_clinical(surv, combined_clin, "sample_id", "sample_id",
                        vars = c("age", "gender", "FAB", "cyto_risk"))
  cat(sprintf("  ✓ 匹配 %d / %d\n", res$n_matched, res$n_total))
  B_data$GPL96_Train$surv <- res$df
  
  cat(sprintf("  age 有值 %d, FAB 有值 %d, cyto_risk 有值 %d\n",
              sum(!is.na(res$df$age)),
              sum(!is.na(res$df$FAB)),
              sum(!is.na(res$df$cyto_risk))))
} else {
  cat("  ❌ 没找到 sample_id, 跳过\n")
}

# ═══════════════════════════════════════════════════════
# 【5】GPL570_Val1 - GSE37642 GPL570 + GSE10358 GPL570
# ═══════════════════════════════════════════════════════
cat("\n── 【5】GPL570_Val1 ──\n")
surv <- B_data$GPL570_Val1$surv
cat(sprintf("  surv N=%d\n", nrow(surv)))

if (!"sample_id" %in% colnames(surv)) {
  expr <- B_data$GPL570_Val1$expr_raw %||% B_data$GPL570_Val1$expr_full
  if (!is.null(expr) && ncol(expr) == nrow(surv)) {
    surv$sample_id <- colnames(expr)
    cat("    从 expr 列名取 sample_id\n")
  }
}

if ("sample_id" %in% colnames(surv)) {
  cat(sprintf("  surv sample_id 示例: %s\n",
              paste(head(surv$sample_id, 3), collapse = ", ")))
  
  # GPL570 队列来源: GSE37642_GPL570 (140) + GSE10358 (304), 合并
  combined_gpl570 <- rbind(
    geo_clin$GSE37642[, c("sample_id", "age", "gender", "FAB", "cyto_risk")],
    geo_clin$GSE10358[, c("sample_id", "age", "gender", "FAB", "cyto_risk")]
  )
  combined_gpl570 <- combined_gpl570[!duplicated(combined_gpl570$sample_id), ]
  
  res <- merge_clinical(surv, combined_gpl570, "sample_id", "sample_id",
                        vars = c("age", "gender", "FAB", "cyto_risk"))
  cat(sprintf("  ✓ 匹配 %d / %d\n", res$n_matched, res$n_total))
  B_data$GPL570_Val1$surv <- res$df
  
  cat(sprintf("  age 有值 %d, FAB 有值 %d, cyto_risk 有值 %d\n",
              sum(!is.na(res$df$age)),
              sum(!is.na(res$df$FAB)),
              sum(!is.na(res$df$cyto_risk))))
} else {
  cat("  ❌ 没找到 sample_id, 跳过\n")
}

# ═══════════════════════════════════════════════════════
# 最终总览
# ═══════════════════════════════════════════════════════
cat("\n\n══════════════════════════════════════════════\n")
cat("对齐结果总览\n")
cat("══════════════════════════════════════════════\n\n")

cat(sprintf("%-15s %5s %5s %5s %5s %5s  %s\n",
            "Cohort", "N", "LCDI", "age", "FAB", "cyto", "备注"))
cat(strrep("-", 80), "\n")

for (cn in names(B_data)) {
  s <- B_data[[cn]]$surv
  n_lcdi <- if ("LCDI" %in% colnames(s)) sum(!is.na(s$LCDI)) else 0
  n_age  <- if ("age" %in% colnames(s)) sum(!is.na(s$age)) else 0
  n_fab  <- if ("FAB" %in% colnames(s)) sum(!is.na(s$FAB)) else 0
  n_cyto <- if ("cyto_risk" %in% colnames(s)) sum(!is.na(s$cyto_risk)) else 0
  
  # Nomogram 可用样本
  avail_adult <- if (all(c("LCDI", "age", "FAB") %in% colnames(s))) {
    sum(complete.cases(s[, c("LCDI", "age", "FAB")]))
  } else 0
  avail_ped <- if (all(c("LCDI", "age", "cyto_risk") %in% colnames(s))) {
    sum(complete.cases(s[, c("LCDI", "age", "cyto_risk")]))
  } else 0
  
  remark <- sprintf("成人3变量:%d / 儿童3变量:%d", avail_adult, avail_ped)
  
  cat(sprintf("%-15s %5d %5d %5d %5d %5d  %s\n",
              cn, nrow(s), n_lcdi, n_age, n_fab, n_cyto, remark))
}

# 保存
saveRDS(B_data, file.path(out_data_dir, "B_cohort_data_5cohorts_clinical.rds"))
cat(sprintf("\n✓ B_cohort_data_5cohorts_clinical.rds 已保存\n"))

cat("\n============================================================\n")
cat("✅ Phase A 完成\n\n")
cat("下一步:\n")
cat("  Phase B Step 1: 多变量 Cox (LCDI + age + FAB) 在 GPL96_Train 建模\n")
cat("  Phase B Step 2: rms 包构建 Nomogram\n")
cat("  Phase B Step 3: Calibration + DCA\n")
cat("  Phase B Step 4: TARGET 儿童 Nomogram\n")
cat("============================================================\n")

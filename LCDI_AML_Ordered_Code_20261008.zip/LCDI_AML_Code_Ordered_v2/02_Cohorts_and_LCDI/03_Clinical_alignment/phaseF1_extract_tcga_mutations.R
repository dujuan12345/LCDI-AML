# ============================================================
# phaseF1_extract_tcga_mutations.R
# 从 TCGA-LAML cBioPortal MAF 提取 FLT3/NPM1/CEBPA 突变
# 合并到 TCGA_Val3 surv
# ============================================================

setwd("D:/26_01_AML/AML_Lactylation_PCD")

suppressPackageStartupMessages({
  library(data.table)
})

cat("============================================================\n")
cat("Phase F Step 1: 提取 TCGA 突变\n")
cat("============================================================\n\n")

# ─────────────────────────────────────────────
# 加载
# ─────────────────────────────────────────────
maf_path <- "data/TCGA/TCGAbiolinks/raw/laml_tcga_pan_can_atlas_2018/data_mutations.txt"
clin_path <- "data/TCGA/TCGAbiolinks/raw/laml_tcga_pan_can_atlas_2018/data_clinical_patient.txt"
sample_path <- "data/TCGA/TCGAbiolinks/raw/laml_tcga_pan_can_atlas_2018/data_clinical_sample.txt"

cat("── 加载 cBioPortal MAF ──\n")
maf <- fread(maf_path, sep = "\t", header = TRUE,
             skip = 0, fill = TRUE, quote = "")
cat(sprintf("  MAF: %d 行 × %d 列\n", nrow(maf), ncol(maf)))
cat(sprintf("  列: %s\n", paste(head(colnames(maf), 15), collapse = ", ")))

# 关键列: Hugo_Symbol, Tumor_Sample_Barcode, Variant_Classification
target_genes <- c("FLT3", "NPM1", "CEBPA")
maf_target <- maf[Hugo_Symbol %in% target_genes, 
                  .(Hugo_Symbol, Tumor_Sample_Barcode,
                    Variant_Classification)]

cat(sprintf("\n  目标基因突变记录: %d\n", nrow(maf_target)))
cat("  分布:\n")
print(table(maf_target$Hugo_Symbol))

# ─────────────────────────────────────────────
# 过滤非沉默突变 (排除 Silent/Intron 等)
# ─────────────────────────────────────────────
nonsilent <- c("Missense_Mutation", "Nonsense_Mutation", "Frame_Shift_Del",
               "Frame_Shift_Ins", "Splice_Site", "In_Frame_Del",
               "In_Frame_Ins", "Translation_Start_Site",
               "Nonstop_Mutation", "Targeted_Region",
               "Initiator_Codon", "Splice_Region")

maf_nonsilent <- maf_target[Variant_Classification %in% nonsilent]
cat(sprintf("\n  Non-silent 突变: %d\n", nrow(maf_nonsilent)))

# 每个 sample 每个基因 = 1 (有/无突变)
maf_nonsilent[, sample_short := substr(Tumor_Sample_Barcode, 1, 12)]

mut_table <- dcast(maf_nonsilent[, .(sample_short, Hugo_Symbol)],
                   sample_short ~ Hugo_Symbol,
                   value.var = "Hugo_Symbol",
                   fun.aggregate = function(x) as.integer(length(x) > 0))

cat(sprintf("\n  突变表: %d 样本\n", nrow(mut_table)))
cat("  阳性数:\n")
for (g in target_genes) {
  if (g %in% colnames(mut_table)) {
    cat(sprintf("    %s: %d\n", g, sum(mut_table[[g]], na.rm = TRUE)))
  }
}

# ─────────────────────────────────────────────
# 合并到 TCGA_Val3 surv
# ─────────────────────────────────────────────
cat("\n── 合并到 TCGA_Val3 surv ──\n")
B_data <- readRDS("data/processed/mime/clean/B_cohort_data_5cohorts_clinical.rds")
tcga_surv <- B_data$TCGA_Val3$surv

# TCGA sample_id 是 TCGA-AB-2803-03, 截 12 字符 = TCGA-AB-2803
tcga_surv$sample_short <- substr(tcga_surv$sample_id, 1, 12)
cat(sprintf("  TCGA_Val3 N=%d, 短ID示例: %s\n",
            nrow(tcga_surv),
            paste(head(tcga_surv$sample_short, 3), collapse = ", ")))

# match 加突变
for (g in target_genes) {
  if (g %in% colnames(mut_table)) {
    tcga_surv[[g]] <- mut_table[[g]][match(tcga_surv$sample_short,
                                            mut_table$sample_short)]
    # match 不到的填 0 (假设这些样本测过 MAF 但没该基因突变)
    # 但需先验证: MAF 里所有 sample 是否在 mut_table 里
    sequenced <- unique(maf$Tumor_Sample_Barcode)
    sequenced_short <- unique(substr(sequenced, 1, 12))
    in_seq <- tcga_surv$sample_short %in% sequenced_short
    
    # 测过但 mut_table 没记录 = 0; 没测过 = NA
    tcga_surv[[g]][is.na(tcga_surv[[g]]) & in_seq] <- 0
  }
}

# 检查
cat(sprintf("\n  合并后 TCGA_Val3:\n"))
for (g in target_genes) {
  if (g %in% colnames(tcga_surv)) {
    tab <- table(tcga_surv[[g]], useNA = "always")
    cat(sprintf("    %s: 0=%d, 1=%d, NA=%d\n",
                g,
                tab[as.character(0)] %||% 0,
                tab[as.character(1)] %||% 0,
                tab[NA] %||% 0))
  }
}

`%||%` <- function(a, b) if (!is.null(a)) a else b

# 移除临时列
tcga_surv$sample_short <- NULL

# ─────────────────────────────────────────────
# 也提取 ELN risk (data_clinical_patient.txt 通常有)
# ─────────────────────────────────────────────
cat("\n── 提取 ELN risk ──\n")
clin <- fread(clin_path, sep = "\t", skip = 4, fill = TRUE, quote = "")
cat(sprintf("  Patient clinical: %d × %d\n", nrow(clin), ncol(clin)))
cat(sprintf("  关键列: %s\n",
            paste(grep("RISK|ELN|CYTO|MUTATION",
                       colnames(clin), value = TRUE, ignore.case = TRUE),
                  collapse = ", ")))

# 找 ELN / Cytogenetic risk 列
eln_col <- intersect(c("RISK_CYTOGENETICS", "RISK_GROUP",
                        "Cytogenetic_Risk", "ELN_RISK"),
                      colnames(clin))[1]

if (!is.na(eln_col)) {
  cat(sprintf("\n  用列: %s\n", eln_col))
  cat("  分布:\n")
  print(table(clin[[eln_col]], useNA = "always"))
  
  # patient ID 列
  pid_col <- intersect(c("PATIENT_ID", "Patient_ID"), colnames(clin))[1]
  
  if (!is.na(pid_col)) {
    tcga_surv$ELN_risk <- clin[[eln_col]][match(
      substr(tcga_surv$sample_id, 1, 12),
      clin[[pid_col]]
    )]
    
    cat(sprintf("\n  TCGA_Val3 加入 ELN_risk:\n"))
    print(table(tcga_surv$ELN_risk, useNA = "always"))
  }
}

# ─────────────────────────────────────────────
# 保存
# ─────────────────────────────────────────────
B_data$TCGA_Val3$surv <- tcga_surv

saveRDS(B_data, "data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds")
cat(sprintf("\n  ✓ 保存: B_cohort_data_5cohorts_clinical_v2.rds\n"))

# 详细 TCGA 表
write.csv(tcga_surv, "data/processed/mime/clean/TCGA_Val3_surv_with_mutations.csv",
          row.names = FALSE)
cat(sprintf("  ✓ TCGA_Val3_surv_with_mutations.csv\n"))

cat("\n══════════════════════════════════════════════\n")
cat("最终 TCGA_Val3 字段:\n")
cat(sprintf("  %s\n", paste(colnames(tcga_surv), collapse = ", ")))
cat("\n下一步:\n")
cat("  source('phaseF2_nomogram_with_mutations.R')\n")
cat("══════════════════════════════════════════════\n")

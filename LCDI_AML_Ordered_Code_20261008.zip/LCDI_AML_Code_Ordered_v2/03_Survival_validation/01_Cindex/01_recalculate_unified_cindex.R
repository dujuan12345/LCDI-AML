options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages(library(survival))

project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/cindex_nomogram_reconciliation_20260902_v1")
input_rds <- file.path(project_root, "AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds")
formula_path <- file.path(project_root, "AML_Lactylation_PCD/results/tables/mime/clean/E_LCDI_formula.csv")
external_dir <- file.path(project_root, "_codex_audit/external_survival_validation_20260804_v1/prepared_inputs")
log_path <- file.path(out_dir, "01_run.log")
B <- 1000L
base_seed <- 20260902L

genes <- c("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")
expected_beta <- c(CREB1 = 0.0925, SLC16A4 = -0.0636, GPX4 = -0.0721, CASP1 = -0.0106, MPO = -0.2095)

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
}

log_con <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
sink(log_con, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

cat("Unified within-cohort gene-z LCDI reconciliation\n")
cat("Started:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Bootstrap:", B, "per cohort; base seed", base_seed, "\n")

formula_df <- read.csv(formula_path, check.names = FALSE)
stopifnot(all(c("Gene", "Coefficient") %in% names(formula_df)))
formula_beta <- setNames(as.numeric(formula_df$Coefficient), toupper(formula_df$Gene))
stopifnot(all(genes %in% names(formula_beta)))
stopifnot(max(abs(formula_beta[genes] - expected_beta[genes])) < 5e-5)
beta <- expected_beta

z1 <- function(x) {
  x <- as.numeric(x)
  s <- stats::sd(x)
  if (!is.finite(s) || s <= 0) stop("Cannot standardize zero-variance gene")
  (x - mean(x)) / s
}

safe_c <- function(time, status, score) {
  as.numeric(survival::concordance(Surv(time, status) ~ score, reverse = TRUE)$concordance)
}

prepare_saved <- function(obj, cohort_name) {
  expr_field <- c("expr_5", "expr_full", "expr_raw")
  expr_field <- expr_field[vapply(expr_field, function(x) !is.null(obj[[x]]), logical(1))][1]
  if (is.na(expr_field)) stop(cohort_name, ": missing expression matrix")
  expr <- as.matrix(obj[[expr_field]])
  rownames(expr) <- toupper(rownames(expr))
  stopifnot(all(genes %in% rownames(expr)))
  expr <- t(expr[genes, , drop = FALSE])
  surv <- as.data.frame(obj$surv)
  surv_id <- if ("sample_id" %in% names(surv)) as.character(surv$sample_id) else rownames(surv)
  idx <- match(rownames(expr), surv_id)
  if (anyNA(idx) || anyDuplicated(idx)) {
    if (nrow(expr) != nrow(surv)) stop(cohort_name, ": cannot align expression and survival")
    idx <- seq_len(nrow(surv))
  }
  surv <- surv[idx, , drop = FALSE]
  time_col <- intersect(c("os_days", "OS_time", "OS.time", "time", "os_time"), names(surv))[1]
  status_col <- intersect(c("os_status", "OS_status", "OS", "status"), names(surv))[1]
  if (is.na(time_col) || is.na(status_col)) stop(cohort_name, ": missing survival columns")
  data.frame(
    cohort = cohort_name,
    sample_id = rownames(expr),
    subject_id = rownames(expr),
    time = as.numeric(surv[[time_col]]),
    status = as.integer(surv[[status_col]]),
    expr,
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

prepare_external <- function(cohort_name) {
  path <- file.path(external_dir, paste0(cohort_name, "_survival_input.tsv"))
  d <- read.delim(path, check.names = FALSE)
  stopifnot(all(c("sample_id", "subject_id", "time_days", "status", genes) %in% names(d)))
  data.frame(
    cohort = cohort_name,
    sample_id = as.character(d$sample_id),
    subject_id = as.character(d$subject_id),
    time = as.numeric(d$time_days),
    status = as.integer(d$status),
    d[, genes, drop = FALSE],
    stringsAsFactors = FALSE,
    check.names = FALSE
  )
}

score_cohort <- function(d) {
  valid <- is.finite(d$time) & d$time > 0 & d$status %in% c(0L, 1L)
  for (g in genes) valid <- valid & is.finite(as.numeric(d[[g]]))
  d <- d[valid, , drop = FALSE]
  if (nrow(d) < 20L || sum(d$status == 1L) < 5L) stop(unique(d$cohort), ": insufficient survival data")
  for (g in genes) d[[paste0("z_", g)]] <- z1(d[[g]])
  zmat <- as.matrix(d[, paste0("z_", genes), drop = FALSE])
  colnames(zmat) <- genes
  d$LCDI <- as.numeric(zmat %*% beta[genes])
  d$MPO_risk <- beta["MPO"] * d$z_MPO
  d$LCDI_per_sd <- z1(d$LCDI)
  d$MPO_risk_per_sd <- z1(d$MPO_risk)
  d
}

metric_one <- function(d, score_col) {
  score <- d[[score_col]]
  fit <- coxph(Surv(time, status) ~ score, data = d, ties = "efron", x = TRUE)
  s <- summary(fit)
  ci <- exp(confint(fit))[1, ]
  ph <- tryCatch(cox.zph(fit)$table[1, "p"], error = function(e) NA_real_)
  data.frame(
    score = score_col,
    cindex = safe_c(d$time, d$status, score),
    hr_per_sd = unname(exp(coef(fit))[1]),
    hr_ci_low = unname(ci[1]),
    hr_ci_high = unname(ci[2]),
    wald_p = unname(s$coefficients[1, "Pr(>|z|)"]),
    ph_p = ph,
    stringsAsFactors = FALSE
  )
}

B_data <- readRDS(input_rds)
saved_names <- c("GPL96_Train", "GPL570_Val1", "GSE10358_Val2", "TCGA_Val3", "TARGET_Val4")
external_names <- c("GSE71014", "GSE106291", "BeatAML2")
all_data <- c(
  setNames(lapply(saved_names, function(x) score_cohort(prepare_saved(B_data[[x]], x))), saved_names),
  setNames(lapply(external_names, function(x) score_cohort(prepare_external(x))), external_names)
)

qc_rows <- list()
metric_rows <- list()
score_rows <- list()
boot_rows <- list()
boot_summary_rows <- list()

for (i in seq_along(all_data)) {
  nm <- names(all_data)[i]
  d <- all_data[[i]]
  cat(sprintf("%s: N=%d, events=%d\n", nm, nrow(d), sum(d$status == 1L)))
  qc_rows[[i]] <- data.frame(
    cohort = nm,
    n = nrow(d),
    events = sum(d$status == 1L),
    censored = sum(d$status == 0L),
    duplicate_sample_ids = sum(duplicated(d$sample_id)),
    duplicate_subject_ids = sum(duplicated(d$subject_id)),
    remaining_na = sum(!complete.cases(d[, c("time", "status", genes, "LCDI", "MPO_risk")])),
    lcdi_mean = mean(d$LCDI),
    lcdi_sd = sd(d$LCDI),
    stringsAsFactors = FALSE
  )
  m1 <- metric_one(d, "LCDI_per_sd")
  m2 <- metric_one(d, "MPO_risk_per_sd")
  m1$cohort <- nm
  m2$cohort <- nm
  metric_rows[[i]] <- rbind(m1, m2)
  score_rows[[i]] <- d[, c("cohort", "sample_id", "subject_id", "time", "status", paste0("z_", genes), "LCDI", "LCDI_per_sd", "MPO_risk", "MPO_risk_per_sd")]

  set.seed(base_seed + i)
  reps <- vector("list", B)
  for (b in seq_len(B)) {
    idx <- sample.int(nrow(d), nrow(d), replace = TRUE)
    db <- d[idx, , drop = FALSE]
    c_lcdi <- tryCatch(safe_c(db$time, db$status, db$LCDI), error = function(e) NA_real_)
    c_mpo <- tryCatch(safe_c(db$time, db$status, db$MPO_risk), error = function(e) NA_real_)
    reps[[b]] <- data.frame(
      cohort = nm,
      iteration = b,
      unique_records = length(unique(idx)),
      events = sum(db$status == 1L),
      cindex_lcdi = c_lcdi,
      cindex_mpo = c_mpo,
      delta_c = c_lcdi - c_mpo,
      stringsAsFactors = FALSE
    )
  }
  br <- do.call(rbind, reps)
  boot_rows[[i]] <- br
  qfun <- function(x) as.numeric(quantile(x[is.finite(x)], c(0.025, 0.5, 0.975)))
  q_l <- qfun(br$cindex_lcdi)
  q_m <- qfun(br$cindex_mpo)
  q_d <- qfun(br$delta_c)
  boot_summary_rows[[i]] <- data.frame(
    cohort = nm,
    bootstrap_requested = B,
    bootstrap_valid = sum(complete.cases(br[, c("cindex_lcdi", "cindex_mpo", "delta_c")])),
    lcdi_boot_mean = mean(br$cindex_lcdi, na.rm = TRUE),
    lcdi_p025 = q_l[1], lcdi_p500 = q_l[2], lcdi_p975 = q_l[3],
    mpo_boot_mean = mean(br$cindex_mpo, na.rm = TRUE),
    mpo_p025 = q_m[1], mpo_p500 = q_m[2], mpo_p975 = q_m[3],
    delta_boot_mean = mean(br$delta_c, na.rm = TRUE),
    delta_p025 = q_d[1], delta_p500 = q_d[2], delta_p975 = q_d[3],
    proportion_delta_gt_0 = mean(br$delta_c > 0, na.rm = TRUE),
    stringsAsFactors = FALSE
  )
}

qc <- do.call(rbind, qc_rows)
metrics <- do.call(rbind, metric_rows)
metrics <- metrics[, c("cohort", "score", "cindex", "hr_per_sd", "hr_ci_low", "hr_ci_high", "wald_p", "ph_p")]
scores <- do.call(rbind, score_rows)
boots <- do.call(rbind, boot_rows)
boot_summary <- do.call(rbind, boot_summary_rows)

write_tsv(qc, file.path(out_dir, "01_cohort_qc.tsv"))
write_tsv(metrics, file.path(out_dir, "01_unified_cindex_metrics.tsv"))
write_tsv(scores, file.path(out_dir, "01_patient_scores.tsv"))
write_tsv(boots, file.path(out_dir, "01_paired_bootstrap_iterations.tsv"))
write_tsv(boot_summary, file.path(out_dir, "01_paired_lcdi_mpo_bootstrap.tsv"))
write_tsv(data.frame(
  parameter = c("score_method", "genes", "coefficients", "bootstrap_B", "base_seed", "formula_refit", "gene_reselection"),
  value = c(
    "within_cohort_gene_z_then_frozen_beta",
    paste(genes, collapse = ";"),
    paste(sprintf("%s=%+.4f", genes, beta[genes]), collapse = ";"),
    B, base_seed, "FALSE", "FALSE"
  )
), file.path(out_dir, "01_method_record.tsv"))
writeLines(capture.output(sessionInfo()), file.path(out_dir, "01_session_info.txt"))
writeLines(c(
  "status\tpassed",
  paste0("completed\t", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
  paste0("cohorts\t", length(all_data)),
  paste0("bootstrap_per_cohort\t", B)
), file.path(out_dir, "01_run_status.tsv"))

cat("\nMetrics:\n")
print(as.data.frame(metrics))
cat("\nPaired bootstrap summary:\n")
print(as.data.frame(boot_summary))
cat("Completed:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")

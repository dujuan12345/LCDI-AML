options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages(library(survival))

root <- "D:/26_01_AML"
out_dir <- file.path(root, "_codex_audit/cindex_nomogram_reconciliation_20260902_v1")
data_path <- file.path(root, "AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds")
formula_path <- file.path(root, "AML_Lactylation_PCD/results/tables/mime/clean/E_LCDI_formula.csv")
within_score_path <- file.path(out_dir, "01_patient_scores.tsv")
B_boot <- 1000L
seed <- 20260904L

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
}
z1 <- function(x) as.numeric((x - mean(x)) / sd(x))
safe_c <- function(time, status, score) {
  as.numeric(concordance(Surv(time, status) ~ score, reverse = TRUE)$concordance)
}

obj <- readRDS(data_path)$TCGA_Val3
form <- read.csv(formula_path, check.names = FALSE)
genes <- toupper(as.character(form$Gene))
beta <- setNames(as.numeric(form$Coefficient), genes)
mu <- setNames(as.numeric(form$Mean_GPL96), genes)
sigma <- setNames(as.numeric(form$SD_GPL96), genes)
expr <- as.matrix(if (!is.null(obj$expr_5)) obj$expr_5 else if (!is.null(obj$expr_full)) obj$expr_full else obj$expr_raw)
rownames(expr) <- toupper(rownames(expr))
expr <- expr[genes, , drop = FALSE]
surv <- as.data.frame(obj$surv)
surv_ids <- as.character(surv$sample_id)
idx <- match(colnames(expr), surv_ids)
if (anyNA(idx) || anyDuplicated(idx)) stop("TCGA alignment failed")
surv <- surv[idx, , drop = FALSE]
valid <- is.finite(as.numeric(surv$OS.time)) & as.numeric(surv$OS.time) > 0 & as.integer(surv$OS) %in% c(0L, 1L)
for (g in genes) valid <- valid & is.finite(expr[g, ])
expr <- expr[, valid, drop = FALSE]
d <- data.frame(
  sample_id = colnames(expr),
  time = as.numeric(surv$OS.time[valid]),
  status = as.integer(surv$OS[valid]),
  stringsAsFactors = FALSE
)
scaled <- sweep(sweep(expr, 1, mu[genes], "-"), 1, sigma[genes], "/")
d$LCDI <- colSums(sweep(scaled, 1, beta[genes], "*"))
d$LCDI_per_sd <- z1(d$LCDI)
d$MPO_risk <- beta["MPO"] * scaled["MPO", ]
d$MPO_risk_per_sd <- z1(d$MPO_risk)

fit <- coxph(Surv(time, status) ~ LCDI_per_sd, data = d)
ci <- exp(confint(fit))[1, ]
metric <- data.frame(
  cohort = "TCGA_Val3",
  score_method = "GPL96_training_mean_sd_then_frozen_beta",
  n = nrow(d),
  events = sum(d$status),
  cindex = safe_c(d$time, d$status, d$LCDI),
  hr_per_sd = exp(coef(fit))[1],
  hr_ci_low = ci[1],
  hr_ci_high = ci[2],
  wald_p = summary(fit)$coefficients[1, "Pr(>|z|)"],
  ph_p = cox.zph(fit)$table[1, "p"],
  stringsAsFactors = FALSE
)

set.seed(seed)
reps <- vector("list", B_boot)
for (b in seq_len(B_boot)) {
  ii <- sample.int(nrow(d), nrow(d), replace = TRUE)
  db <- d[ii, , drop = FALSE]
  c_l <- safe_c(db$time, db$status, db$LCDI)
  c_m <- safe_c(db$time, db$status, db$MPO_risk)
  reps[[b]] <- data.frame(
    iteration = b,
    unique_records = length(unique(ii)),
    events = sum(db$status),
    cindex_lcdi = c_l,
    cindex_mpo = c_m,
    delta_c = c_l - c_m,
    stringsAsFactors = FALSE
  )
}
reps <- do.call(rbind, reps)
q <- function(x) as.numeric(quantile(x, c(0.025, 0.5, 0.975)))
ql <- q(reps$cindex_lcdi)
qm <- q(reps$cindex_mpo)
qd <- q(reps$delta_c)
summary <- data.frame(
  cohort = "TCGA_Val3",
  bootstrap_requested = B_boot,
  bootstrap_valid = sum(complete.cases(reps)),
  lcdi_boot_mean = mean(reps$cindex_lcdi),
  lcdi_p025 = ql[1], lcdi_p500 = ql[2], lcdi_p975 = ql[3],
  mpo_boot_mean = mean(reps$cindex_mpo),
  mpo_p025 = qm[1], mpo_p500 = qm[2], mpo_p975 = qm[3],
  delta_boot_mean = mean(reps$delta_c),
  delta_p025 = qd[1], delta_p500 = qd[2], delta_p975 = qd[3],
  proportion_delta_gt_0 = mean(reps$delta_c > 0),
  seed = seed,
  stringsAsFactors = FALSE
)

within_scores <- read.delim(within_score_path, check.names = FALSE)
target_scores <- within_scores[within_scores$cohort == "TARGET_Val4", c("cohort", "sample_id", "LCDI_per_sd"), drop = FALSE]
target_scores$score_method <- "TARGET_within_cohort_gene_z_then_frozen_beta"
tcga_scores <- data.frame(
  cohort = "TCGA_Val3",
  sample_id = d$sample_id,
  LCDI_per_sd = d$LCDI_per_sd,
  score_method = "GPL96_training_mean_sd_then_frozen_beta",
  stringsAsFactors = FALSE
)
final_scores <- rbind(tcga_scores, target_scores)

write_tsv(metric, file.path(out_dir, "10_tcga_training_scale_metric.tsv"))
write_tsv(reps, file.path(out_dir, "10_tcga_training_scale_bootstrap_iterations.tsv"))
write_tsv(summary, file.path(out_dir, "10_tcga_training_scale_bootstrap_summary.tsv"))
write_tsv(final_scores, file.path(out_dir, "10_final_tcga_target_scores.tsv"))
writeLines(capture.output(sessionInfo()), file.path(out_dir, "10_session_info.txt"))
writeLines(c("status\tpassed", paste0("completed\t", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"))), file.path(out_dir, "10_run_status.tsv"))

print(as.data.frame(metric))
print(as.data.frame(summary))

# LCDI vs MPO incremental prognostic analysis
# Theme framing: LCDI is a lactylation x programmed-cell-death informed score.
# This analysis tests whether the fixed non-MPO component adds information beyond MPO;
# it does not redefine or refit the published LCDI formula.

options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(survival)
  library(timeROC)
})

project_root <- "D:/26_01_AML"
audit_root <- file.path(project_root, "_codex_audit/lcdi_mpo_increment_20260803_v1")
run_mode <- Sys.getenv("RUN_MODE", unset = "final")
run_tag <- Sys.getenv("RUN_TAG", unset = run_mode)
score_mode <- Sys.getenv("SCORE_MODE", unset = "operational")
B <- as.integer(Sys.getenv("BOOT_B", unset = "1000"))
base_seed <- as.integer(Sys.getenv("BOOT_SEED", unset = "20260803"))
stopifnot(run_mode %in% c("smoke_test", "final"), score_mode %in% c("operational", "intended", "hybrid"),
          grepl("^[A-Za-z0-9_.-]+$", run_tag), B >= 10L)

input_cohort <- file.path(project_root, "AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds")
input_fit <- file.path(project_root, "AML_Lactylation_PCD/data/processed/mime/clean/E_cox_5gene_fit.rds")
stopifnot(file.exists(input_cohort), file.exists(input_fit))

out_dir <- file.path(audit_root, run_tag)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
sentinel <- file.path(out_dir, "run_status.tsv")
if (file.exists(sentinel)) stop("Output already exists: ", sentinel)

log_con <- file(file.path(out_dir, "run.log"), open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
sink(log_con, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

cat("LCDI-MPO incremental analysis\n")
cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Run mode:", run_mode, "\nRun tag:", run_tag, "\nScore mode:", score_mode,
    "\nB:", B, "\nSeed:", base_seed, "\n")
cat("Input cohort:", input_cohort, "\nInput fit:", input_fit, "\n\n")

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", row.names = FALSE, col.names = TRUE,
              quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}

z1 <- function(x) {
  x <- as.numeric(x)
  s <- sd(x, na.rm = TRUE)
  if (!is.finite(s) || s <= 0) stop("Cannot standardize predictor")
  as.numeric((x - mean(x, na.rm = TRUE)) / s)
}

safe_cindex <- function(time, status, score) {
  ok <- is.finite(time) & !is.na(status) & is.finite(score)
  if (sum(ok) < 10L || sum(status[ok] == 1L) < 2L) return(NA_real_)
  tryCatch(
    as.numeric(concordance(Surv(time[ok], status[ok]) ~ score[ok], reverse = TRUE)$concordance),
    error = function(e) NA_real_
  )
}

safe_auc <- function(data, score, times_eval = c(365, 1095, 1825)) {
  ok <- is.finite(data$time) & !is.na(data$status) & is.finite(score)
  if (sum(ok) < 20L || sum(data$status[ok] == 1L) < 2L) return(rep(NA_real_, length(times_eval)))
  tryCatch(
    suppressWarnings(timeROC(T = data$time[ok], delta = data$status[ok], marker = score[ok],
                             cause = 1, weighting = "marginal", times = times_eval,
                             iid = FALSE)$AUC),
    error = function(e) rep(NA_real_, length(times_eval))
  )
}

fit_cox <- function(formula, data) {
  tryCatch({
    fit <- coxph(formula, data = data, ties = "efron", x = TRUE, y = TRUE,
                 model = TRUE, singular.ok = FALSE)
    if (any(!is.finite(coef(fit)))) stop("non-finite coefficient")
    fit
  }, error = function(e) structure(list(message = conditionMessage(e)), class = "fit_error"))
}

safe_lp <- function(fit, newdata) {
  tryCatch({
    p <- as.numeric(predict(fit, newdata = newdata, type = "lp", reference = "zero"))
    if (length(p) != nrow(newdata) || any(!is.finite(p))) stop("invalid prediction")
    p
  }, error = function(e) rep(NA_real_, nrow(newdata)))
}

extract_lrt_p <- function(fit0, fit1) {
  a <- tryCatch(anova(fit0, fit1, test = "LRT"), error = function(e) NULL)
  if (is.null(a)) return(NA_real_)
  pcol <- grep("P\\(", colnames(a), value = TRUE)
  if (!length(pcol)) pcol <- grep("Pr", colnames(a), value = TRUE)
  if (!length(pcol)) return(NA_real_)
  as.numeric(a[nrow(a), pcol[1]])
}

cox_terms <- function(fit, cohort, model) {
  s <- summary(fit)$coefficients
  data.frame(
    cohort = cohort, model = model, term = rownames(s),
    coefficient = s[, "coef"], hazard_ratio = s[, "exp(coef)"],
    standard_error = s[, "se(coef)"], z = s[, "z"],
    p_value = s[, "Pr(>|z|)"], row.names = NULL, check.names = FALSE
  )
}

B_data <- readRDS(input_cohort)
fit5 <- readRDS(input_fit)
beta <- coef(fit5)
genes <- names(beta)
non_mpo_genes <- setdiff(genes, "MPO")
stopifnot(identical(genes, c("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")))

gpl96_expr <- B_data$GPL96_Train$expr_raw[genes, , drop = FALSE]
mu_train <- rowMeans(gpl96_expr)
sd_train <- apply(gpl96_expr, 1, sd)

prepare_cohort <- function(cohort_name) {
  obj <- B_data[[cohort_name]]
  target <- identical(cohort_name, "TARGET_Val4")
  expr <- if (target) obj$expr_5 else obj$expr_raw[genes, , drop = FALSE]
  expr <- expr[genes, , drop = FALSE]
  surv <- obj$surv
  idx <- match(colnames(expr), surv$sample_id)
  if (anyNA(idx)) stop(cohort_name, ": expression-survival sample mismatch")
  surv <- surv[idx, , drop = FALSE]
  if (!identical(as.character(surv$sample_id), colnames(expr))) stop(cohort_name, ": order mismatch")

  # Operational score chain in the current five-cohort object:
  # phase2b_fix_lcdi_direction.R overwrote the first four cohorts using expr_raw,
  # while TARGET retained internally z-scored expr_5. Reconstruct that exact chain
  # as the primary analysis, and retain the originally intended GPL96-standardized
  # score as a sensitivity analysis.
  expr_operational <- expr
  if (target) {
    expr_intended_z <- expr
  } else {
    expr_intended_z <- sweep(expr, 1, mu_train[genes], "-")
    expr_intended_z <- sweep(expr_intended_z, 1, sd_train[genes], "/")
  }
  lcdi_calc <- as.numeric(t(expr_operational) %*% beta[genes])
  mpo_component <- as.numeric(expr_operational["MPO", ] * beta["MPO"])
  non_mpo_component <- as.numeric(t(expr_operational[non_mpo_genes, , drop = FALSE]) %*% beta[non_mpo_genes])
  lcdi_intended <- as.numeric(t(expr_intended_z) %*% beta[genes])
  mpo_intended <- as.numeric(expr_intended_z["MPO", ] * beta["MPO"])
  non_mpo_intended <- as.numeric(t(expr_intended_z[non_mpo_genes, , drop = FALSE]) %*% beta[non_mpo_genes])
  time <- if (target) as.numeric(surv$os_days) else as.numeric(surv$OS.time)
  status <- if (target) as.integer(surv$os_status) else as.integer(surv$OS)
  saved <- as.numeric(surv$LCDI)
  data <- data.frame(
    sample_id = surv$sample_id,
    time = time,
    status = status,
    LCDI_saved = saved,
    LCDI_calc = lcdi_calc,
    LCDI_z = z1(saved),
    LCDI_intended_z = z1(lcdi_intended),
    MPO_expression = as.numeric(expr["MPO", ]),
    MPO_component = mpo_component,
    MPO_risk_z = z1(mpo_component),
    nonMPO_component = non_mpo_component,
    nonMPO_risk_z = z1(non_mpo_component),
    MPO_intended_risk_z = z1(mpo_intended),
    nonMPO_intended_risk_z = z1(non_mpo_intended),
    stringsAsFactors = FALSE
  )
  if (score_mode == "intended" || (score_mode == "hybrid" && cohort_name == "GPL96_Train")) {
    data$LCDI_z <- data$LCDI_intended_z
    data$MPO_risk_z <- data$MPO_intended_risk_z
    data$nonMPO_risk_z <- data$nonMPO_intended_risk_z
  }
  rownames(data) <- data$sample_id
  list(data = data, surv = surv, expr_operational = expr_operational,
       max_abs_lcdi_diff = max(abs(saved - lcdi_calc)),
       max_abs_decomposition_diff = max(abs(lcdi_calc - mpo_component - non_mpo_component)),
       max_abs_operational_vs_intended = max(abs(lcdi_calc - lcdi_intended)))
}

cohorts <- names(B_data)
prepared <- setNames(lapply(cohorts, prepare_cohort), cohorts)

cohort_qc <- do.call(rbind, lapply(cohorts, function(cohort) {
  d <- prepared[[cohort]]$data
  data.frame(
    cohort = cohort, n = nrow(d), events = sum(d$status == 1L),
    censored = sum(d$status == 0L), duplicate_sample_id = sum(duplicated(d$sample_id)),
    invalid_time = sum(!is.finite(d$time) | d$time <= 0), remaining_na = sum(is.na(d)),
    max_abs_saved_vs_rebuilt_LCDI = prepared[[cohort]]$max_abs_lcdi_diff,
    max_abs_component_decomposition_error = prepared[[cohort]]$max_abs_decomposition_diff,
    max_abs_operational_vs_intended_LCDI = prepared[[cohort]]$max_abs_operational_vs_intended,
    cor_LCDI_MPO_risk = cor(d$LCDI_z, d$MPO_risk_z),
    cor_LCDI_nonMPO_risk = cor(d$LCDI_z, d$nonMPO_risk_z),
    stringsAsFactors = FALSE
  )
}))
write_tsv(cohort_qc, file.path(out_dir, "cohort_qc_and_score_reconstruction.tsv"))

expected_n <- c(GPL96_Train = 580L, GPL570_Val1 = 215L, GSE10358_Val2 = 91L, TCGA_Val3 = 149L, TARGET_Val4 = 1944L)
expected_events <- c(GPL96_Train = 411L, GPL570_Val1 = 145L, GSE10358_Val2 = 45L, TCGA_Val3 = 92L, TARGET_Val4 = 685L)
stopifnot(all(cohort_qc$n == expected_n[cohort_qc$cohort]),
          all(cohort_qc$events == expected_events[cohort_qc$cohort]),
          all(cohort_qc$duplicate_sample_id == 0L), all(cohort_qc$remaining_na == 0L),
          max(cohort_qc$max_abs_saved_vs_rebuilt_LCDI) < 1e-10,
          max(cohort_qc$max_abs_component_decomposition_error) < 1e-12)

five_metrics <- list()
five_terms <- list()
five_nested <- list()
five_boot_detail <- list()
five_boot_summary <- list()

for (j in seq_along(cohorts)) {
  cohort <- cohorts[j]
  d <- prepared[[cohort]]$data
  cat("Five-cohort fixed-score analysis:", cohort, "\n")
  fit_mpo <- fit_cox(Surv(time, status) ~ MPO_risk_z, d)
  fit_lcdi <- fit_cox(Surv(time, status) ~ LCDI_z, d)
  fit_non <- fit_cox(Surv(time, status) ~ nonMPO_risk_z, d)
  fit_joint <- fit_cox(Surv(time, status) ~ MPO_risk_z + nonMPO_risk_z, d)
  stopifnot(!inherits(fit_mpo, "fit_error"), !inherits(fit_lcdi, "fit_error"),
            !inherits(fit_non, "fit_error"), !inherits(fit_joint, "fit_error"))
  models_now <- list(MPO = fit_mpo, LCDI = fit_lcdi, nonMPO = fit_non, MPO_plus_nonMPO = fit_joint)
  scores_now <- list(MPO = d$MPO_risk_z, LCDI = d$LCDI_z, nonMPO = d$nonMPO_risk_z,
                     MPO_plus_nonMPO = safe_lp(fit_joint, d))
  for (m in names(models_now)) {
    fit <- models_now[[m]]
    score <- scores_now[[m]]
    five_metrics[[length(five_metrics) + 1L]] <- data.frame(
      cohort = cohort, model = m, n = nrow(d), events = sum(d$status),
      c_index = safe_cindex(d$time, d$status, score), AIC = AIC(fit),
      loglik = as.numeric(logLik(fit)), stringsAsFactors = FALSE
    )
    five_terms[[length(five_terms) + 1L]] <- cox_terms(fit, cohort, m)
  }
  ph <- tryCatch(cox.zph(fit_joint), error = function(e) NULL)
  five_nested[[length(five_nested) + 1L]] <- data.frame(
    cohort = cohort, comparison = "MPO_plus_nonMPO_vs_MPO",
    lrt_p = extract_lrt_p(fit_mpo, fit_joint),
    delta_AIC = AIC(fit_joint) - AIC(fit_mpo),
    joint_global_PH_p = if (!is.null(ph)) ph$table["GLOBAL", "p"] else NA_real_,
    stringsAsFactors = FALSE
  )

  set.seed(base_seed + j * 1000L)
  rows <- vector("list", B)
  for (b in seq_len(B)) {
    if (b == 1L || b %% 200L == 0L || b == B) cat(cohort, "fixed-score bootstrap", b, "/", B, "\n")
    idx <- sample.int(nrow(d), nrow(d), replace = TRUE)
    db <- d[idx, , drop = FALSE]
    c_lcdi <- safe_cindex(db$time, db$status, db$LCDI_z)
    c_mpo <- safe_cindex(db$time, db$status, db$MPO_risk_z)
    c_lcdi_intended <- safe_cindex(db$time, db$status, db$LCDI_intended_z)
    c_mpo_intended <- safe_cindex(db$time, db$status, db$MPO_intended_risk_z)
    rows[[b]] <- data.frame(cohort = cohort, iteration = b,
                            unique_records = length(unique(idx)), events = sum(db$status),
                            C_LCDI = c_lcdi, C_MPO = c_mpo, delta_C_LCDI_minus_MPO = c_lcdi - c_mpo,
                            C_LCDI_intended = c_lcdi_intended, C_MPO_intended = c_mpo_intended,
                            delta_C_intended_LCDI_minus_MPO = c_lcdi_intended - c_mpo_intended)
  }
  detail <- do.call(rbind, rows)
  five_boot_detail[[length(five_boot_detail) + 1L]] <- detail
  x <- detail$delta_C_LCDI_minus_MPO[is.finite(detail$delta_C_LCDI_minus_MPO)]
  xi <- detail$delta_C_intended_LCDI_minus_MPO[is.finite(detail$delta_C_intended_LCDI_minus_MPO)]
  five_boot_summary[[length(five_boot_summary) + 1L]] <- data.frame(
    cohort = cohort, bootstrap_requested = B, bootstrap_valid = length(x),
    apparent_delta_C = safe_cindex(d$time, d$status, d$LCDI_z) - safe_cindex(d$time, d$status, d$MPO_risk_z),
    bootstrap_mean_delta_C = mean(x), p025 = quantile(x, .025), p500 = quantile(x, .5), p975 = quantile(x, .975),
    proportion_delta_C_gt_0 = mean(x > 0),
    intended_bootstrap_valid = length(xi),
    intended_apparent_delta_C = safe_cindex(d$time, d$status, d$LCDI_intended_z) - safe_cindex(d$time, d$status, d$MPO_intended_risk_z),
    intended_bootstrap_mean_delta_C = mean(xi), intended_p025 = quantile(xi, .025),
    intended_p500 = quantile(xi, .5), intended_p975 = quantile(xi, .975),
    intended_proportion_delta_C_gt_0 = mean(xi > 0), stringsAsFactors = FALSE
  )
}

five_metrics <- do.call(rbind, five_metrics)
five_terms <- do.call(rbind, five_terms)
five_nested <- do.call(rbind, five_nested)
five_boot_detail <- do.call(rbind, five_boot_detail)
five_boot_summary <- do.call(rbind, five_boot_summary)
write_tsv(five_metrics, file.path(out_dir, "five_cohort_apparent_metrics.tsv"))
write_tsv(five_terms, file.path(out_dir, "five_cohort_cox_terms.tsv"))
write_tsv(five_nested, file.path(out_dir, "five_cohort_nested_increment_tests.tsv"))
write_tsv(five_boot_detail, file.path(out_dir, "five_cohort_fixed_score_bootstrap_iterations.tsv"))
write_tsv(five_boot_summary, file.path(out_dir, "five_cohort_fixed_score_deltaC_summary.tsv"))

prepare_clinical <- function(cohort) {
  p <- prepared[[cohort]]
  s <- p$surv
  score <- p$data
  if (cohort == "TCGA_Val3") {
    d <- data.frame(
      sample_id = s$sample_id, time = as.numeric(s$OS.time), status = as.integer(s$OS),
      age = as.numeric(s$age), FAB = factor(s$FAB),
      cyto = factor(s$cyto_risk, levels = c("Favorable", "Intermediate", "Adverse")),
      FLT3 = factor(s$FLT3, levels = c(0, 1), labels = c("WT", "Mut")),
      NPM1 = factor(s$NPM1, levels = c(0, 1), labels = c("WT", "Mut")),
      CEBPA = factor(s$CEBPA, levels = c(0, 1), labels = c("WT", "Mut")),
      LCDI_z = score$LCDI_z, MPO_risk_z = score$MPO_risk_z,
      nonMPO_risk_z = score$nonMPO_risk_z
    )
    d <- d[complete.cases(d) & d$time > 0, , drop = FALSE]
    counts <- table(d$FAB)
    rare <- names(counts)[counts < 5L]
    d$FAB <- as.character(d$FAB)
    d$FAB[d$FAB %in% rare] <- "Other"
    d$FAB <- factor(d$FAB)
  } else {
    d <- data.frame(
      sample_id = s$sample_id, time = as.numeric(s$os_days), status = as.integer(s$os_status),
      age = as.numeric(s$age),
      cyto = factor(s$cyto_risk, levels = c("Favorable", "Intermediate", "Adverse")),
      FLT3 = factor(s$FLT3, levels = c(0, 1), labels = c("WT", "Mut")),
      NPM1 = factor(s$NPM1, levels = c(0, 1), labels = c("WT", "Mut")),
      CEBPA = factor(s$CEBPA, levels = c(0, 1), labels = c("WT", "Mut")),
      LCDI_z = score$LCDI_z, MPO_risk_z = score$MPO_risk_z,
      nonMPO_risk_z = score$nonMPO_risk_z
    )
    d <- d[complete.cases(d) & d$time > 0, , drop = FALSE]
  }
  rownames(d) <- d$sample_id
  d
}

tcga <- prepare_clinical("TCGA_Val3")
target <- prepare_clinical("TARGET_Val4")
stopifnot(nrow(tcga) == 145L, sum(tcga$status) == 89L,
          nrow(target) == 1857L, sum(target$status) == 672L,
          !anyDuplicated(tcga$sample_id), !anyDuplicated(target$sample_id))

clinical_qc <- data.frame(
  cohort = c("TCGA", "TARGET"), n = c(nrow(tcga), nrow(target)),
  events = c(sum(tcga$status), sum(target$status)),
  duplicate_sample_id = c(sum(duplicated(tcga$sample_id)), sum(duplicated(target$sample_id))),
  remaining_na = c(sum(is.na(tcga)), sum(is.na(target)))
)
write_tsv(clinical_qc, file.path(out_dir, "clinical_complete_case_qc.tsv"))

clinical_models <- list(
  TCGA = list(
    CLIN = Surv(time, status) ~ age + FAB + cyto + FLT3 + NPM1 + CEBPA,
    CLIN_MPO = Surv(time, status) ~ age + FAB + cyto + FLT3 + NPM1 + CEBPA + MPO_risk_z,
    CLIN_LCDI = Surv(time, status) ~ age + FAB + cyto + FLT3 + NPM1 + CEBPA + LCDI_z,
    CLIN_MPO_NONMPO = Surv(time, status) ~ age + FAB + cyto + FLT3 + NPM1 + CEBPA + MPO_risk_z + nonMPO_risk_z
  ),
  TARGET = list(
    CLIN = Surv(time, status) ~ age + cyto + FLT3 + NPM1 + CEBPA,
    CLIN_MPO = Surv(time, status) ~ age + cyto + FLT3 + NPM1 + CEBPA + MPO_risk_z,
    CLIN_LCDI = Surv(time, status) ~ age + cyto + FLT3 + NPM1 + CEBPA + LCDI_z,
    CLIN_MPO_NONMPO = Surv(time, status) ~ age + cyto + FLT3 + NPM1 + CEBPA + MPO_risk_z + nonMPO_risk_z
  )
)

model_defs <- do.call(rbind, lapply(names(clinical_models), function(cohort) {
  do.call(rbind, lapply(names(clinical_models[[cohort]]), function(model) data.frame(
    cohort = cohort, model = model,
    formula = paste(deparse(clinical_models[[cohort]][[model]]), collapse = " "),
    analysis_set = "Clinical full-model complete cases; identical across models",
    theme_interpretation = if (model == "CLIN_MPO_NONMPO") "Tests non-MPO fixed component beyond MPO" else "",
    stringsAsFactors = FALSE
  )))
}))
write_tsv(model_defs, file.path(out_dir, "clinical_model_definitions.tsv"))

metric_names <- c("C_index", "AUC_1yr", "AUC_3yr", "AUC_5yr")
metric_cols <- c(C_index = "optimism_C", AUC_1yr = "optimism_AUC_1yr",
                 AUC_3yr = "optimism_AUC_3yr", AUC_5yr = "optimism_AUC_5yr")

apparent_one <- function(data, formula, cohort, model) {
  fit <- fit_cox(formula, data)
  if (inherits(fit, "fit_error")) stop(cohort, " ", model, ": ", fit$message)
  lp <- safe_lp(fit, data)
  auc <- as.numeric(safe_auc(data, lp))
  list(
    fit = fit,
    metrics = setNames(as.numeric(c(safe_cindex(data$time, data$status, lp),
                auc[1], auc[2], auc[3])),
                c("C_index", "AUC_1yr", "AUC_3yr", "AUC_5yr")),
    terms = cox_terms(fit, cohort, model)
  )
}

bootstrap_model <- function(data, formula, cohort, model, indices, apparent) {
  rows <- vector("list", length(indices))
  for (b in seq_along(indices)) {
    if (b == 1L || b %% 100L == 0L || b == length(indices)) cat(cohort, model, "bootstrap", b, "/", length(indices), "\n")
    idx <- indices[[b]]
    db <- data[idx, , drop = FALSE]
    fit <- fit_cox(formula, db)
    if (inherits(fit, "fit_error")) {
      rows[[b]] <- data.frame(cohort = cohort, model = model, iteration = b,
                              fit_ok = FALSE, failure_reason = fit$message,
                              optimism_C = NA, optimism_AUC_1yr = NA,
                              optimism_AUC_3yr = NA, optimism_AUC_5yr = NA)
      next
    }
    lp_b <- safe_lp(fit, db); lp_o <- safe_lp(fit, data)
    cb <- safe_cindex(db$time, db$status, lp_b); co <- safe_cindex(data$time, data$status, lp_o)
    ab <- safe_auc(db, lp_b); ao <- safe_auc(data, lp_o)
    opt <- setNames(as.numeric(c(cb - co, ab[1] - ao[1], ab[2] - ao[2], ab[3] - ao[3])),
                    c("optimism_C", "optimism_AUC_1yr", "optimism_AUC_3yr", "optimism_AUC_5yr"))
    ok <- is.finite(opt)
    rows[[b]] <- data.frame(cohort = cohort, model = model, iteration = b,
                            fit_ok = TRUE, failure_reason = if (all(ok)) "" else "one_or_more_metrics_failed",
                            optimism_C = if (ok["optimism_C"]) opt["optimism_C"] else NA,
                            optimism_AUC_1yr = if (ok["optimism_AUC_1yr"]) opt["optimism_AUC_1yr"] else NA,
                            optimism_AUC_3yr = if (ok["optimism_AUC_3yr"]) opt["optimism_AUC_3yr"] else NA,
                            optimism_AUC_5yr = if (ok["optimism_AUC_5yr"]) opt["optimism_AUC_5yr"] else NA)
  }
  detail <- do.call(rbind, rows)
  summary <- do.call(rbind, lapply(metric_names, function(metric) {
    opt <- detail[[metric_cols[metric]]]
    opt <- opt[is.finite(opt)]
    dist <- apparent[metric] - opt
    dist <- dist[is.finite(dist)]
    q <- if (length(dist)) quantile(dist, c(.025, .5, .975)) else rep(NA_real_, 3L)
    data.frame(cohort = cohort, model = model, metric = metric,
               apparent = apparent[metric], bootstrap_requested = length(indices),
               bootstrap_valid = length(opt), bootstrap_failed = length(indices) - length(opt),
               mean_optimism = if (length(opt)) mean(opt) else NA_real_,
               optimism_corrected = if (length(opt)) apparent[metric] - mean(opt) else NA_real_,
               corrected_p025 = q[1], corrected_p500 = q[2],
               corrected_p975 = q[3], stringsAsFactors = FALSE)
  }))
  list(detail = detail, summary = summary)
}

clinical_apparent <- list(); clinical_terms <- list(); clinical_detail <- list(); clinical_summary <- list(); clinical_lrt <- list()
full_fits <- list(TCGA = list(), TARGET = list())

for (j in seq_along(c("TCGA", "TARGET"))) {
  cohort <- c("TCGA", "TARGET")[j]
  d <- if (cohort == "TCGA") tcga else target
  set.seed(base_seed + 10000L + j * 1000L)
  indices <- replicate(B, sample.int(nrow(d), nrow(d), replace = TRUE), simplify = FALSE)
  for (model in names(clinical_models[[cohort]])) {
    app <- apparent_one(d, clinical_models[[cohort]][[model]], cohort, model)
    full_fits[[cohort]][[model]] <- app$fit
    clinical_apparent[[length(clinical_apparent) + 1L]] <- data.frame(
      cohort = cohort, model = model, n = nrow(d), events = sum(d$status),
      C_index = app$metrics["C_index"], AUC_1yr = app$metrics["AUC_1yr"],
      AUC_3yr = app$metrics["AUC_3yr"], AUC_5yr = app$metrics["AUC_5yr"],
      AIC = AIC(app$fit), loglik = as.numeric(logLik(app$fit)), stringsAsFactors = FALSE
    )
    clinical_terms[[length(clinical_terms) + 1L]] <- app$terms
    boot <- bootstrap_model(d, clinical_models[[cohort]][[model]], cohort, model, indices, app$metrics)
    clinical_detail[[length(clinical_detail) + 1L]] <- boot$detail
    clinical_summary[[length(clinical_summary) + 1L]] <- boot$summary
  }
  f <- full_fits[[cohort]]
  clinical_lrt[[length(clinical_lrt) + 1L]] <- rbind(
    data.frame(cohort = cohort, comparison = "CLIN_MPO_vs_CLIN", lrt_p = extract_lrt_p(f$CLIN, f$CLIN_MPO), delta_AIC = AIC(f$CLIN_MPO) - AIC(f$CLIN)),
    data.frame(cohort = cohort, comparison = "CLIN_LCDI_vs_CLIN", lrt_p = extract_lrt_p(f$CLIN, f$CLIN_LCDI), delta_AIC = AIC(f$CLIN_LCDI) - AIC(f$CLIN)),
    data.frame(cohort = cohort, comparison = "CLIN_MPO_NONMPO_vs_CLIN_MPO", lrt_p = extract_lrt_p(f$CLIN_MPO, f$CLIN_MPO_NONMPO), delta_AIC = AIC(f$CLIN_MPO_NONMPO) - AIC(f$CLIN_MPO))
  )
}

clinical_apparent <- do.call(rbind, clinical_apparent)
clinical_terms <- do.call(rbind, clinical_terms)
clinical_detail <- do.call(rbind, clinical_detail)
clinical_summary <- do.call(rbind, clinical_summary)
clinical_lrt <- do.call(rbind, clinical_lrt)

make_comparisons <- function(cohort, summary, detail) {
  pairs <- list(
    c("CLIN_MPO", "CLIN"), c("CLIN_LCDI", "CLIN"),
    c("CLIN_LCDI", "CLIN_MPO"), c("CLIN_MPO_NONMPO", "CLIN_MPO"),
    c("CLIN_MPO_NONMPO", "CLIN_LCDI")
  )
  out <- list()
  for (pair in pairs) {
    hi <- pair[1]; lo <- pair[2]
    dh <- detail[detail$cohort == cohort & detail$model == hi, ]
    dl <- detail[detail$cohort == cohort & detail$model == lo, ]
    z <- merge(dh, dl, by = c("cohort", "iteration"), suffixes = c("_hi", "_lo"))
    for (metric in metric_names) {
      ah <- summary$apparent[summary$cohort == cohort & summary$model == hi & summary$metric == metric]
      al <- summary$apparent[summary$cohort == cohort & summary$model == lo & summary$metric == metric]
      oc <- metric_cols[metric]
      od <- z[[paste0(oc, "_hi")]] - z[[paste0(oc, "_lo")]]
      od <- od[is.finite(od)]
      dist <- (ah - al) - od
      dist <- dist[is.finite(dist)]
      q <- if (length(dist)) quantile(dist, c(.025, .5, .975)) else rep(NA_real_, 3L)
      out[[length(out) + 1L]] <- data.frame(
        cohort = cohort, comparison = paste0(hi, "_minus_", lo), metric = metric,
        apparent_difference = ah - al, paired_bootstrap_valid = length(od),
        optimism_corrected_difference = if (length(od)) (ah - al) - mean(od) else NA_real_,
        corrected_difference_p025 = q[1], corrected_difference_p500 = q[2],
        corrected_difference_p975 = q[3], proportion_corrected_gt_0 = if (length(dist)) mean(dist > 0) else NA_real_,
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, out)
}

clinical_comparisons <- rbind(
  make_comparisons("TCGA", clinical_summary, clinical_detail),
  make_comparisons("TARGET", clinical_summary, clinical_detail)
)

write_tsv(clinical_apparent, file.path(out_dir, "clinical_apparent_metrics.tsv"))
write_tsv(clinical_terms, file.path(out_dir, "clinical_cox_terms.tsv"))
write_tsv(clinical_lrt, file.path(out_dir, "clinical_nested_increment_tests.tsv"))
write_tsv(clinical_detail, file.path(out_dir, "clinical_bootstrap_iterations.tsv"))
write_tsv(clinical_summary, file.path(out_dir, "clinical_optimism_corrected_performance.tsv"))
write_tsv(clinical_comparisons, file.path(out_dir, "clinical_optimism_corrected_comparisons.tsv"))

# Figure 1: fixed LCDI minus fixed MPO C-index across cohorts
draw_delta_forest <- function() {
  x <- five_boot_summary
  ord <- rev(seq_len(nrow(x)))
  short_cohort <- c(GPL96_Train = "GPL96", GPL570_Val1 = "GPL570",
                    GSE10358_Val2 = "GSE10358", TCGA_Val3 = "TCGA", TARGET_Val4 = "TARGET")
  par(mar = c(5, 7, 4, 2) + .1)
  plot(x$apparent_delta_C[ord], seq_along(ord), xlim = range(c(x$p025, x$p975, 0)) + c(-.005, .005),
       ylim = c(.5, length(ord) + .5), pch = 19, xlab = "Delta C-index: LCDI minus MPO", ylab = "",
       yaxt = "n", main = paste(tools::toTitleCase(score_mode), "fixed-score increment"))
  segments(x$p025[ord], seq_along(ord), x$p975[ord], seq_along(ord), lwd = 2)
  abline(v = 0, lty = 2, col = "gray45")
  axis(2, at = seq_along(ord), labels = short_cohort[x$cohort[ord]], las = 1)
  mtext(sprintf("Record-level bootstrap; B=%d", B), side = 3, line = .2, cex = .8)
}
pdf(file.path(out_dir, "Figure_increment_fixed_LCDI_vs_MPO.pdf"), 7.5, 5.5); draw_delta_forest(); dev.off()
png(file.path(out_dir, "Figure_increment_fixed_LCDI_vs_MPO.png"), 1800, 1320, res = 240); draw_delta_forest(); dev.off()

# Figure 2: optimism-corrected clinical C-index increments
draw_clinical_increment <- function() {
  keep <- clinical_comparisons$metric == "C_index" & clinical_comparisons$comparison %in% c(
    "CLIN_MPO_minus_CLIN", "CLIN_LCDI_minus_CLIN", "CLIN_MPO_NONMPO_minus_CLIN_MPO")
  x <- clinical_comparisons[keep, ]
  labs <- c(CLIN_MPO_minus_CLIN = "Clinical + MPO", CLIN_LCDI_minus_CLIN = "Clinical + LCDI",
            CLIN_MPO_NONMPO_minus_CLIN_MPO = "+ Non-MPO after MPO")
  x$label <- labs[x$comparison]
  par(mfrow = c(1, 2), mar = c(5, 7.5, 3, 1), oma = c(0, 0, 2, 0))
  for (cohort in c("TCGA", "TARGET")) {
    z <- x[x$cohort == cohort, ]
    yy <- rev(seq_len(nrow(z)))
    xr <- range(c(z$corrected_difference_p025, z$corrected_difference_p975, 0)) + c(-.003, .003)
    plot(z$optimism_corrected_difference, yy, xlim = xr, ylim = c(.5, nrow(z) + .5), pch = 19,
         xlab = "Corrected delta C-index", ylab = "", yaxt = "n", main = cohort)
    segments(z$corrected_difference_p025, yy, z$corrected_difference_p975, yy, lwd = 2)
    abline(v = 0, lty = 2, col = "gray45")
    axis(2, at = yy, labels = z$label, las = 1, cex.axis = .8)
  }
  mtext(sprintf("Patient bootstrap optimism correction; B=%d", B), outer = TRUE, side = 3, line = -1, cex = .85)
}
pdf(file.path(out_dir, "Figure_clinical_increment_LCDI_MPO.pdf"), 11, 5.8); draw_clinical_increment(); dev.off()
png(file.path(out_dir, "Figure_clinical_increment_LCDI_MPO.png"), 2640, 1392, res = 240); draw_clinical_increment(); dev.off()

saveRDS(list(
  metadata = list(run_mode = run_mode, run_tag = run_tag, score_mode = score_mode, B = B, seed = base_seed, input_cohort = input_cohort,
                  input_fit = input_fit, theme = "lactylation x programmed cell death",
                  formula_refit = FALSE, time_points_days = c(365, 1095, 1825)),
  beta = beta, cohort_qc = cohort_qc, five_metrics = five_metrics,
  five_nested = five_nested, five_boot_summary = five_boot_summary,
  clinical_qc = clinical_qc, clinical_apparent = clinical_apparent,
  clinical_lrt = clinical_lrt, clinical_summary = clinical_summary,
  clinical_comparisons = clinical_comparisons
), file.path(out_dir, "lcdi_mpo_increment_results.rds"))

method <- data.frame(
  field = c("theme", "score_mode", "primary_score_chain", "sensitivity_score_chain", "fixed_formula", "formula_refit", "MPO_test", "nonMPO_test",
            "five_cohort_bootstrap_unit", "clinical_bootstrap_unit", "bootstrap_B", "seed",
            "clinical_models", "time_points_days", "interpretation_boundary", "software"),
  value = c("lactylation x programmed cell death informed candidate score", score_mode,
            if (score_mode == "operational") "current operational object: expr_raw for first four cohorts; internally z-scored expr_5 for TARGET" else if (score_mode == "intended") "formal intended formula: GPL96 mean/SD standardization for first four cohorts; internally z-scored TARGET" else "agreed hybrid: GPL96 uses GPL96-standardized formula; GPL570/GSE10358/TCGA use simplified fixed-coefficient score on existing expression; TARGET retains internal z-score",
            if (score_mode == "operational") "originally intended: GPL96 mean/SD standardization for first four cohorts; internally z-scored TARGET" else if (score_mode == "intended") "current operational object retained only for reconstruction audit" else "intended-all-four and operational-all-four runs retained as implementation sensitivities",
            "exact GPL96 Cox coefficients", "FALSE",
            "fixed MPO coefficient component", "fixed four-gene component tested beyond MPO",
            "analysis record; GPL96/GPL570 are not deduplicated patients", "patient/sample record",
            B, base_seed, "clinical; clinical+MPO; clinical+LCDI; clinical+MPO+nonMPO",
            "365,1095,1825", "Increment is prognostic information, not causal mechanism",
            paste0("R ", getRversion(), "; survival ", packageVersion("survival"), "; timeROC ", packageVersion("timeROC"))),
  stringsAsFactors = FALSE
)
write_tsv(method, file.path(out_dir, "method_record.tsv"))
capture.output(sessionInfo(), file = file.path(out_dir, "session_info.txt"))

status <- data.frame(
  field = c("status", "run_mode", "run_tag", "score_mode", "completed", "bootstrap_B", "five_cohorts",
            "tcga_complete_n_events", "target_complete_n_events", "source_files_modified",
            "existing_results_overwritten", "v18_modified"),
  value = c("passed", run_mode, run_tag, score_mode, format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), B, 5,
            "145/89", "1857/672", 0, 0, 0), stringsAsFactors = FALSE
)
write_tsv(status, sentinel)
cat("\nCompleted:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\nStatus: passed\n")

from __future__ import annotations

import csv
import gzip
import hashlib
import json
import math
import statistics
import sys
from collections import Counter, defaultdict
from datetime import datetime
from pathlib import Path

import openpyxl


PROJECT = Path(r"D:\26_01_AML")
DOWNLOAD_ROOT = PROJECT / "_codex_audit" / "external_cohort_download_20260804_v1" / "downloads"
OUT_ROOT = Path(__file__).resolve().parent
INPUT_DIR = OUT_ROOT / "prepared_inputs"
TARGET_GENES = ("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")
EXPECTED_BETA = {
    "CREB1": 0.0925,
    "SLC16A4": -0.0636,
    "GPX4": -0.0721,
    "CASP1": -0.0106,
    "MPO": -0.2095,
}
FORMULA_PATH = PROJECT / "AML_Lactylation_PCD" / "results" / "tables" / "mime" / "clean" / "E_LCDI_formula.csv"


def sha256(path: Path) -> str:
    digest = hashlib.sha256()
    with path.open("rb") as handle:
        for chunk in iter(lambda: handle.read(8 * 1024 * 1024), b""):
            digest.update(chunk)
    return digest.hexdigest().upper()


def as_float(value) -> float:
    if value is None or str(value).strip() == "":
        return math.nan
    return float(value)


def median(values: list[float]) -> float:
    clean = [v for v in values if math.isfinite(v)]
    return statistics.median(clean) if clean else math.nan


def iqr(values: list[float]) -> float:
    clean = sorted(v for v in values if math.isfinite(v))
    if len(clean) < 4:
        return math.nan
    q = statistics.quantiles(clean, n=4, method="inclusive")
    return q[2] - q[0]


def parse_soft_samples(path: Path) -> list[dict]:
    samples: list[dict] = []
    current: dict | None = None
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line.startswith("^SAMPLE"):
                if current is not None:
                    samples.append(current)
                current = {"gsm": line.split("=", 1)[1].strip(), "characteristics": []}
            elif current is not None and line.startswith("!Sample_title"):
                current["title"] = line.split("=", 1)[1].strip()
            elif current is not None and line.startswith("!Sample_source_name_ch1"):
                current["source"] = line.split("=", 1)[1].strip()
            elif current is not None and line.startswith("!Sample_characteristics_ch1"):
                current["characteristics"].append(line.split("=", 1)[1].strip())
    if current is not None:
        samples.append(current)
    return samples


def characteristic_value(record: dict, prefix: str) -> str | None:
    prefix_lower = prefix.lower()
    for item in record["characteristics"]:
        if item.lower().startswith(prefix_lower):
            return item[len(prefix):].strip()
    return None


def read_series_matrix(path: Path, wanted_probes: set[str] | None = None) -> tuple[list[str], dict[str, list[float]]]:
    sample_ids: list[str] = []
    selected: dict[str, list[float]] = {}
    in_table = False
    header_seen = False
    with gzip.open(path, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        reader = csv.reader(handle, delimiter="\t", quotechar='"')
        for fields in reader:
            if not fields:
                continue
            first = fields[0]
            if first == "!series_matrix_table_begin":
                in_table = True
                continue
            if first == "!series_matrix_table_end":
                break
            if not in_table:
                continue
            if not header_seen:
                if first != "ID_REF":
                    raise ValueError(f"Unexpected Series Matrix header: {first}")
                sample_ids = fields[1:]
                header_seen = True
                continue
            probe = first
            if wanted_probes is not None and probe not in wanted_probes:
                continue
            values = [as_float(v) for v in fields[1:]]
            if len(values) != len(sample_ids):
                raise ValueError(f"Width mismatch for {probe}: {len(values)} vs {len(sample_ids)}")
            selected[probe] = values
    if not sample_ids:
        raise ValueError(f"No matrix table found in {path}")
    return sample_ids, selected


def read_gpl_annotation(path: Path) -> tuple[list[str], dict[str, set[str]]]:
    header: list[str] = []
    symbol_to_probes: dict[str, set[str]] = defaultdict(set)
    in_table = False
    with gzip.open(path, "rt", encoding="utf-8", errors="replace") as handle:
        for raw in handle:
            line = raw.rstrip("\r\n")
            if line == "!platform_table_begin":
                in_table = True
                continue
            if line == "!platform_table_end":
                break
            if not in_table or not line:
                continue
            fields = line.split("\t")
            if not header:
                header = fields
                continue
            row = dict(zip(header, fields))
            probe = row.get("ID", "").strip()
            symbols = {part.strip() for part in row.get("Gene symbol", "").split("///") if part.strip()}
            for symbol in symbols:
                symbol_to_probes[symbol].add(probe)
    return header, symbol_to_probes


def write_tsv(path: Path, rows: list[dict], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fieldnames, delimiter="\t", extrasaction="ignore")
        writer.writeheader()
        writer.writerows(rows)


def validate_frozen_formula() -> list[dict]:
    with FORMULA_PATH.open("r", encoding="utf-8-sig", newline="") as handle:
        rows = list(csv.DictReader(handle))
    observed = {row["Gene"]: float(row["Coefficient"]) for row in rows}
    if set(observed) != set(EXPECTED_BETA):
        raise ValueError(f"Formula genes differ: {observed}")
    for gene, expected in EXPECTED_BETA.items():
        if abs(observed[gene] - expected) > 1e-12:
            raise ValueError(f"Coefficient mismatch {gene}: {observed[gene]} vs {expected}")
    return rows


def prepare_gse71014() -> tuple[list[dict], list[dict], dict]:
    root = DOWNLOAD_ROOT / "GSE71014"
    annotation_path = root / "GPL10558.annot.gz"
    series_path = root / "GSE71014_series_matrix.txt.gz"
    soft_path = root / "GSE71014_family.soft.gz"
    _, symbol_to_probes = read_gpl_annotation(annotation_path)
    gene_probes = {gene: sorted(symbol_to_probes.get(gene, set())) for gene in TARGET_GENES}
    missing = [gene for gene, probes in gene_probes.items() if not probes]
    if missing:
        raise ValueError(f"GSE71014 annotation missing genes: {missing}")
    wanted = set().union(*gene_probes.values())
    sample_ids, probe_values = read_series_matrix(series_path, wanted)
    absent_probes = sorted(wanted - set(probe_values))
    if absent_probes:
        raise ValueError(f"GSE71014 annotated probes absent from matrix: {absent_probes}")

    gene_primary: dict[str, list[float]] = {}
    gene_alt: dict[str, list[float]] = {}
    mapping_rows: list[dict] = []
    for gene in TARGET_GENES:
        probes = gene_probes[gene]
        gene_primary[gene] = [median([probe_values[p][i] for p in probes]) for i in range(len(sample_ids))]
        probe_iqr = {p: iqr(probe_values[p]) for p in probes}
        best_probe = sorted(probes, key=lambda p: (-probe_iqr[p], p))[0]
        gene_alt[gene] = probe_values[best_probe]
        for probe in probes:
            mapping_rows.append(
                {
                    "cohort": "GSE71014",
                    "gene": gene,
                    "probe_or_stable_id": probe,
                    "primary_included": "yes",
                    "sensitivity_selected": "yes" if probe == best_probe else "no",
                    "selection_metric_IQR": probe_iqr[probe],
                }
            )

    clinical = {record["gsm"]: record for record in parse_soft_samples(soft_path)}
    rows: list[dict] = []
    for i, sample_id in enumerate(sample_ids):
        if sample_id not in clinical:
            raise ValueError(f"GSE71014 sample missing clinical: {sample_id}")
        record = clinical[sample_id]
        os_months = as_float(characteristic_value(record, "overall survival (months):"))
        event = int(float(characteristic_value(record, "event (1: dead, 0:alive):")))
        row = {
            "cohort": "GSE71014",
            "sample_id": sample_id,
            "subject_id": sample_id,
            "time_days": os_months * 365.25 / 12,
            "time_original": os_months,
            "time_unit_original": "months",
            "status": event,
            "selection_reason": "all_public_CN_AML_with_complete_OS",
        }
        for gene in TARGET_GENES:
            row[gene] = gene_primary[gene][i]
            row[f"{gene}_alt_highest_IQR_probe"] = gene_alt[gene][i]
        rows.append(row)
    included = [r for r in rows if r["time_days"] > 0 and r["status"] in (0, 1)]
    qc = {
        "public_samples": len(sample_ids),
        "clinical_records": len(clinical),
        "included": len(included),
        "events": sum(r["status"] for r in included),
        "censored": sum(1 - r["status"] for r in included),
        "gene_probe_counts": {gene: len(gene_probes[gene]) for gene in TARGET_GENES},
        "duplicate_sample_ids": len(sample_ids) - len(set(sample_ids)),
    }
    return included, mapping_rows, qc


def prepare_gse106291() -> tuple[list[dict], list[dict], dict]:
    root = DOWNLOAD_ROOT / "GSE106291"
    matrix_path = root / "GSE106291_Matrix_table.xlsx"
    soft_path = root / "GSE106291_family.soft.gz"
    workbook = openpyxl.load_workbook(matrix_path, read_only=True, data_only=True)
    worksheet = workbook["RNASeq"]
    iterator = worksheet.iter_rows(values_only=True)
    header = [str(v).strip() for v in next(iterator)]
    sample_titles = header[1:]
    expression: dict[str, list[float]] = {}
    for values in iterator:
        gene = str(values[0]).strip() if values[0] is not None else ""
        if gene in TARGET_GENES:
            expression[gene] = [as_float(v) for v in values[1:]]
    workbook.close()
    missing = sorted(set(TARGET_GENES) - set(expression))
    if missing:
        raise ValueError(f"GSE106291 matrix missing genes: {missing}")
    if any(len(expression[g]) != len(sample_titles) for g in TARGET_GENES):
        raise ValueError("GSE106291 target gene width mismatch")

    samples = parse_soft_samples(soft_path)
    clinical_by_title = {record.get("title", ""): record for record in samples}
    if len(clinical_by_title) != len(samples):
        raise ValueError("GSE106291 duplicate sample titles")
    rows: list[dict] = []
    for i, title in enumerate(sample_titles):
        if title not in clinical_by_title:
            raise ValueError(f"GSE106291 matrix title missing clinical: {title}")
        record = clinical_by_title[title]
        time_days = as_float(characteristic_value(record, "overall survival (days):"))
        life = (characteristic_value(record, "life status:") or "").strip().lower()
        if life not in {"dead", "alive"}:
            raise ValueError(f"Unexpected life status for {title}: {life}")
        row = {
            "cohort": "GSE106291",
            "sample_id": record["gsm"],
            "subject_id": title,
            "matrix_sample_id": title,
            "time_days": time_days,
            "time_original": time_days,
            "time_unit_original": "days",
            "status": 1 if life == "dead" else 0,
            "age_years": as_float(characteristic_value(record, "age (years):")),
            "sex": characteristic_value(record, "gender:"),
            "response": characteristic_value(record, "response:"),
            "selection_reason": "all_public_AML_with_complete_OS_mixed_AMLCG_source",
        }
        for gene in TARGET_GENES:
            row[gene] = expression[gene][i]
        rows.append(row)
    included = [r for r in rows if r["time_days"] > 0 and r["status"] in (0, 1)]
    mapping_rows = [
        {
            "cohort": "GSE106291",
            "gene": gene,
            "probe_or_stable_id": gene,
            "primary_included": "yes",
            "sensitivity_selected": "not_applicable",
            "selection_metric_IQR": iqr(expression[gene]),
        }
        for gene in TARGET_GENES
    ]
    qc = {
        "matrix_samples": len(sample_titles),
        "soft_samples": len(samples),
        "included": len(included),
        "events": sum(r["status"] for r in included),
        "censored": sum(1 - r["status"] for r in included),
        "duplicate_matrix_sample_ids": len(sample_titles) - len(set(sample_titles)),
        "independence_flag": "mixed_210_AMLCG2008_plus_40_AMLCG1999_without_per_sample_trial_mapping",
    }
    return included, mapping_rows, qc


def read_beat_expression(path: Path) -> tuple[list[str], dict[str, list[float]], dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", errors="replace") as handle:
        header = handle.readline().rstrip("\r\n").split("\t")
        sample_ids = header[4:]
        expression: dict[str, list[float]] = {}
        stable_ids: dict[str, str] = {}
        for line in handle:
            fields = line.rstrip("\r\n").split("\t")
            if len(fields) != len(header):
                raise ValueError("BeatAML normalized matrix width mismatch")
            gene = fields[1].strip()
            if gene in TARGET_GENES:
                if gene in expression:
                    raise ValueError(f"Duplicate target gene in BeatAML normalized matrix: {gene}")
                stable_ids[gene] = fields[0].strip()
                expression[gene] = [as_float(v) for v in fields[4:]]
    missing = sorted(set(TARGET_GENES) - set(expression))
    if missing:
        raise ValueError(f"BeatAML matrix missing genes: {missing}")
    return sample_ids, expression, stable_ids


def prepare_beataml() -> tuple[list[dict], list[dict], dict, list[dict]]:
    root = DOWNLOAD_ROOT / "BEATAML1.0" / "BeatAML2_processed"
    expression_path = root / "beataml_waves1to4_norm_exp_dbgap.txt"
    clinical_path = root / "beataml_wv1to4_clinical.xlsx"
    sample_ids, expression, stable_ids = read_beat_expression(expression_path)
    expression_index = {sample: i for i, sample in enumerate(sample_ids)}
    workbook = openpyxl.load_workbook(clinical_path, read_only=True, data_only=True)
    worksheet = workbook["summary"]
    iterator = worksheet.iter_rows(values_only=True)
    headers = [str(v).strip() if v is not None else "" for v in next(iterator)]
    idx = {name: i for i, name in enumerate(headers)}
    clinical_rows = list(iterator)
    workbook.close()

    aml_label = "ACUTE MYELOID LEUKAEMIA (AML) AND RELATED PRECURSOR NEOPLASMS"
    flow = Counter()
    eligible_by_subject: dict[str, list[dict]] = defaultdict(list)
    for values in clinical_rows:
        flow["clinical_rows"] += 1
        sample = str(values[idx["dbgap_rnaseq_sample"]]).strip() if values[idx["dbgap_rnaseq_sample"]] is not None else ""
        if sample not in expression_index:
            continue
        flow["in_expression_707"] += 1
        if str(values[idx["dxAtSpecimenAcquisition"]]).strip() != aml_label:
            continue
        flow["aml_at_acquisition"] += 1
        if str(values[idx["diseaseStageAtSpecimenCollection"]]).strip() != "Initial Diagnosis":
            continue
        flow["initial_diagnosis"] += 1
        vital = str(values[idx["vitalStatus"]]).strip()
        if vital not in {"Alive", "Dead"}:
            continue
        flow["known_vital_status"] += 1
        os_days = as_float(values[idx["overallSurvival"]])
        if not math.isfinite(os_days) or os_days <= 0:
            continue
        flow["positive_os"] += 1
        subject = str(values[idx["dbgap_subject_id"]]).strip() if values[idx["dbgap_subject_id"]] is not None else ""
        if not subject:
            continue
        time_relative = as_float(values[idx["timeOfSampleCollectionRelativeToInclusion"]])
        if not math.isfinite(time_relative):
            time_relative = math.inf
        record = {
            "cohort": "BeatAML2",
            "sample_id": sample,
            "subject_id": subject,
            "time_days": os_days,
            "time_original": os_days,
            "time_unit_original": "days",
            "status": 1 if vital == "Dead" else 0,
            "time_relative_to_inclusion_days": time_relative,
            "specimen_type": values[idx["specimenType"]],
            "specific_diagnosis": values[idx["specificDxAtAcquisition"]],
            "age_years": as_float(values[idx["ageAtDiagnosis"]]),
            "sex": values[idx["consensus_sex"]],
            "cohort_wave": values[idx["cohort"]],
            "selection_reason": "AML_initial_diagnosis_known_OS_unique_subject_earliest",
        }
        expr_i = expression_index[sample]
        for gene in TARGET_GENES:
            record[gene] = expression[gene][expr_i]
        eligible_by_subject[subject].append(record)

    selected: list[dict] = []
    duplicates_removed = 0
    selection_audit: list[dict] = []
    for subject, candidates in eligible_by_subject.items():
        ordered = sorted(candidates, key=lambda r: (r["time_relative_to_inclusion_days"], r["sample_id"]))
        chosen = ordered[0]
        selected.append(chosen)
        duplicates_removed += len(ordered) - 1
        for rank, record in enumerate(ordered, start=1):
            selection_audit.append(
                {
                    "subject_id": subject,
                    "sample_id": record["sample_id"],
                    "time_relative_to_inclusion_days": record["time_relative_to_inclusion_days"],
                    "rank_within_subject": rank,
                    "selected": "yes" if rank == 1 else "no",
                }
            )
    selected.sort(key=lambda r: r["subject_id"])
    flow["eligible_rows_before_subject_dedup"] = sum(len(v) for v in eligible_by_subject.values())
    flow["unique_subjects_selected"] = len(selected)
    flow["duplicate_rows_removed"] = duplicates_removed
    mapping_rows = [
        {
            "cohort": "BeatAML2",
            "gene": gene,
            "probe_or_stable_id": stable_ids[gene],
            "primary_included": "yes",
            "sensitivity_selected": "not_applicable",
            "selection_metric_IQR": iqr(expression[gene]),
        }
        for gene in TARGET_GENES
    ]
    qc = {
        "expression_samples": len(sample_ids),
        "duplicate_expression_sample_ids": len(sample_ids) - len(set(sample_ids)),
        "flow": dict(flow),
        "included": len(selected),
        "events": sum(r["status"] for r in selected),
        "censored": sum(1 - r["status"] for r in selected),
        "unique_subjects": len({r["subject_id"] for r in selected}),
    }
    return selected, mapping_rows, qc, selection_audit


def validate_rows(name: str, rows: list[dict]) -> dict:
    if not rows:
        raise ValueError(f"No rows prepared for {name}")
    sample_ids = [r["sample_id"] for r in rows]
    subject_ids = [r["subject_id"] for r in rows]
    if len(sample_ids) != len(set(sample_ids)):
        raise ValueError(f"Duplicate sample IDs in {name}")
    if name == "BeatAML2" and len(subject_ids) != len(set(subject_ids)):
        raise ValueError("BeatAML subject deduplication failed")
    for row in rows:
        if not (math.isfinite(float(row["time_days"])) and float(row["time_days"]) > 0):
            raise ValueError(f"Invalid time in {name}: {row}")
        if int(row["status"]) not in (0, 1):
            raise ValueError(f"Invalid status in {name}: {row}")
        for gene in TARGET_GENES:
            if not math.isfinite(float(row[gene])):
                raise ValueError(f"Missing {gene} in {name}: {row['sample_id']}")
    return {
        "rows": len(rows),
        "samples": len(set(sample_ids)),
        "subjects": len(set(subject_ids)),
        "events": sum(int(r["status"]) for r in rows),
        "time_min_days": min(float(r["time_days"]) for r in rows),
        "time_max_days": max(float(r["time_days"]) for r in rows),
    }


def main() -> int:
    INPUT_DIR.mkdir(parents=True, exist_ok=True)
    formula_rows = validate_frozen_formula()
    g710_rows, g710_map, g710_qc = prepare_gse71014()
    g106_rows, g106_map, g106_qc = prepare_gse106291()
    beat_rows, beat_map, beat_qc, beat_selection = prepare_beataml()

    common_fields = [
        "cohort", "sample_id", "subject_id", "time_days", "time_original",
        "time_unit_original", "status", "age_years", "sex", "response",
        "matrix_sample_id", "time_relative_to_inclusion_days", "specimen_type",
        "specific_diagnosis", "cohort_wave", "selection_reason",
        *TARGET_GENES,
        *[f"{gene}_alt_highest_IQR_probe" for gene in TARGET_GENES],
    ]
    write_tsv(INPUT_DIR / "GSE71014_survival_input.tsv", g710_rows, common_fields)
    write_tsv(INPUT_DIR / "GSE106291_survival_input.tsv", g106_rows, common_fields)
    write_tsv(INPUT_DIR / "BeatAML2_survival_input.tsv", beat_rows, common_fields)
    mapping_rows = g710_map + g106_map + beat_map
    write_tsv(
        INPUT_DIR / "gene_mapping_and_probe_selection.tsv",
        mapping_rows,
        ["cohort", "gene", "probe_or_stable_id", "primary_included", "sensitivity_selected", "selection_metric_IQR"],
    )
    write_tsv(
        INPUT_DIR / "BeatAML2_subject_selection_audit.tsv",
        beat_selection,
        ["subject_id", "sample_id", "time_relative_to_inclusion_days", "rank_within_subject", "selected"],
    )
    write_tsv(
        INPUT_DIR / "frozen_formula.tsv",
        [
            {
                "gene": row["Gene"],
                "coefficient": row["Coefficient"],
                "training_mean_GPL96": row["Mean_GPL96"],
                "training_sd_GPL96": row["SD_GPL96"],
            }
            for row in formula_rows
        ],
        ["gene", "coefficient", "training_mean_GPL96", "training_sd_GPL96"],
    )

    source_paths = [
        FORMULA_PATH,
        PROJECT / "AML_Lactylation_PCD" / "data" / "processed" / "mime" / "clean" / "E_cox_5gene_fit.rds",
        DOWNLOAD_ROOT / "GSE71014" / "GSE71014_series_matrix.txt.gz",
        DOWNLOAD_ROOT / "GSE71014" / "GSE71014_family.soft.gz",
        DOWNLOAD_ROOT / "GSE71014" / "GPL10558.annot.gz",
        DOWNLOAD_ROOT / "GSE106291" / "GSE106291_Matrix_table.xlsx",
        DOWNLOAD_ROOT / "GSE106291" / "GSE106291_family.soft.gz",
        DOWNLOAD_ROOT / "BEATAML1.0" / "BeatAML2_processed" / "beataml_waves1to4_norm_exp_dbgap.txt",
        DOWNLOAD_ROOT / "BEATAML1.0" / "BeatAML2_processed" / "beataml_wv1to4_clinical.xlsx",
    ]
    write_tsv(
        INPUT_DIR / "source_hashes.tsv",
        [{"path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)} for path in source_paths],
        ["path", "bytes", "sha256"],
    )
    validation = {
        "generated_at": datetime.now().astimezone().isoformat(),
        "status": "passed",
        "frozen_formula_sha256": sha256(FORMULA_PATH),
        "coefficients": EXPECTED_BETA,
        "prepared": {
            "GSE71014": validate_rows("GSE71014", g710_rows),
            "GSE106291": validate_rows("GSE106291", g106_rows),
            "BeatAML2": validate_rows("BeatAML2", beat_rows),
        },
        "dataset_qc": {
            "GSE71014": g710_qc,
            "GSE106291": g106_qc,
            "BeatAML2": beat_qc,
        },
        "outputs": sorted(str(path) for path in INPUT_DIR.iterdir() if path.is_file()),
    }
    with (INPUT_DIR / "preparation_validation_summary.json").open("w", encoding="utf-8") as handle:
        json.dump(validation, handle, ensure_ascii=False, indent=2)
    print(json.dumps(validation, ensure_ascii=False, indent=2))
    return 0


if __name__ == "__main__":
    sys.exit(main())

suppressPackageStartupMessages({
  library(survival)
  library(timeROC)
})

options(stringsAsFactors = FALSE, warn = 1)

project_root <- "D:/26_01_AML"
audit_root <- file.path(project_root, "_codex_audit/external_survival_validation_20260804_v1")
input_root <- file.path(audit_root, "prepared_inputs")
result_root <- file.path(audit_root, "results")
figure_root <- file.path(audit_root, "figures")
dir.create(result_root, recursive = TRUE, showWarnings = FALSE)
dir.create(figure_root, recursive = TRUE, showWarnings = FALSE)

genes <- c("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")
beta <- c(CREB1 = 0.0925, SLC16A4 = -0.0636, GPX4 = -0.0721,
          CASP1 = -0.0106, MPO = -0.2095)
stopifnot(identical(names(beta), genes))
formula_table <- read.delim(file.path(input_root, "frozen_formula.tsv"), check.names = FALSE,
                            fileEncoding = "UTF-8-BOM")
stopifnot(setequal(formula_table$gene, genes))
training_mean <- setNames(as.numeric(formula_table$training_mean_GPL96), formula_table$gene)[genes]
training_sd <- setNames(as.numeric(formula_table$training_sd_GPL96), formula_table$gene)[genes]
stopifnot(all(is.finite(training_mean)), all(is.finite(training_sd) & training_sd > 0))
base_seed <- 20260804L
B <- 1000L
auc_times <- c(365.25, 3 * 365.25, 5 * 365.25)
auc_labels <- c("1 year", "3 years", "5 years")

cat("Three-cohort external LCDI survival validation\n")
cat("Started:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("R:", R.version.string, "\n")
cat("survival:", as.character(packageVersion("survival")), "\n")
cat("timeROC:", as.character(packageVersion("timeROC")), "\n")
cat("Bootstrap B:", B, "seed base:", base_seed, "\n\n")

read_input <- function(name) {
  path <- file.path(input_root, paste0(name, "_survival_input.tsv"))
  d <- read.delim(path, check.names = FALSE, na.strings = c("", "NA"),
                  quote = "", fileEncoding = "UTF-8-BOM")
  required <- c("cohort", "sample_id", "subject_id", "time_days", "status", genes)
  stopifnot(all(required %in% names(d)))
  d$time_days <- as.numeric(d$time_days)
  d$status <- as.integer(d$status)
  for (g in genes) d[[g]] <- as.numeric(d[[g]])
  stopifnot(nrow(d) > 0, !anyDuplicated(d$sample_id),
            all(is.finite(d$time_days) & d$time_days > 0),
            all(d$status %in% c(0L, 1L)),
            all(vapply(d[genes], function(x) all(is.finite(x)), logical(1))))
  d
}

z1 <- function(x) {
  s <- sd(x)
  if (!is.finite(s) || s <= 0) stop("Cannot standardize constant vector")
  as.numeric((x - mean(x)) / s)
}

prepare_scores <- function(d, cohort) {
  z_expr <- sapply(d[genes], z1)
  colnames(z_expr) <- genes
  primary <- as.numeric(z_expr[, genes, drop = FALSE] %*% beta[genes])
  raw <- as.numeric(as.matrix(d[, genes, drop = FALSE]) %*% beta[genes])
  training_scaled_expr <- sweep(as.matrix(d[, genes, drop = FALSE]), 2, training_mean, "-")
  training_scaled_expr <- sweep(training_scaled_expr, 2, training_sd, "/")
  training_scaled <- as.numeric(training_scaled_expr[, genes, drop = FALSE] %*% beta[genes])
  mpo_risk <- beta["MPO"] * z_expr[, "MPO"]
  d$LCDI_primary <- primary
  d$LCDI_primary_z <- z1(primary)
  d$LCDI_raw <- raw
  d$LCDI_raw_z <- z1(raw)
  d$LCDI_training_scale_z <- z1(training_scaled)
  d$MPO_risk_z <- z1(mpo_risk)
  if (cohort == "GSE71014") {
    alt_cols <- paste0(genes, "_alt_highest_IQR_probe")
    stopifnot(all(alt_cols %in% names(d)))
    alt_expr <- sapply(d[alt_cols], function(x) z1(as.numeric(x)))
    colnames(alt_expr) <- genes
    alt <- as.numeric(alt_expr[, genes, drop = FALSE] %*% beta[genes])
    d$LCDI_alt_probe_z <- z1(alt)
  } else {
    d$LCDI_alt_probe_z <- NA_real_
  }
  d$risk_group <- factor(ifelse(d$LCDI_primary > median(d$LCDI_primary), "High", "Low"),
                         levels = c("Low", "High"))
  d
}

safe_cindex <- function(time, status, score) {
  fit <- concordance(Surv(time, status) ~ score, reverse = TRUE, timewt = "n")
  c(value = as.numeric(fit$concordance), se = sqrt(as.numeric(fit$var)))
}

bootstrap_cindex <- function(d, score_col, seed, B) {
  set.seed(seed)
  out <- rep(NA_real_, B)
  n <- nrow(d)
  for (b in seq_len(B)) {
    idx <- sample.int(n, n, replace = TRUE)
    db <- d[idx, , drop = FALSE]
    if (length(unique(db$status)) < 2L || sum(db$status) < 2L) next
    out[b] <- tryCatch(
      safe_cindex(db$time_days, db$status, db[[score_col]])["value"],
      error = function(e) NA_real_
    )
  }
  out
}

cox_score_result <- function(d, score_col, cohort, mode) {
  work <- data.frame(time = d$time_days, status = d$status, score = d[[score_col]])
  fit <- coxph(Surv(time, status) ~ score, data = work, ties = "efron",
               x = TRUE, y = TRUE, model = TRUE)
  sm <- summary(fit)
  ci <- safe_cindex(work$time, work$status, work$score)
  ph <- tryCatch(cox.zph(fit, transform = "km")$table["score", "p"],
                 error = function(e) NA_real_)
  data.frame(
    cohort = cohort,
    mode = mode,
    N = nrow(work),
    events = sum(work$status),
    HR_per_SD = unname(exp(coef(fit))[1]),
    HR_low = unname(exp(confint(fit))[1, 1]),
    HR_high = unname(exp(confint(fit))[1, 2]),
    cox_p = sm$coefficients[1, "Pr(>|z|)"],
    PH_test_p = ph,
    C_index = ci["value"],
    C_index_SE = ci["se"],
    C_index_low_analytic = max(0, ci["value"] - 1.96 * ci["se"]),
    C_index_high_analytic = min(1, ci["value"] + 1.96 * ci["se"]),
    stringsAsFactors = FALSE
  )
}

group_result <- function(d, cohort) {
  fit <- coxph(Surv(time_days, status) ~ risk_group, data = d, ties = "efron")
  lr <- survdiff(Surv(time_days, status) ~ risk_group, data = d)
  ci <- exp(confint(fit))[1, ]
  data.frame(
    cohort = cohort,
    threshold = median(d$LCDI_primary),
    low_N = sum(d$risk_group == "Low"),
    low_events = sum(d$status[d$risk_group == "Low"]),
    high_N = sum(d$risk_group == "High"),
    high_events = sum(d$status[d$risk_group == "High"]),
    HR_high_vs_low = unname(exp(coef(fit))[1]),
    HR_low = unname(ci[1]),
    HR_high = unname(ci[2]),
    cox_p = summary(fit)$coefficients[1, "Pr(>|z|)"],
    logrank_p = pchisq(lr$chisq, df = length(lr$n) - 1L, lower.tail = FALSE),
    stringsAsFactors = FALSE
  )
}

median_followup <- function(d) {
  fit <- survfit(Surv(time_days, 1L - status) ~ 1, data = d)
  as.numeric(summary(fit)$table["median"])
}

at_risk_rows <- function(d, cohort) {
  fit <- survfit(Surv(time_days, status) ~ risk_group, data = d)
  s <- summary(fit, times = auc_times, extend = TRUE)
  data.frame(
    cohort = cohort,
    risk_group = sub("risk_group=", "", s$strata),
    time_years = s$time / 365.25,
    n_risk = s$n.risk,
    n_event_interval = s$n.event,
    stringsAsFactors = FALSE
  )
}

auc_rows <- function(d, cohort) {
  fit <- tryCatch(
    timeROC(T = d$time_days, delta = d$status, marker = d$LCDI_primary_z,
            cause = 1, weighting = "marginal", times = auc_times, iid = FALSE),
    error = function(e) e
  )
  if (inherits(fit, "error")) {
    return(data.frame(cohort = cohort, time_years = auc_times / 365.25,
                      AUC = NA_real_, status = paste("failed", conditionMessage(fit)),
                      stringsAsFactors = FALSE))
  }
  data.frame(cohort = cohort, time_years = fit$times / 365.25,
             AUC = as.numeric(fit$AUC), status = "passed",
             stringsAsFactors = FALSE)
}

cohort_names <- c("GSE71014", "GSE106291", "BeatAML2")
display_names <- c(GSE71014 = "GSE71014", GSE106291 = "GSE106291", BeatAML2 = "Beat AML")
input_data <- lapply(cohort_names, read_input)
names(input_data) <- cohort_names
data_list <- Map(prepare_scores, input_data, cohort_names)
names(data_list) <- cohort_names

for (cohort in cohort_names) {
  d <- data_list[[cohort]]
  cat(sprintf("%s: N=%d, events=%d, censored=%d, median follow-up=%.1f days\n",
              cohort, nrow(d), sum(d$status), sum(d$status == 0), median_followup(d)))
}

primary_rows <- list()
sensitivity_rows <- list()
group_rows <- list()
bootstrap_rows <- list()
bootstrap_summary_rows <- list()
auc_all <- list()
risk_all <- list()
patient_scores <- list()

for (i in seq_along(cohort_names)) {
  cohort <- cohort_names[i]
  d <- data_list[[cohort]]
  primary <- cox_score_result(d, "LCDI_primary_z", cohort, "primary_within_cohort_gene_z")
  boots <- bootstrap_cindex(d, "LCDI_primary_z", base_seed + i, B)
  valid <- boots[is.finite(boots)]
  primary$C_index_low_bootstrap <- unname(quantile(valid, 0.025, na.rm = TRUE, type = 6))
  primary$C_index_high_bootstrap <- unname(quantile(valid, 0.975, na.rm = TRUE, type = 6))
  primary$bootstrap_valid <- length(valid)
  primary$median_followup_days <- median_followup(d)
  primary_rows[[cohort]] <- primary
  bootstrap_rows[[cohort]] <- data.frame(cohort = cohort, replicate = seq_len(B), C_index = boots)
  bootstrap_summary_rows[[cohort]] <- data.frame(
    cohort = cohort, B = B, valid = length(valid),
    mean = mean(valid), sd = sd(valid),
    q025 = unname(quantile(valid, .025, type = 6)),
    median = median(valid), q975 = unname(quantile(valid, .975, type = 6))
  )
  sensitivity_rows[[paste0(cohort, "_raw")]] <- cox_score_result(
    d, "LCDI_raw_z", cohort, "supplier_processed_scale_fixed_beta")
  sensitivity_rows[[paste0(cohort, "_mpo")]] <- cox_score_result(
    d, "MPO_risk_z", cohort, "frozen_MPO_risk_component")
  sensitivity_rows[[paste0(cohort, "_training_scale")]] <- cox_score_result(
    d, "LCDI_training_scale_z", cohort, "postfit_diagnostic_GPL96_training_mean_sd")
  if (cohort == "GSE71014") {
    sensitivity_rows[[paste0(cohort, "_alt")]] <- cox_score_result(
      d, "LCDI_alt_probe_z", cohort, "highest_IQR_probe_per_gene")
  }
  group_rows[[cohort]] <- group_result(d, cohort)
  auc_all[[cohort]] <- auc_rows(d, cohort)
  risk_all[[cohort]] <- at_risk_rows(d, cohort)
  patient_scores[[cohort]] <- data.frame(
    cohort = cohort, sample_id = d$sample_id, subject_id = d$subject_id,
    time_days = d$time_days, status = d$status,
    LCDI_primary = d$LCDI_primary, LCDI_primary_z = d$LCDI_primary_z,
    risk_group = as.character(d$risk_group), LCDI_raw_z = d$LCDI_raw_z,
    LCDI_training_scale_z = d$LCDI_training_scale_z, MPO_risk_z = d$MPO_risk_z,
    LCDI_alt_probe_z = d$LCDI_alt_probe_z,
    stringsAsFactors = FALSE
  )
}

primary_df <- do.call(rbind, primary_rows)
rownames(primary_df) <- NULL
primary_df$cox_FDR_BH <- p.adjust(primary_df$cox_p, method = "BH")
group_df <- do.call(rbind, group_rows)
rownames(group_df) <- NULL
group_df$logrank_FDR_BH <- p.adjust(group_df$logrank_p, method = "BH")
sensitivity_df <- do.call(rbind, sensitivity_rows)
rownames(sensitivity_df) <- NULL
auc_df <- do.call(rbind, auc_all)
risk_df <- do.call(rbind, risk_all)
bootstrap_df <- do.call(rbind, bootstrap_rows)
bootstrap_summary_df <- do.call(rbind, bootstrap_summary_rows)
patient_scores_df <- do.call(rbind, patient_scores)

write.table(primary_df, file.path(result_root, "cohort_primary_continuous_results.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(group_df, file.path(result_root, "cohort_median_group_results.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(sensitivity_df, file.path(result_root, "cohort_sensitivity_results.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(auc_df, file.path(result_root, "time_dependent_auc.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(risk_df, file.path(result_root, "at_risk_counts.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(bootstrap_df, file.path(result_root, "bootstrap_cindex_replicates.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(bootstrap_summary_df, file.path(result_root, "bootstrap_cindex_summary.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)
write.table(patient_scores_df, file.path(result_root, "patient_level_scores.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

metadata <- data.frame(
  field = c("model", "genes", "coefficients", "primary_score", "continuous_HR",
            "C_index", "KM_cutoff", "time_AUC", "bootstrap", "seed",
            "GSE71014_probe_rule", "GSE106291_independence", "BeatAML_selection",
            "postfit_diagnostic",
            "R", "survival", "timeROC", "generated_at"),
  value = c(
    "frozen GPL96 five-gene LCDI; no refit",
    paste(genes, collapse = ","),
    paste(sprintf("%s=%+.4f", names(beta), beta), collapse = ";"),
    "within-cohort gene z-score then frozen beta",
    "per 1 SD LCDI",
    "Harrell C; higher LCDI treated as higher risk; analytic and 1000-bootstrap CI",
    "within-cohort median; descriptive only",
    "1, 3, 5 years; timeROC marginal weighting",
    paste0("patient-level with replacement; B=", B),
    as.character(base_seed),
    "primary=median across exact-symbol probes; sensitivity=highest-IQR probe",
    "all 250 mixed source; 210 AMLCG-2008 + 40 AMLCG-1999 not separable in public SOFT",
    "AML at acquisition; Initial Diagnosis; known vital status; OS>0; earliest sample per subject",
    "GPL96 training mean/SD score added after first fit as scale-sensitivity diagnostic; does not replace primary",
    R.version.string,
    as.character(packageVersion("survival")),
    as.character(packageVersion("timeROC")),
    format(Sys.time(), "%Y-%m-%dT%H:%M:%S%z")
  ), stringsAsFactors = FALSE
)
write.table(metadata, file.path(result_root, "analysis_metadata.tsv"),
            sep = "\t", quote = FALSE, row.names = FALSE)

draw_km <- function() {
  old <- par(no.readonly = TRUE); on.exit(par(old))
  par(mfrow = c(1, 3), mar = c(4.2, 4.2, 3.6, 1.0), oma = c(0, 0, 1.3, 0),
      mgp = c(2.5, 0.7, 0))
  cols <- c(Low = "#2C7BB6", High = "#D7191C")
  for (cohort in cohort_names) {
    d <- data_list[[cohort]]
    fit <- survfit(Surv(time_days, status) ~ risk_group, data = d)
    xmax_years <- max(5, ceiling(max(d$time_days) / 365.25))
    ticks_years <- pretty(c(0, xmax_years), n = 6)
    plot(fit, col = cols, lwd = 2.2, mark.time = FALSE, conf.int = FALSE,
         xaxt = "n", xlab = "Time (years)", ylab = "Overall survival probability",
         main = display_names[[cohort]], xlim = c(0, max(ticks_years) * 365.25),
         ylim = c(0, 1))
    axis(1, at = ticks_years * 365.25, labels = ticks_years)
    legend("bottomleft", legend = c("Low LCDI", "High LCDI"), col = cols,
           lwd = 2.2, bty = "n", cex = 0.82)
    gr <- group_df[group_df$cohort == cohort, ]
    legend("topright",
           legend = c(sprintf("N=%d, events=%d", nrow(d), sum(d$status)),
                      sprintf("HR=%.2f (%.2f-%.2f)", gr$HR_high_vs_low, gr$HR_low, gr$HR_high),
                      sprintf("Log-rank P=%s", format.pval(gr$logrank_p, digits = 2, eps = 1e-4))),
           bty = "n", cex = 0.78)
  }
  mtext("Fixed five-gene LCDI: cohort-specific median groups", outer = TRUE, cex = 1.15, font = 2)
}

pdf(file.path(figure_root, "Figure1_KM_three_external_cohorts.pdf"), width = 12.6, height = 4.4)
draw_km(); dev.off()
png(file.path(figure_root, "Figure1_KM_three_external_cohorts.png"), width = 3024, height = 1056, res = 240)
draw_km(); dev.off()

draw_cindex <- function() {
  x <- primary_df$C_index
  lo <- primary_df$C_index_low_bootstrap
  hi <- primary_df$C_index_high_bootstrap
  y <- rev(seq_along(cohort_names))
  par(mar = c(4.4, 6.2, 3.3, 2.0))
  plot(x, y, xlim = range(c(0.35, 0.75, lo, hi), na.rm = TRUE), ylim = c(0.5, 3.5),
       pch = 19, cex = 1.25, yaxt = "n", xlab = "Harrell C-index (95% bootstrap CI)",
       ylab = "", main = "Fixed LCDI discrimination in external cohorts")
  abline(v = 0.5, col = "#777777", lty = 2)
  segments(lo, y, hi, y, lwd = 2)
  segments(lo, y - 0.08, lo, y + 0.08, lwd = 1.5)
  segments(hi, y - 0.08, hi, y + 0.08, lwd = 1.5)
  axis(2, at = y, labels = display_names[cohort_names], las = 1)
  text(hi, y, labels = sprintf("  %.3f [%.3f-%.3f]", x, lo, hi), pos = 4, cex = 0.82)
}

pdf(file.path(figure_root, "Figure2_Cindex_three_external_cohorts.pdf"), width = 8.2, height = 4.8)
draw_cindex(); dev.off()
png(file.path(figure_root, "Figure2_Cindex_three_external_cohorts.png"), width = 1968, height = 1152, res = 240)
draw_cindex(); dev.off()

draw_auc <- function() {
  cols <- c(GSE71014 = "#1B9E77", GSE106291 = "#7570B3", BeatAML2 = "#D95F02")
  par(mar = c(4.4, 4.6, 3.3, 1.4))
  plot(NA, xlim = c(1, 5), ylim = range(c(0.35, 0.8, auc_df$AUC), na.rm = TRUE),
       xlab = "Time (years)", ylab = "Time-dependent AUC", xaxt = "n",
       main = "Fixed LCDI time-dependent discrimination")
  axis(1, at = c(1, 3, 5))
  abline(h = 0.5, col = "#777777", lty = 2)
  for (cohort in cohort_names) {
    d <- auc_df[auc_df$cohort == cohort, ]
    lines(d$time_years, d$AUC, type = "b", pch = 19, lwd = 2.2, col = cols[[cohort]])
  }
  legend("topright", legend = display_names[cohort_names], col = cols[cohort_names],
         lwd = 2.2, pch = 19, bty = "n")
}

pdf(file.path(figure_root, "Figure3_timeAUC_three_external_cohorts.pdf"), width = 7.3, height = 5.2)
draw_auc(); dev.off()
png(file.path(figure_root, "Figure3_timeAUC_three_external_cohorts.png"), width = 1752, height = 1248, res = 240)
draw_auc(); dev.off()

saveRDS(list(
  coefficients = beta,
  protocol = "00_analysis_protocol.md",
  data = data_list,
  primary = primary_df,
  groups = group_df,
  sensitivity = sensitivity_df,
  auc = auc_df,
  at_risk = risk_df,
  bootstrap_summary = bootstrap_summary_df,
  metadata = metadata
), file.path(result_root, "external_survival_validation_results.rds"))

cat("\nPrimary continuous results:\n")
print(primary_df)
cat("\nMedian-group results:\n")
print(group_df)
cat("\nTime-dependent AUC:\n")
print(auc_df)
cat("\nCompleted:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("STATUS=passed\n")

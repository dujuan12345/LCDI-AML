options(stringsAsFactors = FALSE, warn = 1)

out_dir <- "D:/26_01_AML/_codex_audit/bootstrap_fixed_formula_20260727"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
log_path <- file.path(out_dir, "02_fixed_lcdi_bootstrap.log")
if (file.exists(log_path)) file.remove(log_path)

log_line <- function(...) {
  txt <- paste0(...)
  cat(txt, "\n")
  cat(txt, "\n", file = log_path, append = TRUE)
}

main <- function() {
  if (!requireNamespace("survival", quietly = TRUE)) {
    stop("Required package 'survival' is unavailable.")
  }

  data_path <- paste0(
    "D:/26_01_AML/AML_Lactylation_PCD/",
    "data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds"
  )
  formula_path <- paste0(
    "D:/26_01_AML/AML_Lactylation_PCD/",
    "results/tables/mime/clean/E_LCDI_formula.csv"
  )

  B <- 1000L
  base_seed <- 20260727L
  cohort_order <- c(
    "GPL96_Train",
    "GPL570_Val1",
    "GSE10358_Val2",
    "TCGA_Val3",
    "TARGET_Val4"
  )

  log_line("Fixed five-gene LCDI formula bootstrap")
  log_line("Started: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"))
  log_line("Bootstrap replicates per cohort: ", B)
  log_line("Sampling: n patients with replacement from each full cohort")
  log_line("Formula refitting or gene reselection: no")
  log_line("Input data: ", data_path)
  log_line("Formula: ", formula_path)

  B_data <- readRDS(data_path)
  formula_df <- read.csv(formula_path, check.names = FALSE)
  required_formula_cols <- c(
    "Gene", "Coefficient", "Mean_GPL96", "SD_GPL96"
  )
  if (!all(required_formula_cols %in% names(formula_df))) {
    stop("Formula CSV lacks required columns.")
  }
  if (anyDuplicated(formula_df$Gene)) {
    stop("Formula CSV contains duplicated genes.")
  }
  if (any(!is.finite(formula_df$Coefficient)) ||
      any(!is.finite(formula_df$Mean_GPL96)) ||
      any(!is.finite(formula_df$SD_GPL96)) ||
      any(formula_df$SD_GPL96 <= 0)) {
    stop("Formula CSV contains invalid numeric values.")
  }

  genes <- as.character(formula_df$Gene)
  coefficients <- setNames(formula_df$Coefficient, genes)
  means <- setNames(formula_df$Mean_GPL96, genes)
  sds <- setNames(formula_df$SD_GPL96, genes)

  log_line(
    "Frozen genes: ",
    paste(
      sprintf(
        "%s(%+.4f)",
        genes,
        coefficients[genes]
      ),
      collapse = "; "
    )
  )

  get_expr <- function(cohort, cname) {
    candidates <- c("expr_5", "expr_full", "expr_raw")
    field <- candidates[
      vapply(candidates, function(x) !is.null(cohort[[x]]), logical(1))
    ][1]
    if (is.na(field)) stop(cname, ": no expression matrix found.")
    expr <- as.matrix(cohort[[field]])
    if (!is.numeric(expr)) stop(cname, ": expression matrix is not numeric.")
    if (is.null(rownames(expr)) || is.null(colnames(expr))) {
      stop(cname, ": expression matrix lacks row or column names.")
    }
    rownames(expr) <- toupper(rownames(expr))
    missing_genes <- setdiff(genes, rownames(expr))
    if (length(missing_genes) > 0) {
      stop(cname, ": missing genes: ", paste(missing_genes, collapse = ", "))
    }
    list(expr = expr[genes, , drop = FALSE], field = field)
  }

  get_surv_columns <- function(surv_df, cname) {
    time_candidates <- c(
      "os_days", "OS_time", "OS.time", "time", "os_time"
    )
    status_candidates <- c(
      "os_status", "OS_status", "OS", "status"
    )
    time_col <- intersect(time_candidates, names(surv_df))[1]
    status_col <- intersect(status_candidates, names(surv_df))[1]
    if (is.na(time_col) || is.na(status_col)) {
      stop(cname, ": survival time/status columns not found.")
    }
    c(time = time_col, status = status_col)
  }

  align_cohort <- function(cohort, cname) {
    expr_info <- get_expr(cohort, cname)
    expr <- expr_info$expr
    surv_df <- as.data.frame(cohort$surv)
    if (nrow(surv_df) == 0) stop(cname, ": empty survival table.")

    surv_id <- if ("sample_id" %in% names(surv_df)) {
      as.character(surv_df$sample_id)
    } else {
      rownames(surv_df)
    }
    expr_id <- colnames(expr)

    exact_order <- length(surv_id) == length(expr_id) &&
      all(!is.na(surv_id)) &&
      identical(as.character(surv_id), as.character(expr_id))
    alignment <- NA_character_

    if (exact_order) {
      alignment <- "exact_id_order"
    } else {
      idx <- match(expr_id, surv_id)
      if (all(!is.na(idx)) && length(unique(idx)) == length(idx)) {
        surv_df <- surv_df[idx, , drop = FALSE]
        surv_id <- surv_id[idx]
        alignment <- "matched_expression_ids_to_survival"
      } else if (ncol(expr) == nrow(surv_df)) {
        alignment <- "positional_fallback"
      } else {
        stop(
          cname,
          ": expression/survival samples cannot be aligned uniquely."
        )
      }
    }

    cols <- get_surv_columns(surv_df, cname)
    z <- sweep(expr, 1, means[genes], FUN = "-")
    z <- sweep(z, 1, sds[genes], FUN = "/")
    score <- as.numeric(
      colSums(z * coefficients[genes], na.rm = FALSE)
    )

    stored_lcdi <- if ("LCDI" %in% names(surv_df)) {
      suppressWarnings(as.numeric(surv_df$LCDI))
    } else {
      rep(NA_real_, nrow(surv_df))
    }

    df <- data.frame(
      sample_id = expr_id,
      time = suppressWarnings(as.numeric(surv_df[[cols["time"]]])),
      status = suppressWarnings(as.numeric(surv_df[[cols["status"]]])),
      LCDI_recomputed = score,
      LCDI_stored = stored_lcdi,
      stringsAsFactors = FALSE
    )
    valid <- is.finite(df$time) &
      df$time > 0 &
      df$status %in% c(0, 1) &
      is.finite(df$LCDI_recomputed)
    df_valid <- df[valid, , drop = FALSE]
    if (nrow(df_valid) < 20 || sum(df_valid$status == 1) < 5) {
      stop(cname, ": insufficient valid samples or events.")
    }

    stored_valid <- is.finite(df_valid$LCDI_stored)
    compare <- data.frame(
      cohort = cname,
      stored_lcdi_available_n = sum(stored_valid),
      pearson_stored_vs_recomputed = if (sum(stored_valid) >= 3) {
        cor(
          df_valid$LCDI_stored[stored_valid],
          df_valid$LCDI_recomputed[stored_valid],
          method = "pearson"
        )
      } else {
        NA_real_
      },
      spearman_stored_vs_recomputed = if (sum(stored_valid) >= 3) {
        cor(
          df_valid$LCDI_stored[stored_valid],
          df_valid$LCDI_recomputed[stored_valid],
          method = "spearman"
        )
      } else {
        NA_real_
      },
      max_abs_difference = if (sum(stored_valid) > 0) {
        max(
          abs(
            df_valid$LCDI_stored[stored_valid] -
              df_valid$LCDI_recomputed[stored_valid]
          )
        )
      } else {
        NA_real_
      },
      stringsAsFactors = FALSE
    )

    qc <- data.frame(
      cohort = cname,
      expression_field = expr_info$field,
      alignment = alignment,
      n_expression = ncol(expr),
      n_survival = nrow(surv_df),
      n_valid = nrow(df_valid),
      events = sum(df_valid$status == 1),
      censored = sum(df_valid$status == 0),
      missing_or_invalid_excluded = sum(!valid),
      duplicate_sample_ids = sum(duplicated(df_valid$sample_id)),
      score_mean = mean(df_valid$LCDI_recomputed),
      score_sd = sd(df_valid$LCDI_recomputed),
      time_min = min(df_valid$time),
      time_median = median(df_valid$time),
      time_max = max(df_valid$time),
      stringsAsFactors = FALSE
    )

    list(data = df_valid, qc = qc, comparison = compare)
  }

  calc_metrics <- function(df) {
    if (nrow(df) < 10 ||
        length(unique(df$status)) < 2 ||
        sum(df$status == 1) < 2 ||
        !is.finite(sd(df$LCDI_recomputed)) ||
        sd(df$LCDI_recomputed) == 0) {
      return(c(cindex = NA_real_, hr_per_sd = NA_real_))
    }

    cindex <- tryCatch(
      survival::concordance(
        survival::Surv(time, status) ~ LCDI_recomputed,
        data = df,
        reverse = TRUE
      )$concordance,
      error = function(e) NA_real_
    )

    df$LCDI_per_sd <- (
      df$LCDI_recomputed - mean(df$LCDI_recomputed)
    ) / sd(df$LCDI_recomputed)
    hr <- tryCatch(
      exp(
        stats::coef(
          survival::coxph(
            survival::Surv(time, status) ~ LCDI_per_sd,
            data = df,
            ties = "efron"
          )
        )[1]
      ),
      error = function(e) NA_real_
    )
    c(cindex = as.numeric(cindex), hr_per_sd = as.numeric(hr))
  }

  summarize_boot <- function(cname, df, iter_df, original) {
    summarize_metric <- function(x) {
      x <- x[is.finite(x)]
      c(
        successful_replicates = length(x),
        mean = mean(x),
        median = median(x),
        sd = stats::sd(x),
        ci_lower = unname(stats::quantile(x, 0.025, names = FALSE)),
        ci_upper = unname(stats::quantile(x, 0.975, names = FALSE))
      )
    }
    c_stats <- summarize_metric(iter_df$cindex)
    hr_stats <- summarize_metric(iter_df$hr_per_sd)
    data.frame(
      cohort = cname,
      n = nrow(df),
      events = sum(df$status == 1),
      bootstrap_requested = B,
      cindex_original = original["cindex"],
      cindex_successful = c_stats["successful_replicates"],
      cindex_boot_mean = c_stats["mean"],
      cindex_boot_median = c_stats["median"],
      cindex_boot_sd = c_stats["sd"],
      cindex_ci_lower = c_stats["ci_lower"],
      cindex_ci_upper = c_stats["ci_upper"],
      hr_per_sd_original = original["hr_per_sd"],
      hr_per_sd_successful = hr_stats["successful_replicates"],
      hr_per_sd_boot_mean = hr_stats["mean"],
      hr_per_sd_boot_median = hr_stats["median"],
      hr_per_sd_boot_sd = hr_stats["sd"],
      hr_per_sd_ci_lower = hr_stats["ci_lower"],
      hr_per_sd_ci_upper = hr_stats["ci_upper"],
      mean_unique_fraction = mean(iter_df$unique_fraction),
      stringsAsFactors = FALSE,
      check.names = FALSE
    )
  }

  cohort_qc <- list()
  comparisons <- list()
  all_iterations <- list()
  all_summaries <- list()

  for (i in seq_along(cohort_order)) {
    cname <- cohort_order[i]
    if (is.null(B_data[[cname]])) {
      stop("Missing cohort in B_data: ", cname)
    }
    aligned <- align_cohort(B_data[[cname]], cname)
    df <- aligned$data
    cohort_qc[[cname]] <- aligned$qc
    comparisons[[cname]] <- aligned$comparison

    original <- calc_metrics(df)
    set.seed(base_seed + i - 1L)
    iter_rows <- vector("list", B)
    n <- nrow(df)

    log_line(
      cname,
      ": N=",
      n,
      ", events=",
      sum(df$status == 1),
      ", seed=",
      base_seed + i - 1L
    )

    for (b in seq_len(B)) {
      idx <- sample.int(n, size = n, replace = TRUE)
      boot_df <- df[idx, , drop = FALSE]
      metrics <- calc_metrics(boot_df)
      iter_rows[[b]] <- data.frame(
        cohort = cname,
        iteration = b,
        seed = base_seed + i - 1L,
        n_draws = n,
        n_unique = length(unique(idx)),
        unique_fraction = length(unique(idx)) / n,
        events_in_draw = sum(boot_df$status == 1),
        cindex = metrics["cindex"],
        hr_per_sd = metrics["hr_per_sd"],
        stringsAsFactors = FALSE,
        check.names = FALSE
      )
    }

    iter_df <- do.call(rbind, iter_rows)
    all_iterations[[cname]] <- iter_df
    all_summaries[[cname]] <- summarize_boot(
      cname,
      df,
      iter_df,
      original
    )
  }

  qc_df <- do.call(rbind, cohort_qc)
  rownames(qc_df) <- NULL
  comparison_df <- do.call(rbind, comparisons)
  rownames(comparison_df) <- NULL
  iterations_df <- do.call(rbind, all_iterations)
  rownames(iterations_df) <- NULL
  summary_df <- do.call(rbind, all_summaries)
  rownames(summary_df) <- NULL

  write.csv(
    formula_df,
    file.path(out_dir, "formula_used.csv"),
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )
  write.csv(
    qc_df,
    file.path(out_dir, "cohort_input_qc.csv"),
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )
  write.csv(
    comparison_df,
    file.path(out_dir, "stored_vs_recomputed_lcdi.csv"),
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )
  write.csv(
    iterations_df,
    file.path(out_dir, "fixed_formula_bootstrap_iterations.csv"),
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )
  write.csv(
    summary_df,
    file.path(out_dir, "fixed_formula_bootstrap_summary.csv"),
    row.names = FALSE,
    fileEncoding = "UTF-8"
  )

  capture.output(
    sessionInfo(),
    file = file.path(out_dir, "sessionInfo.txt")
  )
  writeLines(
    c(
      "status=passed",
      paste0("completed_at=", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
      paste0("bootstrap_replicates_per_cohort=", B),
      paste0("cohorts=", length(cohort_order)),
      paste0("iteration_rows=", nrow(iterations_df)),
      "sampling=with_replacement",
      "formula_refit=no",
      "gene_reselection=no",
      "ci_method=percentile"
    ),
    con = file.path(out_dir, "run_status.txt"),
    useBytes = TRUE
  )

  log_line("Completed cohorts: ", nrow(summary_df))
  log_line("Iteration rows: ", nrow(iterations_df))
  log_line(
    "Mean unique fraction range: ",
    sprintf(
      "%.3f-%.3f",
      min(summary_df$mean_unique_fraction),
      max(summary_df$mean_unique_fraction)
    )
  )
  log_line("Completed: ", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"))
}

tryCatch(
  main(),
  error = function(e) {
    log_line("FAILED: ", conditionMessage(e))
    writeLines(
      c(
        "status=failed",
        paste0("failed_at=", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z")),
        paste0("error=", conditionMessage(e))
      ),
      con = file.path(out_dir, "run_status.txt"),
      useBytes = TRUE
    )
    quit(save = "no", status = 1L, runLast = FALSE)
  }
)

# True patient-level bootstrap validation for unified-score nomograms.
# Authorized by the user on 2026-09-02.
# Source data and historical project outputs are read-only.
# All generated artifacts are written under:
# D:/26_01_AML/_codex_audit/chapter5_nomogram_true_bootstrap_20260730_v1

options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  suppressWarnings(library(survival))
  suppressWarnings(library(timeROC))
})

project_root <- "D:/26_01_AML"
input_path <- file.path(
  project_root,
  "AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds"
)
score_path <- file.path(
  project_root,
  "_codex_audit/cindex_nomogram_reconciliation_20260902_v1/10_final_tcga_target_scores.tsv"
)
audit_root <- file.path(
  project_root,
  "_codex_audit/cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram"
)

run_mode <- Sys.getenv("RUN_MODE", unset = "final")
B <- as.integer(Sys.getenv("BOOT_B", unset = "1000"))
cal_B <- as.integer(Sys.getenv("CAL_B", unset = as.character(B)))
base_seed <- as.integer(Sys.getenv("BOOT_SEED", unset = "20260904"))
resume_performance <- identical(
  tolower(Sys.getenv("RESUME_PERFORMANCE", unset = "false")),
  "true"
)

stopifnot(
  run_mode %in% c("smoke_test", "final"),
  is.finite(B), B >= 2L,
  is.finite(cal_B), cal_B >= 2L,
  is.finite(base_seed),
  file.exists(input_path),
  file.exists(score_path)
)

out_dir <- file.path(audit_root, run_mode)
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)
log_path <- file.path(out_dir, "run.log")
log_connection <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_connection, split = TRUE)
sink(log_connection, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(), silent = TRUE)
  try(close(log_connection), silent = TRUE)
}, add = TRUE)

cat("Final branch-specific score true bootstrap nomogram validation\n")
cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Run mode:", run_mode, "\n")
cat("Input:", input_path, "\n")
cat("Unified score input:", score_path, "\n")
cat("Output:", out_dir, "\n")
cat("B:", B, "\n")
cat("Calibration B:", cal_B, "\n")
cat("Base seed:", base_seed, "\n\n")
cat("Resume validated performance checkpoints:", resume_performance, "\n\n")

write_tsv <- function(x, path) {
  write.table(
    x,
    file = path,
    sep = "\t",
    row.names = FALSE,
    col.names = TRUE,
    quote = FALSE,
    na = "NA",
    fileEncoding = "UTF-8"
  )
}

safe_cindex <- function(data, lp) {
  ok <- is.finite(lp) & is.finite(data$time) & !is.na(data$status)
  if (sum(ok) < 10L || sum(data$status[ok] == 1L) < 2L) {
    return(NA_real_)
  }
  tryCatch(
    as.numeric(
      survival::concordance(
        Surv(data$time[ok], data$status[ok]) ~ lp[ok],
        reverse = TRUE
      )$concordance
    ),
    error = function(e) NA_real_
  )
}

safe_auc <- function(data, lp, times_eval) {
  ok <- is.finite(lp) & is.finite(data$time) & !is.na(data$status)
  if (sum(ok) < 20L || sum(data$status[ok] == 1L) < 2L) {
    return(rep(NA_real_, length(times_eval)))
  }
  tryCatch(
    suppressWarnings(
      timeROC::timeROC(
        T = data$time[ok],
        delta = data$status[ok],
        marker = lp[ok],
        cause = 1,
        weighting = "marginal",
        times = times_eval,
        iid = FALSE
      )$AUC
    ),
    error = function(e) rep(NA_real_, length(times_eval))
  )
}

fit_cox <- function(formula, data) {
  tryCatch(
    {
      fit <- survival::coxph(
        formula,
        data = data,
        ties = "efron",
        x = TRUE,
        y = TRUE,
        model = TRUE,
        singular.ok = FALSE
      )
      if (any(!is.finite(stats::coef(fit)))) {
        stop("non-finite coefficient")
      }
      fit
    },
    error = function(e) structure(list(message = conditionMessage(e)), class = "fit_error")
  )
}

safe_lp <- function(fit, newdata) {
  tryCatch(
    {
      lp <- as.numeric(
        predict(
          fit,
          newdata = newdata,
          type = "lp",
          reference = "zero"
        )
      )
      if (length(lp) != nrow(newdata)) {
        stop("prediction length mismatch")
      }
      lp
    },
    error = function(e) rep(NA_real_, nrow(newdata))
  )
}

prepare_data <- function(B_data) {
  tcga_raw <- B_data$TCGA_Val3$surv
  target_raw <- B_data$TARGET_Val4$surv

  score_df <- read.delim(score_path, check.names = FALSE)
  required_score_cols <- c("cohort", "sample_id", "LCDI_per_sd")
  if (!all(required_score_cols %in% names(score_df))) {
    stop("Unified score file lacks required columns")
  }
  lookup_score <- function(cohort_name, sample_ids) {
    sub <- score_df[score_df$cohort == cohort_name, required_score_cols, drop = FALSE]
    if (anyDuplicated(sub$sample_id)) stop(cohort_name, ": duplicate score sample IDs")
    idx <- match(as.character(sample_ids), as.character(sub$sample_id))
    if (anyNA(idx)) stop(cohort_name, ": score alignment failed")
    as.numeric(sub$LCDI_per_sd[idx])
  }

  tcga <- data.frame(
    sample_id = tcga_raw$sample_id,
    time = as.numeric(tcga_raw$OS.time),
    status = as.integer(tcga_raw$OS),
    LCDI = lookup_score("TCGA_Val3", tcga_raw$sample_id),
    age = as.numeric(tcga_raw$age),
    FAB = factor(tcga_raw$FAB),
    cyto = factor(
      tcga_raw$cyto_risk,
      levels = c("Favorable", "Intermediate", "Adverse")
    ),
    FLT3 = factor(tcga_raw$FLT3, levels = c(0, 1), labels = c("WT", "Mut")),
    NPM1 = factor(tcga_raw$NPM1, levels = c(0, 1), labels = c("WT", "Mut")),
    CEBPA = factor(tcga_raw$CEBPA, levels = c(0, 1), labels = c("WT", "Mut"))
  )
  tcga <- tcga[complete.cases(tcga) & tcga$time > 0, , drop = FALSE]
  fab_counts_before <- table(tcga$FAB)
  tcga$FAB <- as.character(tcga$FAB)
  rare_fab <- names(fab_counts_before)[fab_counts_before < 5L]
  tcga$FAB[tcga$FAB %in% rare_fab] <- "Other"
  tcga$FAB <- factor(tcga$FAB)
  rownames(tcga) <- tcga$sample_id

  target <- data.frame(
    sample_id = target_raw$sample_id,
    case_id = target_raw$case_id,
    time = as.numeric(target_raw$os_days),
    status = as.integer(target_raw$os_status),
    LCDI = lookup_score("TARGET_Val4", target_raw$sample_id),
    age = as.numeric(target_raw$age),
    cyto = factor(
      target_raw$cyto_risk,
      levels = c("Favorable", "Intermediate", "Adverse")
    ),
    FLT3 = factor(target_raw$FLT3, levels = c(0, 1), labels = c("WT", "Mut")),
    NPM1 = factor(target_raw$NPM1, levels = c(0, 1), labels = c("WT", "Mut")),
    CEBPA = factor(target_raw$CEBPA, levels = c(0, 1), labels = c("WT", "Mut"))
  )
  target <- target[complete.cases(target) & target$time > 0, , drop = FALSE]
  rownames(target) <- target$sample_id

  list(
    tcga = tcga,
    target = target,
    raw_n = c(TCGA = nrow(tcga_raw), TARGET = nrow(target_raw)),
    raw_events = c(
      TCGA = sum(tcga_raw$OS == 1L, na.rm = TRUE),
      TARGET = sum(target_raw$os_status == 1L, na.rm = TRUE)
    ),
    rare_fab = rare_fab,
    fab_counts_before = fab_counts_before
  )
}

metric_names <- c("C_index", "AUC_1yr", "AUC_3yr", "AUC_5yr")
times_eval <- c(365, 1095, 1825)

bootstrap_one_model <- function(
  data,
  formula,
  indices,
  cohort,
  model_id,
  apparent
) {
  rows <- vector("list", length(indices))
  for (b in seq_along(indices)) {
    if (b == 1L || b %% 100L == 0L || b == length(indices)) {
      cat(sprintf(
        "%s Model %s bootstrap %d/%d\n",
        cohort, model_id, b, length(indices)
      ))
    }

    idx <- indices[[b]]
    boot_data <- data[idx, , drop = FALSE]
    fit <- fit_cox(formula, boot_data)
    if (inherits(fit, "fit_error")) {
      rows[[b]] <- data.frame(
        cohort = cohort,
        model = model_id,
        iteration = b,
        unique_patients = length(unique(idx)),
        events_in_resample = sum(boot_data$status == 1L),
        fit_ok = FALSE,
        failure_reason = fit$message,
        C_boot = NA_real_,
        C_original = NA_real_,
        optimism_C = NA_real_,
        AUC_1yr_boot = NA_real_,
        AUC_1yr_original = NA_real_,
        optimism_AUC_1yr = NA_real_,
        AUC_3yr_boot = NA_real_,
        AUC_3yr_original = NA_real_,
        optimism_AUC_3yr = NA_real_,
        AUC_5yr_boot = NA_real_,
        AUC_5yr_original = NA_real_,
        optimism_AUC_5yr = NA_real_
      )
      next
    }

    lp_boot <- safe_lp(fit, boot_data)
    lp_original <- safe_lp(fit, data)
    c_boot <- safe_cindex(boot_data, lp_boot)
    c_original <- safe_cindex(data, lp_original)
    auc_boot <- safe_auc(boot_data, lp_boot, times_eval)
    auc_original <- safe_auc(data, lp_original, times_eval)

    rows[[b]] <- data.frame(
      cohort = cohort,
      model = model_id,
      iteration = b,
      unique_patients = length(unique(idx)),
      events_in_resample = sum(boot_data$status == 1L),
      fit_ok = TRUE,
      failure_reason = "",
      C_boot = c_boot,
      C_original = c_original,
      optimism_C = c_boot - c_original,
      AUC_1yr_boot = auc_boot[1],
      AUC_1yr_original = auc_original[1],
      optimism_AUC_1yr = auc_boot[1] - auc_original[1],
      AUC_3yr_boot = auc_boot[2],
      AUC_3yr_original = auc_original[2],
      optimism_AUC_3yr = auc_boot[2] - auc_original[2],
      AUC_5yr_boot = auc_boot[3],
      AUC_5yr_original = auc_original[3],
      optimism_AUC_5yr = auc_boot[3] - auc_original[3]
    )
  }

  detail <- do.call(rbind, rows)
  optimism_cols <- c(
    C_index = "optimism_C",
    AUC_1yr = "optimism_AUC_1yr",
    AUC_3yr = "optimism_AUC_3yr",
    AUC_5yr = "optimism_AUC_5yr"
  )

  summary_rows <- lapply(metric_names, function(metric) {
    opt <- detail[[optimism_cols[[metric]]]]
    opt <- opt[is.finite(opt)]
    corrected_distribution <- apparent[[metric]] - opt
    data.frame(
      cohort = cohort,
      model = model_id,
      metric = metric,
      apparent = apparent[[metric]],
      bootstrap_requested = length(indices),
      bootstrap_valid = length(opt),
      bootstrap_failed = length(indices) - length(opt),
      mean_optimism = if (length(opt)) mean(opt) else NA_real_,
      optimism_sd = if (length(opt) > 1L) stats::sd(opt) else NA_real_,
      optimism_se = if (length(opt) > 1L) {
        stats::sd(opt) / sqrt(length(opt))
      } else {
        NA_real_
      },
      optimism_corrected = if (length(opt)) {
        apparent[[metric]] - mean(opt)
      } else {
        NA_real_
      },
      corrected_distribution_p025 = if (length(opt)) {
        as.numeric(stats::quantile(corrected_distribution, 0.025, na.rm = TRUE))
      } else {
        NA_real_
      },
      corrected_distribution_p500 = if (length(opt)) {
        as.numeric(stats::quantile(corrected_distribution, 0.500, na.rm = TRUE))
      } else {
        NA_real_
      },
      corrected_distribution_p975 = if (length(opt)) {
        as.numeric(stats::quantile(corrected_distribution, 0.975, na.rm = TRUE))
      } else {
        NA_real_
      },
      stringsAsFactors = FALSE
    )
  })

  list(detail = detail, summary = do.call(rbind, summary_rows))
}

apparent_metrics <- function(data, formula, cohort, model_id) {
  fit <- fit_cox(formula, data)
  if (inherits(fit, "fit_error")) {
    stop(sprintf(
      "Full-data model failed: %s Model %s: %s",
      cohort, model_id, fit$message
    ))
  }
  lp <- safe_lp(fit, data)
  auc <- safe_auc(data, lp, times_eval)
  metrics <- c(
    C_index = unname(safe_cindex(data, lp)),
    AUC_1yr = unname(auc[1]),
    AUC_3yr = unname(auc[2]),
    AUC_5yr = unname(auc[3])
  )
  coef_table <- data.frame(
    cohort = cohort,
    model = model_id,
    term = names(stats::coef(fit)),
    coefficient = as.numeric(stats::coef(fit)),
    hazard_ratio = exp(as.numeric(stats::coef(fit))),
    stringsAsFactors = FALSE
  )
  list(fit = fit, metrics = metrics, coefficients = coef_table)
}

run_calibration <- function(
  data,
  formula,
  cohort,
  time_days,
  B_cal,
  seed,
  m
) {
  dd_bootstrap_cal <- rms::datadist(data)
  assign("dd_bootstrap_cal", dd_bootstrap_cal, envir = .GlobalEnv)
  old_datadist <- getOption("datadist")
  options(datadist = "dd_bootstrap_cal")
  on.exit({
    options(datadist = old_datadist)
    if (exists("dd_bootstrap_cal", envir = .GlobalEnv, inherits = FALSE)) {
      rm("dd_bootstrap_cal", envir = .GlobalEnv)
    }
  }, add = TRUE)

  fit <- rms::cph(
    formula,
    data = data,
    x = TRUE,
    y = TRUE,
    surv = TRUE,
    time.inc = time_days
  )
  set.seed(seed)
  cal <- rms::calibrate(
    fit,
    cmethod = "KM",
    method = "boot",
    u = time_days,
    m = m,
    B = B_cal,
    pr = FALSE
  )

  year <- time_days / 365
  cal_df <- as.data.frame(unclass(cal))
  cal_df$cohort <- cohort
  cal_df$year <- year
  cal_df$bootstrap_requested <- B_cal
  cal_df$group_size_target <- m
  cal_df$curve_row <- seq_len(nrow(cal_df))

  stem <- sprintf(
    "calibration_%s_%dyr_B%d",
    tolower(cohort),
    as.integer(year),
    B_cal
  )
  saveRDS(
    list(fit = fit, calibration = cal),
    file.path(out_dir, paste0(stem, ".rds"))
  )
  write_tsv(cal_df, file.path(out_dir, paste0(stem, ".tsv")))

  draw_calibration <- function() {
    plot(
      cal,
      xlab = sprintf("Predicted %d-Year Survival", as.integer(year)),
      ylab = sprintf("Observed %d-Year Survival", as.integer(year)),
      subtitles = FALSE,
      col = if (cohort == "TCGA") "#C0392B" else "#6C3483",
      lwd = 2
    )
    abline(0, 1, lty = 2, col = "gray35")
    title(main = sprintf(
      "%s Model D: Bootstrap-Corrected Calibration",
      cohort
    ))
    mtext(sprintf(
      "Patient-level bootstrap with replacement; B=%d",
      B_cal
    ), side = 3, line = 0.15, cex = 0.75)
  }

  grDevices::pdf(
    file.path(out_dir, paste0(stem, ".pdf")),
    width = 6.5,
    height = 6.5
  )
  draw_calibration()
  grDevices::dev.off()

  grDevices::png(
    file.path(out_dir, paste0(stem, ".png")),
    width = 1600,
    height = 1600,
    res = 240
  )
  draw_calibration()
  grDevices::dev.off()

  cal_df
}

run_rms_validate <- function(data, formula, cohort, B_validate, seed) {
  dd_bootstrap_val <- rms::datadist(data)
  assign("dd_bootstrap_val", dd_bootstrap_val, envir = .GlobalEnv)
  old_datadist <- getOption("datadist")
  options(datadist = "dd_bootstrap_val")
  on.exit({
    options(datadist = old_datadist)
    if (exists("dd_bootstrap_val", envir = .GlobalEnv, inherits = FALSE)) {
      rm("dd_bootstrap_val", envir = .GlobalEnv)
    }
  }, add = TRUE)

  fit <- rms::cph(
    formula,
    data = data,
    x = TRUE,
    y = TRUE,
    surv = TRUE,
    time.inc = 365
  )
  set.seed(seed)
  val <- rms::validate(
    fit,
    method = "boot",
    B = B_validate,
    dxy = TRUE,
    pr = FALSE
  )
  val_df <- data.frame(
    cohort = cohort,
    index = rownames(val),
    as.data.frame(unclass(val)),
    row.names = NULL,
    check.names = FALSE
  )
  saveRDS(
    list(fit = fit, validation = val),
    file.path(
      out_dir,
      sprintf("rms_validate_%s_modelD_B%d.rds", tolower(cohort), B_validate)
    )
  )
  write_tsv(
    val_df,
    file.path(
      out_dir,
      sprintf("rms_validate_%s_modelD_B%d.tsv", tolower(cohort), B_validate)
    )
  )
  val_df
}

predict_survival_at <- function(fit, newdata, time_days) {
  baseline <- tryCatch(
    survival::basehaz(fit, centered = FALSE),
    error = function(e) NULL
  )
  if (is.null(baseline) || !nrow(baseline)) {
    return(rep(NA_real_, nrow(newdata)))
  }
  eligible <- baseline$time <= time_days
  cumulative_hazard <- if (any(eligible)) {
    max(baseline$hazard[eligible], na.rm = TRUE)
  } else {
    0
  }
  lp <- safe_lp(fit, newdata)
  prediction <- exp(-cumulative_hazard * exp(lp))
  prediction[!is.finite(prediction)] <- NA_real_
  pmin(1, pmax(0, prediction))
}

km_survival_at <- function(data, time_days) {
  fit <- tryCatch(
    survival::survfit(Surv(time, status) ~ 1, data = data),
    error = function(e) NULL
  )
  if (is.null(fit)) {
    return(c(survival = NA_real_, standard_error = NA_real_))
  }
  sm <- tryCatch(
    summary(fit, times = time_days, extend = TRUE),
    error = function(e) NULL
  )
  if (is.null(sm) || !length(sm$surv)) {
    return(c(survival = NA_real_, standard_error = NA_real_))
  }
  c(
    survival = as.numeric(sm$surv[1]),
    standard_error = if (length(sm$std.err)) as.numeric(sm$std.err[1]) else NA_real_
  )
}

grouped_calibration <- function(data, predicted_survival, time_days, groups) {
  ok <- is.finite(predicted_survival)
  d <- data[ok, , drop = FALSE]
  p <- predicted_survival[ok]
  if (length(p) < groups * 5L) {
    return(NULL)
  }
  ranks <- rank(p, ties.method = "first")
  group_id <- pmin(groups, ceiling(ranks / length(ranks) * groups))
  rows <- lapply(seq_len(groups), function(g) {
    use <- group_id == g
    km <- km_survival_at(d[use, , drop = FALSE], time_days)
    data.frame(
      group = g,
      n = sum(use),
      events = sum(d$status[use] == 1L),
      mean_predicted = mean(p[use]),
      observed_km = unname(km["survival"]),
      observed_km_se = unname(km["standard_error"]),
      stringsAsFactors = FALSE
    )
  })
  curve <- do.call(rbind, rows)
  curve <- curve[
    is.finite(curve$mean_predicted) & is.finite(curve$observed_km),
    ,
    drop = FALSE
  ]
  if (nrow(curve) < 2L) {
    return(NULL)
  }
  curve <- curve[order(curve$mean_predicted), , drop = FALSE]
  weights <- curve$n / sum(curve$n)
  list(
    curve = curve,
    ICI = sum(weights * abs(curve$observed_km - curve$mean_predicted)),
    Emax = max(abs(curve$observed_km - curve$mean_predicted))
  )
}

interpolate_observed <- function(curve, grid) {
  tryCatch(
    stats::approx(
      x = curve$mean_predicted,
      y = curve$observed_km,
      xout = grid,
      rule = 2,
      ties = mean
    )$y,
    error = function(e) rep(NA_real_, length(grid))
  )
}

run_grouped_bootstrap_calibration <- function(
  data,
  formula,
  indices,
  cohort,
  B_cal,
  groups
) {
  full_fit <- fit_cox(formula, data)
  if (inherits(full_fit, "fit_error")) {
    stop(sprintf("%s full Model D calibration fit failed", cohort))
  }

  curve_outputs <- list()
  metric_outputs <- list()
  iteration_outputs <- list()

  for (j in seq_along(times_eval)) {
    time_days <- times_eval[j]
    year <- as.integer(time_days / 365)
    apparent_prediction <- predict_survival_at(full_fit, data, time_days)
    apparent <- grouped_calibration(
      data,
      apparent_prediction,
      time_days,
      groups
    )
    if (is.null(apparent)) {
      stop(sprintf("%s %d-year apparent calibration failed", cohort, year))
    }

    grid <- apparent$curve$mean_predicted
    optimism_curve <- matrix(
      NA_real_,
      nrow = B_cal,
      ncol = length(grid)
    )
    iteration_rows <- vector("list", B_cal)

    for (b in seq_len(B_cal)) {
      if (b == 1L || b %% 100L == 0L || b == B_cal) {
        cat(sprintf(
          "%s Model D grouped calibration %d-year %d/%d\n",
          cohort, year, b, B_cal
        ))
      }
      idx <- indices[[b]]
      boot_data <- data[idx, , drop = FALSE]
      fit <- fit_cox(formula, boot_data)
      if (inherits(fit, "fit_error")) {
        iteration_rows[[b]] <- data.frame(
          cohort = cohort,
          year = year,
          iteration = b,
          fit_ok = FALSE,
          failure_reason = fit$message,
          ICI_boot = NA_real_,
          ICI_original = NA_real_,
          optimism_ICI = NA_real_,
          Emax_boot = NA_real_,
          Emax_original = NA_real_,
          optimism_Emax = NA_real_,
          stringsAsFactors = FALSE
        )
        next
      }

      pred_boot <- predict_survival_at(fit, boot_data, time_days)
      pred_original <- predict_survival_at(fit, data, time_days)
      cal_boot <- grouped_calibration(
        boot_data, pred_boot, time_days, groups
      )
      cal_original <- grouped_calibration(
        data, pred_original, time_days, groups
      )
      if (is.null(cal_boot) || is.null(cal_original)) {
        iteration_rows[[b]] <- data.frame(
          cohort = cohort,
          year = year,
          iteration = b,
          fit_ok = FALSE,
          failure_reason = "grouped calibration failed",
          ICI_boot = NA_real_,
          ICI_original = NA_real_,
          optimism_ICI = NA_real_,
          Emax_boot = NA_real_,
          Emax_original = NA_real_,
          optimism_Emax = NA_real_,
          stringsAsFactors = FALSE
        )
        next
      }

      observed_boot <- interpolate_observed(cal_boot$curve, grid)
      observed_original <- interpolate_observed(cal_original$curve, grid)
      optimism_curve[b, ] <- observed_boot - observed_original
      iteration_rows[[b]] <- data.frame(
        cohort = cohort,
        year = year,
        iteration = b,
        fit_ok = TRUE,
        failure_reason = "",
        ICI_boot = cal_boot$ICI,
        ICI_original = cal_original$ICI,
        optimism_ICI = cal_boot$ICI - cal_original$ICI,
        Emax_boot = cal_boot$Emax,
        Emax_original = cal_original$Emax,
        optimism_Emax = cal_boot$Emax - cal_original$Emax,
        stringsAsFactors = FALSE
      )
    }

    iteration_table <- do.call(rbind, iteration_rows)
    iteration_outputs[[length(iteration_outputs) + 1L]] <- iteration_table
    valid_curve <- rowSums(is.finite(optimism_curve)) == ncol(optimism_curve)
    corrected_curve_distribution <- sweep(
      optimism_curve[valid_curve, , drop = FALSE],
      2,
      apparent$curve$observed_km,
      FUN = function(opt, app) app - opt
    )
    corrected_curve_distribution <- matrix(
      pmin(1, pmax(0, as.numeric(corrected_curve_distribution))),
      nrow = sum(valid_curve),
      ncol = length(grid)
    )
    corrected_curve <- pmin(
      1,
      pmax(
        0,
        apparent$curve$observed_km -
          colMeans(optimism_curve[valid_curve, , drop = FALSE])
      )
    )
    curve_table <- data.frame(
      cohort = cohort,
      year = year,
      group = apparent$curve$group,
      n = apparent$curve$n,
      events = apparent$curve$events,
      mean_predicted = apparent$curve$mean_predicted,
      apparent_observed_km = apparent$curve$observed_km,
      apparent_observed_km_se = apparent$curve$observed_km_se,
      bootstrap_valid = sum(valid_curve),
      mean_optimism_observed = colMeans(
        optimism_curve[valid_curve, , drop = FALSE]
      ),
      optimism_corrected_observed = corrected_curve,
      corrected_distribution_p025 = apply(
        corrected_curve_distribution,
        2,
        quantile,
        probs = 0.025,
        na.rm = TRUE
      ),
      corrected_distribution_p500 = apply(
        corrected_curve_distribution,
        2,
        quantile,
        probs = 0.500,
        na.rm = TRUE
      ),
      corrected_distribution_p975 = apply(
        corrected_curve_distribution,
        2,
        quantile,
        probs = 0.975,
        na.rm = TRUE
      ),
      stringsAsFactors = FALSE
    )
    curve_outputs[[length(curve_outputs) + 1L]] <- curve_table

    metric_rows <- lapply(c("ICI", "Emax"), function(metric) {
      optimism <- iteration_table[[paste0("optimism_", metric)]]
      optimism <- optimism[is.finite(optimism)]
      apparent_value <- apparent[[metric]]
      corrected_distribution <- pmin(
        1,
        pmax(0, apparent_value - optimism)
      )
      data.frame(
        cohort = cohort,
        year = year,
        metric = metric,
        apparent = apparent_value,
        bootstrap_requested = B_cal,
        bootstrap_valid = length(optimism),
        bootstrap_failed = B_cal - length(optimism),
        mean_optimism = mean(optimism),
        optimism_corrected = apparent_value - mean(optimism),
        corrected_distribution_p025 = as.numeric(
          quantile(corrected_distribution, 0.025)
        ),
        corrected_distribution_p500 = as.numeric(
          quantile(corrected_distribution, 0.500)
        ),
        corrected_distribution_p975 = as.numeric(
          quantile(corrected_distribution, 0.975)
        ),
        stringsAsFactors = FALSE
      )
    })
    metric_outputs[[length(metric_outputs) + 1L]] <- do.call(
      rbind,
      metric_rows
    )

    draw_calibration <- function() {
      plot(
        c(0, 1),
        c(0, 1),
        type = "n",
        xlab = sprintf("Predicted %d-Year Survival", year),
        ylab = sprintf("Observed %d-Year Survival", year),
        main = sprintf(
          "%s Model D: Bootstrap-Corrected Calibration",
          cohort
        ),
        xlim = c(0, 1),
        ylim = c(0, 1)
      )
      abline(0, 1, lty = 2, col = "gray35")
      lines(
        curve_table$mean_predicted,
        curve_table$apparent_observed_km,
        type = "b",
        pch = 1,
        lty = 3,
        col = "gray45"
      )
      lines(
        curve_table$mean_predicted,
        curve_table$optimism_corrected_observed,
        type = "b",
        pch = 16,
        lwd = 2,
        col = if (cohort == "TCGA") "#C0392B" else "#6C3483"
      )
      legend(
        "topleft",
        legend = c("Ideal", "Apparent", "Optimism-corrected"),
        lty = c(2, 3, 1),
        pch = c(NA, 1, 16),
        col = c("gray35", "gray45", if (cohort == "TCGA") "#C0392B" else "#6C3483"),
        bty = "n"
      )
      mtext(
        sprintf(
          "Patient bootstrap with replacement; B=%d; grouped KM",
          B_cal
        ),
        side = 3,
        line = 0.15,
        cex = 0.72
      )
    }

    stem <- sprintf(
      "calibration_%s_%dyr_B%d",
      tolower(cohort),
      year,
      B_cal
    )
    grDevices::pdf(
      file.path(out_dir, paste0(stem, ".pdf")),
      width = 6.5,
      height = 6.5
    )
    draw_calibration()
    grDevices::dev.off()
    grDevices::png(
      file.path(out_dir, paste0(stem, ".png")),
      width = 1600,
      height = 1600,
      res = 240
    )
    draw_calibration()
    grDevices::dev.off()
  }

  list(
    curves = do.call(rbind, curve_outputs),
    metrics = do.call(rbind, metric_outputs),
    iterations = do.call(rbind, iteration_outputs)
  )
}

make_comparison_table <- function(all_detail, all_summary, cohort) {
  cohort_detail <- all_detail[all_detail$cohort == cohort, , drop = FALSE]
  cohort_summary <- all_summary[all_summary$cohort == cohort, , drop = FALSE]
  comparisons <- c("D-A", "D-B", "D-C")
  out <- list()

  for (comparison in comparisons) {
    parts <- strsplit(comparison, "-", fixed = TRUE)[[1]]
    high <- parts[1]
    low <- parts[2]
    d_high <- cohort_detail[cohort_detail$model == high, , drop = FALSE]
    d_low <- cohort_detail[cohort_detail$model == low, , drop = FALSE]
    merged <- merge(
      d_high,
      d_low,
      by = c("cohort", "iteration"),
      suffixes = c("_high", "_low")
    )

    for (metric in metric_names) {
      opt_col <- switch(
        metric,
        C_index = "optimism_C",
        AUC_1yr = "optimism_AUC_1yr",
        AUC_3yr = "optimism_AUC_3yr",
        AUC_5yr = "optimism_AUC_5yr"
      )
      apparent_high <- cohort_summary$apparent[
        cohort_summary$model == high & cohort_summary$metric == metric
      ]
      apparent_low <- cohort_summary$apparent[
        cohort_summary$model == low & cohort_summary$metric == metric
      ]
      opt_diff <- merged[[paste0(opt_col, "_high")]] -
        merged[[paste0(opt_col, "_low")]]
      ok <- is.finite(opt_diff)
      corrected_diff_distribution <-
        (apparent_high - apparent_low) - opt_diff[ok]

      out[[length(out) + 1L]] <- data.frame(
        cohort = cohort,
        comparison = comparison,
        metric = metric,
        apparent_difference = apparent_high - apparent_low,
        paired_bootstrap_valid = sum(ok),
        mean_difference_in_optimism = if (any(ok)) mean(opt_diff[ok]) else NA_real_,
        optimism_corrected_difference = if (any(ok)) {
          (apparent_high - apparent_low) - mean(opt_diff[ok])
        } else {
          NA_real_
        },
        corrected_difference_p025 = if (any(ok)) {
          as.numeric(quantile(corrected_diff_distribution, 0.025))
        } else {
          NA_real_
        },
        corrected_difference_p500 = if (any(ok)) {
          as.numeric(quantile(corrected_diff_distribution, 0.500))
        } else {
          NA_real_
        },
        corrected_difference_p975 = if (any(ok)) {
          as.numeric(quantile(corrected_diff_distribution, 0.975))
        } else {
          NA_real_
        },
        stringsAsFactors = FALSE
      )
    }
  }
  do.call(rbind, out)
}

B_data <- readRDS(input_path)
prepared <- prepare_data(B_data)
tcga <- prepared$tcga
target <- prepared$target

stopifnot(
  nrow(tcga) == 145L,
  sum(tcga$status == 1L) == 89L,
  nrow(target) == 1857L,
  sum(target$status == 1L) == 672L,
  all(tcga$status %in% c(0L, 1L)),
  all(target$status %in% c(0L, 1L)),
  !anyDuplicated(tcga$sample_id),
  !anyDuplicated(target$sample_id)
)

cohort_qc <- data.frame(
  cohort = c("TCGA", "TARGET"),
  raw_n = as.integer(prepared$raw_n[c("TCGA", "TARGET")]),
  raw_events = as.integer(prepared$raw_events[c("TCGA", "TARGET")]),
  complete_case_n = c(nrow(tcga), nrow(target)),
  complete_case_events = c(sum(tcga$status), sum(target$status)),
  censored = c(sum(tcga$status == 0L), sum(target$status == 0L)),
  duplicate_sample_id = c(
    sum(duplicated(tcga$sample_id)),
    sum(duplicated(target$sample_id))
  ),
  invalid_survival_time = c(
    sum(!is.finite(tcga$time) | tcga$time <= 0),
    sum(!is.finite(target$time) | target$time <= 0)
  ),
  remaining_na = c(sum(is.na(tcga)), sum(is.na(target))),
  stringsAsFactors = FALSE
)
write_tsv(cohort_qc, file.path(out_dir, "cohort_qc.tsv"))

factor_counts <- rbind(
  data.frame(
    cohort = "TCGA",
    variable = "FAB",
    level = names(table(tcga$FAB)),
    n = as.integer(table(tcga$FAB))
  ),
  data.frame(
    cohort = "TCGA",
    variable = "cyto",
    level = names(table(tcga$cyto)),
    n = as.integer(table(tcga$cyto))
  ),
  data.frame(
    cohort = "TCGA",
    variable = "FLT3",
    level = names(table(tcga$FLT3)),
    n = as.integer(table(tcga$FLT3))
  ),
  data.frame(
    cohort = "TCGA",
    variable = "NPM1",
    level = names(table(tcga$NPM1)),
    n = as.integer(table(tcga$NPM1))
  ),
  data.frame(
    cohort = "TCGA",
    variable = "CEBPA",
    level = names(table(tcga$CEBPA)),
    n = as.integer(table(tcga$CEBPA))
  ),
  data.frame(
    cohort = "TARGET",
    variable = "cyto",
    level = names(table(target$cyto)),
    n = as.integer(table(target$cyto))
  ),
  data.frame(
    cohort = "TARGET",
    variable = "FLT3",
    level = names(table(target$FLT3)),
    n = as.integer(table(target$FLT3))
  ),
  data.frame(
    cohort = "TARGET",
    variable = "NPM1",
    level = names(table(target$NPM1)),
    n = as.integer(table(target$NPM1))
  ),
  data.frame(
    cohort = "TARGET",
    variable = "CEBPA",
    level = names(table(target$CEBPA)),
    n = as.integer(table(target$CEBPA))
  )
)
write_tsv(factor_counts, file.path(out_dir, "factor_level_counts.tsv"))

models <- list(
  TCGA = list(
    A = Surv(time, status) ~ LCDI,
    B = Surv(time, status) ~ LCDI + age + FAB,
    C = Surv(time, status) ~ LCDI + age + FAB + cyto,
    D = Surv(time, status) ~ LCDI + age + FAB + cyto + FLT3 + NPM1 + CEBPA
  ),
  TARGET = list(
    A = Surv(time, status) ~ LCDI,
    B = Surv(time, status) ~ LCDI + age,
    C = Surv(time, status) ~ LCDI + age + cyto,
    D = Surv(time, status) ~ LCDI + age + cyto + FLT3 + NPM1 + CEBPA
  )
)

model_definitions <- do.call(
  rbind,
  lapply(names(models), function(cohort) {
    do.call(
      rbind,
      lapply(names(models[[cohort]]), function(model_id) {
        data.frame(
          cohort = cohort,
          model = model_id,
          formula = paste(deparse(models[[cohort]][[model_id]]), collapse = " "),
          complete_case_rule = "Model D variables complete; identical patients for A-D",
          selection_inside_bootstrap = FALSE,
          stringsAsFactors = FALSE
        )
      })
    )
  })
)
write_tsv(model_definitions, file.path(out_dir, "model_definitions.tsv"))

set.seed(base_seed + 1000L)
tcga_indices <- replicate(
  B,
  sample.int(nrow(tcga), nrow(tcga), replace = TRUE),
  simplify = FALSE
)
set.seed(base_seed + 2000L)
target_indices <- replicate(
  B,
  sample.int(nrow(target), nrow(target), replace = TRUE),
  simplify = FALSE
)

bootstrap_sample_qc <- rbind(
  data.frame(
    cohort = "TCGA",
    iteration = seq_len(B),
    unique_patients = vapply(tcga_indices, function(i) length(unique(i)), integer(1)),
    events_in_resample = vapply(
      tcga_indices,
      function(i) sum(tcga$status[i] == 1L),
      integer(1)
    )
  ),
  data.frame(
    cohort = "TARGET",
    iteration = seq_len(B),
    unique_patients = vapply(target_indices, function(i) length(unique(i)), integer(1)),
    events_in_resample = vapply(
      target_indices,
      function(i) sum(target$status[i] == 1L),
      integer(1)
    )
  )
)
write_tsv(bootstrap_sample_qc, file.path(out_dir, "bootstrap_sample_qc.tsv"))

all_detail <- list()
all_summary <- list()
all_coefficients <- list()
full_fits <- list(TCGA = list(), TARGET = list())

for (cohort in c("TCGA", "TARGET")) {
  data <- if (cohort == "TCGA") tcga else target
  indices <- if (cohort == "TCGA") tcga_indices else target_indices

  for (model_id in names(models[[cohort]])) {
    formula <- models[[cohort]][[model_id]]
    cat("\n", cohort, " Model ", model_id, " apparent fit\n", sep = "")
    apparent <- apparent_metrics(data, formula, cohort, model_id)
    full_fits[[cohort]][[model_id]] <- apparent$fit
    all_coefficients[[length(all_coefficients) + 1L]] <- apparent$coefficients

    checkpoint_path <- file.path(
      out_dir,
      sprintf("checkpoint_%s_model%s.rds", tolower(cohort), model_id)
    )
    if (resume_performance && file.exists(checkpoint_path)) {
      checkpoint_existing <- readRDS(checkpoint_path)
      stopifnot(
        identical(checkpoint_existing$cohort, cohort),
        identical(checkpoint_existing$model, model_id),
        nrow(checkpoint_existing$detail) == B,
        all(checkpoint_existing$detail$iteration == seq_len(B))
      )
      boot <- list(
        detail = checkpoint_existing$detail,
        summary = checkpoint_existing$summary
      )
      cat(sprintf(
        "%s Model %s: resumed %d validated bootstrap iterations\n",
        cohort, model_id, nrow(boot$detail)
      ))
    } else {
      boot <- bootstrap_one_model(
        data = data,
        formula = formula,
        indices = indices,
        cohort = cohort,
        model_id = model_id,
        apparent = apparent$metrics
      )
    }
    all_detail[[length(all_detail) + 1L]] <- boot$detail
    all_summary[[length(all_summary) + 1L]] <- boot$summary

    checkpoint <- list(
      cohort = cohort,
      model = model_id,
      apparent = apparent$metrics,
      detail = boot$detail,
      summary = boot$summary
    )
    saveRDS(
      checkpoint,
      checkpoint_path
    )
  }
}

all_detail <- do.call(rbind, all_detail)
all_summary <- do.call(rbind, all_summary)
all_coefficients <- do.call(rbind, all_coefficients)

write_tsv(all_detail, file.path(out_dir, "bootstrap_iterations_all_models.tsv"))
write_tsv(all_summary, file.path(out_dir, "bootstrap_optimism_corrected_performance.tsv"))
write_tsv(all_coefficients, file.path(out_dir, "apparent_model_coefficients.tsv"))

comparison_table <- rbind(
  make_comparison_table(all_detail, all_summary, "TCGA"),
  make_comparison_table(all_detail, all_summary, "TARGET")
)
write_tsv(
  comparison_table,
  file.path(out_dir, "bootstrap_model_comparisons.tsv")
)

cat("\nRunning grouped-KM bootstrap-corrected calibration for Model D\n")
tcga_calibration <- run_grouped_bootstrap_calibration(
  data = tcga,
  formula = models$TCGA$D,
  indices = tcga_indices,
  cohort = "TCGA",
  B_cal = cal_B,
  groups = 4L
)
target_calibration <- run_grouped_bootstrap_calibration(
  data = target,
  formula = models$TARGET$D,
  indices = target_indices,
  cohort = "TARGET",
  B_cal = cal_B,
  groups = 5L
)
calibration_curves <- rbind(
  tcga_calibration$curves,
  target_calibration$curves
)
calibration_metrics <- rbind(
  tcga_calibration$metrics,
  target_calibration$metrics
)
calibration_iterations <- rbind(
  tcga_calibration$iterations,
  target_calibration$iterations
)
write_tsv(
  calibration_curves,
  file.path(out_dir, "calibration_modelD_curves.tsv")
)
write_tsv(
  calibration_metrics,
  file.path(out_dir, "calibration_modelD_metrics.tsv")
)
write_tsv(
  calibration_iterations,
  file.path(out_dir, "calibration_modelD_iterations.tsv")
)

saveRDS(
  list(
    metadata = list(
      run_mode = run_mode,
      B = B,
      calibration_B = cal_B,
      base_seed = base_seed,
      resume_performance = resume_performance,
      times_eval = times_eval,
      input_path = input_path,
      score_path = score_path,
      created = format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
      fixed_candidate_models = TRUE,
      variable_selection_repeated = FALSE
    ),
    cohort_qc = cohort_qc,
    model_definitions = model_definitions,
    full_fits = full_fits,
    performance = all_summary,
    comparisons = comparison_table,
    calibration_curves = calibration_curves,
    calibration_metrics = calibration_metrics
  ),
  file.path(out_dir, "true_bootstrap_nomogram_results.rds")
)

method_record <- data.frame(
  field = c(
    "sampling_unit",
    "sampling_replacement",
    "resample_size",
    "bootstrap_iterations",
    "calibration_iterations",
    "base_seed",
    "validation_method",
    "optimism_definition",
    "corrected_metric",
    "model_comparison_population",
    "candidate_model_status",
    "variable_selection_repeated",
    "time_points_days",
    "censoring_AUC",
    "software",
    "LCDI_score_source"
    ,"resume_performance_checkpoints"
  ),
  value = c(
    "patient",
    "TRUE",
    "N within cohort",
    as.character(B),
    as.character(cal_B),
    as.character(base_seed),
    "Harrell patient-level bootstrap optimism correction",
    "performance in bootstrap sample minus performance on original sample using bootstrap-fitted model",
    "full-data apparent performance minus mean optimism",
    "identical Model-D complete cases for Models A-D within each cohort",
    "fixed candidate models; no data-driven variable selection in this run",
    "FALSE",
    paste(times_eval, collapse = ","),
    "timeROC marginal IPCW",
    paste0(
      "R ", getRversion(),
      "; survival ", packageVersion("survival"),
      "; timeROC ", packageVersion("timeROC")
    ),
    "10_final_tcga_target_scores.tsv; TCGA uses GPL96 training mean/SD and frozen beta; TARGET uses within-cohort gene z-score and frozen beta",
    as.character(resume_performance)
  ),
  stringsAsFactors = FALSE
)
write_tsv(method_record, file.path(out_dir, "method_record.tsv"))

capture.output(
  sessionInfo(),
  file = file.path(out_dir, "session_info.txt")
)

run_status <- data.frame(
  field = c(
    "status",
    "run_mode",
    "start_or_end_time",
    "bootstrap_requested_per_model",
    "calibration_requested_per_timepoint",
    "tcga_n",
    "tcga_events",
    "target_n",
    "target_events",
    "source_files_modified",
    "historical_results_overwritten",
    "word_modified"
  ),
  value = c(
    "passed",
    run_mode,
    format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
    B,
    cal_B,
    nrow(tcga),
    sum(tcga$status),
    nrow(target),
    sum(target$status),
    0,
    0,
    0
  )
)
write_tsv(run_status, file.path(out_dir, "run_status.tsv"))

cat("\nCompleted:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Status: passed\n")
cat("Source files modified: 0\n")
cat("Historical results overwritten: 0\n")
cat("Word modified: 0\n")

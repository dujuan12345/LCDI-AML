options(stringsAsFactors = FALSE)
suppressPackageStartupMessages(library(survival))

root <- "D:/26_01_AML/_codex_audit/cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram/final"
obj <- readRDS(file.path(root, "true_bootstrap_nomogram_results.rds"))

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
}

coef_rows <- list()
for (cohort in names(obj$full_fits)) {
  for (model in names(obj$full_fits[[cohort]])) {
    fit <- obj$full_fits[[cohort]][[model]]
    ss <- summary(fit)$coefficients
    ci <- exp(confint(fit))
    coef_rows[[length(coef_rows) + 1L]] <- data.frame(
      cohort = cohort,
      model = model,
      term = rownames(ss),
      coefficient = ss[, "coef"],
      hazard_ratio = ss[, "exp(coef)"],
      ci_low = ci[, 1],
      ci_high = ci[, 2],
      wald_p = ss[, "Pr(>|z|)"],
      stringsAsFactors = FALSE
    )
  }
}
coef_table <- do.call(rbind, coef_rows)
write_tsv(coef_table, file.path(root, "nomogram_coefficient_inference.tsv"))

lrt_rows <- list()
for (cohort in names(obj$full_fits)) {
  models <- obj$full_fits[[cohort]]
  pairs <- list(c("A", "B"), c("B", "C"), c("C", "D"), c("A", "D"))
  for (pair in pairs) {
    a <- anova(models[[pair[1]]], models[[pair[2]]], test = "LRT")
    lrt_rows[[length(lrt_rows) + 1L]] <- data.frame(
      cohort = cohort,
      comparison = paste0(pair[2], "-", pair[1]),
      chisq = a$Chisq[2],
      df = a$Df[2],
      p_value = a$`Pr(>|Chi|)`[2],
      stringsAsFactors = FALSE
    )
  }
}
lrt_table <- do.call(rbind, lrt_rows)
write_tsv(lrt_table, file.path(root, "nomogram_nested_lrt.tsv"))

print(as.data.frame(coef_table[coef_table$term == "LCDI", ]))
print(as.data.frame(lrt_table))

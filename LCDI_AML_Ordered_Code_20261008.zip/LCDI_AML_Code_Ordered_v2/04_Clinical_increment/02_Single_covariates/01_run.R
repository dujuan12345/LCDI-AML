options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages(library(survival))
suppressPackageStartupMessages(library(timeROC))
root <- 'D:/26_01_AML';out_dir <- file.path(root,'_codex_audit/single_covariate_increment_20260907_v1')
origin <- file.path(root,'_codex_audit/cindex_nomogram_reconciliation_20260902_v1');cache <- file.path(origin,'final_branch_nomogram/final')
stopifnot(!file.exists(file.path(out_dir,'COMPLETE.txt')))
score_path <- file.path(origin,'10_final_tcga_target_scores.tsv')
input_path <- file.path(root,'AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds')
metric_names <- c('C_index','AUC_1yr','AUC_3yr','AUC_5yr');times_eval <- c(365,1095,1825)
needed <- c('write_tsv','safe_cindex','safe_auc','fit_cox','safe_lp','prepare_data','bootstrap_one_model','apparent_metrics')
loaded <- character()
for(ex in parse(file.path(origin,'11_recalculate_final_branch_nomogram.R'))){
 if(is.call(ex) && identical(ex[[1]],as.name('<-')) && is.symbol(ex[[2]]) && as.character(ex[[2]]) %in% needed && is.call(ex[[3]]) && identical(ex[[3]][[1]],as.name('function'))){eval(ex);loaded <- c(loaded,as.character(ex[[2]]))}
}
stopifnot(setequal(needed,loaded))
prepared <- prepare_data(readRDS(input_path));old <- readRDS(file.path(cache,'true_bootstrap_nomogram_results.rds'))
old_iterations <- read.delim(file.path(cache,'bootstrap_iterations_all_models.tsv'),check.names=FALSE)
old_performance <- read.delim(file.path(cache,'bootstrap_optimism_corrected_performance.tsv'),check.names=FALSE)
sample_qc <- read.delim(file.path(cache,'bootstrap_sample_qc.tsv'),check.names=FALSE)
# Fixed scope before examining results: TCGA six covariates, TARGET five (FAB not included).
# Same E/F complete cases, same paired patient resamples, no variable selection.
variables <- list(TCGA=c('age','FAB','cyto','FLT3','NPM1','CEBPA'),TARGET=c('age','cyto','FLT3','NPM1','CEBPA'))
performance <- list();details <- list();comparisons <- list();tests <- list();inputs <- list();coefficients <- list();defs <- list();qc <- list()
oc <- c(C_index='optimism_C',AUC_1yr='optimism_AUC_1yr',AUC_3yr='optimism_AUC_3yr',AUC_5yr='optimism_AUC_5yr')
for(cohort in names(variables)){
 d <- prepared[[tolower(cohort)]];n <- nrow(d);events <- sum(d$status==1L)
 stopifnot(n==if(cohort=='TCGA')145 else 1857,events==if(cohort=='TCGA')89 else 672,!anyDuplicated(d$sample_id))
 full <- old$full_fits[[cohort]]$D;stopifnot(identical(rownames(full$model),rownames(d)))
 stopifnot(max(abs(full$y[,1]-d$time))<1e-9,all(full$y[,2]==d$status))
 lp <- safe_lp(full,d);actual <- c(C_index=safe_cindex(d,lp),setNames(safe_auc(d,lp,times_eval),metric_names[-1]))
 check <- old_performance[old_performance$cohort==cohort & old_performance$model=='D',]
 stopifnot(max(abs(actual[check$metric]-check$apparent))<1e-10)
 B <- 1000L;seed <- as.integer(old$metadata$base_seed)+if(cohort=='TCGA')1000L else 2000L
 set.seed(seed);indices <- replicate(B,sample.int(n,n,replace=TRUE),simplify=FALSE)
 sq <- sample_qc[sample_qc$cohort==cohort,];stopifnot(all(sq$unique_patients==vapply(indices,function(i)length(unique(i)),integer(1))))
 ev <- grep('event',names(sq),value=TRUE)[1];stopifnot(all(sq[[ev]]==vapply(indices,function(i)sum(d$status[i]==1),numeric(1))))
 qc[[cohort]] <- data.frame(cohort=cohort,n=n,events=events,seed=seed,full_apparent_max_error=max(abs(actual[check$metric]-check$apparent)),unique_IDs=TRUE,NA_count=sum(is.na(d)),resampling_qc_identical=TRUE)
 write_tsv(d,file.path(out_dir,paste0('02_',cohort,'_analysis_inputs.tsv')))
 for(variable in variables[[cohort]]){
  pair <- list();app <- list()
  for(augmented in c(FALSE,TRUE)){
   model_id <- paste0(variable,if(augmented)'_plus_LCDI' else '_alone')
   f <- as.formula(paste('Surv(time,status)~',variable,if(augmented)'+ LCDI' else ''))
   a <- apparent_metrics(d,f,cohort,model_id);app[[if(augmented)'high' else 'low']] <- a
   reuse <- cohort=='TARGET' && variable=='age' && augmented
   if(reuse){
    saved <- old_performance[old_performance$cohort==cohort & old_performance$model=='B',]
    stopifnot(max(abs(a$metrics[saved$metric]-saved$apparent))<1e-10)
    it <- old_iterations[old_iterations$cohort==cohort & old_iterations$model=='B',];it$model <- model_id;saved$model <- model_id
    z <- list(detail=it,summary=saved)
    cat('Reused TARGET age + LCDI model B bootstrap\n')
   }else z <- bootstrap_one_model(d,f,indices,cohort,model_id,a$metrics)
   z$detail$covariate <- variable;z$detail$augmented <- augmented;z$detail$cached <- reuse
   z$summary$covariate <- variable;z$summary$augmented <- augmented;z$summary$cached <- reuse
   a$coefficients$covariate <- variable;a$coefficients$augmented <- augmented
   details[[length(details)+1L]] <- z$detail;performance[[length(performance)+1L]] <- z$summary;coefficients[[length(coefficients)+1L]] <- a$coefficients
   pair[[if(augmented)'high' else 'low']] <- z
   defs[[length(defs)+1L]] <- data.frame(cohort=cohort,model=model_id,covariate=variable,augmented=augmented,formula=paste(deparse(f),collapse=' '),n=n,events=events,cached=reuse)
   write_tsv(z$detail,file.path(out_dir,paste0('iter_',cohort,'_',model_id,'.tsv')))
  }
  logratio <- 2*(as.numeric(logLik(app$high$fit))-as.numeric(logLik(app$low$fit)));df <- length(coef(app$high$fit))-length(coef(app$low$fit));stopifnot(df==1)
  tests[[length(tests)+1L]] <- data.frame(cohort=cohort,covariate=variable,n=n,events=events,df=df,LRT=logratio,P=pchisq(logratio,df,lower.tail=FALSE))
  p <- merge(pair$high$detail,pair$low$detail,by=c('cohort','iteration'),suffixes=c('_high','_low'))
  stopifnot(all(p$unique_patients_high==p$unique_patients_low),all(p$events_in_resample_high==p$events_in_resample_low))
  for(metric in metric_names){
   opthi <- p[[paste0(oc[[metric]],'_high')]];optlo <- p[[paste0(oc[[metric]],'_low')]];ok <- is.finite(opthi)&is.finite(optlo)
   bh <- app$high$metrics[[metric]]-opthi[ok];bl <- app$low$metrics[[metric]]-optlo[ok];dist <- bh-bl
   comparisons[[length(comparisons)+1L]] <- data.frame(cohort=cohort,covariate=variable,metric=metric,n=n,events=events,paired_valid=sum(ok),baseline_apparent=app$low$metrics[[metric]],augmented_apparent=app$high$metrics[[metric]],baseline_corrected=mean(bl),augmented_corrected=mean(bh),corrected_delta=mean(dist),distribution_p025=unname(quantile(dist,.025)),distribution_p975=unname(quantile(dist,.975)))
  }
 }
}
tests <- do.call(rbind,tests);stopifnot(nrow(tests)==11L);tests$FDR <- p.adjust(tests$P,method='BH')
write_tsv(do.call(rbind,qc),file.path(out_dir,'02_input_QC.tsv'))
write_tsv(do.call(rbind,defs),file.path(out_dir,'02_model_definitions.tsv'))
write_tsv(do.call(rbind,details),file.path(out_dir,'03_all_iterations.tsv'))
write_tsv(do.call(rbind,performance),file.path(out_dir,'04_model_performance.tsv'))
write_tsv(do.call(rbind,comparisons),file.path(out_dir,'05_paired_increments.tsv'))
write_tsv(tests,file.path(out_dir,'06_LRT_tests.tsv'))
write_tsv(do.call(rbind,coefficients),file.path(out_dir,'07_coefficients.tsv'))
writeLines(capture.output(sessionInfo()),file.path(out_dir,'session_info.txt'))
writeLines(c('status=passed','comparisons=11','models=22','new_bootstrap_models=21','cached_bootstrap_models=1','B=1000','FDR_family=11_LCDI_addition_LRTs','figure_modified=FALSE'),file.path(out_dir,'COMPLETE.txt'))
cat('COMPLETE: 11 single-covariate comparisons\n')

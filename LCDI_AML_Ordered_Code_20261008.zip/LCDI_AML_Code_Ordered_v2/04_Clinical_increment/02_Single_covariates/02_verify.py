from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.stats import chi2
D=Path(__file__).parent;R=D.parent.parent
run=json.loads((D/'run.run.json').read_text(encoding='utf8'));assert run['state']=='passed' and run['exit_code']==0
read=lambda n:pd.read_csv(D/n,sep='\t')
it=read('03_all_iterations.tsv');perf=read('04_model_performance.tsv');delta=read('05_paired_increments.tsv');lrt=read('06_LRT_tests.tsv');defs=read('02_model_definitions.tsv');qc=read('02_input_QC.tsv')
assert len(it)==22000 and len(perf)==88 and len(delta)==44 and len(lrt)==11 and len(defs)==22
assert not it.duplicated(['cohort','model','iteration']).any()
assert defs.groupby('cohort').size().to_dict()=={'TARGET':10,'TCGA':12}
assert defs.cached.sum()==1 and it.cached.sum()==1000
assert qc.n.tolist()==[145,1857] and qc.events.tolist()==[89,672] and qc.NA_count.eq(0).all() and qc.full_apparent_max_error.max()<1e-10
oc={'C_index':'optimism_C','AUC_1yr':'optimism_AUC_1yr','AUC_3yr':'optimism_AUC_3yr','AUC_5yr':'optimism_AUC_5yr'}
for row in perf.itertuples():
 vals=it[(it.cohort==row.cohort)&(it.model==row.model)][oc[row.metric]].dropna().to_numpy();dist=row.apparent-vals
 assert len(vals)==row.bootstrap_valid
 assert np.allclose([dist.mean(),*np.quantile(dist,[.025,.975])],[row.optimism_corrected,row.corrected_distribution_p025,row.corrected_distribution_p975],atol=1e-12,rtol=0)
for row in delta.itertuples():
 high=it[(it.cohort==row.cohort)&(it.covariate==row.covariate)&it.augmented];low=it[(it.cohort==row.cohort)&(it.covariate==row.covariate)&~it.augmented]
 pair=high.merge(low,on=['cohort','iteration'],suffixes=('_high','_low'),validate='1:1')
 assert pair.unique_patients_high.equals(pair.unique_patients_low) and pair.events_in_resample_high.equals(pair.events_in_resample_low)
 o=oc[row.metric];ok=np.isfinite(pair[o+'_high'])&np.isfinite(pair[o+'_low']);pair=pair[ok]
 bh=row.augmented_apparent-pair[o+'_high'];bl=row.baseline_apparent-pair[o+'_low'];dist=bh-bl
 assert len(dist)==row.paired_valid
 assert np.allclose([bl.mean(),bh.mean(),dist.mean(),*np.quantile(dist,[.025,.975])],[row.baseline_corrected,row.augmented_corrected,row.corrected_delta,row.distribution_p025,row.distribution_p975],rtol=0,atol=1e-12)
assert np.allclose(chi2.sf(lrt.LRT,lrt.df),lrt.P,rtol=1e-10,atol=1e-14)
order=np.argsort(lrt.P.to_numpy());f=lrt.P.to_numpy()[order]*len(lrt)/np.arange(1,len(lrt)+1);adj=np.minimum.accumulate(f[::-1])[::-1];expect=np.empty(len(lrt));expect[order]=np.minimum(adj,1)
assert np.allclose(expect,lrt.FDR,rtol=1e-10,atol=1e-14)
joined=delta.merge(lrt[['cohort','covariate','LRT','P','FDR']],on=['cohort','covariate'],validate='m:1');joined.to_csv(D/'08_verified_results.tsv',sep='\t',index=False,encoding='utf-8-sig')
counts={m:{'positive':int((x.corrected_delta>0).sum()),'interval_above_zero':int((x.distribution_p025>0).sum()),'total':len(x)} for m,x in delta.groupby('metric')}
sources=[D/'01_run.R',D/'run.run.json',D/'03_all_iterations.tsv',D/'04_model_performance.tsv',D/'05_paired_increments.tsv',D/'06_LRT_tests.tsv',R/'AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds',D.parent/'cindex_nomogram_reconciliation_20260902_v1/10_final_tcga_target_scores.tsv',D.parent/'cindex_nomogram_reconciliation_20260902_v1/11_recalculate_final_branch_nomogram.R',D.parent/'cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram/final/true_bootstrap_nomogram_results.rds',D.parent/'cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram/final/bootstrap_iterations_all_models.tsv',D.parent/'cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram/final/bootstrap_optimism_corrected_performance.tsv',D.parent/'cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram/final/bootstrap_sample_qc.tsv']
(D/'08_source_manifest.json').write_text(json.dumps([{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],ensure_ascii=False,indent=2),encoding='utf8')
q={'passed':True,'R_exit_code':0,'covariate_pairs':11,'models':22,'new_bootstrap_models':21,'cached_bootstrap_models':1,'B_per_model':1000,'metric_comparisons_verified':44,'LRT_FDR_family_size':11,'LRT_FDR_passes':int((lrt.FDR<.05).sum()),'direction_counts':counts,'figure_modified':False,'manuscript_modified':False}
(D/'08_QC.json').write_text(json.dumps(q,ensure_ascii=False,indent=2),encoding='utf8')
print(joined[joined.metric=='C_index'][['cohort','covariate','baseline_corrected','augmented_corrected','corrected_delta','distribution_p025','distribution_p975','P','FDR']].to_string(index=False));print(json.dumps(q,ensure_ascii=False))

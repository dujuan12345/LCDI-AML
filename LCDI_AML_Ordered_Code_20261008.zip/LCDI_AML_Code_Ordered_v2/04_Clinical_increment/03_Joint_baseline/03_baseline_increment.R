# Add the clinical/genetic baseline to the exact cached E/F validation chain.
# Default is preflight only. Pass bootstrap only after user authorization.
options(stringsAsFactors=FALSE, warn=1)
suppressPackageStartupMessages(library(survival))
suppressPackageStartupMessages(library(timeROC))
root <- 'D:/26_01_AML'
task <- file.path(root,'_codex_audit/consistency_v30_20260907')
origin <- file.path(root,'_codex_audit/cindex_nomogram_reconciliation_20260902_v1')
cache <- file.path(origin,'final_branch_nomogram/final')
args <- commandArgs(trailingOnly=TRUE)
mode <- if(length(args)) args[1] else 'preflight'
stopifnot(mode %in% c('preflight','bootstrap'))
out_dir <- file.path(task,paste0('increment_',mode))
if(dir.exists(out_dir)) stop('Refusing to overwrite existing output: ',out_dir)
dir.create(out_dir)
score_path <- file.path(origin,'10_final_tcga_target_scores.tsv')
input_path <- file.path(root,'AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds')
metric_names <- c('C_index','AUC_1yr','AUC_3yr','AUC_5yr')
times_eval <- c(365,1095,1825)
needed <- c('write_tsv','safe_cindex','safe_auc','fit_cox','safe_lp','prepare_data','bootstrap_one_model','apparent_metrics')
expressions <- parse(file.path(origin,'11_recalculate_final_branch_nomogram.R'))
loaded <- character()
for(ex in expressions){
 if(is.call(ex) && identical(ex[[1]],as.name('<-')) && is.symbol(ex[[2]]) && as.character(ex[[2]]) %in% needed && is.call(ex[[3]]) && identical(ex[[3]][[1]],as.name('function'))){eval(ex);loaded <- c(loaded,as.character(ex[[2]]))}
}
stopifnot(setequal(needed,loaded))
data <- prepare_data(readRDS(input_path))
fits <- readRDS(file.path(cache,'true_bootstrap_nomogram_results.rds'))
cache_iter <- read.delim(file.path(cache,'bootstrap_iterations_all_models.tsv'),check.names=FALSE)
cache_perf <- read.delim(file.path(cache,'bootstrap_optimism_corrected_performance.tsv'),check.names=FALSE)
sample_qc <- read.delim(file.path(cache,'bootstrap_sample_qc.tsv'),check.names=FALSE)
forms <- list(TCGA=Surv(time,status)~age+FAB+cyto+FLT3+NPM1+CEBPA,TARGET=Surv(time,status)~age+cyto+FLT3+NPM1+CEBPA)
qa <- list();summaries <- list();comparisons <- list();lrt <- list();details <- list()
for(cohort in names(forms)){
 d <- data[[tolower(cohort)]];n <- nrow(d);events <- sum(d$status==1)
 stopifnot(n==if(cohort=='TCGA')145 else 1857,events==if(cohort=='TCGA')89 else 672,!anyDuplicated(d$sample_id))
 full <- fits$full_fits[[cohort]][['D']]
 stopifnot(inherits(full,'coxph'))
 # Verify cached full fit uses the same individual records in the same order.
 stopifnot(identical(rownames(full$model),rownames(d)))
 stopifnot(max(abs(as.numeric(full$y[,1])-d$time))<1e-9,all(as.numeric(full$y[,2])==d$status))
 lp <- safe_lp(full,d)
 actual <- c(C_index=safe_cindex(d,lp),setNames(safe_auc(d,lp,times_eval),metric_names[-1]))
 old <- cache_perf[cache_perf$cohort==cohort & cache_perf$model=='D',]
 stopifnot(max(abs(actual[old$metric]-old$apparent))<1e-10)
 B <- as.integer(fits$metadata$B);seed <- as.integer(fits$metadata$base_seed)+if(cohort=='TCGA')1000L else 2000L
 set.seed(seed);indices <- replicate(B,sample.int(n,n,replace=TRUE),simplify=FALSE)
 sq <- sample_qc[sample_qc$cohort==cohort,]
 stopifnot(nrow(sq)==B,all(sq$unique_patients==vapply(indices,function(x)length(unique(x)),integer(1))))
 eventcol <- grep('event',names(sq),value=TRUE)[1]
 stopifnot(all(sq[[eventcol]]==vapply(indices,function(x)sum(d$status[x]==1),numeric(1))))
 base <- apparent_metrics(d,forms[[cohort]],cohort,'Baseline')
 lrt_p <- as.numeric(anova(base$fit,full,test='LRT')[2,'Pr(>|Chi|)'])
 if(!length(lrt_p) || !is.finite(lrt_p)) lrt_p <- pchisq(2*(as.numeric(logLik(full))-as.numeric(logLik(base$fit))),df=length(coef(full))-length(coef(base$fit)),lower.tail=FALSE)
 lrt[[cohort]] <- data.frame(cohort=cohort,n=n,events=events,df=length(coef(full))-length(coef(base$fit)),LRT=2*(as.numeric(logLik(full))-as.numeric(logLik(base$fit))),P=lrt_p)
 qa[[cohort]] <- data.frame(cohort=cohort,n=n,events=events,seed=seed,B=B,full_apparent_max_error=max(abs(actual[old$metric]-old$apparent)),sample_order_identical=TRUE,resampling_qc_identical=TRUE)
 write_tsv(data.frame(sample_id=d$sample_id,time=d$time,status=d$status,LCDI=d$LCDI),file.path(out_dir,paste0(cohort,'_input_records.tsv')))
 write_tsv(data.frame(metric=metric_names,baseline_apparent=base$metrics[metric_names],full_apparent=actual[metric_names]),file.path(out_dir,paste0(cohort,'_apparent.tsv')))
 if(mode=='bootstrap'){
  z <- bootstrap_one_model(d,forms[[cohort]],indices,cohort,'Baseline',base$metrics)
  details[[cohort]] <- z$detail;summaries[[cohort]] <- z$summary
  high <- cache_iter[cache_iter$cohort==cohort & cache_iter$model=='D',]
  pair <- merge(high,z$detail,by=c('cohort','iteration'),suffixes=c('_full','_base'))
  oc <- c(C_index='optimism_C',AUC_1yr='optimism_AUC_1yr',AUC_3yr='optimism_AUC_3yr',AUC_5yr='optimism_AUC_5yr')
  for(metric in metric_names){
   opt <- pair[[paste0(oc[[metric]],'_full')]]-pair[[paste0(oc[[metric]],'_base')]];ok <- is.finite(opt)
   delta <- actual[[metric]]-base$metrics[[metric]];dist <- delta-opt[ok]
   comparisons[[length(comparisons)+1L]] <- data.frame(cohort=cohort,metric=metric,apparent_difference=delta,paired_valid=sum(ok),optimism_corrected_difference=delta-mean(opt[ok]),distribution_p025=unname(quantile(dist,.025)),distribution_p975=unname(quantile(dist,.975)))
  }
 }
}
write_tsv(do.call(rbind,qa),file.path(out_dir,'01_preflight_QC.tsv'))
lt <- do.call(rbind,lrt);lt$FDR <- p.adjust(lt$P,method='BH');write_tsv(lt,file.path(out_dir,'02_increment_LRT.tsv'))
if(mode=='bootstrap'){
 write_tsv(do.call(rbind,details),file.path(out_dir,'03_baseline_iterations.tsv'))
 write_tsv(do.call(rbind,summaries),file.path(out_dir,'04_baseline_performance.tsv'))
 write_tsv(do.call(rbind,comparisons),file.path(out_dir,'05_paired_increment.tsv'))
}
writeLines(capture.output(sessionInfo()),file.path(out_dir,'session_info.txt'))
writeLines(c(paste0('mode=',mode),'status=passed',paste0('bootstrap_baseline_executed=',mode=='bootstrap'),'full_model_bootstrap_rerun=FALSE','calibration_rerun=FALSE'),file.path(out_dir,'COMPLETE.txt'))
cat('COMPLETE ',mode,'\n')

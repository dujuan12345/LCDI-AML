from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.stats import chi2
D=Path(__file__).parent;I=D/'increment_bootstrap';N=D.parent/'cindex_nomogram_reconciliation_20260902_v1/final_branch_nomogram/final'
run=json.loads((D/'baseline_run.run.json').read_text(encoding='utf8'));assert run['exit_code']==0 and run['state']=='passed'
read=lambda p:pd.read_csv(p,sep='\t')
base=read(I/'03_baseline_iterations.tsv');bperf=read(I/'04_baseline_performance.tsv');full=read(N/'bootstrap_iterations_all_models.tsv');full=full[full.model=='D'];fperf=read(N/'bootstrap_optimism_corrected_performance.tsv');fperf=fperf[fperf.model=='D'];delta=read(I/'05_paired_increment.tsv');lrt=read(I/'02_increment_LRT.tsv');qc=read(I/'01_preflight_QC.tsv')
assert len(base)==len(full)==2000 and len(bperf)==len(fperf)==len(delta)==8
assert not base.duplicated(['cohort','iteration']).any()
assert qc.n.tolist()==[145,1857] and qc.events.tolist()==[89,672]
assert qc.full_apparent_max_error.max()<1e-10 and qc.resampling_qc_identical.all() and qc.sample_order_identical.all()
metrics={'C_index':'optimism_C','AUC_1yr':'optimism_AUC_1yr','AUC_3yr':'optimism_AUC_3yr','AUC_5yr':'optimism_AUC_5yr'}
rows=[]
for cohort in ['TCGA','TARGET']:
 low=base[base.cohort==cohort];hi=full[full.cohort==cohort];pair=hi.merge(low,on=['cohort','iteration'],suffixes=('_full','_base'),validate='1:1')
 assert pair.unique_patients_full.equals(pair.unique_patients_base)
 assert pair.events_in_resample_full.equals(pair.events_in_resample_base)
 for m,oc in metrics.items():
  b=bperf[(bperf.cohort==cohort)&(bperf.metric==m)].iloc[0];f=fperf[(fperf.cohort==cohort)&(fperf.metric==m)].iloc[0];reported=delta[(delta.cohort==cohort)&(delta.metric==m)].iloc[0]
  optim=low[oc].dropna().to_numpy();assert len(optim)==b.bootstrap_valid
  bd=b.apparent-optim
  assert np.isclose(bd.mean(),b.optimism_corrected,rtol=0,atol=1e-12)
  assert np.allclose(np.quantile(bd,[.025,.975]),[b.corrected_distribution_p025,b.corrected_distribution_p975],rtol=0,atol=1e-12)
  ok=np.isfinite(pair[oc+'_full'])&np.isfinite(pair[oc+'_base']);p=pair[ok]
  bc=b.apparent-p[oc+'_base'];fc=f.apparent-p[oc+'_full'];dist=fc-bc
  assert len(dist)==reported.paired_valid
  assert np.allclose([dist.mean(),*np.quantile(dist,[.025,.975])],[reported.optimism_corrected_difference,reported.distribution_p025,reported.distribution_p975],rtol=0,atol=1e-12)
  rows.append({'cohort':cohort,'metric':m,'n':int(qc[qc.cohort==cohort].n.iloc[0]),'events':int(qc[qc.cohort==cohort].events.iloc[0]),'baseline_corrected_all_valid':b.optimism_corrected,'full_corrected_all_valid':f.optimism_corrected,'baseline_valid':int(b.bootstrap_valid),'full_valid':int(f.bootstrap_valid),'paired_valid':len(dist),'baseline_corrected_paired':bc.mean(),'full_corrected_paired':fc.mean(),'paired_delta':dist.mean(),'distribution_p025':float(dist.quantile(.025)),'distribution_p975':float(dist.quantile(.975))})
assert np.allclose(chi2.sf(lrt.LRT,lrt.df),lrt.P,rtol=1e-10)
order=np.argsort(lrt.P.to_numpy());raw=lrt.P.to_numpy()[order]*2/np.arange(1,3);adj=np.minimum.accumulate(raw[::-1])[::-1];fd=np.empty(2);fd[order]=np.minimum(adj,1);assert np.allclose(fd,lrt.FDR,rtol=1e-10)
out=pd.DataFrame(rows);out.to_json(D/'05_verified_increment.json',orient='records',indent=2,force_ascii=False)
out.to_csv(D/'05_verified_increment.tsv',sep='\t',index=False,encoding='utf-8-sig')
sources=[D/'03_baseline_increment.R',D/'baseline_run.run.json',I/'01_preflight_QC.tsv',I/'02_increment_LRT.tsv',I/'03_baseline_iterations.tsv',I/'04_baseline_performance.tsv',I/'05_paired_increment.tsv',N/'bootstrap_iterations_all_models.tsv',N/'bootstrap_optimism_corrected_performance.tsv',N/'true_bootstrap_nomogram_results.rds',N.parent.parent/'10_final_tcga_target_scores.tsv',N.parent.parent/'11_recalculate_final_branch_nomogram.R']
sources=[{'path':str(p),'bytes':p.stat().st_size,'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources]
(D/'05_increment_sources.json').write_text(json.dumps(sources,ensure_ascii=False,indent=2),encoding='utf8')
(D/'05_increment_QC.json').write_text(json.dumps({'passed':True,'R_exit_code':0,'baseline_bootstraps':2000,'cached_full_bootstraps_reused':2000,'metrics_recomputed_from_iterations':8,'sample_resample_matching':True,'LRT_BH_family':'two cohort-specific LCDI additions','LRT_BH_recalculated':True,'interval_type':'2.5%-97.5% quantiles of apparent difference minus paired optimism; conditional correction distribution, not an external-validation CI','figure2_modified':False,'manuscript_fig2_modified':False},ensure_ascii=False,indent=2),encoding='utf8')
print(out.to_string(index=False));print(lrt.to_string(index=False))

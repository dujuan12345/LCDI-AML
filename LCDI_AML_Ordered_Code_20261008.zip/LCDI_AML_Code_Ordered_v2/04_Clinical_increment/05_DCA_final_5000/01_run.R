options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages(library(survival))
root <- 'D:/26_01_AML';out <- file.path(root,'_codex_audit/dca_curve_inference_20260907_v2')
stopifnot(!file.exists(file.path(out,'COMPLETE.txt')))
origin <- file.path(root,'_codex_audit/cindex_nomogram_reconciliation_20260902_v1');dcadir <- file.path(root,'_codex_audit/figure2_dca_preview_20260903_v1')
score_path <- file.path(origin,'10_final_tcga_target_scores.tsv')
input_path <- file.path(root,'AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds')
get_functions <- function(path,names){
 loaded <- character()
 for(ex in parse(path)) if(is.call(ex)&&identical(ex[[1]],as.name('<-'))&&is.symbol(ex[[2]])&&as.character(ex[[2]])%in%names&&is.call(ex[[3]])&&identical(ex[[3]][[1]],as.name('function'))){eval(ex,envir=.GlobalEnv);loaded<-c(loaded,as.character(ex[[2]]))}
 stopifnot(setequal(loaded,names))
}
get_functions(file.path(origin,'11_recalculate_final_branch_nomogram.R'),c('prepare_data','fit_cox','safe_lp'))
get_functions(file.path(dcadir,'01_run_final_branch_dca.R'),c('predict_risk_at','step_survival','ipcw_components'))
write_tsv <- function(x,p)write.table(x,file.path(out,p),sep='\t',row.names=FALSE,quote=FALSE,na='NA',fileEncoding='UTF-8')
prep <- prepare_data(readRDS(input_path));saved <- readRDS(file.path(origin,'final_branch_nomogram/final/true_bootstrap_nomogram_results.rds'))
original <- read.delim(file.path(dcadir,'01_dca_curve_values.tsv'),check.names=FALSE)
thresholds <- seq(.05,.75,.01);time_days<-1095;B<-5000L
models <- c('A','D','All','None');col_names <- unlist(lapply(models,function(m)paste0(m,'_',sprintf('%03d',round(thresholds*100)))))
curves <- function(d,fits,weights=NULL){
 w <- if(is.null(weights))ipcw_components(d,time_days) else weights
 values <- lapply(c('A','D'),function(m){
  risk <- predict_risk_at(fits[[m]],d,time_days);stopifnot(length(risk)==nrow(d),all(is.finite(risk)))
  positive <- outer(risk,thresholds,'>=')
  tp <- colSums(positive*w$case_weight)/nrow(d);fp <- colSums(positive*w$control_weight)/nrow(d)
  tp-fp*thresholds/(1-thresholds)
 })
 all <- mean(w$case_weight)-mean(w$control_weight)*thresholds/(1-thresholds)
 z <- c(values[[1]],values[[2]],all,rep(0,length(thresholds)));names(z)<-col_names;z
}
observed <- list();boots <- list();optimism <- list();qcs <- list();failures <- list()
for(cohort in c('TCGA','TARGET')){
 d <- prep[[tolower(cohort)]];n <- nrow(d);stopifnot(n==if(cohort=='TCGA')145 else 1857)
 fits <- saved$full_fits[[cohort]][c('A','D')]
 stopifnot(all(vapply(fits,function(f)identical(rownames(f$model),rownames(d)),logical(1))))
 w0 <- ipcw_components(d,time_days);obs <- curves(d,fits,w0)
 obsrows <- data.frame(cohort=cohort,year=3,model=rep(models,each=length(thresholds)),threshold=rep(thresholds,length(models)),net_benefit=as.numeric(obs))
 old <- original[original$cohort==cohort & original$year==3 & original$threshold<=.750000001 & original$model%in%c('A','D','Treat all','Treat none'),]
 old$model[old$model=='Treat all']<-'All';old$model[old$model=='Treat none']<-'None'
 joined <- merge(obsrows,old[,c('cohort','year','model','threshold','net_benefit')],by=c('cohort','year','model','threshold'),suffixes=c('_new','_old'))
 stopifnot(nrow(joined)==4*length(thresholds))
 model_diff <- max(abs(joined$net_benefit_new[joined$model%in%c('A','D')]-joined$net_benefit_old[joined$model%in%c('A','D')]))
 stopifnot(model_diff<1e-10)
 write_tsv(joined,paste0('02_',cohort,'_curve_reconciliation.tsv'))
 observed[[cohort]]<-obsrows
 values <- matrix(NA_real_,B,length(col_names),dimnames=list(NULL,col_names));opt <- values
 seed <- as.integer(saved$metadata$base_seed)+if(cohort=='TCGA')1000L else 2000L
 set.seed(seed);indices <- replicate(B,sample.int(n,n,replace=TRUE),simplify=FALSE)
 qc <- data.frame(cohort=cohort,iteration=seq_len(B),fit_ok=FALSE,reason=NA_character_,warnings=0L,unique_patients=NA_integer_,events=NA_integer_)
 # Reuse the original 1000 paired resamples exactly; add fixed iterations 1001-5000.
 previous <- file.path(root,'_codex_audit/dca_curve_inference_20260907_v1')
 bv <- read.delim(file.path(previous,'03_bootstrap_curves.tsv'),check.names=FALSE);bv<-bv[bv$cohort==cohort,]
 bo <- read.delim(file.path(previous,'04_bootstrap_optimism.tsv'),check.names=FALSE);bo<-bo[bo$cohort==cohort,]
 bq <- read.delim(file.path(previous,'03_iteration_QC.tsv'),check.names=FALSE);bq<-bq[bq$cohort==cohort,]
 stopifnot(nrow(bv)==1000L,nrow(bo)==1000L,nrow(bq)==1000L)
 stopifnot(all(bq$unique_patients==vapply(indices[1:1000],function(i)length(unique(i)),integer(1))))
 stopifnot(all(bq$events==vapply(indices[1:1000],function(i)sum(d$status[i]==1),numeric(1))))
 values[1:1000,]<-as.matrix(bv[,col_names]);opt[1:1000,]<-as.matrix(bo[,col_names]);qc[1:1000,names(bq)]<-bq
 for(b in seq.int(1001L,B)){
  if(b==1 || b%%100==0)cat(cohort,'bootstrap',b,'/',B,'\n')
  idx<-indices[[b]];db<-d[idx,,drop=FALSE];qc$unique_patients[b]<-length(unique(idx));qc$events[b]<-sum(db$status==1)
  warning_count<-0L
  z <- tryCatch(withCallingHandlers({
   fs<-lapply(fits,function(f)fit_cox(formula(f),db))
   if(any(vapply(fs,inherits,logical(1),'fit_error')))stop(paste(vapply(fs,function(f)if(inherits(f,'fit_error'))f$message else '',character(1)),collapse=';'))
   wb<-ipcw_components(db,time_days);train<-curves(db,fs,wb);test<-curves(d,fs,w0)
   stopifnot(all(is.finite(train)),all(is.finite(test)))
   list(train=train,optimism=train-test)
  },warning=function(w){warning_count<<-warning_count+1L}),error=function(e)list(error=conditionMessage(e)))
  qc$warnings[b]<-warning_count
  if(!is.null(z$error)){qc$reason[b]<-z$error;next}
  values[b,]<-z$train;opt[b,]<-z$optimism;qc$fit_ok[b]<-TRUE;qc$reason[b]<-''
 }
 stopifnot(sum(qc$fit_ok)>=4500L)
 boots[[cohort]]<-data.frame(cohort=cohort,iteration=seq_len(B),values,check.names=FALSE)
 optimism[[cohort]]<-data.frame(cohort=cohort,iteration=seq_len(B),opt,check.names=FALSE)
 qcs[[cohort]]<-qc
 write_tsv(qc,paste0('03_',cohort,'_iteration_QC.tsv'))
 write_tsv(data.frame(cohort=cohort,model_curve_max_difference=model_diff,reference_max_difference=max(abs(joined$net_benefit_new[joined$model=='All']-joined$net_benefit_old[joined$model=='All'])),IPCW_case_plus_control=mean(w0$case_weight)+mean(w0$control_weight),n=n,events=sum(d$status),seed=seed),paste0('02_',cohort,'_input_QC.tsv'))
}
write_tsv(do.call(rbind,observed),'02_observed_curves.tsv');write_tsv(do.call(rbind,boots),'03_bootstrap_curves.tsv');write_tsv(do.call(rbind,optimism),'04_bootstrap_optimism.tsv');write_tsv(do.call(rbind,qcs),'03_iteration_QC.tsv')
writeLines(capture.output(sessionInfo()),file.path(out,'session_info.txt'))
writeLines(c('status=passed','B=5000_each_cohort','time_days=1095','thresholds=0.05_to_0.75_step0.01','model_curves_unchanged=TRUE','Treat_all_unified_IPCW=TRUE'),file.path(out,'COMPLETE.txt'))
cat('COMPLETE DCA paired-bootstrap\n')

from pathlib import Path
import json,hashlib
import numpy as np,pandas as pd
from scipy.stats import norm
D=Path(__file__).parent;run=json.loads((D/'run.run.json').read_text(encoding='utf8'));assert run['state']=='passed' and run['exit_code']==0
read=lambda n:pd.read_csv(D/n,sep='\t')
obs=read('02_observed_curves.tsv');boot=read('03_bootstrap_curves.tsv');op=read('04_bootstrap_optimism.tsv');iq=read('03_iteration_QC.tsv')
obs['model']=obs['model'].fillna('None')
assert len(obs)==568 and len(boot)==len(iq)==10000
t=np.arange(5,76)/100;weights=np.ones(71);weights[[0,-1]]=.5;weights=weights/weights.sum()
comparisons=[('Full_vs_LCDI','D','A'),('LCDI_vs_All','A','All'),('LCDI_vs_None','A','None'),('Full_vs_All','D','All'),('Full_vs_None','D','None')]
def BH(p):
 p=np.asarray(p);order=np.argsort(p);q=p[order]*len(p)/np.arange(1,len(p)+1);out=np.empty(len(p));out[order]=np.minimum(1,np.minimum.accumulate(q[::-1])[::-1]);return out
global_rows=[];point_rows=[];qc=[]
for cohort in ['TCGA','TARGET']:
 frame=boot[boot.cohort==cohort];optframe=op[op.cohort==cohort];okay=iq[iq.cohort==cohort].fit_ok.to_numpy();assert len(frame)==len(okay)==5000
 assert okay.sum()>=4500
 def columns(model):return [f'{model}_{i:03d}' for i in range(5,76)]
 def observed(model):return obs[(obs.cohort==cohort)&(obs.model==model)].sort_values('threshold').net_benefit.to_numpy()
 assert np.allclose(observed('None'),0)
 for label,high,low in comparisons:
  estimate=observed(high)-observed(low);values=frame.loc[:,columns(high)].to_numpy()-frame.loc[:,columns(low)].to_numpy();values=values[okay]
  estimate[np.abs(estimate)<1e-12]=0;values[np.abs(values)<1e-12]=0
  assert np.isfinite(values).all()
  eff=float(estimate@weights);avg=values@weights;se=float(avg.std(ddof=1));center=avg-eff
  p=(1+np.sum(np.abs(center)>=abs(eff)-1e-14))/(len(avg)+1)
  normalp=2*norm.sf(abs(eff)/se) if se>1e-12 else (1 if abs(eff)<1e-12 else 0)
  lo,hi=np.quantile(avg,[.025,.975])
  def optimism(model):
   if model in ['All','None']:return np.zeros((okay.sum(),71))
   return optframe.loc[:,columns(model)].to_numpy()[okay]
  delta_opt=optimism(high)-optimism(low);corrected=estimate-delta_opt.mean(axis=0)
  global_rows.append({'cohort':cohort,'comparison':label,'high_model':high,'low_model':low,'time_years':3,'threshold_min':.05,'threshold_max':.75,'threshold_n':71,'mean_delta_NB':eff,'area_delta_NB':eff*.70,'bootstrap_mean':float(avg.mean()),'bootstrap_se':se,'centered_p025':eff-float(np.quantile(np.abs(center),.95)),'centered_p975':eff+float(np.quantile(np.abs(center),.95)),'percentile_p025':lo,'percentile_p975':hi,'P_bootstrap_centered':p,'P_normal_approx':normalp,'bootstrap_valid':len(avg),'optimism_corrected_mean_delta_NB':float(corrected@weights)})
  sd=values.std(axis=0,ddof=1);nondeg=sd>1e-12
  z=np.abs((values[:,nondeg]-estimate[nondeg])/sd[nondeg])
  critical=float(np.quantile(z.max(axis=1),.95)) if nondeg.any() else 0.
  pl,pu=np.quantile(values,[.025,.975],axis=0)
  pp=(1+np.sum(np.abs(values-estimate)>=np.abs(estimate)-1e-14,axis=0))/(len(values)+1)
  for j,pt in enumerate(t):
   point_rows.append({'cohort':cohort,'comparison':label,'threshold':pt,'delta_NB':estimate[j],'percentile_p025':pl[j],'percentile_p975':pu[j],'SE':sd[j],'P_bootstrap_centered':pp[j],'simultaneous_lower':estimate[j]-critical*sd[j],'simultaneous_upper':estimate[j]+critical*sd[j],'max_t_critical':critical,'bootstrap_valid':len(values),'optimism_corrected_delta_NB':corrected[j]})
  qc.append({'cohort':cohort,'comparison':label,'max_abs_trapz_error':float(np.max(np.abs(np.trapz(values,t,axis=1)/.70-avg))),'degenerate_points':int((~nondeg).sum())})
g=pd.DataFrame(global_rows);g['FDR']=BH(g.P_bootstrap_centered);p=pd.DataFrame(point_rows);p['FDR']=BH(p.P_bootstrap_centered)
assert len(g)==10 and len(p)==710
assert max(x['max_abs_trapz_error'] for x in qc)<1e-12
g.to_csv(D/'05_global_comparisons.tsv',sep='\t',index=False,encoding='utf-8-sig');p.to_csv(D/'06_pointwise_comparisons.tsv',sep='\t',index=False,encoding='utf-8-sig')
def ranges(xs):
 xs=sorted(round(float(x),2) for x in xs)
 if not xs:return ''
 groups=[];start=last=xs[0]
 for x in xs[1:]:
  if abs(x-last-.01)>1e-8:groups.append((start,last));start=x
  last=x
 groups.append((start,last));return '; '.join(f'{a:.2f}-{b:.2f}' for a,b in groups)
rs=[]
for (co,label),x in p.groupby(['cohort','comparison'],sort=False):
 rs.append({'cohort':co,'comparison':label,'pointwise_positive_FDR05_ranges':ranges(x[(x.FDR<.05)&(x.delta_NB>0)].threshold),'simultaneous_positive_ranges':ranges(x[x.simultaneous_lower>1e-12].threshold),'nominal_percentile_positive_ranges':ranges(x[x.percentile_p025>1e-12].threshold)})
pd.DataFrame(rs).to_csv(D/'07_threshold_ranges.tsv',sep='\t',index=False,encoding='utf-8-sig')
sources=[D/x for x in ['00_protocol.md','01_run.R','02_inference.py','run.run.json','02_observed_curves.tsv','03_bootstrap_curves.tsv','04_bootstrap_optimism.tsv','03_iteration_QC.tsv']]
(D/'08_source_manifest.json').write_text(json.dumps([{'path':str(x),'bytes':x.stat().st_size,'sha256':hashlib.sha256(x.read_bytes()).hexdigest()} for x in sources],ensure_ascii=False,indent=2),encoding='utf8')
(D/'08_QC.json').write_text(json.dumps({'passed':True,'global_tests':10,'pointwise_tests':710,'bootstrap_valid_by_cohort':iq.groupby('cohort').fit_ok.sum().astype(int).to_dict(),'uniform_grid_mean_equals_trapezoid':True,'finite_statistics':bool(np.isfinite(g.select_dtypes('number')).all().all()),'simultaneous_bands':'within each comparison over 71 thresholds; max standardized centered bootstrap deviation','reference_estimator':'shared case/control IPCW for all strategies','checks':qc},indent=2),encoding='utf8')
print(g[['cohort','comparison','mean_delta_NB','percentile_p025','percentile_p975','P_bootstrap_centered','FDR','optimism_corrected_mean_delta_NB']].to_string(index=False));print(pd.DataFrame(rs).to_string(index=False))

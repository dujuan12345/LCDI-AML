from pathlib import Path
import json
import numpy as np,pandas as pd
D=Path(__file__).parent
g=pd.read_csv(D/'05_global_comparisons.tsv',sep='\t');p=pd.read_csv(D/'06_pointwise_comparisons.tsv',sep='\t')
main=['LCDI_vs_All','LCDI_vs_None'];g=g[g.comparison.isin(main)].copy();p=p[p.comparison.isin(main)].copy()
def BH(x):
 x=np.asarray(x);order=np.argsort(x);y=x[order]*len(x)/np.arange(1,len(x)+1);z=np.empty(len(x));z[order]=np.minimum(1,np.minimum.accumulate(y[::-1])[::-1]);return z
g['FDR_original_10_tests']=g.FDR;g['FDR']=BH(g.P_bootstrap_centered)
p['FDR_original_710_tests']=p.FDR;p['FDR']=BH(p.P_bootstrap_centered)
assert len(g)==4 and len(p)==284
obs=pd.read_csv(D/'02_observed_curves.tsv',sep='\t');obs['model']=obs.model.fillna('None');boot=pd.read_csv(D/'03_bootstrap_curves.tsv',sep='\t');iq=pd.read_csv(D/'03_iteration_QC.tsv',sep='\t')
def ranges(xs):
 xs=sorted(round(float(x),2) for x in xs)
 if not xs:return ''
 groups=[];start=last=xs[0]
 for x in xs[1:]:
  if abs(x-last-.01)>1e-8:groups.append((start,last));start=x
  last=x
 groups.append((start,last));return '; '.join(f'{a:.2f}-{b:.2f}' for a,b in groups)
rows=[];summary=[]
for co in ['TCGA','TARGET']:
 b=boot[boot.cohort==co];okay=iq[iq.cohort==co].fit_ok.to_numpy();b=b[okay]
 def array(model):return b[[f'{model}_{i:03d}' for i in range(5,76)]].to_numpy()
 def vector(model):return obs[(obs.cohort==co)&(obs.model==model)].sort_values('threshold').net_benefit.to_numpy()
 estimates=np.concatenate([vector('A')-vector('All'),vector('A')-vector('None')]);values=np.concatenate([array('A')-array('All'),array('A')-array('None')],axis=1)
 estimates[np.abs(estimates)<1e-12]=0;values[np.abs(values)<1e-12]=0
 sd=values.std(axis=0,ddof=1);ok=sd>1e-12;maxdev=np.max(np.abs((values[:,ok]-estimates[ok])/sd[ok]),axis=1);critical=np.quantile(maxdev,.95)
 low=estimates-critical*sd;high=estimates+critical*sd
 thresholds=np.arange(5,76)/100
 for i,t in enumerate(thresholds):rows.append({'cohort':co,'threshold':t,'LCDI_minus_All':estimates[i],'LCDI_minus_None':estimates[i+71],'joint_lower_vs_All':low[i],'joint_upper_vs_All':high[i],'joint_lower_vs_None':low[i+71],'joint_upper_vs_None':high[i+71],'joint_max_t_critical':critical,'bootstrap_valid':len(values),'jointly_positive':bool(low[i]>1e-12 and low[i+71]>1e-12)})
 pp=p[p.cohort==co].pivot(index='threshold',columns='comparison',values=['delta_NB','FDR'])
 pointwise=(pp['delta_NB']>0).all(axis=1)&(pp['FDR']<.05).all(axis=1)
 summary.append({'cohort':co,'direction_above_both':ranges(thresholds[(estimates[:71]>1e-12)&(estimates[71:]>1e-12)]),'pointwise_both_BH_FDR05':ranges(pp.index[pointwise]),'joint_95_simultaneous_above_both':ranges(thresholds[(low[:71]>1e-12)&(low[71:]>1e-12)]),'bootstrap_valid':len(values)})
g.to_csv(D/'09_LCDI_default_global.tsv',sep='\t',index=False,encoding='utf-8-sig');p.to_csv(D/'09_LCDI_default_pointwise.tsv',sep='\t',index=False,encoding='utf-8-sig');pd.DataFrame(rows).to_csv(D/'09_joint_simultaneous_bands.tsv',sep='\t',index=False,encoding='utf-8-sig');pd.DataFrame(summary).to_csv(D/'09_LCDI_above_both_ranges.tsv',sep='\t',index=False,encoding='utf-8-sig')
(D/'09_scope_QC.json').write_text(json.dumps({'passed':True,'primary_global_tests':4,'pointwise_tests':284,'joint_band_points_per_cohort':142,'question':'LCDI above Treat-all and Treat-none','full_vs_lcdi_primary':False,'all_previous_comparisons_archived':True},indent=2),encoding='utf8')
print(g[['cohort','comparison','mean_delta_NB','centered_p025','centered_p975','P_bootstrap_centered','FDR','bootstrap_valid']].to_string(index=False));print(pd.DataFrame(summary).to_string(index=False))

from pathlib import Path
import json
import pandas as pd,numpy as np
D=Path(__file__).parent;old=D.parent/'dca_curve_inference_20260907_v1'
run=json.loads((D/'run.run.json').read_text(encoding='utf8'));assert run['exit_code']==0
b=pd.read_csv(D/'03_bootstrap_curves.tsv',sep='\t');b0=pd.read_csv(old/'03_bootstrap_curves.tsv',sep='\t');iq=pd.read_csv(D/'03_iteration_QC.tsv',sep='\t');obs=pd.read_csv(D/'02_observed_curves.tsv',sep='\t');obs.model=obs.model.fillna('None');g=pd.read_csv(D/'09_LCDI_default_global.tsv',sep='\t');points=pd.read_csv(D/'09_LCDI_default_pointwise.tsv',sep='\t');joint=pd.read_csv(D/'09_joint_simultaneous_bands.tsv',sep='\t')
for co in ['TCGA','TARGET']:
 assert np.allclose(b[(b.cohort==co)&(b.iteration<=1000)].iloc[:,2:],b0[b0.cohort==co].iloc[:,2:],equal_nan=True,rtol=0,atol=1e-12)
 z=b[b.cohort==co];z=z[iq[iq.cohort==co].fit_ok.to_numpy()]
 for baseline,label in [('All','LCDI_vs_All'),('None','LCDI_vs_None')]:
  x=obs[(obs.cohort==co)&(obs.model=='A')].sort_values('threshold').net_benefit.to_numpy()-obs[(obs.cohort==co)&(obs.model==baseline)].sort_values('threshold').net_benefit.to_numpy()
  matrix=z[[f'A_{i:03d}' for i in range(5,76)]].to_numpy()-z[[f'{baseline}_{i:03d}' for i in range(5,76)]].to_numpy()
  theta=np.trapz(x,dx=.01)/.70;draws=np.trapz(matrix,dx=.01,axis=1)/.70;prob=(1+sum(abs(draws-theta)>=abs(theta)-1e-14))/(len(draws)+1)
  row=g[(g.cohort==co)&(g.comparison==label)].iloc[0]
  assert np.allclose([theta,prob],[row.mean_delta_NB,row.P_bootstrap_centered],rtol=0,atol=1e-12)
  radius=np.quantile(abs(draws-theta),.95);assert np.allclose([theta-radius,theta+radius],[row.centered_p025,row.centered_p975],atol=1e-12,rtol=0)
def bh(x):
 arr=np.asarray(x);idx=np.argsort(arr);out=np.empty(len(arr));out[idx]=np.minimum(1,np.minimum.accumulate((arr[idx]*len(arr)/np.arange(1,len(arr)+1))[::-1])[::-1]);return out
assert np.allclose(g.FDR,bh(g.P_bootstrap_centered)) and np.allclose(points.FDR,bh(points.P_bootstrap_centered))
assert np.array_equal(joint.jointly_positive,(joint.joint_lower_vs_All>1e-12)&(joint.joint_lower_vs_None>1e-12))
assert not joint.jointly_positive.any()
q={'passed':True,'R_exit':0,'first_1000_reuse_verified':True,'primary_four_tests_recomputed':True,'primary_global_FDR_family':4,'primary_pointwise_FDR_family':284,'joint_band_requires_both_references':True,'joint_band_positive_thresholds':0,'valid_counts':iq.groupby('cohort').fit_ok.sum().astype(int).to_dict()}
(D/'10_validation.json').write_text(json.dumps(q,indent=2),encoding='utf8');print(q)

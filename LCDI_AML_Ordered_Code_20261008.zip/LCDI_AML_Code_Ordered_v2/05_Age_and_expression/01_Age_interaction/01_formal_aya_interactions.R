options(stringsAsFactors = FALSE, width = 180)

suppressPackageStartupMessages(library(survival))

input_file <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/phaseE1_aya_summary.rds"
output_dir <- "D:/26_01_AML/_codex_audit/chapter6_interactions_20260731_v1"
dir.create(output_dir, recursive = TRUE, showWarnings = FALSE)

log_file <- file.path(output_dir, "run.log")
log_con <- file(log_file, open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
sink(log_con, type = "message")

status_file <- file.path(output_dir, "run_status.txt")
writeLines("running", status_file)

fmt_p <- function(x) {
  ifelse(x < 0.001, formatC(x, format = "e", digits = 2), formatC(x, format = "f", digits = 3))
}

write_tsv <- function(x, file) {
  write.table(x, file = file.path(output_dir, file), sep = "\t", quote = FALSE,
              row.names = FALSE, na = "NA", fileEncoding = "UTF-8")
}

lrt_row <- function(base_fit, full_fit, family, exposure, modifier, model_name,
                    base_formula, full_formula) {
  lrt <- anova(base_fit, full_fit, test = "LRT")
  data.frame(
    family = family,
    exposure = exposure,
    modifier = modifier,
    model = model_name,
    n = full_fit$n,
    events = full_fit$nevent,
    df = lrt$Df[2],
    LRT_chisq = lrt$Chisq[2],
    P = lrt$`Pr(>|Chi|)`[2],
    loglik_base = as.numeric(logLik(base_fit)),
    loglik_full = as.numeric(logLik(full_fit)),
    base_formula = base_formula,
    full_formula = full_formula,
    stringsAsFactors = FALSE
  )
}

group_slopes <- function(fit, data, exposure, modifier, model_name) {
  b <- coef(fit)
  vv <- vcov(fit)
  levs <- levels(data[[modifier]])
  out <- vector("list", length(levs))
  for (i in seq_along(levs)) {
    lev <- levs[i]
    L <- setNames(rep(0, length(b)), names(b))
    L[exposure] <- 1
    if (i > 1) {
      candidates <- c(
        paste0(exposure, ":", modifier, lev),
        paste0(modifier, lev, ":", exposure)
      )
      hit <- candidates[candidates %in% names(b)]
      if (length(hit) != 1) {
        stop("Cannot uniquely identify interaction coefficient for ", exposure,
             " and ", modifier, " level ", lev)
      }
      L[hit] <- 1
    }
    estimate <- sum(L * b)
    se <- sqrt(as.numeric(t(L) %*% vv %*% L))
    z <- estimate / se
    d <- data[data[[modifier]] == lev, , drop = FALSE]
    out[[i]] <- data.frame(
      model = model_name,
      exposure = exposure,
      modifier = modifier,
      group = lev,
      n = nrow(d),
      events = sum(d$status == 1),
      logHR = estimate,
      SE = se,
      HR_per_global_SD = exp(estimate),
      CI_low = exp(estimate - qnorm(0.975) * se),
      CI_high = exp(estimate + qnorm(0.975) * se),
      P = 2 * pnorm(abs(z), lower.tail = FALSE),
      stringsAsFactors = FALSE
    )
  }
  do.call(rbind, out)
}

coef_table <- function(fit, model_name) {
  s <- summary(fit)$coefficients
  data.frame(
    model = model_name,
    term = rownames(s),
    coefficient = s[, "coef"],
    HR = exp(s[, "coef"]),
    SE = s[, "se(coef)"],
    z = s[, "z"],
    P = s[, "Pr(>|z|)"],
    row.names = NULL,
    stringsAsFactors = FALSE
  )
}

ph_table <- function(fit, model_name) {
  z <- cox.zph(fit, transform = "km")
  tab <- as.data.frame(z$table)
  data.frame(
    model = model_name,
    term = rownames(tab),
    chisq = tab$chisq,
    df = tab$df,
    P = tab$p,
    row.names = NULL,
    stringsAsFactors = FALSE
  )
}

plot_forest <- function(y, hr, low, high, labels, xlim, xlab, main, p_text) {
  plot(NA, xlim = xlim, ylim = c(0.5, length(y) + 0.8), log = "x",
       yaxt = "n", ylab = "", xlab = xlab, main = main, bty = "n")
  abline(v = 1, col = "grey55", lty = 2)
  segments(low, y, high, y, lwd = 2, col = "#35618D")
  points(hr, y, pch = 19, cex = 1.1, col = "#B64B47")
  axis(2, at = y, labels = labels, las = 1, tick = FALSE)
  mtext(p_text, side = 3, line = 0.1, cex = 0.76)
}

cat("Formal AYA interaction analysis\n")
cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n")
cat("Input:", input_file, "\n")

obj <- readRDS(input_file)
if (!"df_all" %in% names(obj)) stop("df_all was not found in phaseE1 object")
d <- obj$df_all

required <- c("time", "status", "age", "cyto_risk", "LCDI", "MPO", "age_group", "AYA_status")
missing_cols <- setdiff(required, names(d))
if (length(missing_cols) > 0) stop("Missing columns: ", paste(missing_cols, collapse = ", "))

d$time <- as.numeric(d$time)
d$status <- as.integer(d$status)
d$LCDI <- as.numeric(d$LCDI)
d$MPO <- as.numeric(d$MPO)
d$age_group <- factor(
  as.character(d$age_group),
  levels = c("Infant_0_2", "Young_2_10", "AYA_10_21", "YoungAdult_21+")
)
d$AYA_status <- factor(as.character(d$AYA_status), levels = c("Non-AYA", "AYA"))
d$cyto_risk <- factor(d$cyto_risk)

if (any(!d$status %in% c(0L, 1L), na.rm = TRUE)) stop("status contains values outside 0/1")
if (any(d$time <= 0, na.rm = TRUE)) stop("time contains non-positive values")
if (anyNA(d[, c("time", "status", "LCDI", "MPO", "age_group", "AYA_status")])) {
  stop("Primary interaction variables contain missing values")
}

d$LCDI_z <- as.numeric(scale(d$LCDI))
d$MPO_z <- as.numeric(scale(d$MPO))

qc <- data.frame(
  item = c(
    "input_rows", "input_events", "duplicate_sample_id",
    "missing_primary_fields", "LCDI_mean_raw", "LCDI_sd_raw",
    "MPO_mean_raw", "MPO_sd_raw", "cyto_complete_rows", "cyto_complete_events"
  ),
  value = c(
    nrow(d), sum(d$status == 1),
    if ("sample_id" %in% names(d)) sum(duplicated(d$sample_id)) else NA,
    sum(!complete.cases(d[, c("time", "status", "LCDI", "MPO", "age_group", "AYA_status")])),
    mean(d$LCDI), sd(d$LCDI), mean(d$MPO), sd(d$MPO),
    sum(complete.cases(d[, c("time", "status", "LCDI_z", "MPO_z", "age_group", "AYA_status", "cyto_risk")])),
    sum(d$status[complete.cases(d[, c("time", "status", "LCDI_z", "MPO_z", "age_group", "AYA_status", "cyto_risk")])] == 1)
  ),
  stringsAsFactors = FALSE
)

lcd_base_formula <- "Surv(time, status) ~ LCDI_z + age_group"
lcd_full_formula <- "Surv(time, status) ~ LCDI_z * age_group"
mpo_base_formula <- "Surv(time, status) ~ MPO_z + AYA_status"
mpo_full_formula <- "Surv(time, status) ~ MPO_z * AYA_status"

fit_lcd_base <- coxph(as.formula(lcd_base_formula), data = d, x = TRUE, model = TRUE)
fit_lcd_full <- coxph(as.formula(lcd_full_formula), data = d, x = TRUE, model = TRUE)
fit_mpo_base <- coxph(as.formula(mpo_base_formula), data = d, x = TRUE, model = TRUE)
fit_mpo_full <- coxph(as.formula(mpo_full_formula), data = d, x = TRUE, model = TRUE)

dc <- d[complete.cases(d[, c("time", "status", "LCDI_z", "MPO_z", "age_group", "AYA_status", "cyto_risk")]), , drop = FALSE]
lcd_base_adj_formula <- "Surv(time, status) ~ LCDI_z + age_group + cyto_risk"
lcd_full_adj_formula <- "Surv(time, status) ~ LCDI_z * age_group + cyto_risk"
mpo_base_adj_formula <- "Surv(time, status) ~ MPO_z + AYA_status + cyto_risk"
mpo_full_adj_formula <- "Surv(time, status) ~ MPO_z * AYA_status + cyto_risk"

fit_lcd_base_adj <- coxph(as.formula(lcd_base_adj_formula), data = dc, x = TRUE, model = TRUE)
fit_lcd_full_adj <- coxph(as.formula(lcd_full_adj_formula), data = dc, x = TRUE, model = TRUE)
fit_mpo_base_adj <- coxph(as.formula(mpo_base_adj_formula), data = dc, x = TRUE, model = TRUE)
fit_mpo_full_adj <- coxph(as.formula(mpo_full_adj_formula), data = dc, x = TRUE, model = TRUE)

global_tests <- rbind(
  lrt_row(fit_lcd_base, fit_lcd_full, "primary", "LCDI_z", "age_group",
          "LCDI_by_age_group", lcd_base_formula, lcd_full_formula),
  lrt_row(fit_mpo_base, fit_mpo_full, "primary", "MPO_z", "AYA_status",
          "MPO_by_AYA_status", mpo_base_formula, mpo_full_formula),
  lrt_row(fit_lcd_base_adj, fit_lcd_full_adj, "sensitivity", "LCDI_z", "age_group",
          "LCDI_by_age_group_adjusted_cyto", lcd_base_adj_formula, lcd_full_adj_formula),
  lrt_row(fit_mpo_base_adj, fit_mpo_full_adj, "sensitivity", "MPO_z", "AYA_status",
          "MPO_by_AYA_status_adjusted_cyto", mpo_base_adj_formula, mpo_full_adj_formula)
)
global_tests$FDR_BH_within_family <- ave(global_tests$P, global_tests$family,
                                        FUN = function(x) p.adjust(x, method = "BH"))

effects <- rbind(
  group_slopes(fit_lcd_full, d, "LCDI_z", "age_group", "LCDI_by_age_group"),
  group_slopes(fit_mpo_full, d, "MPO_z", "AYA_status", "MPO_by_AYA_status"),
  group_slopes(fit_lcd_full_adj, dc, "LCDI_z", "age_group", "LCDI_by_age_group_adjusted_cyto"),
  group_slopes(fit_mpo_full_adj, dc, "MPO_z", "AYA_status", "MPO_by_AYA_status_adjusted_cyto")
)

coefficients <- rbind(
  coef_table(fit_lcd_full, "LCDI_by_age_group"),
  coef_table(fit_mpo_full, "MPO_by_AYA_status"),
  coef_table(fit_lcd_full_adj, "LCDI_by_age_group_adjusted_cyto"),
  coef_table(fit_mpo_full_adj, "MPO_by_AYA_status_adjusted_cyto")
)

ph_diagnostics <- rbind(
  ph_table(fit_lcd_full, "LCDI_by_age_group"),
  ph_table(fit_mpo_full, "MPO_by_AYA_status"),
  ph_table(fit_lcd_full_adj, "LCDI_by_age_group_adjusted_cyto"),
  ph_table(fit_mpo_full_adj, "MPO_by_AYA_status_adjusted_cyto")
)

write_tsv(qc, "interaction_input_qc.tsv")
write_tsv(global_tests, "interaction_global_tests.tsv")
write_tsv(effects, "interaction_group_specific_effects.tsv")
write_tsv(coefficients, "interaction_coefficients.tsv")
write_tsv(ph_diagnostics, "interaction_ph_diagnostics.tsv")

saveRDS(
  list(
    input_file = input_file,
    input_sha256 = "BF5A1CC5D3E396CD0A1CFA184384E4E8776EFFC73280B9DF97AE432063741F9C",
    seed = "not_applicable",
    global_tests = global_tests,
    effects = effects,
    coefficients = coefficients,
    ph_diagnostics = ph_diagnostics,
    fits = list(
      fit_lcd_base = fit_lcd_base, fit_lcd_full = fit_lcd_full,
      fit_mpo_base = fit_mpo_base, fit_mpo_full = fit_mpo_full,
      fit_lcd_base_adj = fit_lcd_base_adj, fit_lcd_full_adj = fit_lcd_full_adj,
      fit_mpo_base_adj = fit_mpo_base_adj, fit_mpo_full_adj = fit_mpo_full_adj
    )
  ),
  file.path(output_dir, "interaction_analysis.rds")
)

wilcox_p <- wilcox.test(LCDI ~ AYA_status, data = d, exact = FALSE)$p.value
aya_means <- tapply(d$LCDI, d$AYA_status, mean)

png(file.path(output_dir, "Figure5_AYA_interactions.png"), width = 3200, height = 1450, res = 300)
par(mfrow = c(1, 3), mar = c(4.2, 5.5, 3.8, 1.0), oma = c(0.2, 0.2, 0.2, 0.2),
    family = "sans")
boxplot(LCDI ~ AYA_status, data = d, col = c("#BFD7EA", "#F4B6A6"), outline = FALSE,
        ylab = "LCDI", xlab = "", main = "A. LCDI distribution", border = "#4A4A4A")
points(c(1, 2), aya_means[c("Non-AYA", "AYA")], pch = 18, cex = 1.4, col = "#8A1C1C")
mtext(sprintf("Wilcoxon P=%s; means: %.3f vs %.3f",
              fmt_p(wilcox_p), aya_means["Non-AYA"], aya_means["AYA"]),
      side = 3, line = 0.25, cex = 0.72)

lcd_eff <- effects[effects$model == "LCDI_by_age_group", ]
lcd_test <- global_tests[global_tests$model == "LCDI_by_age_group", ]
plot_forest(
  y = rev(seq_len(nrow(lcd_eff))),
  hr = lcd_eff$HR_per_global_SD,
  low = lcd_eff$CI_low,
  high = lcd_eff$CI_high,
  labels = c("Infant 0-<2", "Young 2-<10", "AYA 10-<21", "Adult >=21"),
  xlim = range(c(lcd_eff$CI_low, lcd_eff$CI_high, 1)) * c(0.92, 1.08),
  xlab = "HR per global SD of LCDI",
  main = "B. LCDI by age band",
  p_text = sprintf("Global interaction P=%s; FDR=%s",
                   fmt_p(lcd_test$P), fmt_p(lcd_test$FDR_BH_within_family))
)

mpo_eff <- effects[effects$model == "MPO_by_AYA_status", ]
mpo_test <- global_tests[global_tests$model == "MPO_by_AYA_status", ]
plot_forest(
  y = rev(seq_len(nrow(mpo_eff))),
  hr = mpo_eff$HR_per_global_SD,
  low = mpo_eff$CI_low,
  high = mpo_eff$CI_high,
  labels = mpo_eff$group,
  xlim = range(c(mpo_eff$CI_low, mpo_eff$CI_high, 1)) * c(0.92, 1.08),
  xlab = "HR per global SD of MPO",
  main = "C. MPO by AYA status",
  p_text = sprintf("Global interaction P=%s; FDR=%s",
                   fmt_p(mpo_test$P), fmt_p(mpo_test$FDR_BH_within_family))
)
dev.off()

pdf(file.path(output_dir, "Figure5_AYA_interactions.pdf"), width = 10.67, height = 4.83,
    family = "Helvetica")
par(mfrow = c(1, 3), mar = c(4.2, 5.5, 3.8, 1.0), oma = c(0.2, 0.2, 0.2, 0.2))
boxplot(LCDI ~ AYA_status, data = d, col = c("#BFD7EA", "#F4B6A6"), outline = FALSE,
        ylab = "LCDI", xlab = "", main = "A. LCDI distribution", border = "#4A4A4A")
points(c(1, 2), aya_means[c("Non-AYA", "AYA")], pch = 18, cex = 1.4, col = "#8A1C1C")
mtext(sprintf("Wilcoxon P=%s; means: %.3f vs %.3f",
              fmt_p(wilcox_p), aya_means["Non-AYA"], aya_means["AYA"]),
      side = 3, line = 0.25, cex = 0.72)
plot_forest(
  y = rev(seq_len(nrow(lcd_eff))), hr = lcd_eff$HR_per_global_SD,
  low = lcd_eff$CI_low, high = lcd_eff$CI_high,
  labels = c("Infant 0-<2", "Young 2-<10", "AYA 10-<21", "Adult >=21"),
  xlim = range(c(lcd_eff$CI_low, lcd_eff$CI_high, 1)) * c(0.92, 1.08),
  xlab = "HR per global SD of LCDI", main = "B. LCDI by age band",
  p_text = sprintf("Global interaction P=%s; FDR=%s",
                   fmt_p(lcd_test$P), fmt_p(lcd_test$FDR_BH_within_family))
)
plot_forest(
  y = rev(seq_len(nrow(mpo_eff))), hr = mpo_eff$HR_per_global_SD,
  low = mpo_eff$CI_low, high = mpo_eff$CI_high, labels = mpo_eff$group,
  xlim = range(c(mpo_eff$CI_low, mpo_eff$CI_high, 1)) * c(0.92, 1.08),
  xlab = "HR per global SD of MPO", main = "C. MPO by AYA status",
  p_text = sprintf("Global interaction P=%s; FDR=%s",
                   fmt_p(mpo_test$P), fmt_p(mpo_test$FDR_BH_within_family))
)
dev.off()

writeLines(capture.output(sessionInfo()), file.path(output_dir, "session_info.txt"))

cat("\nGlobal interaction tests:\n")
print(global_tests)
cat("\nGroup-specific effects:\n")
print(effects)
cat("\nPH diagnostics:\n")
print(ph_diagnostics)
cat("End:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %Z"), "\n")

writeLines("passed", status_file)
sink(type = "message")
sink()
close(log_con)

from __future__ import annotations

import csv
import gzip
import json
from collections import Counter, defaultdict
from pathlib import Path


ROOT = Path(__file__).resolve().parent
MATRIX = ROOT / "downloads" / "GSE13159_series_matrix.txt.gz"
MAPPING = ROOT / "results" / "gpl570_five_gene_probe_mapping.tsv"
META_OUT = ROOT / "results" / "sample_metadata_raw.tsv"
EXPR_OUT = ROOT / "results" / "five_gene_probe_expression.tsv"
SUMMARY_OUT = ROOT / "results" / "metadata_summary.json"


def parse_row(line: str) -> list[str]:
    return next(csv.reader([line], delimiter="\t", quotechar='"'))


def main() -> None:
    probe_to_gene: dict[str, str] = {}
    with MAPPING.open(encoding="utf-8") as handle:
        for row in csv.DictReader(handle, delimiter="\t"):
            probe_to_gene[row["PROBEID"]] = row["SYMBOL"]

    metadata_rows: dict[str, list[list[str]]] = defaultdict(list)
    sample_ids: list[str] = []
    expression_rows: list[tuple[str, str, list[str]]] = []
    with gzip.open(MATRIX, "rt", encoding="utf-8", errors="replace", newline="") as handle:
        in_table = False
        for raw in handle:
            line = raw.rstrip("\r\n")
            if not in_table:
                if line == "!series_matrix_table_begin":
                    in_table = True
                    continue
                if line.startswith("!Sample_"):
                    fields = parse_row(line)
                    metadata_rows[fields[0]].append(fields[1:])
                continue
            if not sample_ids:
                fields = parse_row(line)
                if not fields or fields[0] != "ID_REF":
                    raise RuntimeError("unexpected matrix header")
                sample_ids = fields[1:]
                continue
            if line == "!series_matrix_table_end":
                break
            fields = parse_row(line)
            if fields and fields[0] in probe_to_gene:
                if len(fields) - 1 != len(sample_ids):
                    raise RuntimeError(f"probe row width mismatch for {fields[0]}")
                expression_rows.append((fields[0], probe_to_gene[fields[0]], fields[1:]))

    if not sample_ids:
        raise RuntimeError("no sample IDs found")
    if len(expression_rows) != len(probe_to_gene):
        found = {row[0] for row in expression_rows}
        missing = sorted(set(probe_to_gene) - found)
        raise RuntimeError(f"missing target probes: {missing}")

    accessions = metadata_rows.get("!Sample_geo_accession", [[]])[0]
    if accessions and accessions != sample_ids:
        raise RuntimeError("sample order mismatch between metadata and matrix")

    scalar_keys = [
        "!Sample_title",
        "!Sample_geo_accession",
        "!Sample_source_name_ch1",
        "!Sample_organism_ch1",
        "!Sample_molecule_ch1",
        "!Sample_extract_protocol_ch1",
        "!Sample_data_processing",
    ]
    characteristic_rows = metadata_rows.get("!Sample_characteristics_ch1", [])
    columns = ["sample_index", "sample_id"]
    for key in scalar_keys:
        columns.append(key.removeprefix("!Sample_"))
    columns.extend(f"characteristics_ch1_{i + 1}" for i in range(len(characteristic_rows)))

    with META_OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(columns)
        for i, sample_id in enumerate(sample_ids):
            values: list[object] = [i + 1, sample_id]
            for key in scalar_keys:
                rows = metadata_rows.get(key, [])
                values.append(rows[0][i] if rows and i < len(rows[0]) else "")
            for row in characteristic_rows:
                values.append(row[i] if i < len(row) else "")
            writer.writerow(values)

    with EXPR_OUT.open("w", encoding="utf-8", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["sample_id", "probe_id", "gene", "expression"])
        for probe_id, gene, values in expression_rows:
            for sample_id, value in zip(sample_ids, values):
                writer.writerow([sample_id, probe_id, gene, value])

    summary: dict[str, object] = {
        "sample_count": len(sample_ids),
        "target_probe_count": len(expression_rows),
        "metadata_keys": {key: len(rows) for key, rows in metadata_rows.items()},
        "top_values": {},
    }
    for key in ["!Sample_title", "!Sample_source_name_ch1"]:
        rows = metadata_rows.get(key, [])
        if rows:
            summary["top_values"][key] = Counter(rows[0]).most_common(30)
    for idx, row in enumerate(characteristic_rows, 1):
        summary["top_values"][f"!Sample_characteristics_ch1_{idx}"] = Counter(row).most_common(30)
    SUMMARY_OUT.write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

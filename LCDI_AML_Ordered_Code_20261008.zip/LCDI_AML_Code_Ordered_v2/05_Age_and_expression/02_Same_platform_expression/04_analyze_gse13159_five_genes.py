from __future__ import annotations

import json
import math
import platform
from pathlib import Path

import matplotlib
import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
import scipy
from scipy.stats import mannwhitneyu, rankdata


ROOT = Path(__file__).resolve().parent
RESULTS = ROOT / "results"
FIGURES = ROOT / "figures"
GENES = ["MPO", "CREB1", "GPX4", "SLC16A4", "CASP1"]
SEED = 20260804
BOOTSTRAPS = 2000


def bh_adjust(values: pd.Series) -> np.ndarray:
    p = np.asarray(values, dtype=float)
    order = np.argsort(p)
    ranked = p[order]
    adjusted = ranked * len(p) / np.arange(1, len(p) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    result = np.empty_like(adjusted)
    result[order] = np.minimum(adjusted, 1.0)
    return result


def rank_biserial(x: np.ndarray, y: np.ndarray) -> float:
    ranks = rankdata(np.concatenate([x, y]), method="average")
    nx = len(x)
    u = ranks[:nx].sum() - nx * (nx + 1) / 2
    return float(2 * u / (nx * len(y)) - 1)


def bootstrap_ci(x: np.ndarray, y: np.ndarray, rng: np.random.Generator) -> tuple[float, float]:
    vals = np.empty(BOOTSTRAPS, dtype=float)
    for index in range(BOOTSTRAPS):
        xb = rng.choice(x, size=len(x), replace=True)
        yb = rng.choice(y, size=len(y), replace=True)
        vals[index] = rank_biserial(xb, yb)
    low, high = np.quantile(vals, [0.025, 0.975], method="weibull")
    return float(low), float(high)


def summarize(group: pd.DataFrame, rng: np.random.Generator, bootstrap: bool) -> dict[str, float | int | str]:
    x = group.loc[group["group"] == "AML BM", "expression"].to_numpy(dtype=float)
    y = group.loc[group["group"] == "Healthy BM", "expression"].to_numpy(dtype=float)
    test = mannwhitneyu(x, y, alternative="two-sided", method="asymptotic")
    effect = rank_biserial(x, y)
    low, high = bootstrap_ci(x, y, rng) if bootstrap else (math.nan, math.nan)
    return {
        "n_aml": len(x),
        "n_healthy": len(y),
        "aml_mean": float(np.mean(x)),
        "healthy_mean": float(np.mean(y)),
        "mean_difference": float(np.mean(x) - np.mean(y)),
        "aml_median": float(np.median(x)),
        "healthy_median": float(np.median(y)),
        "median_difference": float(np.median(x) - np.median(y)),
        "rank_biserial": effect,
        "rank_biserial_ci_low": low,
        "rank_biserial_ci_high": high,
        "mann_whitney_u": float(test.statistic),
        "raw_p": float(test.pvalue),
        "direction": "Higher_in_AML" if np.mean(x) > np.mean(y) else "Lower_in_AML",
    }


def main() -> None:
    RESULTS.mkdir(parents=True, exist_ok=True)
    FIGURES.mkdir(parents=True, exist_ok=True)
    meta = pd.read_csv(RESULTS / "sample_metadata_raw.tsv", sep="\t", dtype=str)
    expr = pd.read_csv(RESULTS / "five_gene_probe_expression.tsv", sep="\t")
    mapping = pd.read_csv(RESULTS / "gpl570_five_gene_probe_mapping.tsv", sep="\t")

    meta["sample_type"] = meta["characteristics_ch1_1"].str.replace("sample type: ", "", regex=False)
    meta["leukemia_class"] = meta["characteristics_ch1_2"].str.replace("leukemia class: ", "", regex=False)
    meta["group"] = np.where(
        (meta["sample_type"] == "bone marrow")
        & (meta["leukemia_class"] == "Non-leukemia and healthy bone marrow"),
        "Healthy BM",
        np.where(
            (meta["sample_type"] == "bone marrow") & meta["leukemia_class"].str.startswith("AML"),
            "AML BM",
            None,
        ),
    )
    included = meta.loc[meta["group"].notna(), ["sample_id", "sample_type", "leukemia_class", "group"]].copy()
    counts = included["group"].value_counts().to_dict()
    assert counts == {"AML BM": 501, "Healthy BM": 73}, counts
    included.to_csv(RESULTS / "included_samples.tsv", sep="\t", index=False)

    dat = expr.merge(included[["sample_id", "group"]], on="sample_id", how="inner", validate="many_to_one")
    dat["expression"] = pd.to_numeric(dat["expression"], errors="raise")
    assert not dat["expression"].isna().any()

    means = dat.groupby(["gene", "probe_id"], as_index=False)["expression"].mean().rename(columns={"expression": "overall_mean"})
    means["specific_at"] = means["probe_id"].str.endswith("_at") & ~means["probe_id"].str.endswith(("_s_at", "_x_at"))
    selection = (
        means.loc[means["specific_at"]]
        .sort_values(["gene", "overall_mean"], ascending=[True, False])
        .groupby("gene", as_index=False)
        .head(1)
    )
    selection["selection_rule"] = "Specific _at probe with highest mean signal across included samples; group labels not used"
    selection["gene_order"] = selection["gene"].map({gene: i for i, gene in enumerate(GENES)})
    selection = selection.sort_values("gene_order").drop(columns="gene_order")
    assert selection["gene"].tolist() == GENES
    selection.to_csv(RESULTS / "primary_probe_selection.tsv", sep="\t", index=False)

    rng = np.random.default_rng(SEED)
    all_rows: list[dict[str, float | int | str]] = []
    for (gene, probe_id), group in dat.groupby(["gene", "probe_id"], sort=False):
        row = {"gene": gene, "probe_id": probe_id}
        row.update(summarize(group, rng, bootstrap=False))
        all_rows.append(row)
    all_results = pd.DataFrame(all_rows)
    all_results["bh_fdr_17_probes"] = bh_adjust(all_results["raw_p"])
    all_results["gene_order"] = all_results["gene"].map({gene: i for i, gene in enumerate(GENES)})
    all_results = all_results.sort_values(["gene_order", "probe_id"]).drop(columns="gene_order")
    all_results.to_csv(RESULTS / "all_probe_sensitivity_results.tsv", sep="\t", index=False)

    primary = dat.merge(selection[["gene", "probe_id", "overall_mean", "selection_rule"]], on=["gene", "probe_id"], how="inner")
    primary_rows: list[dict[str, float | int | str]] = []
    for gene in GENES:
        group = primary.loc[primary["gene"] == gene]
        probe_id = str(group["probe_id"].iloc[0])
        row = {"gene": gene, "probe_id": probe_id, "overall_mean": float(group["overall_mean"].iloc[0]), "selection_rule": str(group["selection_rule"].iloc[0])}
        row.update(summarize(group, rng, bootstrap=True))
        primary_rows.append(row)
    primary_results = pd.DataFrame(primary_rows)
    primary_results["bh_fdr_5_genes"] = bh_adjust(primary_results["raw_p"])
    primary_results.to_csv(RESULTS / "primary_five_gene_results.tsv", sep="\t", index=False)

    colors = {"Healthy BM": "#4C78A8", "AML BM": "#D55E00"}
    fig, axes = plt.subplots(1, 5, figsize=(11.5, 4.3))
    jitter_rng = np.random.default_rng(SEED)
    for axis, gene in zip(axes, GENES):
        subset = primary.loc[primary["gene"] == gene]
        groups = [subset.loc[subset["group"] == label, "expression"].to_numpy() for label in ["Healthy BM", "AML BM"]]
        violin = axis.violinplot(groups, positions=[1, 2], widths=0.78, showmeans=False, showmedians=False, showextrema=False)
        for body, label in zip(violin["bodies"], ["Healthy BM", "AML BM"]):
            body.set_facecolor(colors[label])
            body.set_edgecolor("none")
            body.set_alpha(0.45)
        box = axis.boxplot(groups, positions=[1, 2], widths=0.24, patch_artist=True, showfliers=False, medianprops={"color": "#111111", "linewidth": 1.0})
        for patch, label in zip(box["boxes"], ["Healthy BM", "AML BM"]):
            patch.set_facecolor(colors[label])
            patch.set_alpha(0.78)
            patch.set_linewidth(0.6)
        for position, values in zip([1, 2], groups):
            jitter = jitter_rng.uniform(-0.12, 0.12, size=len(values))
            axis.scatter(np.full(len(values), position) + jitter, values, s=4, alpha=0.16, color="#202020", linewidths=0)
        result = primary_results.loc[primary_results["gene"] == gene].iloc[0]
        label = (
            f"MD={result['mean_difference']:.3f}\n"
            f"r={result['rank_biserial']:.2f} ({result['rank_biserial_ci_low']:.2f}, {result['rank_biserial_ci_high']:.2f})\n"
            f"FDR={result['bh_fdr_5_genes']:.2g}"
        )
        axis.text(0.98, 0.98, label, transform=axis.transAxes, ha="right", va="top", fontsize=7.7)
        axis.set_title(gene, fontsize=10, fontweight="bold")
        axis.set_xticks([1, 2], ["Healthy BM\n(n=73)", "AML BM\n(n=501)"], fontsize=7.5)
        axis.grid(axis="y", color="#D9D9D9", linewidth=0.5, alpha=0.7)
        axis.set_axisbelow(True)
        axis.spines[["top", "right"]].set_visible(False)
        if axis is axes[0]:
            axis.set_ylabel("Normalized microarray signal (unitless)", fontsize=9)
    fig.suptitle("Five-gene expression in AML and healthy bone marrow (GSE13159)", fontsize=12, fontweight="bold", y=0.98)
    fig.text(0.5, 0.925, "Strict bone-marrow subset; MD, mean difference; r, rank-biserial effect (95% bootstrap CI)", ha="center", fontsize=8.5)
    fig.subplots_adjust(left=0.065, right=0.995, top=0.82, bottom=0.20, wspace=0.27)
    png = FIGURES / "gse13159_five_gene_expression_v1.png"
    pdf = FIGURES / "gse13159_five_gene_expression_v1.pdf"
    fig.savefig(png, dpi=400, facecolor="white")
    fig.savefig(pdf, facecolor="white")
    plt.close(fig)

    summary = {
        "dataset": "GSE13159",
        "platform": "GPL570",
        "included": counts,
        "excluded": {"AML peripheral blood": 41, "Healthy peripheral blood": 1, "Other leukemia or MDS": 1480},
        "normalization": meta["data_processing"].dropna().unique().tolist(),
        "primary_probe_rule": selection["selection_rule"].iloc[0],
        "primary_test": "two-sided Mann-Whitney U; BH across five primary genes",
        "sensitivity": "all 17 mapped probes; BH across 17 probes",
        "bootstrap": {"seed": SEED, "replicates": BOOTSTRAPS, "unit": "patient sample", "stratified_by_group": True},
        "environment": {"python": platform.python_version(), "numpy": np.__version__, "pandas": pd.__version__, "scipy": scipy.__version__, "matplotlib": matplotlib.__version__},
    }
    (RESULTS / "analysis_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(primary_results.to_string(index=False))
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

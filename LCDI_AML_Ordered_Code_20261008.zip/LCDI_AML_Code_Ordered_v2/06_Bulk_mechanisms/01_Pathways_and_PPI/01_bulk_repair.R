options(stringsAsFactors=FALSE,warn=1,width=160)
root<-'D:/26_01_AML'; out<-file.path(root,'_codex_audit/upstream_repair_20260905_v1/bulk');dir.create(out,showWarnings=FALSE)
if(file.exists(file.path(out,'COMPLETE'))) stop('Completed output exists')
con<-file(file.path(out,'run.log'),'wt');sink(con,split=TRUE);sink(con,type='message')
suppressPackageStartupMessages({library(limma);library(clusterProfiler);library(org.Hs.eg.db);library(AnnotationDbi);library(msigdbr)})
BiocParallel::register(BiocParallel::SerialParam())
w<-function(x,n)write.table(x,file.path(out,n),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
base<-file.path(root,'AML_Lactylation_PCD/data/processed/mime/clean')
beta<-c(CREB1=.0925,SLC16A4=-.0636,GPX4=-.0721,CASP1=-.0106,MPO=-.2095)
sc<-read.delim(file.path(root,'_codex_audit/cindex_nomogram_reconciliation_20260902_v1/01_patient_scores.tsv'),check.names=FALSE)
sc<-sc[sc$cohort=='GPL96_Train',];stopifnot(nrow(sc)==580,!anyDuplicated(sc$sample_id),!anyDuplicated(sc$subject_id))
expr<-readRDS(file.path(base,'GPL96_Train_full_expr.rds'));stopifnot(all(sc$sample_id%in%colnames(expr)),!anyDuplicated(rownames(expr)))
expr<-as.matrix(expr[,sc$sample_id]);stopifnot(all(is.finite(expr)))
b2<-readRDS(file.path(base,'B_cohort_data_5cohorts_clinical_v2.rds'))$GPL96_Train
oldscore<-b2$surv$LCDI[match(sc$sample_id,b2$surv$sample_id)]
sc$old_LCDI<-oldscore;sc$old_group<-ifelse(oldscore>median(oldscore),'High','Low');sc$group<-ifelse(sc$LCDI>median(sc$LCDI),'High','Low')
sc$changed<-sc$old_group!=sc$group
frozen_calc<-as.numeric(as.matrix(sc[,paste0('z_',names(beta))])%*%beta)
full_z_calc<-as.numeric(scale(t(expr[names(beta),]))%*%beta)
raw_calc<-as.numeric(t(expr[names(beta),])%*%beta)
qc<-data.frame(metric=c('samples','genes','events','old_median','new_median','changed_groups','frozen_formula_max_error','full_expression_z_score_max_error','raw_expression_vs_old_score_max_error','expression_NA','duplicate_sample_id'),value=c(nrow(sc),nrow(expr),sum(sc$status),median(oldscore),median(sc$LCDI),sum(sc$changed),max(abs(frozen_calc-sc$LCDI)),max(abs(full_z_calc-sc$LCDI)),max(abs(raw_calc-oldscore)),sum(!is.finite(expr)),anyDuplicated(sc$sample_id)))
stopifnot(max(abs(frozen_calc-sc$LCDI))<1e-10,max(abs(full_z_calc-sc$LCDI))<1e-7,sum(sc$changed)==48)
w(sc,'01_corrected_sample_scores_groups.tsv');w(qc,'01_input_score_qc.tsv')
de<-function(gr){g<-factor(gr,levels=c('Low','High'));fit<-eBayes(lmFit(expr,model.matrix(~g)));tab<-topTable(fit,coef=2,number=Inf,sort.by='none');tab$gene<-rownames(tab);list(fit=fit,tab=tab)}
legacy<-readRDS(file.path(base,'phaseE2_GSEA_results.rds'))
oldfit<-de(sc$old_group);oldtab<-legacy$deg
if(!'gene'%in%names(oldtab)) oldtab$gene<-rownames(oldtab)
oldtab<-oldtab[match(oldfit$tab$gene,oldtab$gene),]
err<-max(abs(oldfit$tab$logFC-oldtab$logFC));stopifnot(is.finite(err),err<1e-8)
w(data.frame(metric=c('legacy_DEG_reproduction_max_logFC_error','legacy_median_matches_saved'),value=c(err,abs(median(oldscore)-legacy$median_lcdi)<1e-10)),'02_legacy_reproduction.tsv')
newfit<-de(sc$group);deg<-newfit$tab;w(deg,'02_DEG_all.tsv');write.csv(deg,file.path(out,'02_DEG_all.csv'),row.names=FALSE)
cmp<-merge(oldtab[,c('gene','logFC','adj.P.Val')],deg[,c('gene','logFC','adj.P.Val')],by='gene',suffixes=c('_old','_new'));cmp$selected_old<-cmp$adj.P.Val_old<.05&abs(cmp$logFC_old)>.5;cmp$selected_new<-cmp$adj.P.Val_new<.05&abs(cmp$logFC_new)>.5;w(cmp,'02_DEG_before_after.tsv')
selected<-deg[deg$adj.P.Val<.05&abs(deg$logFC)>.5,];selected$direction<-ifelse(selected$logFC>0,'Up_in_LCDI_High','Down_in_LCDI_High');w(selected,'02_selected_DEGs.tsv')
ranked<-sort(setNames(newfit$fit$t[,2],rownames(expr)),decreasing=TRUE)
gsea_results<-list()
for(kind in c('hallmark','kegg')) {
 obj<-legacy[[paste0('gsea_',kind)]]; gs<-obj@geneSets
 t2g<-data.frame(term=rep(names(gs),lengths(gs)),gene=unlist(gs,use.names=FALSE));w(t2g,paste0('03_frozen_',kind,'_TERM2GENE.tsv'))
 set.seed(42);cat('GSEA',kind,format(Sys.time()),'\n')
 fit<-GSEA(ranked,TERM2GENE=t2g,pvalueCutoff=1,pAdjustMethod='BH',minGSSize=obj@params$minGSSize,maxGSSize=obj@params$maxGSSize,exponent=obj@params$exponent,eps=1e-10,verbose=FALSE)
 tab<-as.data.frame(fit);w(tab,paste0('03_GSEA_',kind,'_all.tsv'));gsea_results[[kind]]<-fit
 old<-as.data.frame(obj@result);comp<-merge(old[,c('ID','NES','pvalue','p.adjust')],tab[,c('ID','NES','pvalue','p.adjust')],by='ID',all=TRUE,suffixes=c('_old','_new'));w(comp,paste0('03_GSEA_',kind,'_before_after.tsv'))
}
saveRDS(gsea_results,file.path(out,'03_GSEA_results.rds'))
cat('ORA',format(Sys.time()),'\n')
mapping<-unique(AnnotationDbi::select(org.Hs.eg.db,keys=rownames(expr),keytype='SYMBOL',columns='ENTREZID'));mapping<-mapping[!is.na(mapping$ENTREZID),];w(mapping,'04_symbol_entrez_mapping.tsv');uni<-unique(mapping$ENTREZID)
kg<-msigdbr(species='Homo sapiens',category='C2',subcategory='CP:KEGG');t2g<-unique(as.data.frame(kg[,c('gs_name','gene_symbol')]));w(t2g,'04_KEGG_ORA_TERM2GENE.tsv')
ors<-list()
for(d in unique(selected$direction)) {
 sy<-selected$gene[selected$direction==d]; ids<-unique(mapping$ENTREZID[mapping$SYMBOL%in%sy])
 for(db in c('BP','CC','MF','KEGG')) {
  if(db=='KEGG') fit<-enricher(sy,universe=rownames(expr),TERM2GENE=t2g,minGSSize=10,maxGSSize=500,pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH') else fit<-enrichGO(ids,universe=uni,OrgDb=org.Hs.eg.db,keyType='ENTREZID',ont=db,readable=TRUE,minGSSize=10,maxGSSize=500,pvalueCutoff=1,qvalueCutoff=1,pAdjustMethod='BH')
  tab<-as.data.frame(fit);if(nrow(tab)){tab$direction<-d;tab$database<-if(db=='KEGG') db else paste0('GO_',db);ors[[length(ors)+1]]<-tab}
 }
}
ora<-do.call(rbind,ors);w(ora,'04_GO_KEGG_ORA_all.tsv');w(do.call(rbind,lapply(split(ora,paste(ora$direction,ora$database)),function(x)data.frame(direction=x$direction[1],database=x$database[1],tested=nrow(x),FDR_lt_05=sum(x$p.adjust<.05)))),'04_ORA_summary.tsv')
cat('Cached immune and drug statistics',format(Sys.time()),'\n')
immune<-readRDS(file.path(base,'phaseE3_ssGSEA_scores.rds'));immune<-as.matrix(immune[,sc$sample_id]);g<-factor(sc$group,levels=c('Low','High'))
fit<-eBayes(lmFit(immune,model.matrix(~g)));im<-topTable(fit,coef=2,number=Inf,sort.by='none');im$cell<-rownames(im);im$mean_low<-rowMeans(immune[,g=='Low']);im$mean_high<-rowMeans(immune[,g=='High']);im$rho<-apply(immune,1,function(y)cor(sc$LCDI,y,method='spearman'));im$cor_p<-apply(immune,1,function(y)cor.test(sc$LCDI,y,method='spearman',exact=FALSE)$p.value);im$cor_FDR<-p.adjust(im$cor_p,'BH');w(im,'05_immune_all.tsv')
oi<-readRDS(file.path(base,'phaseE3_immune_results.rds'))$diff_im;w(merge(oi,im,by='cell',suffixes=c('_old','_new')),'05_immune_before_after.tsv')
pred<-as.matrix(readRDS(file.path(base,'phaseE4_GDSC_IC50_pred.rds'))[sc$sample_id,,drop=FALSE]);stopifnot(!anyNA(pred),identical(rownames(pred),sc$sample_id))
dr<-do.call(rbind,lapply(seq_len(ncol(pred)),function(j){v<-pred[,j];lo<-median(v[g=='Low']);hi<-median(v[g=='High']);data.frame(drug=colnames(pred)[j],median_low=lo,median_high=hi,median_difference=hi-lo,log2FC=if(lo>0&&hi>0)log2(hi/lo) else NA_real_,p_wilcox=wilcox.test(v[g=='Low'],v[g=='High'])$p.value)}));dr$p_adj<-p.adjust(dr$p_wilcox,'BH');dr$direction<-ifelse(dr$median_difference<0,'High_more_sensitive','Low_more_sensitive');w(dr,'06_drug_all.tsv')
od<-readRDS(file.path(base,'phaseE4_drug_results.rds'));w(merge(od$diff_drug,dr,by='drug',suffixes=c('_old','_new')),'06_drug_before_after.tsv');capture.output(str(od$AML_drugs),file=file.path(out,'06_AML_drug_selection.txt'))
w(data.frame(metric=c('selected_DEGs','up','down','Hallmark_FDR05','KEGG_GSEA_FDR05','immune_FDR05','drug_FDR05','drug_tested','immune_tested'),value=c(nrow(selected),sum(selected$logFC>0),sum(selected$logFC<0),sum(gsea_results$hallmark@result$p.adjust<.05),sum(gsea_results$kegg@result$p.adjust<.05),sum(im$adj.P.Val<.05),sum(dr$p_adj<.05),ncol(pred),nrow(immune))),'07_summary.tsv')
capture.output(sessionInfo(),file=file.path(out,'session_info.txt'));writeLines('passed_computational_checks; PPI and independent validation separate',file.path(out,'COMPLETE'))
cat('COMPLETE',format(Sys.time()),'\n');sink(type='message');sink();close(con)

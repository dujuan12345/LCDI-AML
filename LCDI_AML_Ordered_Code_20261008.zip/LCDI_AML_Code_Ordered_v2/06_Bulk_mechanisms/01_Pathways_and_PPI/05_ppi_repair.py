from __future__ import annotations

import gzip
import hashlib
import json
from collections import defaultdict, deque
from pathlib import Path

import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
OUT = PROJECT / "_codex_audit" / "upstream_repair_20260905_v1" / "bulk"
DOWNLOADS = PROJECT / "_codex_audit" / "figure4_go_kegg_ppi_20260903_v1" / "downloads"
SELECTED = OUT / "02_selected_DEGs.tsv"
INFO = DOWNLOADS / "9606.protein.info.v12.0.txt.gz"
ALIASES = DOWNLOADS / "9606.protein.aliases.v12.0.clean.txt.gz"
LINKS = DOWNLOADS / "9606.protein.physical.links.v12.0.txt.gz"
MIN_SCORE = 400


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def read_tsv_gz(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", compression="gzip", low_memory=False)


def components(nodes: list[str], neighbors: dict[str, set[str]]) -> dict[str, int]:
    component_id: dict[str, int] = {}
    current = 0
    for start in nodes:
        if start in component_id:
            continue
        current += 1
        queue: deque[str] = deque([start])
        component_id[start] = current
        while queue:
            node = queue.popleft()
            for nxt in neighbors.get(node, set()):
                if nxt not in component_id:
                    component_id[nxt] = current
                    queue.append(nxt)
    return component_id


def main() -> None:
    for path in [SELECTED, INFO, ALIASES, LINKS]:
        if not path.is_file():
            raise FileNotFoundError(path)

    selected = pd.read_csv(SELECTED, sep="\t")
    selected_genes = selected["gene"].astype(str).tolist()
    selected_set = set(selected_genes)
    if not selected_genes or len(selected_genes) != len(selected_set):
        raise ValueError("Expected nonempty unique selected genes")

    info = read_tsv_gz(INFO)
    protein_col = "#string_protein_id" if "#string_protein_id" in info.columns else info.columns[0]
    name_col = "preferred_name"
    info = info[[protein_col, name_col]].rename(columns={protein_col: "string_protein_id", name_col: "preferred_name"})
    preferred = info.loc[info.preferred_name.isin(selected_set)].copy()

    alias_hits: list[dict[str, str]] = []
    mapped_symbols = set(preferred.preferred_name)
    missing = selected_set - mapped_symbols
    if missing:
        with gzip.open(ALIASES, "rt", encoding="utf-8") as handle:
            header = handle.readline().rstrip("\n").split("\t")
            protein_idx = header.index("#string_protein_id") if "#string_protein_id" in header else 0
            alias_idx = header.index("alias")
            source_idx = header.index("source")
            for line in handle:
                fields = line.rstrip("\n").split("\t")
                if fields[alias_idx] in missing:
                    alias_hits.append({
                        "string_protein_id": fields[protein_idx],
                        "preferred_name": fields[alias_idx],
                        "mapping_source": fields[source_idx],
                    })

    preferred["mapping_source"] = "preferred_name"
    mapping = pd.concat([preferred, pd.DataFrame(alias_hits)], ignore_index=True)
    mapping = mapping.sort_values(["preferred_name", "mapping_source", "string_protein_id"]).drop_duplicates("preferred_name")
    mapping = selected[["gene", "direction", "logFC", "adj.P.Val"]].merge(
        mapping, how="left", left_on="gene", right_on="preferred_name"
    )
    mapping.to_csv(OUT / "02_string_local_mapping.tsv", sep="\t", index=False)

    protein_to_gene = dict(zip(mapping.string_protein_id.dropna(), mapping.loc[mapping.string_protein_id.notna(), "gene"]))
    wanted = set(protein_to_gene)
    edge_rows: list[tuple[str, str, int]] = []
    with gzip.open(LINKS, "rt", encoding="utf-8") as handle:
        header = handle.readline().strip().split()
        if header[:3] != ["protein1", "protein2", "combined_score"]:
            raise ValueError(f"Unexpected STRING header: {header}")
        for line in handle:
            protein1, protein2, score_text = line.rstrip().split()
            score = int(score_text)
            if score >= MIN_SCORE and protein1 in wanted and protein2 in wanted and protein1 != protein2:
                gene1, gene2 = protein_to_gene[protein1], protein_to_gene[protein2]
                a, b = sorted((gene1, gene2))
                edge_rows.append((a, b, score))

    edges = pd.DataFrame(edge_rows, columns=["from", "to", "combined_score"])
    if len(edges):
        edges = edges.sort_values("combined_score", ascending=False).drop_duplicates(["from", "to"])
    edges.to_csv(OUT / "02_string_physical_edges.tsv", sep="\t", index=False)

    neighbors: dict[str, set[str]] = defaultdict(set)
    for row in edges.itertuples(index=False):
        neighbors[row[0]].add(row[1])
        neighbors[row[1]].add(row[0])
    comp = components(selected_genes, neighbors)
    nodes = selected[["gene", "direction", "logFC", "adj.P.Val"]].copy()
    nodes["mapped_to_string"] = nodes.gene.isin(set(mapping.loc[mapping.string_protein_id.notna(), "gene"]))
    nodes["degree"] = nodes.gene.map(lambda gene: len(neighbors.get(gene, set())))
    nodes["component_id"] = nodes.gene.map(comp)
    nodes["isolated"] = nodes.degree.eq(0)
    nodes = nodes.sort_values(["degree", "adj.P.Val"], ascending=[False, True])
    nodes.to_csv(OUT / "02_string_physical_nodes.tsv", sep="\t", index=False)

    status = {
        "status": "passed",
        "string_version": "12.0",
        "species": 9606,
        "network_type": "physical",
        "required_score": MIN_SCORE,
        "additional_nodes": 0,
        "selected_genes": len(selected_genes),
        "mapped_genes": int(nodes.mapped_to_string.sum()),
        "network_nodes_with_edges": int((nodes.degree > 0).sum()),
        "isolated_nodes": int(nodes.isolated.sum()),
        "edges": int(len(edges)),
        "components_including_isolates": int(nodes.component_id.nunique()),
        "top_degree": nodes.loc[:, ["gene", "degree"]].head(10).to_dict("records"),
        "downloads": {path.name: {"bytes": path.stat().st_size, "sha256": sha256(path)} for path in [INFO, ALIASES, LINKS]},
        "input_sha256": sha256(SELECTED),
    }
    (OUT / "02_string_local_status.json").write_text(json.dumps(status, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(status, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

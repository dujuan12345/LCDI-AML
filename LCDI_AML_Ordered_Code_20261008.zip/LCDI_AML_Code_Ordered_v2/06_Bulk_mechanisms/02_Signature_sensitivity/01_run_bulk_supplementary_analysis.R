options(stringsAsFactors = FALSE)
set.seed(20260801)

out_dir <- "D:/26_01_AML/_codex_audit/chapter7_supplementary_analysis_20260801_v1"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

log_path <- file.path(out_dir, "01_run_bulk_supplementary_analysis.log")
log_con <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_con, type = "output")
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

cat("Chapter 7 bulk supplementary analysis\n")
cat("Date:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Seed: 20260801\n")

suppressPackageStartupMessages({
  library(limma)
})

expr_path <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/GPL96_Train_full_expr.rds"
immune_path <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/phaseE3_immune_results.rds"
geneset_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/genesets_used.rds"

expr <- readRDS(expr_path)
immune <- readRDS(immune_path)
genesets_saved <- readRDS(geneset_path)

stopifnot(is.matrix(expr), nrow(expr) == 13039L, ncol(expr) == 580L)
stopifnot(all(c("group", "lcdi", "median_lcdi") %in% names(immune)))

stopifnot(length(immune$lcdi) == length(immune$group))
names(immune$lcdi) <- names(immune$group)
sample_ids <- intersect(colnames(expr), names(immune$group))
stopifnot(length(sample_ids) == 580L)
expr <- expr[, sample_ids, drop = FALSE]
group <- factor(as.character(immune$group[sample_ids]), levels = c("Low", "High"))
lcdi <- as.numeric(immune$lcdi[sample_ids])
names(lcdi) <- sample_ids
stopifnot(!anyNA(group), !anyNA(lcdi), sum(group == "Low") == 290L, sum(group == "High") == 290L)

cat("Expression:", nrow(expr), "genes x", ncol(expr), "samples\n")
cat("Groups: Low=", sum(group == "Low"), "; High=", sum(group == "High"), "\n", sep = "")
cat("LCDI median:", median(lcdi), "\n")

marker_families <- list(
  T_cell_identity = c("CD3D", "CD3E", "CD247", "CD4", "CD8A", "CD8B"),
  Cytotoxic_effectors = c("GZMB", "PRF1", "NKG7", "GNLY", "CCL5"),
  ISG_core = c("IFI44", "MX1", "OAS1", "IFIT1", "IFIT3", "ISG15")
)
marker_table <- do.call(rbind, lapply(names(marker_families), function(family) {
  data.frame(family = family, gene = marker_families[[family]])
}))
marker_table$present <- marker_table$gene %in% rownames(expr)
utils::write.table(marker_table, file.path(out_dir, "01_marker_gene_coverage.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)
if (any(!marker_table$present)) {
  cat("Missing planned marker genes:", paste(marker_table$gene[!marker_table$present], collapse = ";"), "\n")
}

marker_genes <- marker_table$gene[marker_table$present]
design <- model.matrix(~ group)
colnames(design) <- c("Intercept", "HighVsLow")
marker_fit <- eBayes(lmFit(expr[marker_genes, , drop = FALSE], design))
marker_tt <- topTable(marker_fit, coef = "HighVsLow", number = Inf, sort.by = "none")
marker_tt$gene <- rownames(marker_tt)
marker_tt$family <- marker_table$family[match(marker_tt$gene, marker_table$gene)]
marker_tt$mean_low <- rowMeans(expr[marker_tt$gene, group == "Low", drop = FALSE])
marker_tt$mean_high <- rowMeans(expr[marker_tt$gene, group == "High", drop = FALSE])
marker_tt$mean_difference <- marker_tt$mean_high - marker_tt$mean_low
marker_tt$cohen_d <- vapply(marker_tt$gene, function(gene) {
  x <- expr[gene, group == "High"]
  y <- expr[gene, group == "Low"]
  pooled <- sqrt(((length(x) - 1) * stats::var(x) + (length(y) - 1) * stats::var(y)) /
                   (length(x) + length(y) - 2))
  if (is.finite(pooled) && pooled > 0) (mean(x) - mean(y)) / pooled else NA_real_
}, numeric(1))

marker_cor <- lapply(marker_tt$gene, function(gene) {
  test <- suppressWarnings(stats::cor.test(expr[gene, ], lcdi, method = "spearman", exact = FALSE))
  data.frame(gene = gene, spearman_rho = unname(test$estimate), spearman_p = test$p.value)
})
marker_cor <- do.call(rbind, marker_cor)
marker_cor$spearman_fdr <- p.adjust(marker_cor$spearman_p, method = "BH")
marker_tt <- merge(marker_tt, marker_cor, by = "gene", sort = FALSE)
marker_tt$group_fdr_family <- ave(marker_tt$P.Value, marker_tt$family, FUN = function(x) p.adjust(x, "BH"))

neutrophil_sets <- list(
  Neutrophil_original = c("CSF3R", "FCGR3B", "FFAR2", "CXCR1", "CXCR2", "MPO", "ELANE", "CTSG"),
  Neutrophil_no_MPO = c("CSF3R", "FCGR3B", "FFAR2", "CXCR1", "CXCR2", "ELANE", "CTSG"),
  Neutrophil_no_MPO_ELANE_CTSG = c("CSF3R", "FCGR3B", "FFAR2", "CXCR1", "CXCR2")
)

lsc17_aliases <- list(
  DNMT3B = c("DNMT3B"), ZBTB46 = c("ZBTB46"), NYNRIN = c("NYNRIN"),
  ARHGAP22 = c("ARHGAP22"), LAPTM4B = c("LAPTM4B"), MMRN1 = c("MMRN1"),
  DPYSL3 = c("DPYSL3"), FAM30A = c("FAM30A", "KIAA0125"), CDK6 = c("CDK6"),
  CPXM1 = c("CPXM1"), SOCS2 = c("SOCS2"), SMIM24 = c("SMIM24"),
  EMP1 = c("EMP1"), BEX3 = c("BEX3", "NGFRAP1"), CD34 = c("CD34"),
  AKR1C3 = c("AKR1C3"), ADGRG1 = c("ADGRG1", "GPR56")
)
lsc17_weights <- c(
  DNMT3B = 0.0874, ZBTB46 = -0.0347, NYNRIN = 0.00865, ARHGAP22 = -0.0138,
  LAPTM4B = 0.00582, MMRN1 = 0.0258, DPYSL3 = 0.0284, FAM30A = 0.0196,
  CDK6 = -0.0704, CPXM1 = -0.0258, SOCS2 = 0.0271, SMIM24 = -0.0226,
  EMP1 = 0.0146, BEX3 = 0.0465, CD34 = 0.0338, AKR1C3 = -0.0402,
  ADGRG1 = 0.0501
)
lsc_mapping <- do.call(rbind, lapply(names(lsc17_aliases), function(canonical) {
  candidates <- lsc17_aliases[[canonical]]
  hits <- candidates[candidates %in% rownames(expr)]
  data.frame(
    canonical_symbol = canonical,
    source_aliases = paste(candidates, collapse = ";"),
    matched_expression_symbol = if (length(hits)) hits[1] else NA_character_,
    weight = lsc17_weights[canonical],
    present = length(hits) > 0
  )
}))
utils::write.table(lsc_mapping, file.path(out_dir, "01_lsc17_gene_mapping.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE, na = "")
cat("LSC17 mapped genes:", sum(lsc_mapping$present), "/17\n")

lsc_matched <- lsc_mapping$matched_expression_symbol[lsc_mapping$present]
lsc_z <- t(scale(t(expr[lsc_matched, , drop = FALSE])))
rownames(lsc_z) <- lsc_mapping$canonical_symbol[lsc_mapping$present]
lsc17_score <- colSums(lsc_z * lsc17_weights[rownames(lsc_z)])

signature_sets <- c(
  marker_families,
  neutrophil_sets,
  list(
    Hallmark_IFN_alpha = genesets_saved[["HALLMARK_INTERFERON_ALPHA_RESPONSE"]],
    LSC17_available_genes_mean_z = names(lsc17_aliases),
    VEGF_signaling_exploratory = genesets_saved[["KEGG_VEGF_SIGNALING_PATHWAY"]]
  )
)

# Replace canonical LSC17 symbols with the expression-matched symbols.
signature_sets[["LSC17_available_genes_mean_z"]] <- lsc_matched
signature_sets_planned <- signature_sets
signature_sets <- lapply(signature_sets_planned, function(gs) unique(gs[gs %in% rownames(expr)]))
coverage <- data.frame(
  signature = names(signature_sets),
  n_genes_planned = lengths(signature_sets_planned),
  n_genes_present = lengths(signature_sets),
  genes_present = vapply(signature_sets, paste, collapse = ";", FUN.VALUE = character(1))
)
utils::write.table(coverage, file.path(out_dir, "01_signature_gene_coverage.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)
stopifnot(all(coverage$n_genes_present >= 3L))

cat("Calculating transparent mean-z scores for", length(signature_sets), "planned signatures\n")
mean_z_score <- function(genes) {
  z <- t(scale(t(expr[genes, sample_ids, drop = FALSE])))
  z[!is.finite(z)] <- 0
  colMeans(z)
}
signature_scores <- do.call(rbind, lapply(signature_sets, mean_z_score))
rownames(signature_scores) <- names(signature_sets)
lsc_partial_name <- paste0("Adapted_LSC", sum(lsc_mapping$present), "_weighted_z")
signature_scores <- rbind(signature_scores, lsc17_score[sample_ids])
rownames(signature_scores)[nrow(signature_scores)] <- lsc_partial_name

signature_fit <- eBayes(lmFit(signature_scores, design))
signature_tt <- topTable(signature_fit, coef = "HighVsLow", number = Inf, sort.by = "none")
signature_tt$signature <- rownames(signature_tt)
signature_tt$mean_low <- rowMeans(signature_scores[signature_tt$signature, group == "Low", drop = FALSE])
signature_tt$mean_high <- rowMeans(signature_scores[signature_tt$signature, group == "High", drop = FALSE])
signature_tt$mean_difference <- signature_tt$mean_high - signature_tt$mean_low
signature_tt$cohen_d <- vapply(signature_tt$signature, function(sig) {
  x <- signature_scores[sig, group == "High"]
  y <- signature_scores[sig, group == "Low"]
  pooled <- sqrt(((length(x) - 1) * stats::var(x) + (length(y) - 1) * stats::var(y)) /
                   (length(x) + length(y) - 2))
  if (is.finite(pooled) && pooled > 0) (mean(x) - mean(y)) / pooled else NA_real_
}, numeric(1))
signature_tt$group_fdr <- p.adjust(signature_tt$P.Value, method = "BH")

signature_cor <- lapply(signature_tt$signature, function(sig) {
  test <- suppressWarnings(stats::cor.test(signature_scores[sig, ], lcdi, method = "spearman", exact = FALSE))
  data.frame(signature = sig, spearman_rho = unname(test$estimate), spearman_p = test$p.value)
})
signature_cor <- do.call(rbind, signature_cor)
signature_cor$spearman_fdr <- p.adjust(signature_cor$spearman_p, method = "BH")
signature_tt <- merge(signature_tt, signature_cor, by = "signature", sort = FALSE)

# Global multiplicity across all pre-specified group tests and continuous correlations.
combined_group_p <- c(marker_tt$P.Value, signature_tt$P.Value)
combined_cor_p <- c(marker_tt$spearman_p, signature_tt$spearman_p)
marker_tt$global_group_fdr <- p.adjust(combined_group_p, "BH")[seq_len(nrow(marker_tt))]
signature_tt$global_group_fdr <- p.adjust(combined_group_p, "BH")[-seq_len(nrow(marker_tt))]
marker_tt$global_spearman_fdr <- p.adjust(combined_cor_p, "BH")[seq_len(nrow(marker_tt))]
signature_tt$global_spearman_fdr <- p.adjust(combined_cor_p, "BH")[-seq_len(nrow(marker_tt))]

marker_cols <- c(
  "family", "gene", "mean_low", "mean_high", "mean_difference", "logFC", "cohen_d",
  "t", "P.Value", "adj.P.Val", "group_fdr_family", "global_group_fdr",
  "spearman_rho", "spearman_p", "spearman_fdr", "global_spearman_fdr"
)
signature_cols <- c(
  "signature", "mean_low", "mean_high", "mean_difference", "logFC", "cohen_d",
  "t", "P.Value", "adj.P.Val", "group_fdr", "global_group_fdr",
  "spearman_rho", "spearman_p", "spearman_fdr", "global_spearman_fdr"
)
marker_out <- marker_tt[, marker_cols]
signature_out <- signature_tt[, signature_cols]
utils::write.table(marker_out, file.path(out_dir, "01_bulk_marker_statistics.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)
utils::write.table(signature_out, file.path(out_dir, "01_bulk_signature_statistics.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

sample_scores <- data.frame(
  sample_id = sample_ids,
  group = as.character(group),
  LCDI = lcdi[sample_ids],
  t(signature_scores[, sample_ids, drop = FALSE]),
  check.names = FALSE
)
utils::write.table(sample_scores, file.path(out_dir, "01_bulk_sample_signature_scores.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

selected_matrix <- rbind(
  LCDI = lcdi,
  `Adapted LSC partial` = signature_scores[lsc_partial_name, ],
  `IFN-alpha` = signature_scores["Hallmark_IFN_alpha", ],
  `ISG core` = signature_scores["ISG_core", ],
  `T-cell identity` = signature_scores["T_cell_identity", ],
  `Cytotoxic effectors` = signature_scores["Cytotoxic_effectors", ],
  Neutrophil = signature_scores["Neutrophil_original", ],
  `Neutrophil no MPO` = signature_scores["Neutrophil_no_MPO", ],
  `Neutrophil core` = signature_scores["Neutrophil_no_MPO_ELANE_CTSG", ],
  `VEGF signaling` = signature_scores["VEGF_signaling_exploratory", ]
)
cor_matrix <- stats::cor(t(selected_matrix), method = "spearman", use = "pairwise.complete.obs")
utils::write.table(cor_matrix, file.path(out_dir, "01_bulk_signature_spearman_matrix.tsv"),
                   sep = "\t", row.names = TRUE, col.names = NA, quote = FALSE)

plot_heatmap <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") grDevices::pdf(filename, width = 8.8, height = 7.6)
  else grDevices::png(filename, width = 2200, height = 1900, res = 260)
  n <- nrow(cor_matrix)
  old_par <- graphics::par(no.readonly = TRUE)
  graphics::par(mar = c(10, 10, 4, 2))
  cols <- grDevices::colorRampPalette(c("#2166AC", "#F7F7F7", "#B2182B"))(101)
  graphics::image(
    x = seq_len(n), y = seq_len(n), z = t(cor_matrix[n:1, , drop = FALSE]),
    zlim = c(-1, 1), col = cols, axes = FALSE,
    xlab = "", ylab = "", main = "Bulk signature correlations (Spearman)"
  )
  graphics::axis(1, at = seq_len(n), labels = colnames(cor_matrix), las = 2, cex.axis = 0.8)
  graphics::axis(2, at = seq_len(n), labels = rev(rownames(cor_matrix)), las = 2, cex.axis = 0.8)
  for (i in seq_len(n)) for (j in seq_len(n)) {
    value <- cor_matrix[n - j + 1, i]
    graphics::text(i, j, sprintf("%.2f", value), cex = 0.62,
                   col = if (abs(value) > 0.62) "white" else "black")
  }
  graphics::box()
  graphics::par(old_par)
  grDevices::dev.off()
}
plot_heatmap(file.path(out_dir, "FigS7A_bulk_signature_correlations.pdf"), "pdf")
plot_heatmap(file.path(out_dir, "FigS7A_bulk_signature_correlations.png"), "png")

scatter_df <- data.frame(
  LCDI = lcdi,
  LSC_partial = signature_scores[lsc_partial_name, ],
  group = group
)
lsc_cor <- signature_out[signature_out$signature == lsc_partial_name, ]
plot_scatter <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") grDevices::pdf(filename, width = 7.2, height = 5.6)
  else grDevices::png(filename, width = 2160, height = 1680, res = 300)
  point_cols <- ifelse(scatter_df$group == "High", "#B2182B99", "#2166AC99")
  graphics::plot(
    scatter_df$LCDI, scatter_df$LSC_partial, pch = 16, col = point_cols,
    xlab = "LCDI score", ylab = paste0("Adapted LSC", sum(lsc_mapping$present), " weighted z-score"),
    main = paste0("LCDI and adapted LSC", sum(lsc_mapping$present), " partial score"),
    sub = sprintf("Spearman rho = %.3f; global BH-FDR = %.2g",
                  lsc_cor$spearman_rho, lsc_cor$global_spearman_fdr)
  )
  graphics::abline(stats::lm(LSC_partial ~ LCDI, data = scatter_df), col = "#333333", lwd = 2)
  graphics::legend("topleft", legend = c("LCDI Low", "LCDI High"),
                   col = c("#2166AC", "#B2182B"), pch = 16, bty = "n")
  grDevices::dev.off()
}
plot_scatter(file.path(out_dir, "FigS7B_LCDI_vs_adapted_LSC_partial.pdf"), "pdf")
plot_scatter(file.path(out_dir, "FigS7B_LCDI_vs_adapted_LSC_partial.png"), "png")

neut_names <- c("Neutrophil_original", "Neutrophil_no_MPO", "Neutrophil_no_MPO_ELANE_CTSG")
neut_df <- do.call(rbind, lapply(neut_names, function(sig) {
  score_z <- as.numeric(scale(signature_scores[sig, ]))
  data.frame(sample_id = sample_ids, group = group, signature = sig, score_z = score_z)
}))
neut_labels <- c("Original", "Without MPO", "Without MPO/ELANE/CTSG")
plot_neutrophil <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") grDevices::pdf(filename, width = 9.2, height = 4.6)
  else grDevices::png(filename, width = 2760, height = 1380, res = 300)
  old_par <- graphics::par(no.readonly = TRUE)
  graphics::par(mfrow = c(1, 3), mar = c(4.5, 4.2, 3.2, 1), oma = c(0, 0, 4, 0))
  for (i in seq_along(neut_names)) {
    sig <- neut_names[i]
    dat <- neut_df[neut_df$signature == sig, ]
    stat_row <- signature_out[signature_out$signature == sig, ]
    graphics::boxplot(score_z ~ group, data = dat, col = c("#2166AC99", "#B2182B99"),
                      outline = FALSE, xlab = "", ylab = if (i == 1) "Mean-z signature score" else "",
                      main = sprintf("%s\nDiff=%.2f; global FDR=%.2g", neut_labels[i],
                                     stat_row$mean_difference, stat_row$global_group_fdr))
    graphics::stripchart(score_z ~ group, data = dat, vertical = TRUE, method = "jitter",
                         jitter = 0.12, add = TRUE, pch = 16, cex = 0.38, col = "#33333366")
  }
  graphics::mtext("Neutrophil signature sensitivity analysis", side = 3,
                  outer = TRUE, line = 2, cex = 1.05)
  graphics::par(old_par)
  grDevices::dev.off()
}
plot_neutrophil(file.path(out_dir, "FigS7C_neutrophil_signature_sensitivity.pdf"), "pdf")
plot_neutrophil(file.path(out_dir, "FigS7C_neutrophil_signature_sensitivity.png"), "png")

saveRDS(
  list(
    marker_statistics = marker_out,
    signature_statistics = signature_out,
    sample_scores = sample_scores,
    correlation_matrix = cor_matrix,
    lsc17_mapping = lsc_mapping,
    seed = 20260801,
    inputs = c(expr_path, immune_path, geneset_path)
  ),
  file.path(out_dir, "01_bulk_supplementary_results.rds")
)

capture.output(sessionInfo(), file = file.path(out_dir, "01_sessionInfo.txt"))

cat("\nMarker statistics:\n")
print(marker_out, row.names = FALSE)
cat("\nSignature statistics:\n")
print(signature_out, row.names = FALSE)
cat("\nCompleted successfully\n")

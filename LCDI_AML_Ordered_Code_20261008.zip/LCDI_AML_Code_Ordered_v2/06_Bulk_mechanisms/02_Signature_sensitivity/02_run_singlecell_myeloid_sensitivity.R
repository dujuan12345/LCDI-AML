options(stringsAsFactors = FALSE)
set.seed(20260801)

out_dir <- "D:/26_01_AML/_codex_audit/chapter7_supplementary_analysis_20260801_v1"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

log_path <- file.path(out_dir, "02_run_singlecell_myeloid_sensitivity.log")
log_con <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_con, type = "output")
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

cat("Adult single-cell myeloid pathway sensitivity analysis\n")
cat("Date:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Seed: 20260801\n")

auc_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/aucell_AUC_matrix.rds"
plain_auc_path <- file.path(out_dir, "02b_aucell_selected_pathways_plain_matrix.rds")
extraction_script_path <- file.path(out_dir, "02b_extract_aucell_pathways_without_namespace.R")
meta_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE116256/J2_LCDI/Results/cell_metadata_with_LCDI.csv"

if (!file.exists(plain_auc_path)) stop("Missing namespace-free AUC extract: ", plain_auc_path)
auc <- readRDS(plain_auc_path)
meta <- utils::read.csv(meta_path, row.names = 1, check.names = FALSE)

cat("AUC matrix:", nrow(auc), "pathways x", ncol(auc), "cells\n")
cat("Metadata:", nrow(meta), "cells x", ncol(meta), "columns\n")
stopifnot(nrow(meta) == 41086L, ncol(auc) > 0L)

common_cells <- intersect(colnames(auc), rownames(meta))
stopifnot(length(common_cells) == ncol(auc))
cat("AUC-metadata overlap:", length(common_cells), "cells\n")
cat("Metadata cells without AUC:", nrow(meta) - length(common_cells), "\n")
auc <- auc[, common_cells, drop = FALSE]
meta <- meta[common_cells, , drop = FALSE]

pathways <- c(
  MYC_targets_V1 = "HALLMARK_MYC_TARGETS_V1",
  Oxidative_phosphorylation = "HALLMARK_OXIDATIVE_PHOSPHORYLATION"
)
stopifnot(all(pathways %in% rownames(auc)))

myeloid_types <- c(
  "HSC", "HSC-like", "Prog", "Prog-like", "GMP", "GMP-like",
  "ProMono", "ProMono-like", "Mono", "Mono-like", "cDC", "cDC-like", "pDC"
)

# Primary sensitivity set: untreated/baseline AML patient samples only.
eligible <- meta$source == "AML" & meta$timepoint == "D0" & meta$CellType %in% myeloid_types
meta_sub <- meta[eligible, , drop = FALSE]
auc_sub <- auc[pathways, rownames(meta_sub), drop = FALSE]
stopifnot(nrow(meta_sub) > 0L, ncol(auc_sub) == nrow(meta_sub))

cat("Primary baseline AML myeloid cells:", nrow(meta_sub), "\n")
cat("Primary samples:", length(unique(meta_sub$sample_id)), "\n")
cat("Cell-type counts:\n")
print(sort(table(meta_sub$CellType), decreasing = TRUE))

aggregate_rows <- list()
idx <- 0L
for (cell_type in myeloid_types) {
  cell_idx <- which(meta_sub$CellType == cell_type)
  if (!length(cell_idx)) next
  samples <- unique(meta_sub$sample_id[cell_idx])
  for (sample_id in samples) {
    use <- cell_idx[meta_sub$sample_id[cell_idx] == sample_id]
    idx <- idx + 1L
    aggregate_rows[[idx]] <- data.frame(
      cell_type = cell_type,
      sample_id = sample_id,
      patient = unique(meta_sub$patient[use])[1],
      n_cells = length(use),
      mean_LCDI = mean(meta_sub$LCDI_score[use], na.rm = TRUE),
      MYC_targets_V1 = mean(auc_sub[pathways["MYC_targets_V1"], use], na.rm = TRUE),
      Oxidative_phosphorylation = mean(auc_sub[pathways["Oxidative_phosphorylation"], use], na.rm = TRUE)
    )
  }
}
aggregates_all <- do.call(rbind, aggregate_rows)
utils::write.table(aggregates_all, file.path(out_dir, "02_singlecell_sample_celltype_aggregates_all.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

# Require at least 20 cells per sample-cell type and at least 5 independent samples.
aggregates <- aggregates_all[aggregates_all$n_cells >= 20, , drop = FALSE]
eligible_types <- names(which(table(aggregates$cell_type) >= 5L))
aggregates <- aggregates[aggregates$cell_type %in% eligible_types, , drop = FALSE]
cat("Eligible cell types (>=5 samples with >=20 cells):", paste(eligible_types, collapse = ";"), "\n")

bootstrap_rho <- function(x, y, n_boot = 2000L) {
  n <- length(x)
  boots <- replicate(n_boot, {
    take <- sample.int(n, n, replace = TRUE)
    suppressWarnings(stats::cor(x[take], y[take], method = "spearman", use = "complete.obs"))
  })
  boots <- boots[is.finite(boots)]
  if (length(boots) < n_boot * 0.8) return(c(NA_real_, NA_real_))
  stats::quantile(boots, c(0.025, 0.975), na.rm = TRUE, names = FALSE)
}

result_rows <- list()
idx <- 0L
for (cell_type in eligible_types) {
  dat <- aggregates[aggregates$cell_type == cell_type, , drop = FALSE]
  for (pathway in names(pathways)) {
    x <- dat$mean_LCDI
    y <- dat[[pathway]]
    test <- suppressWarnings(stats::cor.test(x, y, method = "spearman", exact = FALSE))
    ci <- bootstrap_rho(x, y)
    group <- factor(ifelse(x > stats::median(x), "High", "Low"), levels = c("Low", "High"))
    group_test <- suppressWarnings(stats::wilcox.test(y ~ group, exact = FALSE))
    idx <- idx + 1L
    result_rows[[idx]] <- data.frame(
      cell_type = cell_type,
      pathway = pathway,
      n_samples = nrow(dat),
      n_cells = sum(dat$n_cells),
      min_cells_per_sample = min(dat$n_cells),
      median_cells_per_sample = stats::median(dat$n_cells),
      spearman_rho = unname(test$estimate),
      rho_ci_low = ci[1],
      rho_ci_high = ci[2],
      spearman_p = test$p.value,
      mean_low = mean(y[group == "Low"]),
      mean_high = mean(y[group == "High"]),
      mean_difference = mean(y[group == "High"]) - mean(y[group == "Low"]),
      wilcoxon_p = group_test$p.value
    )
  }
}
results <- do.call(rbind, result_rows)
results$spearman_fdr <- p.adjust(results$spearman_p, method = "BH")
results$wilcoxon_fdr <- p.adjust(results$wilcoxon_p, method = "BH")
results <- results[order(results$pathway, results$spearman_rho), ]
utils::write.table(results, file.path(out_dir, "02_singlecell_myeloid_pathway_statistics.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)
utils::write.table(aggregates, file.path(out_dir, "02_singlecell_sample_celltype_aggregates_eligible.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

direction_summary <- do.call(rbind, lapply(split(results, results$pathway), function(x) {
  data.frame(
    pathway = unique(x$pathway),
    eligible_cell_types = nrow(x),
    negative_rho = sum(x$spearman_rho < 0, na.rm = TRUE),
    positive_rho = sum(x$spearman_rho > 0, na.rm = TRUE),
    fdr_lt_0_05 = sum(x$spearman_fdr < 0.05, na.rm = TRUE),
    fdr_lt_0_05_negative = sum(x$spearman_fdr < 0.05 & x$spearman_rho < 0, na.rm = TRUE),
    median_rho = stats::median(x$spearman_rho, na.rm = TRUE)
  )
}))
utils::write.table(direction_summary, file.path(out_dir, "02_singlecell_direction_summary.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

plot_forest <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") grDevices::pdf(filename, width = 9.2, height = 6.8)
  else grDevices::png(filename, width = 2760, height = 2040, res = 300)
  old_par <- graphics::par(no.readonly = TRUE)
  graphics::par(mfrow = c(1, 2), mar = c(5, 8.2, 4, 1.2), oma = c(0, 0, 2, 0))
  pathway_labels <- c(MYC_targets_V1 = "MYC targets V1", Oxidative_phosphorylation = "Oxidative phosphorylation")
  for (pathway in names(pathways)) {
    dat <- results[results$pathway == pathway, ]
    dat <- dat[order(dat$spearman_rho), ]
    y <- seq_len(nrow(dat))
    graphics::plot(
      dat$spearman_rho, y, xlim = c(-1, 1), ylim = c(0.5, nrow(dat) + 0.5),
      yaxt = "n", pch = 16, col = ifelse(dat$spearman_fdr < 0.05, "#B2182B", "#555555"),
      xlab = "Spearman rho (sample-level means)", ylab = "", main = pathway_labels[pathway]
    )
    graphics::segments(dat$rho_ci_low, y, dat$rho_ci_high, y,
                       col = ifelse(dat$spearman_fdr < 0.05, "#B2182B", "#777777"), lwd = 1.5)
    graphics::points(dat$spearman_rho, y, pch = 16,
                     col = ifelse(dat$spearman_fdr < 0.05, "#B2182B", "#555555"))
    graphics::axis(2, at = y, labels = paste0(dat$cell_type, " (n=", dat$n_samples, ")"), las = 2, cex.axis = 0.78)
    graphics::abline(v = 0, lty = 2, col = "#666666")
    graphics::grid(nx = 5, ny = NA, col = "#DDDDDD", lty = 1)
  }
  graphics::mtext("Baseline AML myeloid subtypes: pathway association with LCDI", side = 3, outer = TRUE, line = -1, cex = 1.05)
  graphics::par(old_par)
  grDevices::dev.off()
}
plot_forest(file.path(out_dir, "FigS7D_singlecell_myeloid_MYC_OXPHOS_forest.pdf"), "pdf")
plot_forest(file.path(out_dir, "FigS7D_singlecell_myeloid_MYC_OXPHOS_forest.png"), "png")

saveRDS(
  list(
    aggregates_all = aggregates_all,
    aggregates_eligible = aggregates,
    statistics = results,
    direction_summary = direction_summary,
    eligibility = list(source = "AML", timepoint = "D0", min_cells = 20L, min_samples = 5L),
    seed = 20260801,
    inputs = c(auc_path, plain_auc_path, meta_path),
    extraction_script = extraction_script_path
  ),
  file.path(out_dir, "02_singlecell_myeloid_sensitivity_results.rds")
)

capture.output(sessionInfo(), file = file.path(out_dir, "02_sessionInfo.txt"))
cat("\nStatistics:\n")
print(results, row.names = FALSE)
cat("\nDirection summary:\n")
print(direction_summary, row.names = FALSE)
cat("\nCompleted successfully\n")

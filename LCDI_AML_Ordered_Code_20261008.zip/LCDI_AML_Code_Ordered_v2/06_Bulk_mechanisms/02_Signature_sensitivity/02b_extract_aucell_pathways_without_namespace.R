options(stringsAsFactors = FALSE)

out_dir <- "D:/26_01_AML/_codex_audit/chapter7_supplementary_analysis_20260801_v1"
log_path <- file.path(out_dir, "02b_extract_aucell_pathways_without_namespace.log")
log_con <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_con, type = "output")
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

auc_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/aucell_AUC_matrix.rds"
output_path <- file.path(out_dir, "02b_aucell_selected_pathways_plain_matrix.rds")
target_pathways <- c("HALLMARK_MYC_TARGETS_V1", "HALLMARK_OXIDATIVE_PHOSPHORYLATION")

cat("Namespace-free AUCell pathway extraction\n")
cat("Date:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("R:", R.version.string, "\n")
cat("Input:", auc_path, "\n")
cat("Output:", output_path, "\n")

# S4 slots are stored as attributes. Accessing the serialized attributes directly
# avoids dispatching AUCell methods or loading the incompatible AUCell namespace.
x <- readRDS(auc_path)
assays_slot <- attr(x, "assays", exact = TRUE)
assay_data <- attr(assays_slot, "data", exact = TRUE)
assay_list <- attr(assay_data, "listData", exact = TRUE)
auc <- assay_list[["AUC"]]

if (is.null(auc)) stop("AUC assay was not found in assays/data/listData")
if (!is.matrix(auc)) auc <- as.matrix(auc)
stopifnot(nrow(auc) == 237L, ncol(auc) == 36564L)
stopifnot(all(target_pathways %in% rownames(auc)))
selected <- auc[target_pathways, , drop = FALSE]
stopifnot(all(is.finite(selected)), !is.null(colnames(selected)))

saveRDS(selected, output_path, compress = FALSE)

cat("Serialized top-level class attribute:", paste(attr(x, "class", exact = TRUE), collapse = ";"), "\n")
cat("AUC dimensions:", nrow(auc), "x", ncol(auc), "\n")
cat("Selected dimensions:", nrow(selected), "x", ncol(selected), "\n")
cat("Selected pathways:", paste(rownames(selected), collapse = ";"), "\n")
cat("Selected value range:", paste(range(selected), collapse = ";"), "\n")
cat("Loaded namespaces:", paste(loadedNamespaces(), collapse = ";"), "\n")
cat("Completed successfully\n")

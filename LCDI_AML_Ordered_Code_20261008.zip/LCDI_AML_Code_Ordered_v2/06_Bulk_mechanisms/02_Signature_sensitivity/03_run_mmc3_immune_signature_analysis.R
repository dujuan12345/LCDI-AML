options(stringsAsFactors = FALSE)
set.seed(20260801)

out_dir <- "D:/26_01_AML/_codex_audit/chapter7_supplementary_analysis_20260801_v1"
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

log_path <- file.path(out_dir, "03_run_mmc3_immune_signature_analysis.log")
log_con <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_con, type = "output")
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

cat("Chapter 7 mmc3 immune-signature supplementary analysis\n")
cat("Date:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Seed: 20260801\n")
cat("Method: per-gene z standardization across samples followed by within-signature mean.\n")
cat("Interpretation: transcriptional signature score, not an absolute cell fraction.\n\n")

expr_path <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/GPL96_Train_full_expr.rds"
immune_path <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/phaseE3_immune_results.rds"
mmc3_path <- "D:/Project_0106_scripts_20260430/Project_0106_scripts_20260430/mmc3.txt"
reference_script_path <- "D:/Project_0106_scripts_20260430/Project_0106_scripts_20260430/r.10_Immune_Infiltration.r"

for (path in c(expr_path, immune_path, mmc3_path, reference_script_path)) {
  if (!file.exists(path)) stop("Missing required input: ", path)
}

expr <- readRDS(expr_path)
immune <- readRDS(immune_path)
mmc3 <- utils::read.delim(mmc3_path, header = TRUE, check.names = FALSE,
                          stringsAsFactors = FALSE, quote = "", comment.char = "")

stopifnot(is.matrix(expr), nrow(expr) == 13039L, ncol(expr) == 580L)
stopifnot(all(c("group", "lcdi", "median_lcdi") %in% names(immune)))
stopifnot(identical(colnames(mmc3), c("Metagene", "Cell type", "Immunity")))
stopifnot(!anyNA(mmc3), nrow(mmc3) > 0L)

rownames(expr) <- toupper(rownames(expr))
if (anyDuplicated(rownames(expr))) {
  gene_factor <- factor(rownames(expr), levels = unique(rownames(expr)))
  expr <- rowsum(expr, gene_factor, reorder = FALSE) /
    as.numeric(table(gene_factor))[seq_len(nlevels(gene_factor))]
}

stopifnot(length(immune$lcdi) == length(immune$group))
names(immune$lcdi) <- names(immune$group)
sample_ids <- intersect(colnames(expr), names(immune$group))
stopifnot(length(sample_ids) == 580L)
expr <- expr[, sample_ids, drop = FALSE]
group <- factor(as.character(immune$group[sample_ids]), levels = c("Low", "High"))
lcdi <- as.numeric(immune$lcdi[sample_ids])
names(lcdi) <- sample_ids
stopifnot(!anyNA(group), !anyNA(lcdi), sum(group == "Low") == 290L,
          sum(group == "High") == 290L)

mmc3$Metagene <- toupper(trimws(mmc3$Metagene))
mmc3$`Cell type` <- trimws(mmc3$`Cell type`)
mmc3$Immunity <- trimws(mmc3$Immunity)
gene_sets_planned <- split(mmc3$Metagene, mmc3$`Cell type`)
gene_sets_planned <- lapply(gene_sets_planned, unique)
gene_sets_present <- lapply(gene_sets_planned, function(x) intersect(x, rownames(expr)))

lcdi_genes <- c("MPO", "CREB1", "GPX4", "SLC16A4", "CASP1")
coverage <- do.call(rbind, lapply(names(gene_sets_planned), function(cell_type) {
  planned <- gene_sets_planned[[cell_type]]
  present <- gene_sets_present[[cell_type]]
  data.frame(
    cell_type = cell_type,
    immunity = paste(unique(mmc3$Immunity[mmc3$`Cell type` == cell_type]), collapse = ";"),
    n_genes_planned = length(planned),
    n_genes_present = length(present),
    coverage_fraction = length(present) / length(planned),
    lcdi_gene_overlap = paste(intersect(planned, lcdi_genes), collapse = ";"),
    genes_present = paste(present, collapse = ";"),
    stringsAsFactors = FALSE
  )
}))
utils::write.table(coverage, file.path(out_dir, "03_mmc3_gene_coverage.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

eligible <- coverage$cell_type[coverage$n_genes_present >= 3L]
gene_sets_present <- gene_sets_present[eligible]
stopifnot(length(gene_sets_present) == 28L)

mean_z_score <- function(genes) {
  z <- t(scale(t(expr[genes, sample_ids, drop = FALSE])))
  z[!is.finite(z)] <- 0
  colMeans(z)
}
scores <- do.call(rbind, lapply(gene_sets_present, mean_z_score))
rownames(scores) <- names(gene_sets_present)
colnames(scores) <- sample_ids
stopifnot(nrow(scores) == 28L, ncol(scores) == 580L, all(is.finite(scores)))

calc_stats <- function(cell_type) {
  score <- scores[cell_type, ]
  high <- score[group == "High"]
  low <- score[group == "Low"]
  wt <- suppressWarnings(stats::wilcox.test(high, low, exact = FALSE, conf.int = TRUE))
  u <- unname(wt$statistic)
  rank_biserial <- 2 * u / (length(high) * length(low)) - 1
  ct <- suppressWarnings(stats::cor.test(score, lcdi, method = "spearman", exact = FALSE))
  data.frame(
    cell_type = cell_type,
    immunity = coverage$immunity[match(cell_type, coverage$cell_type)],
    n_genes_present = length(gene_sets_present[[cell_type]]),
    mean_low = mean(low),
    mean_high = mean(high),
    mean_difference_high_minus_low = mean(high) - mean(low),
    median_low = stats::median(low),
    median_high = stats::median(high),
    median_difference_high_minus_low = stats::median(high) - stats::median(low),
    hodges_lehmann_high_minus_low = if (!is.null(wt$estimate)) unname(wt$estimate) else NA_real_,
    rank_biserial_high_vs_low = rank_biserial,
    wilcoxon_w = u,
    group_p = wt$p.value,
    spearman_rho = unname(ct$estimate),
    spearman_p = ct$p.value,
    stringsAsFactors = FALSE
  )
}

statistics <- do.call(rbind, lapply(rownames(scores), calc_stats))
statistics$group_fdr <- p.adjust(statistics$group_p, method = "BH")
statistics$spearman_fdr <- p.adjust(statistics$spearman_p, method = "BH")
statistics <- statistics[order(statistics$group_fdr, statistics$group_p), ]
rownames(statistics) <- NULL
utils::write.table(statistics, file.path(out_dir, "03_mmc3_immune_signature_statistics.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

sample_scores <- data.frame(
  sample_id = sample_ids,
  group = as.character(group),
  LCDI = lcdi,
  t(scores[, sample_ids, drop = FALSE]),
  check.names = FALSE
)
utils::write.table(sample_scores, file.path(out_dir, "03_mmc3_sample_scores.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

t_types <- grep("T cell|T helper", rownames(scores), value = TRUE)
key_types <- unique(c("Neutrophil", t_types, "Natural killer cell", "Monocyte", "MDSC"))
key_types <- key_types[key_types %in% rownames(scores)]
key_stats <- statistics[match(key_types, statistics$cell_type), ]
utils::write.table(key_stats, file.path(out_dir, "03_mmc3_key_immune_statistics.tsv"),
                   sep = "\t", row.names = FALSE, quote = FALSE)

plot_forest <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") grDevices::pdf(filename, width = 8.5, height = 8.5)
  else grDevices::png(filename, width = 2550, height = 2550, res = 300)
  dat <- statistics[order(statistics$rank_biserial_high_vs_low), ]
  y <- seq_len(nrow(dat))
  point_col <- ifelse(dat$group_fdr < 0.05, "#B2182B", "#777777")
  old_par <- graphics::par(no.readonly = TRUE)
  graphics::par(mar = c(4.5, 13, 3.5, 1.5))
  graphics::plot(dat$rank_biserial_high_vs_low, y, pch = 16, col = point_col,
                 xlim = range(c(-0.5, 0.5, dat$rank_biserial_high_vs_low)),
                 yaxt = "n", ylab = "", xlab = "Rank-biserial effect (LCDI High vs Low)",
                 main = "mmc3 immune transcriptional signatures")
  graphics::abline(v = 0, lty = 2, col = "#555555")
  graphics::axis(2, at = y, labels = dat$cell_type, las = 2, cex.axis = 0.72)
  graphics::legend("bottomright", legend = c("BH-FDR < 0.05", "BH-FDR >= 0.05"),
                   pch = 16, col = c("#B2182B", "#777777"), bty = "n", cex = 0.8)
  graphics::par(old_par)
  grDevices::dev.off()
}
plot_forest(file.path(out_dir, "FigS7E_mmc3_immune_signature_effects.pdf"), "pdf")
plot_forest(file.path(out_dir, "FigS7E_mmc3_immune_signature_effects.png"), "png")

selected_plot_types <- c("Neutrophil", "Activated CD4 T cell", "Activated CD8 T cell",
                         "Regulatory T cell", "Natural killer cell", "Monocyte")
selected_plot_types <- selected_plot_types[selected_plot_types %in% rownames(scores)]
plot_selected <- function(filename, device = c("pdf", "png")) {
  device <- match.arg(device)
  if (device == "pdf") grDevices::pdf(filename, width = 10, height = 6.7)
  else grDevices::png(filename, width = 3000, height = 2010, res = 300)
  old_par <- graphics::par(no.readonly = TRUE)
  graphics::par(mfrow = c(2, 3), mar = c(4, 4, 3, 1))
  for (cell_type in selected_plot_types) {
    dat <- data.frame(score = scores[cell_type, ], group = group)
    st <- statistics[statistics$cell_type == cell_type, ]
    graphics::boxplot(score ~ group, data = dat, outline = FALSE,
                      col = c("#2166AC99", "#B2182B99"), xlab = "",
                      ylab = "Mean-z signature score",
                      main = sprintf("%s\nr_rb=%.2f; FDR=%.2g", cell_type,
                                     st$rank_biserial_high_vs_low, st$group_fdr))
    graphics::stripchart(score ~ group, data = dat, vertical = TRUE, method = "jitter",
                         jitter = 0.12, add = TRUE, pch = 16, cex = 0.35, col = "#33333355")
  }
  graphics::par(old_par)
  grDevices::dev.off()
}
plot_selected(file.path(out_dir, "FigS7F_mmc3_selected_immune_signatures.pdf"), "pdf")
plot_selected(file.path(out_dir, "FigS7F_mmc3_selected_immune_signatures.png"), "png")

saveRDS(
  list(
    statistics = statistics,
    coverage = coverage,
    sample_scores = sample_scores,
    score_matrix = scores,
    method = "per-gene z standardization across samples, then signature mean",
    interpretation = "transcriptional signature score; not an absolute cell fraction",
    seed = 20260801,
    inputs = c(expr_path, immune_path, mmc3_path, reference_script_path)
  ),
  file.path(out_dir, "03_mmc3_immune_signature_results.rds")
)

capture.output(sessionInfo(), file = file.path(out_dir, "03_sessionInfo.txt"))

cat("Expression:", nrow(expr), "genes x", ncol(expr), "samples\n")
cat("Groups: Low=", sum(group == "Low"), "; High=", sum(group == "High"), "\n", sep = "")
cat("mmc3 rows:", nrow(mmc3), "; planned cell types:", length(gene_sets_planned),
    "; eligible cell types:", length(gene_sets_present), "\n")
cat("Neutrophil LCDI-gene overlap:",
    ifelse(nzchar(coverage$lcdi_gene_overlap[coverage$cell_type == "Neutrophil"]),
           coverage$lcdi_gene_overlap[coverage$cell_type == "Neutrophil"], "none"), "\n")
cat("\nTop immune-signature statistics:\n")
print(statistics, row.names = FALSE)
cat("\nCompleted successfully\n")

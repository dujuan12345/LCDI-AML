options(stringsAsFactors = FALSE, warn = 1, digits = 17)

audit_dir <- "D:/26_01_AML/_codex_audit/chapter7_open_source_deconvolution_20260801_v1"
source_dir <- file.path(audit_dir, "sources", "quantiseqr_1.18.0_source")
local_lib <- file.path(audit_dir, "r_library")
legacy_lib <- "D:/R-4.5.2/library"
expr_path <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/GPL96_Train_full_expr.rds"
immune_path <- "D:/26_01_AML/AML_Lactylation_PCD/data/processed/mime/clean/phaseE3_immune_results.rds"
seed <- 20260801L

.libPaths(c(local_lib, legacy_lib, .libPaths()))

log_path <- file.path(audit_dir, "04_run_formal_quantiseq_source_mode.log")
log_con <- file(log_path, open = "wt", encoding = "UTF-8")
sink(log_con, type = "output")
sink(log_con, type = "message")
on.exit({
  sink(type = "message")
  sink(type = "output")
  close(log_con)
}, add = TRUE)

cat("Formal GPL96 quanTIseq source-mode supplementary analysis\n")
cat("Started:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("R:", R.version.string, "\n")
cat("Seed:", seed, "\n")

stopifnot(getRversion() == "4.5.3")
stopifnot(!requireNamespace("quantiseqr", quietly = TRUE))
stopifnot(requireNamespace("limSolve", quietly = TRUE))
stopifnot(requireNamespace("preprocessCore", quietly = TRUE))
stopifnot(file.exists(expr_path), file.exists(immune_path), dir.exists(source_dir))

qenv <- new.env(parent = globalenv())
qenv$lsei <- limSolve::lsei
qenv$normalize.quantiles <- preprocessCore::normalize.quantiles
qenv$system.file <- function(..., package = "base", lib.loc = NULL, mustWork = FALSE) {
  if (identical(package, "quantiseqr")) {
    path <- file.path(source_dir, "inst", ...)
    if (mustWork && !file.exists(path)) stop("Source-mode resource not found: ", path)
    return(path)
  }
  base::system.file(..., package = package, lib.loc = lib.loc, mustWork = mustWork)
}
sys.source(file.path(source_dir, "R", "quantiseqr_helpers.R"), envir = qenv)
sys.source(file.path(source_dir, "R", "quantiseqr.R"), envir = qenv)

expr <- readRDS(expr_path)
immune <- readRDS(immune_path)
stopifnot(is.matrix(expr), is.numeric(expr), nrow(expr) == 13039L, ncol(expr) == 580L)
stopifnot(all(c("group", "lcdi") %in% names(immune)))
if (is.null(names(immune$lcdi))) names(immune$lcdi) <- names(immune$group)
sample_ids <- intersect(colnames(expr), names(immune$group))
stopifnot(length(sample_ids) == 580L)
expr <- expr[, sample_ids, drop = FALSE]
group <- factor(as.character(immune$group[sample_ids]), levels = c("Low", "High"))
lcdi <- as.numeric(immune$lcdi[sample_ids])
stopifnot(!anyNA(group), !anyNA(lcdi), sum(group == "Low") == 290L, sum(group == "High") == 290L)

metadata <- data.frame(Sample = sample_ids, group = group, lcdi = lcdi, check.names = FALSE)
utils::write.table(metadata, file.path(audit_dir, "04_quanti_sample_metadata.tsv"),
                   sep = "\t", quote = FALSE, row.names = FALSE)

sig_path <- file.path(source_dir, "inst", "extdata", "TIL10_signature.txt")
signature <- utils::read.delim(sig_path, check.names = FALSE)
signature_genes <- unique(toupper(signature$ID))
formula_genes <- c("MPO", "CREB1", "GPX4", "SLC16A4", "CASP1")
coupling_genes <- c(formula_genes, "ELANE", "CTSG")
input_genes <- unique(toupper(rownames(expr)))
sig_qc <- data.frame(
  metric = c("signature_gene_count", "signature_genes_found_by_exact_symbol",
             "signature_exact_symbol_coverage", "formula_gene_overlap_count",
             "formula_gene_overlap", "coupling_gene_overlap_count", "coupling_gene_overlap"),
  value = c(length(signature_genes), length(intersect(signature_genes, input_genes)),
            length(intersect(signature_genes, input_genes)) / length(signature_genes),
            length(intersect(signature_genes, formula_genes)),
            paste(intersect(signature_genes, formula_genes), collapse = ";"),
            length(intersect(signature_genes, coupling_genes)),
            paste(intersect(signature_genes, coupling_genes), collapse = ";")),
  stringsAsFactors = FALSE
)
utils::write.table(sig_qc, file.path(audit_dir, "04_quanti_signature_qc.tsv"),
                   sep = "\t", quote = FALSE, row.names = FALSE)

variants <- list(
  primary = list(is_arraydata = TRUE, is_tumordata = FALSE, scale_mRNA = TRUE),
  tumor_filter = list(is_arraydata = TRUE, is_tumordata = TRUE, scale_mRNA = TRUE),
  no_mrna_scaling = list(is_arraydata = TRUE, is_tumordata = FALSE, scale_mRNA = FALSE)
)

run_variant <- function(pars, label) {
  cat("\n=== Variant:", label, "===\n")
  result <- qenv$run_quantiseq(
    expression_data = expr,
    signature_matrix = "TIL10",
    is_arraydata = pars$is_arraydata,
    is_tumordata = pars$is_tumordata,
    scale_mRNA = pars$scale_mRNA,
    method = "lsei"
  )
  stopifnot(is.data.frame(result), nrow(result) == 580L, ncol(result) == 12L)
  stopifnot(identical(as.character(result$Sample), sample_ids))
  values <- as.matrix(result[, -1, drop = FALSE])
  stopifnot(all(is.finite(values)), min(values) >= -1e-12)
  stopifnot(max(abs(rowSums(values) - 1)) < 1e-8)
  result
}

results <- lapply(names(variants), function(x) run_variant(variants[[x]], x))
names(results) <- names(variants)

fraction_paths <- c(
  primary = "04_quanti_primary_fractions.tsv",
  tumor_filter = "04_quanti_tumor_filter_fractions.tsv",
  no_mrna_scaling = "04_quanti_no_mrna_scaling_fractions.tsv"
)
for (variant in names(results)) {
  export <- results[[variant]]
  export[-1] <- lapply(export[-1], function(x) sprintf("%.17g", x))
  utils::write.table(export, file.path(audit_dir, fraction_paths[[variant]]),
                     sep = "\t", quote = FALSE, row.names = FALSE)
}
saveRDS(results, file.path(audit_dir, "04_quanti_all_fractions.rds"), version = 3)

rank_biserial <- function(x_high, x_low) {
  n_high <- length(x_high)
  n_low <- length(x_low)
  ranks <- rank(c(x_high, x_low), ties.method = "average")
  u_high <- sum(ranks[seq_len(n_high)]) - n_high * (n_high + 1) / 2
  2 * u_high / (n_high * n_low) - 1
}

bootstrap_rbc <- function(x, g, n_boot = 1000L, seed_offset = 0L) {
  set.seed(seed + seed_offset)
  high <- x[g == "High"]
  low <- x[g == "Low"]
  estimates <- replicate(n_boot, {
    h <- sample(high, length(high), replace = TRUE)
    l <- sample(low, length(low), replace = TRUE)
    rank_biserial(h, l)
  })
  unname(stats::quantile(estimates, probs = c(0.025, 0.975), type = 6, na.rm = TRUE))
}

analyse_component <- function(x, cell_type, variant, idx) {
  high <- x[group == "High"]
  low <- x[group == "Low"]
  wilcox <- suppressWarnings(stats::wilcox.test(high, low, exact = FALSE))
  spearman <- suppressWarnings(stats::cor.test(x, lcdi, method = "spearman", exact = FALSE))
  ci <- if (variant == "primary") bootstrap_rbc(x, group, 1000L, idx) else c(NA_real_, NA_real_)
  data.frame(
    variant = variant,
    cell_type = cell_type,
    n_low = length(low),
    n_high = length(high),
    mean_low = mean(low),
    mean_high = mean(high),
    mean_diff_high_minus_low = mean(high) - mean(low),
    median_low = stats::median(low),
    median_high = stats::median(high),
    median_diff_high_minus_low = stats::median(high) - stats::median(low),
    rank_biserial_high_vs_low = rank_biserial(high, low),
    rank_biserial_ci_low = ci[1],
    rank_biserial_ci_high = ci[2],
    wilcoxon_p = wilcox$p.value,
    spearman_rho_lcdi = unname(spearman$estimate),
    spearman_p = spearman$p.value,
    stringsAsFactors = FALSE
  )
}

stats_list <- list()
counter <- 0L
for (variant in names(results)) {
  cell_types <- colnames(results[[variant]])[-1]
  for (cell_type in cell_types) {
    counter <- counter + 1L
    stats_list[[counter]] <- analyse_component(results[[variant]][[cell_type]], cell_type, variant, counter)
  }
}
stats_table <- do.call(rbind, stats_list)
stats_table$wilcoxon_fdr_within_variant <- ave(stats_table$wilcoxon_p, stats_table$variant,
                                               FUN = function(x) stats::p.adjust(x, method = "BH"))
stats_table$spearman_fdr_within_variant <- ave(stats_table$spearman_p, stats_table$variant,
                                               FUN = function(x) stats::p.adjust(x, method = "BH"))
stats_table$wilcoxon_fdr_global <- stats::p.adjust(stats_table$wilcoxon_p, method = "BH")
stats_table$spearman_fdr_global <- stats::p.adjust(stats_table$spearman_p, method = "BH")
utils::write.table(stats_table, file.path(audit_dir, "04_quanti_group_and_lcdi_statistics.tsv"),
                   sep = "\t", quote = FALSE, row.names = FALSE)

concordance_list <- list()
counter <- 0L
for (variant in setdiff(names(results), "primary")) {
  for (cell_type in colnames(results$primary)[-1]) {
    counter <- counter + 1L
    test <- suppressWarnings(stats::cor.test(results$primary[[cell_type]], results[[variant]][[cell_type]],
                                              method = "spearman", exact = FALSE))
    concordance_list[[counter]] <- data.frame(
      sensitivity_variant = variant,
      cell_type = cell_type,
      spearman_rho_vs_primary = unname(test$estimate),
      p_value = test$p.value,
      stringsAsFactors = FALSE
    )
  }
}
concordance <- do.call(rbind, concordance_list)
concordance$fdr <- ave(concordance$p_value, concordance$sensitivity_variant,
                       FUN = function(x) stats::p.adjust(x, method = "BH"))
utils::write.table(concordance, file.path(audit_dir, "04_quanti_sensitivity_concordance.tsv"),
                   sep = "\t", quote = FALSE, row.names = FALSE)

variant_qc <- do.call(rbind, lapply(names(results), function(variant) {
  values <- as.matrix(results[[variant]][, -1, drop = FALSE])
  data.frame(
    variant = variant,
    n_samples = nrow(values),
    n_components = ncol(values),
    min_fraction = min(values),
    max_fraction = max(values),
    max_rowsum_error = max(abs(rowSums(values) - 1)),
    n_nonfinite = sum(!is.finite(values)),
    n_negative = sum(values < -1e-12),
    stringsAsFactors = FALSE
  )
}))
utils::write.table(variant_qc, file.path(audit_dir, "04_quanti_formal_qc.tsv"),
                   sep = "\t", quote = FALSE, row.names = FALSE)

short_labels <- c(
  "B.cells" = "B", "Macrophages.M1" = "M1", "Macrophages.M2" = "M2",
  "Monocytes" = "Mono", "Neutrophils" = "Neut", "NK.cells" = "NK",
  "T.cells.CD4" = "CD4 T", "T.cells.CD8" = "CD8 T", "Tregs" = "Treg",
  "Dendritic.cells" = "DC", "Other" = "Other"
)

draw_effect_plot <- function() {
  dat <- stats_table[stats_table$variant == "primary", ]
  ord <- order(dat$rank_biserial_high_vs_low)
  dat <- dat[ord, ]
  y <- seq_len(nrow(dat))
  sig <- dat$wilcoxon_fdr_within_variant < 0.05
  cols <- ifelse(sig, "#B2182B", "#666666")
  old <- par(mar = c(4.5, 7.2, 2.6, 1.2))
  on.exit(par(old), add = TRUE)
  plot(dat$rank_biserial_high_vs_low, y, type = "n", yaxt = "n",
       xlab = "Rank-biserial effect (High - Low)", ylab = "",
       xlim = range(c(dat$rank_biserial_ci_low, dat$rank_biserial_ci_high, 0), na.rm = TRUE),
       main = "quanTIseq primary analysis")
  abline(v = 0, lty = 2, col = "#999999")
  segments(dat$rank_biserial_ci_low, y, dat$rank_biserial_ci_high, y, col = cols, lwd = 2)
  points(dat$rank_biserial_high_vs_low, y, pch = 19, col = cols, cex = 1.1)
  axis(2, at = y, labels = unname(short_labels[dat$cell_type]), las = 1)
  legend("bottomright", legend = c("BH FDR < 0.05", "BH FDR >= 0.05"),
         col = c("#B2182B", "#666666"), pch = 19, bty = "n", cex = 0.85)
}

draw_boxplots <- function() {
  old <- par(mfrow = c(3, 4), mar = c(3.3, 3.5, 2.2, 0.8), oma = c(1.5, 1.5, 2, 0.5))
  on.exit(par(old), add = TRUE)
  for (cell_type in colnames(results$primary)[-1]) {
    cell_values <- results$primary[[cell_type]]
    upper <- max(cell_values, na.rm = TRUE)
    if (!is.finite(upper) || upper <= 0) upper <- 1e-6
    boxplot(results$primary[[cell_type]] ~ group,
            names = c("Low", "High"), col = c("#4C78A8", "#E45756"),
            outline = FALSE, ylab = "Fraction", xlab = "", ylim = c(0, upper * 1.05),
            main = unname(short_labels[cell_type]), cex.main = 0.95)
    stripchart(results$primary[[cell_type]] ~ group, vertical = TRUE, method = "jitter",
               pch = 16, cex = 0.28, col = grDevices::adjustcolor("black", alpha.f = 0.22), add = TRUE)
  }
  plot.new()
  legend("center", legend = c("LCDI Low", "LCDI High"), fill = c("#4C78A8", "#E45756"), bty = "n")
  mtext("quanTIseq primary relative fractions", outer = TRUE, side = 3, line = 0.5, cex = 1.2)
}

draw_sensitivity_heatmap <- function() {
  variants_order <- c("primary", "tumor_filter", "no_mrna_scaling")
  cells <- colnames(results$primary)[-1]
  mat <- matrix(NA_real_, nrow = length(cells), ncol = length(variants_order),
                dimnames = list(unname(short_labels[cells]), c("Primary", "Tumor filter", "No mRNA scaling")))
  for (i in seq_along(cells)) {
    for (j in seq_along(variants_order)) {
      row <- stats_table$cell_type == cells[i] & stats_table$variant == variants_order[j]
      mat[i, j] <- stats_table$rank_biserial_high_vs_low[row]
    }
  }
  zlim <- max(abs(mat), na.rm = TRUE)
  palette <- grDevices::colorRampPalette(c("#2166AC", "white", "#B2182B"))(101)
  old <- par(mar = c(7, 7, 3, 2))
  on.exit(par(old), add = TRUE)
  image(seq_len(ncol(mat)), seq_len(nrow(mat)), t(mat), axes = FALSE,
        xlab = "", ylab = "", col = palette, zlim = c(-zlim, zlim),
        main = "High-vs-Low effect sensitivity")
  axis(1, at = seq_len(ncol(mat)), labels = colnames(mat), las = 2)
  axis(2, at = seq_len(nrow(mat)), labels = rownames(mat), las = 1)
  for (i in seq_len(nrow(mat))) {
    for (j in seq_len(ncol(mat))) {
      text(j, i, sprintf("%.2f", mat[i, j]), cex = 0.82)
    }
  }
  box()
  mtext("Rank-biserial effect (red: higher in LCDI High)", side = 1, line = 5.4, cex = 0.85)
}

grDevices::png(file.path(audit_dir, "FigS7G_quanti_primary_effects.png"),
               width = 2600, height = 2100, res = 300)
draw_effect_plot()
grDevices::dev.off()
grDevices::pdf(file.path(audit_dir, "FigS7G_quanti_primary_effects.pdf"), width = 8.5, height = 7)
draw_effect_plot()
grDevices::dev.off()

grDevices::png(file.path(audit_dir, "FigS7H_quanti_group_boxplots.png"),
               width = 3300, height = 2600, res = 300)
draw_boxplots()
grDevices::dev.off()
grDevices::pdf(file.path(audit_dir, "FigS7H_quanti_group_boxplots.pdf"), width = 11, height = 8.5)
draw_boxplots()
grDevices::dev.off()

grDevices::png(file.path(audit_dir, "FigS7I_quanti_sensitivity_heatmap.png"),
               width = 2600, height = 2500, res = 300)
draw_sensitivity_heatmap()
grDevices::dev.off()
grDevices::pdf(file.path(audit_dir, "FigS7I_quanti_sensitivity_heatmap.pdf"), width = 8.5, height = 8)
draw_sensitivity_heatmap()
grDevices::dev.off()

writeLines(capture.output(sessionInfo()), file.path(audit_dir, "04_sessionInfo.txt"), useBytes = TRUE)

primary_stats <- stats_table[stats_table$variant == "primary", ]
cat("\nPrimary BH-significant group comparisons:", sum(primary_stats$wilcoxon_fdr_within_variant < 0.05), "/ 11\n")
cat("Primary BH-significant LCDI correlations:", sum(primary_stats$spearman_fdr_within_variant < 0.05), "/ 11\n")
cat("Completed:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("FORMAL_QUANTISEQ_ANALYSIS_PASSED=True\n")

options(stringsAsFactors = FALSE, warn = 1, digits = 17)

audit_dir <- "D:/26_01_AML/_codex_audit/chapter7_open_source_deconvolution_20260801_v1"
results <- readRDS(file.path(audit_dir, "04_quanti_all_fractions.rds"))
stopifnot(identical(names(results), c("primary", "tumor_filter", "no_mrna_scaling")))

fraction_paths <- c(
  primary = "04_quanti_primary_fractions.tsv",
  tumor_filter = "04_quanti_tumor_filter_fractions.tsv",
  no_mrna_scaling = "04_quanti_no_mrna_scaling_fractions.tsv"
)
for (variant in names(results)) {
  stopifnot(nrow(results[[variant]]) == 580L, ncol(results[[variant]]) == 12L)
  export <- results[[variant]]
  export[-1] <- lapply(export[-1], function(x) sprintf("%.17g", x))
  utils::write.table(export, file.path(audit_dir, fraction_paths[[variant]]),
                     sep = "\t", quote = FALSE, row.names = FALSE)
}

cat("QUANTISEQ_FULL_PRECISION_EXPORT_PASSED=True\n")

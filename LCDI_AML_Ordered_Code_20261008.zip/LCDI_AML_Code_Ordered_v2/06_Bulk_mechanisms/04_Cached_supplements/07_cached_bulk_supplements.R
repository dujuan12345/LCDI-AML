options(stringsAsFactors=FALSE,warn=1)
root<-'D:/26_01_AML';task<-file.path(root,'_codex_audit/upstream_repair_20260905_v1');out<-file.path(task,'bulk/cached_supplements');dir.create(out,showWarnings=FALSE)
suppressPackageStartupMessages(library(limma))
w<-function(x,n)write.table(x,file.path(out,n),sep='\t',row.names=FALSE,quote=FALSE)
sc<-read.delim(file.path(task,'bulk/01_corrected_sample_scores_groups.tsv'));g<-factor(sc$group,levels=c('Low','High'))
paths<-c(signatures='_codex_audit/chapter7_supplementary_analysis_20260801_v1/01_bulk_sample_signature_scores.tsv',mmc3='_codex_audit/chapter7_supplementary_analysis_20260801_v1/03_mmc3_sample_scores.tsv',quanti_primary='_codex_audit/chapter7_open_source_deconvolution_20260801_v1/04_quanti_primary_fractions.tsv',quanti_no_mrna='_codex_audit/chapter7_open_source_deconvolution_20260801_v1/04_quanti_no_mrna_scaling_fractions.tsv',quanti_tumor='_codex_audit/chapter7_open_source_deconvolution_20260801_v1/04_quanti_tumor_filter_fractions.tsv')
rows<-list();qc<-list()
for(n in names(paths)) {
 d<-read.delim(file.path(root,paths[n]),check.names=FALSE);ids<-d[[1]];stopifnot(!anyDuplicated(ids),setequal(ids,sc$sample_id));d<-d[match(sc$sample_id,ids),];v<-as.matrix(d[,setdiff(names(d),c(names(d)[1],'group','LCDI'))]);stopifnot(all(is.finite(v)))
 fit<-eBayes(lmFit(t(v),model.matrix(~g)));a<-topTable(fit,coef=2,number=Inf,sort.by='none');a$endpoint<-rownames(a);a$family<-n
 a$rho<-apply(v,2,function(x)if(sd(x)>0)cor(x,sc$LCDI,method='spearman')else NA_real_)
 a$cor_p<-apply(v,2,function(x)if(sd(x)>0)cor.test(x,sc$LCDI,method='spearman',exact=FALSE)$p.value else NA_real_);a$cor_FDR<-p.adjust(a$cor_p,'BH');a$mean_high<-colMeans(v[g=='High',]);a$mean_low<-colMeans(v[g=='Low',]);rows[[n]]<-a
 qc[[n]]<-data.frame(family=n,path=file.path(root,paths[n]),samples=nrow(v),endpoints=ncol(v),nonfinite=sum(!is.finite(v)))
 w(data.frame(sample_id=sc$sample_id,group=sc$group,LCDI=sc$LCDI,v,check.names=FALSE),paste0(n,'_corrected_scores.tsv'))
}
w(do.call(rbind,rows),'all_corrected_statistics.tsv');w(do.call(rbind,qc),'QC.tsv')
base<-file.path(root,'AML_Lactylation_PCD/data/processed/mime/clean');b<-readRDS(file.path(base,'B_cohort_data_5cohorts_clinical_v2.rds'))$GPL96_Train
beta<-c(CREB1=.0925,SLC16A4=-.0636,GPX4=-.0721,CASP1=-.0106,MPO=-.2095)
x<-t(readRDS(file.path(base,'GPL96_Train_full_expr.rds'))[names(beta),sc$sample_id]);y<-sc$old_LCDI
algebra<-lm.fit(x,y);stopifnot(max(abs(algebra$residuals))<1e-8)
w(data.frame(gene=names(beta),old_raw_linear_weight=algebra$coefficients,frozen_z_weight=beta,expression_sd=apply(x,2,sd),old_effect_per_gene_SD=algebra$coefficients*apply(x,2,sd)),'old_score_algebraic_reconstruction.tsv')
w(data.frame(note='Algebraic identity of saved score, not a survival model refit',max_residual=max(abs(algebra$residuals))),'old_score_reconstruction_QC.tsv')
capture.output(sessionInfo(),file=file.path(out,'session_info.txt'));writeLines('passed_cached_score_statistics_and_algebraic_identity',file.path(out,'COMPLETE'))

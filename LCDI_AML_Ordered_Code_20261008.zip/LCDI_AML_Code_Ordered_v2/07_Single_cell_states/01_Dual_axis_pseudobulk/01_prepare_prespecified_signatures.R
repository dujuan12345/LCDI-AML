# Freeze prespecified pathway signatures from the locally installed msigdbr package.

options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages(library(msigdbr))

project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/dual_axis_pseudobulk_20260819_v1")
status_path <- file.path(out_dir, "signature_run_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed signature output")

write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", row.names = FALSE,
              col.names = TRUE, quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}

lcd_genes <- c("MPO", "CREB1", "GPX4", "SLC16A4", "CASP1")
targets <- data.frame(
  program = c("E2F_targets", "MYC_targets_V1", "oxidative_phosphorylation",
              "inflammatory_response", "pyroptosis", "ferroptosis",
              "proton_coupled_monocarboxylate_transport"),
  gs_name = c("HALLMARK_E2F_TARGETS", "HALLMARK_MYC_TARGETS_V1",
              "HALLMARK_OXIDATIVE_PHOSPHORYLATION", "HALLMARK_INFLAMMATORY_RESPONSE",
              "REACTOME_PYROPTOSIS", "WP_FERROPTOSIS",
              "REACTOME_PROTON_COUPLED_MONOCARBOXYLATE_TRANSPORT"),
  collection = c(rep("H", 4), rep("C2", 3)),
  rationale = c("prespecified proliferation", "prespecified proliferation",
                "prespecified energy metabolism", "prespecified inflammation",
                "prespecified inflammatory cell death", "prespecified redox cell death",
                "prespecified monocarboxylate transport"),
  stringsAsFactors = FALSE
)

h <- msigdbr(species = "Homo sapiens", category = "H")
c2 <- msigdbr(species = "Homo sapiens", category = "C2")
all_sets <- rbind(h[, c("gs_name", "gene_symbol")], c2[, c("gs_name", "gene_symbol")])
sel <- merge(targets, all_sets, by = "gs_name", all.x = TRUE, sort = FALSE)
if (anyNA(sel$gene_symbol)) stop("One or more prespecified gene sets were not found")
sel$excluded_LCDI_gene <- sel$gene_symbol %in% lcd_genes

membership <- sel[!sel$excluded_LCDI_gene,
                  c("program", "gs_name", "collection", "rationale", "gene_symbol")]
membership <- unique(membership)
membership <- membership[order(membership$program, membership$gene_symbol), ]
excluded <- unique(sel[sel$excluded_LCDI_gene,
                       c("program", "gs_name", "gene_symbol")])
summary <- do.call(rbind, lapply(seq_len(nrow(targets)), function(i) {
  z <- sel[sel$program == targets$program[i], ]
  data.frame(
    program = targets$program[i], gs_name = targets$gs_name[i], collection = targets$collection[i],
    original_genes = length(unique(z$gene_symbol)),
    excluded_LCDI_genes = paste(sort(unique(z$gene_symbol[z$excluded_LCDI_gene])), collapse = ";"),
    excluded_n = length(unique(z$gene_symbol[z$excluded_LCDI_gene])),
    final_genes = length(unique(z$gene_symbol[!z$excluded_LCDI_gene])),
    rationale = targets$rationale[i], stringsAsFactors = FALSE
  )
}))
if (any(summary$final_genes < 5L)) stop("A prespecified signature has fewer than five genes after exclusion")

write_tsv(membership, "prespecified_signature_membership.tsv")
write_tsv(excluded, "prespecified_signature_excluded_LCDI_genes.tsv")
write_tsv(summary, "prespecified_signature_summary.tsv")
capture.output(sessionInfo(), file = file.path(out_dir, "signature_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "programs", "LCDI_genes_excluded", "package"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), nrow(targets),
            paste(lcd_genes, collapse = ";"), paste0("msigdbr ", packageVersion("msigdbr"))),
  stringsAsFactors = FALSE
), "signature_run_status.tsv")


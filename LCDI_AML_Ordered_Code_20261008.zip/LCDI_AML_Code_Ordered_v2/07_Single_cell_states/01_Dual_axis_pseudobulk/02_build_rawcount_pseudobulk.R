# Build raw-count patient/sample-by-lineage pseudobulk profiles from existing Seurat objects.

options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(edgeR)
})

project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/dual_axis_pseudobulk_20260819_v1")
adult_path <- file.path(project_root, "AML_Lactylation_PCD/scRNA/GSE116256/J2_LCDI/Data/seurat_obj_with_LCDI.rds")
pediatric_path <- file.path(project_root, "AML_Lactylation_PCD/scRNA/GSE185381/J10_LCDI/Data/seurat_obj_with_LCDI_GSE185381.rds")
membership_path <- file.path(out_dir, "prespecified_signature_membership.tsv")
status_path <- file.path(out_dir, "pseudobulk_run_status.tsv")
seed <- 20260819L
min_cells <- 20L
set.seed(seed)
stopifnot(file.exists(adult_path), file.exists(pediatric_path), file.exists(membership_path))
if (file.exists(status_path)) stop("Refusing to overwrite completed pseudobulk output")

log_con <- file(file.path(out_dir, "pseudobulk_run.log"), open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
sink(log_con, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", row.names = FALSE,
              col.names = TRUE, quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}
z_rows <- function(x) {
  mu <- rowMeans(x)
  ss <- apply(x, 1, sd)
  keep <- is.finite(ss) & ss > 0
  out <- matrix(NA_real_, nrow(x), ncol(x), dimnames = dimnames(x))
  out[keep, ] <- sweep(sweep(x[keep, , drop = FALSE], 1, mu[keep], "-"), 1, ss[keep], "/")
  out
}
map_adult <- function(x) {
  y <- rep(NA_character_, length(x))
  y[x == "HSC-like"] <- "HSC-like/HSC"
  y[x == "Prog-like"] <- "Progenitor-like/MPP"
  y[x == "GMP-like"] <- "GMP-like/GMP"
  y[x %in% c("ProMono-like", "Mono-like")] <- "Monocytic-like"
  y
}
map_pediatric <- function(x) {
  y <- rep(NA_character_, length(x))
  y[x == "HSC"] <- "HSC-like/HSC"
  y[x %in% c("MPP", "MEP")] <- "Progenitor-like/MPP"
  y[x == "GMP"] <- "GMP-like/GMP"
  y[x %in% c("CD14+ monocyte", "HLA-II+ monocyte", "CD16+ monocyte")] <- "Monocytic-like"
  y
}

signatures <- read.delim(membership_path, check.names = FALSE, stringsAsFactors = FALSE)
beta <- c(CREB1 = 0.0925, SLC16A4 = -0.0636, GPX4 = -0.0721,
          CASP1 = -0.0106, MPO = -0.2095)
non_mpo <- setdiff(names(beta), "MPO")

process_one <- function(path, dataset) {
  cat("Loading", dataset, path, "\n")
  obj <- readRDS(path)
  meta <- obj[[]]
  counts <- LayerData(obj[["RNA"]], layer = "counts")
  stopifnot(inherits(counts, "sparseMatrix"), identical(colnames(counts), rownames(meta)),
            all(names(beta) %in% rownames(counts)))

  if (dataset == "adult") {
    keep_base <- meta$source == "AML" & meta$timepoint == "D0" &
      meta$PredictionRefined_clean == "malignant"
    unit <- as.character(meta$patient)
    original <- as.character(meta$CellType_ordered)
    common <- map_adult(original)
    filter_text <- "source=AML;timepoint=D0;PredictionRefined_clean=malignant"
  } else {
    keep_base <- meta$ap_aml_age == "pediatric_AML" & meta$malignant == "malignant"
    unit <- as.character(meta$samples)
    original <- as.character(meta$Broad_cell_identity)
    common <- map_pediatric(original)
    filter_text <- "ap_aml_age=pediatric_AML;malignant=malignant"
  }
  keep <- keep_base & !is.na(unit) & nzchar(unit) & !is.na(common)
  cell_meta <- data.frame(cell = rownames(meta)[keep], unit = unit[keep],
                          lineage_original = original[keep], lineage_common = common[keep],
                          stringsAsFactors = FALSE)
  cell_meta$group <- paste(cell_meta$unit, cell_meta$lineage_common, sep = "|||")
  group_counts <- sort(table(cell_meta$group), decreasing = TRUE)
  retained <- names(group_counts)[group_counts >= min_cells]
  cell_meta <- cell_meta[cell_meta$group %in% retained, , drop = FALSE]
  groups <- sort(unique(cell_meta$group))
  g <- factor(cell_meta$group, levels = groups)
  design <- sparseMatrix(i = seq_along(g), j = as.integer(g), x = 1,
                         dims = c(length(g), length(groups)),
                         dimnames = list(cell_meta$cell, groups))
  pb_counts <- counts[, cell_meta$cell, drop = FALSE] %*% design
  lib_size <- as.numeric(colSums(pb_counts))
  if (any(lib_size <= 0)) stop(dataset, ": zero pseudobulk library")
  logcpm <- edgeR::cpm(pb_counts, log = TRUE, prior.count = 1)
  expr_z <- z_rows(logcpm)

  split_group <- strsplit(groups, "\\|\\|\\|")
  group_meta <- data.frame(
    dataset = dataset,
    unit = vapply(split_group, `[`, character(1), 1),
    lineage_common = vapply(split_group, `[`, character(1), 2),
    group = groups,
    n_cells = as.integer(group_counts[groups]),
    library_size = lib_size,
    stringsAsFactors = FALSE
  )
  stopifnot(!anyDuplicated(group_meta$group), all(group_meta$n_cells >= min_cells))

  five_logcpm <- t(logcpm[names(beta), , drop = FALSE])
  colnames(five_logcpm) <- paste0(names(beta), "_logCPM")
  five_z <- t(expr_z[names(beta), , drop = FALSE])
  colnames(five_z) <- paste0(names(beta), "_z")
  score <- as.numeric(t(expr_z[names(beta), , drop = FALSE]) %*% beta)
  mpo_axis <- as.numeric(expr_z["MPO", ] * beta["MPO"])
  non_axis <- as.numeric(t(expr_z[non_mpo, , drop = FALSE]) %*% beta[non_mpo])
  score_table <- cbind(group_meta, five_logcpm, five_z,
                       LCDI_pseudobulk = score, MPO_axis = mpo_axis, nonMPO_axis = non_axis)
  score_table$MPO_axis_z <- as.numeric(scale(score_table$MPO_axis))
  score_table$nonMPO_axis_z <- as.numeric(scale(score_table$nonMPO_axis))
  score_table$LCDI_pseudobulk_z <- as.numeric(scale(score_table$LCDI_pseudobulk))

  contrib <- do.call(rbind, lapply(non_mpo, function(gene) data.frame(
    dataset = dataset, unit = group_meta$unit, lineage_common = group_meta$lineage_common,
    group = group_meta$group, gene = gene, gene_z = as.numeric(expr_z[gene, ]),
    coefficient = unname(beta[gene]), contribution = as.numeric(expr_z[gene, ] * beta[gene]),
    stringsAsFactors = FALSE
  )))
  contrib$contribution_z <- ave(contrib$contribution, contrib$gene,
                                FUN = function(x) as.numeric(scale(x)))

  pathway_rows <- list()
  overlap_rows <- list()
  for (program in unique(signatures$program)) {
    requested <- unique(signatures$gene_symbol[signatures$program == program])
    present <- intersect(requested, rownames(expr_z))
    usable <- present[is.finite(rowSums(expr_z[present, , drop = FALSE]))]
    if (length(usable) < 5L) stop(dataset, ": fewer than five usable genes for ", program)
    pathway_rows[[length(pathway_rows) + 1L]] <- data.frame(
      dataset = dataset, unit = group_meta$unit, lineage_common = group_meta$lineage_common,
      group = group_meta$group, program = program,
      pathway_score = colMeans(expr_z[usable, , drop = FALSE]), stringsAsFactors = FALSE
    )
    overlap_rows[[length(overlap_rows) + 1L]] <- data.frame(
      dataset = dataset, program = program, requested_genes = length(requested),
      present_genes = length(present), usable_genes = length(usable),
      missing_genes = paste(sort(setdiff(requested, present)), collapse = ";"),
      stringsAsFactors = FALSE
    )
  }
  pathway <- do.call(rbind, pathway_rows)
  pathway$pathway_score_z <- ave(pathway$pathway_score, pathway$program,
                                 FUN = function(x) as.numeric(scale(x)))
  overlap <- do.call(rbind, overlap_rows)
  composition <- aggregate(rep(1L, nrow(cell_meta)),
                           by = list(dataset = rep(dataset, nrow(cell_meta)), unit = cell_meta$unit,
                                     lineage_common = cell_meta$lineage_common,
                                     lineage_original = cell_meta$lineage_original), sum)
  names(composition)[5] <- "n_cells"
  qc <- data.frame(
    dataset = dataset, object_path = path, object_genes = nrow(obj), object_cells = ncol(obj),
    counts_class = class(counts)[1], selected_cells = nrow(cell_meta),
    retained_groups = nrow(group_meta), retained_units = length(unique(group_meta$unit)),
    lineages = length(unique(group_meta$lineage_common)), min_cells = min_cells,
    minimum_library_size = min(lib_size), median_library_size = median(lib_size),
    maximum_library_size = max(lib_size), max_decomposition_error = max(abs(score - mpo_axis - non_axis)),
    filter = filter_text, stringsAsFactors = FALSE
  )
  rm(obj, meta, counts, pb_counts, logcpm, expr_z, design)
  gc()
  list(scores = score_table, contributions = contrib, pathways = pathway,
       overlap = overlap, composition = composition, qc = qc)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\nSeed:", seed, "\n")
adult <- process_one(adult_path, "adult")
pediatric <- process_one(pediatric_path, "pediatric")

write_tsv(rbind(adult$scores, pediatric$scores), "pseudobulk_unit_lineage_scores.tsv")
write_tsv(rbind(adult$contributions, pediatric$contributions), "pseudobulk_nonMPO_gene_contributions.tsv")
write_tsv(rbind(adult$pathways, pediatric$pathways), "pseudobulk_pathway_scores.tsv")
write_tsv(rbind(adult$overlap, pediatric$overlap), "pseudobulk_signature_overlap_qc.tsv")
write_tsv(rbind(adult$composition, pediatric$composition), "pseudobulk_lineage_composition.tsv")
write_tsv(rbind(adult$qc, pediatric$qc), "pseudobulk_input_qc.tsv")
capture.output(sessionInfo(), file = file.path(out_dir, "pseudobulk_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "seed", "minimum_cells", "normalization", "inference_unit", "packages"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), seed, min_cells,
            "raw counts summed per biological-unit-by-lineage; edgeR logCPM prior.count=1; per-dataset gene z-score",
            "patient/sample x mapped lineage", paste0("R ", getRversion(), "; Seurat ",
            packageVersion("Seurat"), "; edgeR ", packageVersion("edgeR"))),
  stringsAsFactors = FALSE
), "pseudobulk_run_status.tsv")
cat("Completed:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\nStatus: passed\n")

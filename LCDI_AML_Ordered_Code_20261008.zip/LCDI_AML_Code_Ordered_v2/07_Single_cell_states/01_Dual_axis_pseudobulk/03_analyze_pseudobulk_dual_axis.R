# Analyze pseudobulk dual-axis robustness, four-gene contributions, and prespecified pathways.

options(stringsAsFactors = FALSE, warn = 1)
project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/dual_axis_pseudobulk_20260819_v1")
status_path <- file.path(out_dir, "analysis_run_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed analysis output")

read_tsv <- function(name) read.delim(file.path(out_dir, name), check.names = FALSE,
                                      stringsAsFactors = FALSE)
write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", row.names = FALSE,
              col.names = TRUE, quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}
global_lineage_test <- function(data, outcome, adjust_mpo = TRUE) {
  d <- data
  d$unit <- factor(d$unit)
  d$lineage_common <- relevel(factor(d$lineage_common), ref = "GMP-like/GMP")
  rhs0 <- if (adjust_mpo) "unit + MPO_axis_z" else "unit"
  f0 <- lm(as.formula(paste(outcome, "~", rhs0)), data = d)
  f1 <- lm(as.formula(paste(outcome, "~", rhs0, "+ lineage_common")), data = d)
  a <- anova(f0, f1)
  c(df_added = a$Df[2], F = a$F[2], p_value = a$`Pr(>F)`[2],
    adjusted_R2_base = summary(f0)$adj.r.squared,
    adjusted_R2_full = summary(f1)$adj.r.squared,
    delta_adjusted_R2 = summary(f1)$adj.r.squared - summary(f0)$adj.r.squared)
}
conditional_pathway_fit <- function(d) {
  d$unit <- factor(d$unit)
  d$lineage_common <- factor(d$lineage_common)
  fit <- lm(pathway_score_z ~ unit + lineage_common + MPO_axis_z + nonMPO_axis_z, data = d)
  s <- summary(fit)$coefficients
  i <- match("nonMPO_axis_z", rownames(s))
  c(coefficient = s[i, "Estimate"], standard_error = s[i, "Std. Error"],
    t = s[i, "t value"], p_value = s[i, "Pr(>|t|)"], df_residual = df.residual(fit),
    partial_R2 = s[i, "t value"]^2 / (s[i, "t value"]^2 + df.residual(fit)))
}

scores <- read_tsv("pseudobulk_unit_lineage_scores.tsv")
contrib <- read_tsv("pseudobulk_nonMPO_gene_contributions.tsv")
pathways <- read_tsv("pseudobulk_pathway_scores.tsv")
qc <- read_tsv("pseudobulk_input_qc.tsv")
sig_summary <- read_tsv("prespecified_signature_summary.tsv")

stopifnot(nrow(qc) == 2L, all(qc$retained_groups > 0), all(qc$max_decomposition_error < 1e-12),
          !anyDuplicated(scores[, c("dataset", "unit", "lineage_common")]),
          all(scores$n_cells >= 20L), !anyNA(scores),
          length(unique(pathways$program)) == 7L,
          !any(sig_summary$excluded_LCDI_genes == "MPO" & sig_summary$final_genes == sig_summary$original_genes))

# Main pseudobulk dual-axis lineage effect.
main_rows <- list()
loo_rows <- list()
for (dataset in unique(scores$dataset)) {
  d <- scores[scores$dataset == dataset, ]
  g <- global_lineage_test(d, "nonMPO_axis_z", TRUE)
  main_rows[[length(main_rows) + 1L]] <- data.frame(
    dataset = dataset, records = nrow(d), units = length(unique(d$unit)),
    lineages = length(unique(d$lineage_common)), t(g), stringsAsFactors = FALSE
  )
  for (u in unique(d$unit)) {
    z <- d[d$unit != u, , drop = FALSE]
    g2 <- global_lineage_test(z, "nonMPO_axis_z", TRUE)
    loo_rows[[length(loo_rows) + 1L]] <- data.frame(
      dataset = dataset, omitted_unit = u, records = nrow(z), units = length(unique(z$unit)),
      lineages = length(unique(z$lineage_common)), t(g2), stringsAsFactors = FALSE
    )
  }
}
main <- do.call(rbind, main_rows)
main$fdr <- p.adjust(main$p_value, method = "BH")
loo <- do.call(rbind, loo_rows)
loo_summary <- do.call(rbind, lapply(split(loo, loo$dataset), function(z) data.frame(
  dataset = unique(z$dataset), omissions = nrow(z), minimum_p = min(z$p_value),
  median_p = median(z$p_value), maximum_p = max(z$p_value),
  proportion_p_lt_0_05 = mean(z$p_value < 0.05),
  proportion_same_positive_F = mean(z$F > 0), stringsAsFactors = FALSE
)))

# Cross-dataset common-lineage centroids.
centroids <- aggregate(scores[, c("MPO_axis_z", "nonMPO_axis_z")],
                       by = list(dataset = scores$dataset, lineage_common = scores$lineage_common), mean)
wide <- reshape(centroids[, c("dataset", "lineage_common", "nonMPO_axis_z")],
                idvar = "lineage_common", timevar = "dataset", direction = "wide")
wide <- wide[complete.cases(wide), ]
centroid_concordance <- data.frame(
  common_lineages = nrow(wide),
  spearman_rho = if (nrow(wide) >= 3L) cor(wide$nonMPO_axis_z.adult,
                                           wide$nonMPO_axis_z.pediatric,
                                           method = "spearman") else NA_real_,
  p_value = if (nrow(wide) >= 4L) cor.test(wide$nonMPO_axis_z.adult,
                                           wide$nonMPO_axis_z.pediatric,
                                           method = "spearman", exact = FALSE)$p.value else NA_real_,
  stringsAsFactors = FALSE
)

# Four-gene contribution to lineage structure after controlling for MPO.
contribution_rows <- list()
for (dataset in unique(contrib$dataset)) {
  s0 <- scores[scores$dataset == dataset,
               c("group", "unit", "lineage_common", "MPO_axis_z")]
  for (gene in unique(contrib$gene)) {
    c0 <- contrib[contrib$dataset == dataset & contrib$gene == gene,
                  c("group", "contribution_z")]
    d <- merge(s0, c0, by = "group", all = FALSE)
    g <- global_lineage_test(d, "contribution_z", TRUE)
    contribution_rows[[length(contribution_rows) + 1L]] <- data.frame(
      dataset = dataset, gene = gene, records = nrow(d), t(g), stringsAsFactors = FALSE
    )
  }
}
contribution_tests <- do.call(rbind, contribution_rows)
contribution_tests$fdr_within_dataset <- ave(contribution_tests$p_value,
                                             contribution_tests$dataset,
                                             FUN = function(x) p.adjust(x, method = "BH"))
gene_replication <- do.call(rbind, lapply(unique(contribution_tests$gene), function(gene) {
  z <- contribution_tests[contribution_tests$gene == gene, ]
  data.frame(
    gene = gene, adult_p = z$p_value[z$dataset == "adult"],
    adult_fdr = z$fdr_within_dataset[z$dataset == "adult"],
    pediatric_p = z$p_value[z$dataset == "pediatric"],
    pediatric_fdr = z$fdr_within_dataset[z$dataset == "pediatric"],
    replicated_lineage_structure = all(z$fdr_within_dataset < 0.05),
    stringsAsFactors = FALSE
  )
}))

# Conditional pathway associations: pathway ~ unit + lineage + MPO + nonMPO.
pathway_rows <- list()
pathway_loo_rows <- list()
for (dataset in unique(pathways$dataset)) {
  s0 <- scores[scores$dataset == dataset,
               c("group", "unit", "lineage_common", "MPO_axis_z", "nonMPO_axis_z")]
  for (program in unique(pathways$program)) {
    p0 <- pathways[pathways$dataset == dataset & pathways$program == program,
                   c("group", "pathway_score_z")]
    d <- merge(s0, p0, by = "group", all = FALSE)
    fit <- conditional_pathway_fit(d)
    pathway_rows[[length(pathway_rows) + 1L]] <- data.frame(
      dataset = dataset, program = program, records = nrow(d), t(fit), stringsAsFactors = FALSE
    )
    for (u in unique(d$unit)) {
      z <- d[d$unit != u, , drop = FALSE]
      f2 <- conditional_pathway_fit(z)
      pathway_loo_rows[[length(pathway_loo_rows) + 1L]] <- data.frame(
        dataset = dataset, program = program, omitted_unit = u,
        coefficient = f2["coefficient"], p_value = f2["p_value"], stringsAsFactors = FALSE
      )
    }
  }
}
pathway_tests <- do.call(rbind, pathway_rows)
pathway_tests$fdr_within_dataset <- ave(pathway_tests$p_value, pathway_tests$dataset,
                                        FUN = function(x) p.adjust(x, method = "BH"))
pathway_loo <- do.call(rbind, pathway_loo_rows)
pathway_loo_summary <- do.call(rbind, lapply(split(pathway_loo,
                                                   interaction(pathway_loo$dataset, pathway_loo$program)),
                                             function(z) data.frame(
  dataset = unique(z$dataset), program = unique(z$program), omissions = nrow(z),
  coefficient_min = min(z$coefficient), coefficient_median = median(z$coefficient),
  coefficient_max = max(z$coefficient), proportion_same_as_full = NA_real_,
  proportion_p_lt_0_05 = mean(z$p_value < 0.05), stringsAsFactors = FALSE
)))
for (i in seq_len(nrow(pathway_loo_summary))) {
  ds <- pathway_loo_summary$dataset[i]
  pr <- pathway_loo_summary$program[i]
  full_b <- pathway_tests$coefficient[pathway_tests$dataset == ds & pathway_tests$program == pr]
  z <- pathway_loo[pathway_loo$dataset == ds & pathway_loo$program == pr, ]
  pathway_loo_summary$proportion_same_as_full[i] <- mean(sign(z$coefficient) == sign(full_b))
}

meta_rows <- list()
for (program in unique(pathway_tests$program)) {
  z <- pathway_tests[pathway_tests$program == program, ]
  w <- 1 / z$standard_error^2
  b <- sum(w * z$coefficient) / sum(w)
  se <- sqrt(1 / sum(w))
  zz <- b / se
  meta_rows[[length(meta_rows) + 1L]] <- data.frame(
    program = program, adult_coefficient = z$coefficient[z$dataset == "adult"],
    adult_p = z$p_value[z$dataset == "adult"],
    adult_fdr = z$fdr_within_dataset[z$dataset == "adult"],
    pediatric_coefficient = z$coefficient[z$dataset == "pediatric"],
    pediatric_p = z$p_value[z$dataset == "pediatric"],
    pediatric_fdr = z$fdr_within_dataset[z$dataset == "pediatric"],
    same_direction = length(unique(sign(z$coefficient))) == 1L,
    fixed_coefficient = b, fixed_se = se, fixed_z = zz,
    fixed_p = 2 * pnorm(-abs(zz)), stringsAsFactors = FALSE
  )
}
pathway_meta <- do.call(rbind, meta_rows)
pathway_meta$fixed_fdr <- p.adjust(pathway_meta$fixed_p, method = "BH")
pathway_meta$replicated <- with(pathway_meta,
                                same_direction & adult_p < 0.05 & pediatric_p < 0.05 & fixed_fdr < 0.05)

main_pass <- all(main$fdr < 0.05)
loo_pass <- all(loo_summary$proportion_p_lt_0_05 >= 0.80)
gene_pass <- any(gene_replication$replicated_lineage_structure)
pathway_pass <- any(pathway_meta$replicated)
phase_gate <- data.frame(
  gate = c("pseudobulk_lineage_effect_both_datasets_FDR_lt_0.05",
           "leave_one_unit_P_lt_0.05_at_least_80pct_both",
           "replicated_four_gene_lineage_driver",
           "replicated_prespecified_pathway_association",
           "phase1_dual_axis_strengthening_pass"),
  pass = c(main_pass, loo_pass, gene_pass, pathway_pass,
           main_pass && loo_pass && (gene_pass || pathway_pass)),
  evidence = c(
    paste(paste0(main$dataset, " FDR=", signif(main$fdr, 4)), collapse = "; "),
    paste(paste0(loo_summary$dataset, "=", round(100 * loo_summary$proportion_p_lt_0_05), "%"), collapse = "; "),
    paste(gene_replication$gene[gene_replication$replicated_lineage_structure], collapse = ";"),
    paste(pathway_meta$program[pathway_meta$replicated], collapse = ";"),
    "Requires both pseudobulk lineage effects, both leave-one proportions >=80%, and a replicated gene driver or pathway"
  ), stringsAsFactors = FALSE
)

write_tsv(main, "pseudobulk_dual_axis_lineage_tests.tsv")
write_tsv(loo, "pseudobulk_leave_one_unit_out.tsv")
write_tsv(loo_summary, "pseudobulk_leave_one_unit_out_summary.tsv")
write_tsv(centroids, "pseudobulk_lineage_centroids.tsv")
write_tsv(wide, "pseudobulk_cross_dataset_lineage_centroids.tsv")
write_tsv(centroid_concordance, "pseudobulk_centroid_concordance.tsv")
write_tsv(contribution_tests, "pseudobulk_gene_contribution_lineage_tests.tsv")
write_tsv(gene_replication, "pseudobulk_gene_contribution_replication.tsv")
write_tsv(pathway_tests, "pseudobulk_conditional_pathway_tests.tsv")
write_tsv(pathway_meta, "pseudobulk_pathway_replication_meta.tsv")
write_tsv(pathway_loo, "pseudobulk_pathway_leave_one_unit_out.tsv")
write_tsv(pathway_loo_summary, "pseudobulk_pathway_leave_one_unit_out_summary.tsv")
write_tsv(phase_gate, "phase1_dual_axis_gate.tsv")

cols <- c("HSC-like/HSC" = "#3B4CC0", "Progenitor-like/MPP" = "#6F92F3",
          "GMP-like/GMP" = "#B5D0E8", "Monocytic-like" = "#B40426")
draw_dual <- function() {
  old <- par(mfrow = c(1, 2), mar = c(4.5, 4.7, 2.3, 1.0))
  on.exit(par(old), add = TRUE)
  for (dataset in c("adult", "pediatric")) {
    z <- scores[scores$dataset == dataset, ]
    plot(z$MPO_axis_z, z$nonMPO_axis_z, pch = 21,
         bg = adjustcolor(cols[z$lineage_common], alpha.f = 0.75), col = "white",
         xlab = "MPO risk axis (pseudobulk z)", ylab = "Non-MPO axis (pseudobulk z)",
         main = dataset)
    abline(h = 0, v = 0, lty = 3, col = "grey65")
    ct <- centroids[centroids$dataset == dataset, ]
    text(ct$MPO_axis_z, ct$nonMPO_axis_z, labels = ct$lineage_common,
         col = cols[ct$lineage_common], cex = 0.68, pos = 3)
  }
}
pdf(file.path(out_dir, "Figure_pseudobulk_dual_axis.pdf"), 11.5, 5.4)
draw_dual()
dev.off()
png(file.path(out_dir, "Figure_pseudobulk_dual_axis.png"), 2760, 1296, res = 240)
draw_dual()
dev.off()

draw_pathways <- function() {
  z <- pathway_meta[order(pathway_meta$fixed_coefficient), ]
  label_map <- c(
    E2F_targets = "E2F targets",
    MYC_targets_V1 = "MYC targets V1",
    oxidative_phosphorylation = "OXPHOS",
    inflammatory_response = "Inflam. response",
    pyroptosis = "Pyroptosis",
    ferroptosis = "Ferroptosis",
    proton_coupled_monocarboxylate_transport = "PC-MCT"
  )
  pathway_labels <- unname(label_map[z$program])
  y <- seq_len(nrow(z))
  xl <- range(c(z$adult_coefficient, z$pediatric_coefficient,
                z$fixed_coefficient - 1.96 * z$fixed_se,
                z$fixed_coefficient + 1.96 * z$fixed_se, 0))
  plot(z$fixed_coefficient, y, xlim = xl, ylim = c(0.5, nrow(z) + 0.5), pch = 18,
       xlab = "Conditional association with non-MPO axis", ylab = "", yaxt = "n")
  segments(z$fixed_coefficient - 1.96 * z$fixed_se, y,
           z$fixed_coefficient + 1.96 * z$fixed_se, y, lwd = 2)
  points(z$adult_coefficient, y + 0.13, pch = 16, col = "#3B4CC0")
  points(z$pediatric_coefficient, y - 0.13, pch = 16, col = "#B40426")
  abline(v = 0, lty = 2, col = "grey50")
  axis(2, at = y, labels = pathway_labels, las = 1, cex.axis = 0.82)
  legend("bottomright", legend = c("adult", "pediatric", "fixed meta"),
         pch = c(16, 16, 18), col = c("#3B4CC0", "#B40426", "black"), bty = "n")
}
pdf(file.path(out_dir, "Figure_pseudobulk_pathway_associations.pdf"), 9.5, 5.8)
par(mar = c(4.2, 7.0, 1.2, 1.0)); draw_pathways(); dev.off()
png(file.path(out_dir, "Figure_pseudobulk_pathway_associations.png"), 2280, 1392, res = 240)
par(mar = c(4.2, 7.0, 1.2, 1.0)); draw_pathways(); dev.off()

capture.output(sessionInfo(), file = file.path(out_dir, "analysis_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "tests", "inference", "phase1_pass"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
            "pseudobulk lineage; leave-one-unit; four-gene attribution; 7 prespecified pathways",
            "biological-unit-by-lineage only", phase_gate$pass[phase_gate$gate == "phase1_dual_axis_strengthening_pass"]),
  stringsAsFactors = FALSE
), "analysis_run_status.tsv")

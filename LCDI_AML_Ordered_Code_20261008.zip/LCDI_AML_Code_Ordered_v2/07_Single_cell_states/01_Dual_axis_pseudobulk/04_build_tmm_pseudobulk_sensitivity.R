# TMM-normalized raw-count pseudobulk sensitivity.

options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(edgeR)
})

project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/dual_axis_pseudobulk_20260819_v1")
adult_path <- file.path(project_root, "AML_Lactylation_PCD/scRNA/GSE116256/J2_LCDI/Data/seurat_obj_with_LCDI.rds")
pediatric_path <- file.path(project_root, "AML_Lactylation_PCD/scRNA/GSE185381/J10_LCDI/Data/seurat_obj_with_LCDI_GSE185381.rds")
membership_path <- file.path(out_dir, "prespecified_signature_membership.tsv")
status_path <- file.path(out_dir, "tmm_run_status.tsv")
min_cells <- 20L
seed <- 20260819L
set.seed(seed)
stopifnot(file.exists(adult_path), file.exists(pediatric_path), file.exists(membership_path))
if (file.exists(status_path)) stop("Refusing to overwrite completed TMM output")

log_con <- file(file.path(out_dir, "tmm_run.log"), open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
sink(log_con, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", row.names = FALSE,
              col.names = TRUE, quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}
z_rows <- function(x) {
  mu <- rowMeans(x)
  ss <- apply(x, 1, sd)
  keep <- is.finite(ss) & ss > 0
  out <- matrix(NA_real_, nrow(x), ncol(x), dimnames = dimnames(x))
  out[keep, ] <- sweep(sweep(x[keep, , drop = FALSE], 1, mu[keep], "-"), 1, ss[keep], "/")
  out
}
map_adult <- function(x) {
  y <- rep(NA_character_, length(x))
  y[x == "HSC-like"] <- "HSC-like/HSC"
  y[x == "Prog-like"] <- "Progenitor-like/MPP"
  y[x == "GMP-like"] <- "GMP-like/GMP"
  y[x %in% c("ProMono-like", "Mono-like")] <- "Monocytic-like"
  y
}
map_pediatric <- function(x) {
  y <- rep(NA_character_, length(x))
  y[x == "HSC"] <- "HSC-like/HSC"
  y[x %in% c("MPP", "MEP")] <- "Progenitor-like/MPP"
  y[x == "GMP"] <- "GMP-like/GMP"
  y[x %in% c("CD14+ monocyte", "HLA-II+ monocyte", "CD16+ monocyte")] <- "Monocytic-like"
  y
}

signatures <- read.delim(membership_path, check.names = FALSE, stringsAsFactors = FALSE)
beta <- c(CREB1 = 0.0925, SLC16A4 = -0.0636, GPX4 = -0.0721,
          CASP1 = -0.0106, MPO = -0.2095)
non_mpo <- setdiff(names(beta), "MPO")

process_one <- function(path, dataset) {
  cat("Loading", dataset, path, "\n")
  obj <- readRDS(path)
  meta <- obj[[]]
  counts <- LayerData(obj[["RNA"]], layer = "counts")
  stopifnot(inherits(counts, "sparseMatrix"), identical(colnames(counts), rownames(meta)),
            all(names(beta) %in% rownames(counts)))
  if (dataset == "adult") {
    keep <- meta$source == "AML" & meta$timepoint == "D0" &
      meta$PredictionRefined_clean == "malignant"
    unit <- as.character(meta$patient)
    common <- map_adult(as.character(meta$CellType_ordered))
  } else {
    keep <- meta$ap_aml_age == "pediatric_AML" & meta$malignant == "malignant"
    unit <- as.character(meta$samples)
    common <- map_pediatric(as.character(meta$Broad_cell_identity))
  }
  keep <- keep & !is.na(unit) & nzchar(unit) & !is.na(common)
  cm <- data.frame(cell = rownames(meta)[keep], unit = unit[keep],
                   lineage_common = common[keep], stringsAsFactors = FALSE)
  cm$group <- paste(cm$unit, cm$lineage_common, sep = "|||")
  sizes <- table(cm$group)
  retained <- names(sizes)[sizes >= min_cells]
  cm <- cm[cm$group %in% retained, , drop = FALSE]
  groups <- sort(unique(cm$group))
  gf <- factor(cm$group, levels = groups)
  design <- sparseMatrix(i = seq_along(gf), j = as.integer(gf), x = 1,
                         dims = c(length(gf), length(groups)),
                         dimnames = list(cm$cell, groups))
  pb <- counts[, cm$cell, drop = FALSE] %*% design
  dge <- DGEList(counts = pb)
  dge <- calcNormFactors(dge, method = "TMM")
  logcpm <- cpm(dge, log = TRUE, prior.count = 1)
  expr_z <- z_rows(logcpm)
  sg <- strsplit(groups, "\\|\\|\\|")
  gm <- data.frame(
    dataset = dataset,
    unit = vapply(sg, `[`, character(1), 1),
    lineage_common = vapply(sg, `[`, character(1), 2),
    group = groups, n_cells = as.integer(sizes[groups]),
    library_size = as.numeric(dge$samples$lib.size),
    norm_factor = as.numeric(dge$samples$norm.factors), stringsAsFactors = FALSE
  )
  score <- as.numeric(t(expr_z[names(beta), , drop = FALSE]) %*% beta)
  mpo <- as.numeric(expr_z["MPO", ] * beta["MPO"])
  non <- as.numeric(t(expr_z[non_mpo, , drop = FALSE]) %*% beta[non_mpo])
  scores <- cbind(gm, LCDI_pseudobulk = score, MPO_axis = mpo, nonMPO_axis = non)
  scores$MPO_axis_z <- as.numeric(scale(scores$MPO_axis))
  scores$nonMPO_axis_z <- as.numeric(scale(scores$nonMPO_axis))
  scores$LCDI_pseudobulk_z <- as.numeric(scale(scores$LCDI_pseudobulk))
  contrib <- do.call(rbind, lapply(non_mpo, function(gene) data.frame(
    dataset = dataset, unit = gm$unit, lineage_common = gm$lineage_common,
    group = gm$group, gene = gene, contribution = as.numeric(expr_z[gene, ] * beta[gene]),
    stringsAsFactors = FALSE
  )))
  contrib$contribution_z <- ave(contrib$contribution, contrib$gene,
                                FUN = function(x) as.numeric(scale(x)))
  p_rows <- list()
  for (program in unique(signatures$program)) {
    requested <- unique(signatures$gene_symbol[signatures$program == program])
    present <- intersect(requested, rownames(expr_z))
    usable <- present[is.finite(rowSums(expr_z[present, , drop = FALSE]))]
    p_rows[[length(p_rows) + 1L]] <- data.frame(
      dataset = dataset, unit = gm$unit, lineage_common = gm$lineage_common,
      group = gm$group, program = program,
      pathway_score = colMeans(expr_z[usable, , drop = FALSE]), stringsAsFactors = FALSE
    )
  }
  pathways <- do.call(rbind, p_rows)
  pathways$pathway_score_z <- ave(pathways$pathway_score, pathways$program,
                                  FUN = function(x) as.numeric(scale(x)))
  qc <- data.frame(
    dataset = dataset, records = nrow(gm), units = length(unique(gm$unit)),
    lineages = length(unique(gm$lineage_common)), selected_cells = nrow(cm),
    min_norm_factor = min(gm$norm_factor), median_norm_factor = median(gm$norm_factor),
    max_norm_factor = max(gm$norm_factor),
    max_decomposition_error = max(abs(score - mpo - non)), stringsAsFactors = FALSE
  )
  rm(obj, meta, counts, pb, dge, logcpm, expr_z, design)
  gc()
  list(scores = scores, contributions = contrib, pathways = pathways, qc = qc)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
adult <- process_one(adult_path, "adult")
pediatric <- process_one(pediatric_path, "pediatric")
write_tsv(rbind(adult$scores, pediatric$scores), "tmm_unit_lineage_scores.tsv")
write_tsv(rbind(adult$contributions, pediatric$contributions), "tmm_nonMPO_gene_contributions.tsv")
write_tsv(rbind(adult$pathways, pediatric$pathways), "tmm_pathway_scores.tsv")
write_tsv(rbind(adult$qc, pediatric$qc), "tmm_input_qc.tsv")
capture.output(sessionInfo(), file = file.path(out_dir, "tmm_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "seed", "normalization", "inference_unit", "packages"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), seed,
            "raw-count pseudobulk; edgeR TMM normalization; logCPM prior.count=1; per-dataset gene z-score",
            "patient/sample x mapped lineage", paste0("R ", getRversion(), "; edgeR ", packageVersion("edgeR"))),
  stringsAsFactors = FALSE
), "tmm_run_status.tsv")
cat("Completed:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\nStatus: passed\n")


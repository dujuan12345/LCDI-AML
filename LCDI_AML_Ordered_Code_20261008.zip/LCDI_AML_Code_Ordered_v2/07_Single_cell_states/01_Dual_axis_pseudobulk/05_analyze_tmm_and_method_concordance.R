# Analyze TMM sensitivity and compare cell-mean, CPM pseudobulk, and TMM pseudobulk axes.

options(stringsAsFactors = FALSE, warn = 1)
project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/dual_axis_pseudobulk_20260819_v1")
prior_dir <- file.path(project_root, "_codex_audit/innovation_gate_20260819_v1")
status_path <- file.path(out_dir, "tmm_analysis_run_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed TMM analysis output")

read_tsv <- function(path) read.delim(path, check.names = FALSE, stringsAsFactors = FALSE)
write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", row.names = FALSE,
              col.names = TRUE, quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}
global_test <- function(d, outcome = "nonMPO_axis_z") {
  d$unit <- factor(d$unit)
  d$lineage_common <- relevel(factor(d$lineage_common), ref = "GMP-like/GMP")
  f0 <- lm(as.formula(paste(outcome, "~ unit + MPO_axis_z")), data = d)
  f1 <- lm(as.formula(paste(outcome, "~ unit + MPO_axis_z + lineage_common")), data = d)
  a <- anova(f0, f1)
  c(F = a$F[2], p_value = a$`Pr(>F)`[2],
    delta_adjusted_R2 = summary(f1)$adj.r.squared - summary(f0)$adj.r.squared)
}
path_fit <- function(d) {
  d$unit <- factor(d$unit)
  d$lineage_common <- factor(d$lineage_common)
  f <- lm(pathway_score_z ~ unit + lineage_common + MPO_axis_z + nonMPO_axis_z, data = d)
  s <- summary(f)$coefficients
  i <- match("nonMPO_axis_z", rownames(s))
  c(coefficient = s[i, "Estimate"], standard_error = s[i, "Std. Error"],
    p_value = s[i, "Pr(>|t|)"])
}

tmm <- read_tsv(file.path(out_dir, "tmm_unit_lineage_scores.tsv"))
tmm_contrib <- read_tsv(file.path(out_dir, "tmm_nonMPO_gene_contributions.tsv"))
tmm_paths <- read_tsv(file.path(out_dir, "tmm_pathway_scores.tsv"))
cpm <- read_tsv(file.path(out_dir, "pseudobulk_unit_lineage_scores.tsv"))
cell <- read_tsv(file.path(prior_dir, "scrna_unit_lineage_dual_axis.tsv"))
stopifnot(!anyDuplicated(tmm[, c("dataset", "unit", "lineage_common")]), !anyNA(tmm))

# Main and leave-one tests.
main_rows <- list()
loo_rows <- list()
for (ds in unique(tmm$dataset)) {
  d <- tmm[tmm$dataset == ds, ]
  g <- global_test(d)
  main_rows[[length(main_rows) + 1L]] <- data.frame(
    dataset = ds, records = nrow(d), units = length(unique(d$unit)), t(g), stringsAsFactors = FALSE)
  for (u in unique(d$unit)) {
    z <- d[d$unit != u, ]
    g2 <- global_test(z)
    loo_rows[[length(loo_rows) + 1L]] <- data.frame(
      dataset = ds, omitted_unit = u, t(g2), stringsAsFactors = FALSE)
  }
}
main <- do.call(rbind, main_rows)
main$fdr <- p.adjust(main$p_value, method = "BH")
loo <- do.call(rbind, loo_rows)
loo_summary <- do.call(rbind, lapply(split(loo, loo$dataset), function(z) data.frame(
  dataset = unique(z$dataset), omissions = nrow(z), minimum_p = min(z$p_value),
  median_p = median(z$p_value), maximum_p = max(z$p_value),
  proportion_p_lt_0_05 = mean(z$p_value < 0.05), stringsAsFactors = FALSE
)))

# Gene contribution lineage tests.
gene_rows <- list()
for (ds in unique(tmm$dataset)) {
  s0 <- tmm[tmm$dataset == ds, c("group", "unit", "lineage_common", "MPO_axis_z")]
  for (gene in unique(tmm_contrib$gene)) {
    c0 <- tmm_contrib[tmm_contrib$dataset == ds & tmm_contrib$gene == gene,
                      c("group", "contribution_z")]
    d <- merge(s0, c0, by = "group")
    g <- global_test(d, "contribution_z")
    gene_rows[[length(gene_rows) + 1L]] <- data.frame(dataset = ds, gene = gene, t(g),
                                                       stringsAsFactors = FALSE)
  }
}
genes <- do.call(rbind, gene_rows)
genes$fdr_within_dataset <- ave(genes$p_value, genes$dataset,
                                FUN = function(x) p.adjust(x, method = "BH"))
gene_rep <- do.call(rbind, lapply(unique(genes$gene), function(gene) {
  z <- genes[genes$gene == gene, ]
  data.frame(gene = gene,
             adult_fdr = z$fdr_within_dataset[z$dataset == "adult"],
             pediatric_fdr = z$fdr_within_dataset[z$dataset == "pediatric"],
             replicated = all(z$fdr_within_dataset < 0.05), stringsAsFactors = FALSE)
}))

# Pathway conditional associations and two-dataset fixed-effect summaries.
path_rows <- list()
for (ds in unique(tmm$dataset)) {
  s0 <- tmm[tmm$dataset == ds,
            c("group", "unit", "lineage_common", "MPO_axis_z", "nonMPO_axis_z")]
  for (program in unique(tmm_paths$program)) {
    p0 <- tmm_paths[tmm_paths$dataset == ds & tmm_paths$program == program,
                    c("group", "pathway_score_z")]
    d <- merge(s0, p0, by = "group")
    f <- path_fit(d)
    path_rows[[length(path_rows) + 1L]] <- data.frame(dataset = ds, program = program,
                                                      t(f), stringsAsFactors = FALSE)
  }
}
paths <- do.call(rbind, path_rows)
paths$fdr_within_dataset <- ave(paths$p_value, paths$dataset,
                                FUN = function(x) p.adjust(x, method = "BH"))
meta <- do.call(rbind, lapply(unique(paths$program), function(program) {
  z <- paths[paths$program == program, ]
  w <- 1 / z$standard_error^2
  b <- sum(w * z$coefficient) / sum(w)
  se <- sqrt(1 / sum(w))
  zz <- b / se
  data.frame(
    program = program,
    adult_coefficient = z$coefficient[z$dataset == "adult"], adult_p = z$p_value[z$dataset == "adult"],
    pediatric_coefficient = z$coefficient[z$dataset == "pediatric"], pediatric_p = z$p_value[z$dataset == "pediatric"],
    same_direction = length(unique(sign(z$coefficient))) == 1L,
    fixed_coefficient = b, fixed_se = se, fixed_p = 2 * pnorm(-abs(zz)), stringsAsFactors = FALSE
  )
}))
meta$fixed_fdr <- p.adjust(meta$fixed_p, method = "BH")
meta$replicated <- with(meta, same_direction & adult_p < 0.05 & pediatric_p < 0.05 & fixed_fdr < 0.05)

# Method concordance by identical biological-unit-by-lineage records.
key <- c("dataset", "unit", "lineage_common")
method_rows <- list()
for (ds in unique(tmm$dataset)) {
  a <- cell[cell$dataset == ds, c(key, "MPO_axis_z", "nonMPO_axis_z", "LCDI_z")]
  names(a)[4:6] <- paste0(c("MPO", "nonMPO", "LCDI"), "_cellmean")
  b <- cpm[cpm$dataset == ds, c(key, "MPO_axis_z", "nonMPO_axis_z", "LCDI_pseudobulk_z")]
  names(b)[4:6] <- paste0(c("MPO", "nonMPO", "LCDI"), "_cpm")
  tt <- tmm[tmm$dataset == ds, c(key, "MPO_axis_z", "nonMPO_axis_z", "LCDI_pseudobulk_z")]
  names(tt)[4:6] <- paste0(c("MPO", "nonMPO", "LCDI"), "_tmm")
  d <- Reduce(function(x, y) merge(x, y, by = key), list(a, b, tt))
  for (axis in c("MPO", "nonMPO", "LCDI")) {
    for (pair in list(c("cellmean", "cpm"), c("cellmean", "tmm"), c("cpm", "tmm"))) {
      x <- d[[paste0(axis, "_", pair[1])]]
      y <- d[[paste0(axis, "_", pair[2])]]
      method_rows[[length(method_rows) + 1L]] <- data.frame(
        dataset = ds, axis = axis, method1 = pair[1], method2 = pair[2], records = nrow(d),
        pearson = cor(x, y, method = "pearson"), spearman = cor(x, y, method = "spearman"),
        stringsAsFactors = FALSE
      )
    }
  }
}
method_concordance <- do.call(rbind, method_rows)

gate <- data.frame(
  gate = c("TMM_lineage_effect_both_FDR_lt_0.05", "TMM_leave_one_at_least_80pct_both",
           "TMM_replicated_gene_driver", "TMM_replicated_pathway", "TMM_phase1_pass"),
  pass = c(all(main$fdr < 0.05), all(loo_summary$proportion_p_lt_0_05 >= 0.80),
           any(gene_rep$replicated), any(meta$replicated),
           all(main$fdr < 0.05) && all(loo_summary$proportion_p_lt_0_05 >= 0.80) &&
             (any(gene_rep$replicated) || any(meta$replicated))),
  evidence = c(
    paste(paste0(main$dataset, " FDR=", signif(main$fdr, 4)), collapse = "; "),
    paste(paste0(loo_summary$dataset, "=", round(100 * loo_summary$proportion_p_lt_0_05), "%"), collapse = "; "),
    paste(gene_rep$gene[gene_rep$replicated], collapse = ";"),
    paste(meta$program[meta$replicated], collapse = ";"),
    "Same prespecified gate as CPM pseudobulk"), stringsAsFactors = FALSE
)

write_tsv(main, "tmm_dual_axis_lineage_tests.tsv")
write_tsv(loo, "tmm_leave_one_unit_out.tsv")
write_tsv(loo_summary, "tmm_leave_one_unit_out_summary.tsv")
write_tsv(genes, "tmm_gene_contribution_lineage_tests.tsv")
write_tsv(gene_rep, "tmm_gene_contribution_replication.tsv")
write_tsv(paths, "tmm_conditional_pathway_tests.tsv")
write_tsv(meta, "tmm_pathway_replication_meta.tsv")
write_tsv(method_concordance, "three_method_axis_concordance.tsv")
write_tsv(gate, "tmm_phase1_gate.tsv")
capture.output(sessionInfo(), file = file.path(out_dir, "tmm_analysis_session_info.txt"))
write_tsv(data.frame(field = c("status", "completed", "phase1_pass"),
                     value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
                               gate$pass[gate$gate == "TMM_phase1_pass"]),
                     stringsAsFactors = FALSE), "tmm_analysis_run_status.tsv")

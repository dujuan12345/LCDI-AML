# Uniform robustness and direction audit for all four non-MPO gene contributions.

options(stringsAsFactors = FALSE, warn = 1)
project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/dual_axis_pseudobulk_20260819_v1")
status_path <- file.path(out_dir, "gene_driver_audit_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed gene-driver audit")
read_tsv <- function(name) read.delim(file.path(out_dir, name), check.names = FALSE,
                                      stringsAsFactors = FALSE)
write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", row.names = FALSE,
              col.names = TRUE, quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}
fit_global <- function(d) {
  d$unit <- factor(d$unit)
  d$lineage_common <- relevel(factor(d$lineage_common), ref = "GMP-like/GMP")
  b <- lm(contribution_z ~ unit + MPO_axis_z, data = d)
  f <- lm(contribution_z ~ unit + MPO_axis_z + lineage_common, data = d)
  a <- anova(b, f)
  c(F = a$F[2], p_value = a$`Pr(>F)`[2])
}

scores <- read_tsv("tmm_unit_lineage_scores.tsv")
contrib <- read_tsv("tmm_nonMPO_gene_contributions.tsv")
merged <- merge(contrib, scores[, c("group", "MPO_axis_z")], by = "group", all = FALSE)
stopifnot(nrow(merged) == nrow(contrib), !anyNA(merged))

coef_rows <- list()
loo_rows <- list()
centroid_rows <- list()
for (ds in unique(merged$dataset)) {
  for (gene in unique(merged$gene)) {
    d <- merged[merged$dataset == ds & merged$gene == gene, ]
    d$unit <- factor(d$unit)
    d$lineage_common <- relevel(factor(d$lineage_common), ref = "GMP-like/GMP")
    fit <- lm(contribution_z ~ unit + MPO_axis_z + lineage_common, data = d)
    s <- summary(fit)$coefficients
    hit <- grepl("^lineage_common", rownames(s))
    coef_rows[[length(coef_rows) + 1L]] <- data.frame(
      dataset = ds, gene = gene, reference = "GMP-like/GMP", term = rownames(s)[hit],
      coefficient = s[hit, "Estimate"], standard_error = s[hit, "Std. Error"],
      p_value = s[hit, "Pr(>|t|)"], row.names = NULL, stringsAsFactors = FALSE
    )
    for (u in unique(d$unit)) {
      z <- droplevels(d[d$unit != u, , drop = FALSE])
      g <- fit_global(z)
      loo_rows[[length(loo_rows) + 1L]] <- data.frame(
        dataset = ds, gene = gene, omitted_unit = u, F = g["F"], p_value = g["p_value"],
        stringsAsFactors = FALSE
      )
    }
    ct <- aggregate(contribution_z ~ lineage_common, data = d, mean)
    ct$dataset <- ds
    ct$gene <- gene
    centroid_rows[[length(centroid_rows) + 1L]] <- ct[, c("dataset", "gene", "lineage_common", "contribution_z")]
  }
}
coefs <- do.call(rbind, coef_rows)
coefs$fdr_within_dataset_gene <- ave(coefs$p_value, interaction(coefs$dataset, coefs$gene),
                                     FUN = function(x) p.adjust(x, method = "BH"))
loo <- do.call(rbind, loo_rows)
loo_summary <- do.call(rbind, lapply(split(loo, interaction(loo$dataset, loo$gene)), function(z) data.frame(
  dataset = unique(z$dataset), gene = unique(z$gene), omissions = nrow(z),
  minimum_p = min(z$p_value), median_p = median(z$p_value), maximum_p = max(z$p_value),
  proportion_p_lt_0_05 = mean(z$p_value < 0.05), stringsAsFactors = FALSE
)))
centroids <- do.call(rbind, centroid_rows)

concordance_rows <- list()
for (gene in unique(centroids$gene)) {
  z <- centroids[centroids$gene == gene, ]
  w <- reshape(z, idvar = "lineage_common", timevar = "dataset", direction = "wide")
  w <- w[complete.cases(w), ]
  rho <- cor(w$contribution_z.adult, w$contribution_z.pediatric, method = "spearman")
  concordance_rows[[length(concordance_rows) + 1L]] <- data.frame(
    gene = gene, common_lineages = nrow(w), spearman_rho = rho,
    p_value = cor.test(w$contribution_z.adult, w$contribution_z.pediatric,
                       method = "spearman", exact = FALSE)$p.value,
    same_sign_lineages_vs_zero = sum(sign(w$contribution_z.adult) == sign(w$contribution_z.pediatric)),
    stringsAsFactors = FALSE
  )
}
concordance <- do.call(rbind, concordance_rows)

global_rep <- read_tsv("tmm_gene_contribution_replication.tsv")
audit <- merge(global_rep, reshape(loo_summary[, c("dataset", "gene", "proportion_p_lt_0_05")],
                                   idvar = "gene", timevar = "dataset", direction = "wide"),
               by = "gene", all = TRUE)
audit <- merge(audit, concordance, by = "gene", all = TRUE)
names(audit) <- sub("proportion_p_lt_0_05\\.", "loo_proportion_", names(audit))
audit$robust_directionally_concordant_driver <- with(
  audit, replicated & loo_proportion_adult >= 0.80 & loo_proportion_pediatric >= 0.80 &
    spearman_rho > 0 & same_sign_lineages_vs_zero >= 3L
)

write_tsv(coefs, "tmm_gene_lineage_contrast_coefficients.tsv")
write_tsv(loo, "tmm_gene_driver_leave_one_unit_out.tsv")
write_tsv(loo_summary, "tmm_gene_driver_leave_one_unit_out_summary.tsv")
write_tsv(centroids, "tmm_gene_lineage_centroids.tsv")
write_tsv(concordance, "tmm_gene_cross_dataset_concordance.tsv")
write_tsv(audit, "tmm_gene_driver_final_audit.tsv")
capture.output(sessionInfo(), file = file.path(out_dir, "gene_driver_audit_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "genes", "robust_concordant_drivers"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
            length(unique(merged$gene)),
            paste(audit$gene[audit$robust_directionally_concordant_driver], collapse = ";")),
  stringsAsFactors = FALSE
), "gene_driver_audit_status.tsv")


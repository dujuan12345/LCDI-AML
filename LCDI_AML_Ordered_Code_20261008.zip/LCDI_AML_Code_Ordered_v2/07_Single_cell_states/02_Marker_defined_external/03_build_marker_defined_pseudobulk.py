from __future__ import annotations

import argparse
import gzip
import hashlib
import json
import re
import sys
import time
from pathlib import Path

import numpy as np
import pandas as pd


MONO_MARKERS = [
    "CST3", "FCER1G", "S100A11", "LYZ", "CTSS", "S100A8", "S100A9",
    "TYROBP", "MS4A6A", "FCN1", "LGALS1", "PSAP", "ANXA2", "CTSD",
    "LST1", "LGALS3",
]

PROG_MARKERS = [
    "SOX4", "CD99", "CFD", "FOS", "ITM2A", "TMSB10", "SH3BGRL3",
    "MGST1", "MRPL33", "MARCKSL1", "GATA2", "HOPX", "CD34", "SPINK2",
]

TARGET_GENES = ["CASP1", "GPX4"]
LCDI_GENES = {"MPO", "CREB1", "GPX4", "SLC16A4", "CASP1"}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


def gene_vector(frame: pd.DataFrame, gene: str) -> np.ndarray | None:
    idx = np.flatnonzero(frame.index.to_numpy(dtype=str) == gene)
    if idx.size == 0:
        return None
    values = frame.iloc[idx, :].to_numpy(dtype=np.float64, copy=False)
    return values.sum(axis=0)


def marker_score(
    frame: pd.DataFrame,
    markers: list[str],
    qc_cols: np.ndarray,
    library_qc: np.ndarray,
) -> tuple[np.ndarray, list[str], list[str]]:
    z_rows: list[np.ndarray] = []
    used: list[str] = []
    missing: list[str] = []
    for gene in markers:
        raw = gene_vector(frame, gene)
        if raw is None:
            missing.append(gene)
            continue
        expr = np.log1p(raw[qc_cols] / library_qc * 1e4)
        sd = float(expr.std(ddof=1))
        if not np.isfinite(sd) or sd <= 0:
            missing.append(gene + ":zero_variance")
            continue
        z_rows.append((expr - expr.mean()) / sd)
        used.append(gene)
    if len(z_rows) < 5:
        raise RuntimeError(f"Fewer than five usable markers: used={used}; missing={missing}")
    return np.vstack(z_rows).mean(axis=0), used, missing


def sum_selected_columns(values: np.ndarray, columns: np.ndarray, chunk: int = 1000) -> np.ndarray:
    result = np.zeros(values.shape[0], dtype=np.int64)
    for start in range(0, values.shape[0], chunk):
        end = min(start + chunk, values.shape[0])
        result[start:end] = values[start:end, columns].sum(axis=1, dtype=np.int64)
    return result


def main() -> int:
    parser = argparse.ArgumentParser()
    parser.add_argument("--input-dir", required=True)
    parser.add_argument("--clinical-xlsx", required=True)
    parser.add_argument("--output-dir", required=True)
    args = parser.parse_args()

    input_dir = Path(args.input_dir).resolve()
    clinical_xlsx = Path(args.clinical_xlsx).resolve()
    output_dir = Path(args.output_dir).resolve()
    output_dir.mkdir(parents=True, exist_ok=True)

    protected = [
        output_dir / "03_pseudobulk_counts.tsv.gz",
        output_dir / "03_patient_state_qc.tsv",
        output_dir / "03_build_status.tsv",
    ]
    existing = [str(p) for p in protected if p.exists()]
    if existing:
        raise FileExistsError(f"Refusing to overwrite existing formal outputs: {existing}")

    pattern = re.compile(r"^GSM\d+_(P(?:0[1-9]|[1-3]\d|40))_dge\.txt\.gz$")
    matched: list[tuple[str, Path]] = []
    for path in input_dir.glob("*.txt.gz"):
        match = pattern.match(path.name)
        if match:
            matched.append((match.group(1), path))
    matched.sort(key=lambda x: int(x[0][1:]))
    expected = [f"P{i:02d}" for i in range(1, 41)]
    observed = [x[0] for x in matched]
    if observed != expected:
        raise RuntimeError(f"Expected P01-P40 exactly; observed={observed}")

    clinical = pd.read_excel(clinical_xlsx, sheet_name="Supplementary Table 4", header=1)
    clinical = clinical.loc[clinical["Sample ID"].isin(expected)].copy()
    if sorted(clinical["Sample ID"].astype(str).tolist()) != expected:
        raise RuntimeError("Clinical table does not contain P01-P40 exactly once")
    clinical.to_csv(output_dir / "03_clinical_P01_P40.tsv", sep="\t", index=False)

    qc_rows: list[dict[str, object]] = []
    presence_rows: list[dict[str, object]] = []
    source_rows: list[dict[str, object]] = []
    pseudobulk_series: list[pd.Series] = []
    total_start = time.time()

    for index, (patient, path) in enumerate(matched, start=1):
        started = time.time()
        print(f"[{index:02d}/40] reading {patient}: {path.name}", flush=True)
        frame = pd.read_csv(
            path,
            sep="\t",
            index_col=0,
            compression="gzip",
            low_memory=False,
        )
        frame = frame.astype(np.int32, copy=False)
        frame.index = frame.index.astype(str)
        genes = frame.index.to_numpy(dtype=str)
        if frame.index.duplicated().any():
            raise RuntimeError(f"Duplicate gene symbols in {path.name}")

        values = frame.to_numpy(dtype=np.int32, copy=False)
        library = values.sum(axis=0, dtype=np.int64)
        detected = (values > 0).sum(axis=0, dtype=np.int32)
        mt_mask = np.char.startswith(genes.astype(str), "MT-")
        mt_counts = values[mt_mask, :].sum(axis=0, dtype=np.int64) if mt_mask.any() else np.zeros(values.shape[1], dtype=np.int64)
        mt_fraction = np.divide(mt_counts, library, out=np.zeros_like(mt_counts, dtype=float), where=library > 0)
        qc = (library >= 500) & (detected >= 200) & (mt_fraction < 0.20)
        qc_cols = np.flatnonzero(qc)
        if qc_cols.size < 80:
            raise RuntimeError(f"{patient} has fewer than 80 QC cells")
        library_qc = library[qc_cols].astype(float)

        mono_score, mono_used, mono_missing = marker_score(frame, MONO_MARKERS, qc_cols, library_qc)
        prog_score, prog_used, prog_missing = marker_score(frame, PROG_MARKERS, qc_cols, library_qc)
        delta = mono_score - prog_score
        q25, q75 = np.quantile(delta, [0.25, 0.75])
        prog_local = np.flatnonzero(delta <= q25)
        mono_local = np.flatnonzero(delta >= q75)
        prog_cols = qc_cols[prog_local]
        mono_cols = qc_cols[mono_local]
        if min(prog_cols.size, mono_cols.size) < 20:
            raise RuntimeError(f"{patient} has fewer than 20 cells in a state extreme")

        prog_sum = sum_selected_columns(values, prog_cols)
        mono_sum = sum_selected_columns(values, mono_cols)
        pseudobulk_series.extend([
            pd.Series(prog_sum, index=genes, name=f"{patient}__Progenitor_like", dtype=np.int64),
            pd.Series(mono_sum, index=genes, name=f"{patient}__Monocytic_like", dtype=np.int64),
        ])

        qc_rows.append(
            {
                "patient": patient,
                "cells_input": int(values.shape[1]),
                "cells_qc": int(qc_cols.size),
                "cells_progenitor_extreme": int(prog_cols.size),
                "cells_monocytic_extreme": int(mono_cols.size),
                "q25_delta": float(q25),
                "q75_delta": float(q75),
                "median_library_input": float(np.median(library)),
                "median_library_qc": float(np.median(library[qc])),
                "median_detected_genes_qc": float(np.median(detected[qc])),
                "max_mt_fraction_qc": float(mt_fraction[qc].max()),
                "mono_markers_used": ";".join(mono_used),
                "prog_markers_used": ";".join(prog_used),
                "mono_markers_missing": ";".join(mono_missing),
                "prog_markers_missing": ";".join(prog_missing),
                "duplicate_gene_rows": int(frame.index.duplicated().sum()),
                "elapsed_seconds": round(time.time() - started, 3),
            }
        )
        all_markers = MONO_MARKERS + PROG_MARKERS + TARGET_GENES + sorted(LCDI_GENES)
        for gene in sorted(set(all_markers)):
            presence_rows.append({"patient": patient, "gene": gene, "present": bool((genes == gene).any())})
        source_rows.append(
            {
                "patient": patient,
                "file": str(path),
                "bytes": path.stat().st_size,
                "sha256": sha256(path),
            }
        )
        print(
            f"[{index:02d}/40] {patient} input={values.shape[1]} qc={qc_cols.size} "
            f"prog={prog_cols.size} mono={mono_cols.size} elapsed={time.time()-started:.1f}s",
            flush=True,
        )
        del frame, values

    if not pseudobulk_series:
        raise RuntimeError("No matrices processed")
    pb_frame = pd.concat(pseudobulk_series, axis=1, join="outer").fillna(0).astype(np.int64)
    pb_frame = pb_frame.sort_index()
    pb_frame.index.name = "gene"
    pb_frame.to_csv(output_dir / "03_pseudobulk_counts.tsv.gz", sep="\t", compression="gzip")
    pd.DataFrame(qc_rows).to_csv(output_dir / "03_patient_state_qc.tsv", sep="\t", index=False)
    pd.DataFrame(presence_rows).to_csv(output_dir / "03_gene_presence.tsv", sep="\t", index=False)
    pd.DataFrame(source_rows).to_csv(output_dir / "03_source_files.tsv", sep="\t", index=False)

    summary = {
        "status": "passed",
        "patients": 40,
        "genes": int(pb_frame.shape[0]),
        "pseudobulk_samples": int(pb_frame.shape[1]),
        "cells_input": int(sum(row["cells_input"] for row in qc_rows)),
        "cells_qc": int(sum(row["cells_qc"] for row in qc_rows)),
        "mono_markers": MONO_MARKERS,
        "prog_markers": PROG_MARKERS,
        "target_genes": TARGET_GENES,
        "lcdi_genes_excluded_from_annotation": sorted(LCDI_GENES),
        "elapsed_seconds": round(time.time() - total_start, 3),
        "python": sys.version,
        "numpy": np.__version__,
        "pandas": pd.__version__,
    }
    (output_dir / "03_build_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    pd.DataFrame([{"status": "passed", **{k: v for k, v in summary.items() if not isinstance(v, list)}}]).to_csv(
        output_dir / "03_build_status.tsv", sep="\t", index=False
    )
    print(json.dumps(summary, ensure_ascii=False, indent=2), flush=True)
    return 0


if __name__ == "__main__":
    raise SystemExit(main())

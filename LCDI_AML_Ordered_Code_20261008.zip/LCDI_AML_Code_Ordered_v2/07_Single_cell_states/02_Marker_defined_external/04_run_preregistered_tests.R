options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(edgeR)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: Rscript 04_run_preregistered_tests.R <output_dir>")
out_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)

protected <- file.path(out_dir, c(
  "04_target_gene_results.tsv",
  "04_target_logcpm_by_patient_state.tsv",
  "04_bootstrap_replicates.tsv",
  "04_test_status.tsv"
))
if (any(file.exists(protected))) stop("Refusing to overwrite existing formal test outputs")

count_path <- file.path(out_dir, "03_pseudobulk_counts.tsv.gz")
qc_path <- file.path(out_dir, "03_patient_state_qc.tsv")
stopifnot(file.exists(count_path), file.exists(qc_path))

dat <- read.delim(gzfile(count_path), check.names = FALSE, row.names = 1)
counts <- as.matrix(dat)
storage.mode(counts) <- "integer"

sample_names <- colnames(counts)
parts <- strsplit(sample_names, "__", fixed = TRUE)
meta <- data.frame(
  sample = sample_names,
  patient = vapply(parts, `[`, character(1), 1),
  state = vapply(parts, `[`, character(1), 2),
  stringsAsFactors = FALSE
)
meta$state <- factor(meta$state, levels = c("Progenitor_like", "Monocytic_like"))
meta$patient <- factor(meta$patient, levels = sprintf("P%02d", 1:40))
if (nrow(meta) != 80L || any(table(meta$patient, meta$state) != 1L)) {
  stop("Expected exactly one sample per patient-state combination")
}

keep <- rowSums(counts >= 5L) >= 4L
dge <- DGEList(counts = counts[keep, , drop = FALSE], samples = meta)
dge <- calcNormFactors(dge, method = "TMM")
logcpm_tmm <- cpm(dge, log = TRUE, prior.count = 0.5)

dge_cpm <- DGEList(counts = counts[keep, , drop = FALSE], samples = meta)
dge_cpm$samples$norm.factors <- 1
logcpm_cpm <- cpm(dge_cpm, log = TRUE, prior.count = 0.5)

targets <- c("CASP1", "GPX4")
if (!all(targets %in% rownames(logcpm_tmm))) stop("CASP1 or GPX4 absent after expression filter")

design <- model.matrix(~ patient + state, data = meta)
coef_name <- "stateMonocytic_like"
if (!coef_name %in% colnames(design)) stop("State coefficient missing")

analyze_one <- function(gene, expr, method, seed_offset = 0L) {
  y <- as.numeric(expr[gene, ])
  fit <- lm.fit(design, y)
  df_res <- nrow(design) - fit$rank
  rss <- sum(fit$residuals^2)
  sigma2 <- rss / df_res
  xtx_inv <- chol2inv(qr.R(qr(design)))
  idx <- match(coef_name, colnames(design))
  beta <- unname(fit$coefficients[idx])
  se <- sqrt(sigma2 * xtx_inv[idx, idx])
  tval <- beta / se
  p_lm <- 2 * pt(abs(tval), df = df_res, lower.tail = FALSE)

  wide <- reshape(
    data.frame(patient = as.character(meta$patient), state = as.character(meta$state), value = y),
    idvar = "patient", timevar = "state", direction = "wide"
  )
  wide <- wide[order(wide$patient), ]
  diff <- wide$value.Monocytic_like - wide$value.Progenitor_like
  wt <- suppressWarnings(wilcox.test(diff, mu = 0, paired = FALSE, exact = FALSE, conf.int = FALSE))

  set.seed(20260825L + seed_offset)
  boot <- replicate(2000L, mean(sample(diff, length(diff), replace = TRUE)))
  ci <- as.numeric(quantile(boot, c(0.025, 0.975), names = FALSE, type = 7))

  loo_beta <- numeric(length(diff))
  loo_p <- numeric(length(diff))
  for (i in seq_along(diff)) {
    kept_patients <- wide$patient[-i]
    use <- as.character(meta$patient) %in% kept_patients
    d2 <- droplevels(meta[use, ])
    x2 <- model.matrix(~ patient + state, data = d2)
    f2 <- lm(as.numeric(expr[gene, use]) ~ patient + state, data = d2)
    sm2 <- summary(f2)$coefficients
    loo_beta[i] <- sm2["stateMonocytic_like", "Estimate"]
    loo_p[i] <- sm2["stateMonocytic_like", "Pr(>|t|)"]
  }

  list(
    result = data.frame(
      gene = gene,
      method = method,
      n_patients = length(diff),
      mean_progenitor_logcpm = mean(wide$value.Progenitor_like),
      mean_monocytic_logcpm = mean(wide$value.Monocytic_like),
      mean_paired_difference = mean(diff),
      median_paired_difference = median(diff),
      state_beta = beta,
      state_se = se,
      state_t = tval,
      state_df = df_res,
      state_p = p_lm,
      wilcoxon_p = wt$p.value,
      bootstrap_ci_low = ci[1],
      bootstrap_ci_high = ci[2],
      loo_direction_positive_fraction = mean(loo_beta > 0),
      loo_p_lt_0_05_fraction = mean(loo_p < 0.05),
      direction = ifelse(beta > 0, "Monocytic_higher", "Progenitor_higher"),
      stringsAsFactors = FALSE
    ),
    expression = data.frame(
      gene = gene,
      method = method,
      patient = wide$patient,
      progenitor_logcpm = wide$value.Progenitor_like,
      monocytic_logcpm = wide$value.Monocytic_like,
      paired_difference = diff,
      stringsAsFactors = FALSE
    ),
    bootstrap = data.frame(
      gene = gene,
      method = method,
      iteration = seq_along(boot),
      mean_paired_difference = boot,
      stringsAsFactors = FALSE
    ),
    loo = data.frame(
      gene = gene,
      method = method,
      omitted_patient = wide$patient,
      state_beta = loo_beta,
      state_p = loo_p,
      stringsAsFactors = FALSE
    )
  )
}

all <- list()
counter <- 0L
for (method in c("TMM", "CPM")) {
  expr <- if (method == "TMM") logcpm_tmm else logcpm_cpm
  for (gene in targets) {
    counter <- counter + 1L
    all[[paste(method, gene, sep = "_")]] <- analyze_one(gene, expr, method, counter)
  }
}

results <- do.call(rbind, lapply(all, `[[`, "result"))
rownames(results) <- NULL
for (method in unique(results$method)) {
  ii <- which(results$method == method)
  results$state_fdr_bh[ii] <- p.adjust(results$state_p[ii], method = "BH")
}
results$primary_gate_pass <- with(results,
  gene == "CASP1" & method == "TMM" & n_patients >= 8 &
    direction == "Monocytic_higher" & state_p < 0.05 &
    bootstrap_ci_low > 0 & loo_direction_positive_fraction >= 0.80
)

expression <- do.call(rbind, lapply(all, `[[`, "expression"))
bootstrap <- do.call(rbind, lapply(all, `[[`, "bootstrap"))
loo <- do.call(rbind, lapply(all, `[[`, "loo"))
norm_factors <- data.frame(
  sample = sample_names,
  patient = as.character(meta$patient),
  state = as.character(meta$state),
  library_size = dge$samples$lib.size,
  tmm_norm_factor = dge$samples$norm.factors,
  effective_library_size = dge$samples$lib.size * dge$samples$norm.factors,
  stringsAsFactors = FALSE
)

write.table(results, file.path(out_dir, "04_target_gene_results.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(expression, file.path(out_dir, "04_target_logcpm_by_patient_state.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(bootstrap, file.path(out_dir, "04_bootstrap_replicates.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(loo, file.path(out_dir, "04_leave_one_patient_out.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(norm_factors, file.path(out_dir, "04_tmm_normalization_factors.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
saveRDS(list(dge = dge, logcpm_tmm = logcpm_tmm, logcpm_cpm = logcpm_cpm, meta = meta), file.path(out_dir, "04_tmm_target_analysis.rds"))

status <- data.frame(
  status = "passed",
  genes_input = nrow(counts),
  genes_kept = sum(keep),
  patients = nlevels(meta$patient),
  pseudobulk_samples = nrow(meta),
  edgeR = as.character(packageVersion("edgeR")),
  R = as.character(getRversion()),
  stringsAsFactors = FALSE
)
write.table(status, file.path(out_dir, "04_test_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
print(results)
print(status)


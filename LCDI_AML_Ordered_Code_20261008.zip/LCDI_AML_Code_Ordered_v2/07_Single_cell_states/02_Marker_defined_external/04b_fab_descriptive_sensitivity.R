options(stringsAsFactors = FALSE, warn = 1)

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: Rscript 04b_fab_descriptive_sensitivity.R <output_dir>")
out_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_path <- file.path(out_dir, "04b_fab_descriptive_sensitivity.tsv")
if (file.exists(out_path)) stop("Refusing to overwrite existing FAB sensitivity output")

expr <- read.delim(file.path(out_dir, "04_target_logcpm_by_patient_state.tsv"))
expr <- expr[expr$method == "TMM", ]
clinical <- read.delim(file.path(out_dir, "03_clinical_P01_P40.tsv"), check.names = FALSE)
clinical$patient <- clinical$`Sample ID`
clinical$fab_group <- ifelse(clinical$`FAB subtype` == "M5", "M5", "Non-M5")

d <- merge(expr, clinical[, c("patient", "FAB subtype", "fab_group")], by = "patient", all.x = TRUE)
if (anyNA(d$fab_group)) stop("Missing FAB group after merge")

rows <- list()
for (gene in c("CASP1", "GPX4")) {
  dg <- d[d$gene == gene, ]
  between <- suppressWarnings(wilcox.test(paired_difference ~ fab_group, data = dg, exact = FALSE))$p.value
  for (group in c("M5", "Non-M5", "All")) {
    x <- if (group == "All") dg$paired_difference else dg$paired_difference[dg$fab_group == group]
    within <- suppressWarnings(wilcox.test(x, mu = 0, exact = FALSE))$p.value
    rows[[length(rows) + 1L]] <- data.frame(
      gene = gene,
      fab_group = group,
      n_patients = length(x),
      mean_paired_difference = mean(x),
      median_paired_difference = median(x),
      positive_fraction = mean(x > 0),
      within_group_wilcoxon_p = within,
      m5_vs_nonm5_wilcoxon_p = between,
      stringsAsFactors = FALSE
    )
  }
}
out <- do.call(rbind, rows)
write.table(out, out_path, sep = "\t", quote = FALSE, row.names = FALSE)
write.table(data.frame(status = "passed", rows = nrow(out)), file.path(out_dir, "04b_fab_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
print(out)


options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 03_load_gate_and_build_pseudobulk.R <input_rds_gz> <output_dir>")
input_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)

protected <- file.path(out_dir, c(
  "03_object_gate_status.tsv",
  "03_pseudobulk_all_diagnosis.rds",
  "03_pseudobulk_mutant_positive.rds"
))
if (any(file.exists(protected))) stop("Refusing to overwrite existing formal object-gate outputs")

status_path <- file.path(out_dir, "03_object_gate_status.tsv")
start_time <- Sys.time()

write_status <- function(status, message, extra = list()) {
  row <- data.frame(status = status, message = message, stringsAsFactors = FALSE)
  for (nm in names(extra)) row[[nm]] <- extra[[nm]]
  write.table(row, status_path, sep = "\t", quote = FALSE, row.names = FALSE)
}

get_counts <- function(obj) {
  assay <- obj[["RNA"]]
  if (inherits(assay, "Assay5")) {
    layers <- Layers(assay, search = "^counts")
    if (length(layers) != 1L) stop("RNA Assay5 must contain exactly one counts layer; observed: ", paste(layers, collapse = ";"))
    return(LayerData(assay, layer = layers[[1]]))
  }
  GetAssayData(obj, assay = "RNA", layer = "counts")
}

build_pseudobulk <- function(counts, meta, mask, layer_name, minimum_patients) {
  m <- meta[mask, , drop = FALSE]
  if (nrow(m) == 0L) {
    tab <- data.frame(donor.id = character(), GMP = integer(), Mono = integer(), eligible = logical(),
                      stringsAsFactors = FALSE)
    write.table(tab, file.path(out_dir, paste0("03_patient_state_counts_", layer_name, ".tsv")),
                sep = "\t", quote = FALSE, row.names = FALSE)
    summary <- data.frame(layer = layer_name, cells_candidate = 0L, patients_candidate = 0L,
                          patients_eligible = 0L, minimum_patients = minimum_patients,
                          gate_pass = FALSE, stringsAsFactors = FALSE)
    return(list(summary = summary, object = NULL, cell_meta = NULL))
  }
  m$state <- ifelse(m$manual_annotation_v3_l3_final == "GMP", "GMP", "Mono")
  tab <- as.data.frame.matrix(table(m$donor.id, m$state))
  if (!"GMP" %in% colnames(tab)) tab$GMP <- 0L
  if (!"Mono" %in% colnames(tab)) tab$Mono <- 0L
  tab$donor.id <- rownames(tab)
  rownames(tab) <- NULL
  tab <- tab[, c("donor.id", "GMP", "Mono")]
  tab$eligible <- tab$GMP >= 20L & tab$Mono >= 20L
  write.table(tab, file.path(out_dir, paste0("03_patient_state_counts_", layer_name, ".tsv")), sep = "\t", quote = FALSE, row.names = FALSE)

  eligible <- tab$donor.id[tab$eligible]
  summary <- data.frame(
    layer = layer_name,
    cells_candidate = nrow(m),
    patients_candidate = length(unique(m$donor.id)),
    patients_eligible = length(eligible),
    minimum_patients = minimum_patients,
    gate_pass = length(eligible) >= minimum_patients,
    stringsAsFactors = FALSE
  )
  if (!summary$gate_pass) return(list(summary = summary, object = NULL, cell_meta = NULL))

  m <- m[m$donor.id %in% eligible, , drop = FALSE]
  cell_names <- rownames(m)
  idx <- match(cell_names, colnames(counts))
  if (anyNA(idx)) stop("Metadata cells missing from counts in layer ", layer_name)
  group <- paste(m$donor.id, m$state, sep = "__")
  group_levels <- as.vector(t(outer(sort(eligible), c("GMP", "Mono"), paste, sep = "__")))
  group_levels <- group_levels[group_levels %in% unique(group)]
  group_factor <- factor(group, levels = group_levels)
  design <- sparseMatrix(i = seq_along(group_factor), j = as.integer(group_factor), x = 1,
                         dims = c(length(group_factor), length(group_levels)),
                         dimnames = list(cell_names, group_levels))
  pb <- counts[, idx, drop = FALSE] %*% design
  sample_meta <- data.frame(
    sample = colnames(pb),
    donor.id = sub("__(GMP|Mono)$", "", colnames(pb)),
    state = sub("^.*__", "", colnames(pb)),
    stringsAsFactors = FALSE
  )
  rownames(sample_meta) <- sample_meta$sample
  cell_meta <- data.frame(
    cell = rownames(m),
    donor.id = m$donor.id,
    annotation = m$manual_annotation_v3_l3_final,
    state = m$state,
    mutant_positive = m$mutant_positive,
    stringsAsFactors = FALSE
  )
  list(summary = summary, object = list(counts = pb, sample_meta = sample_meta), cell_meta = cell_meta)
}

result <- tryCatch({
  cat("Loading object:", input_path, "\n")
  outer_con <- gzfile(input_path, open = "rb")
  inner_con <- gzcon(outer_con)
  obj <- readRDS(inner_con)
  close(inner_con)
  cat("Object loaded\n")
  if (!inherits(obj, "Seurat")) stop("Input is not a Seurat object: ", paste(class(obj), collapse = ";"))
  required_assay <- "RNA"
  if (!required_assay %in% Assays(obj)) stop("RNA assay missing")

  meta <- obj[[]]
  write.table(data.frame(column = colnames(meta), stringsAsFactors = FALSE),
              file.path(out_dir, "03_metadata_columns.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  candidate_fields <- grep("disease|diagn|stage|sample|origin|source|institute|cohort|condition", colnames(meta),
                           ignore.case = TRUE, value = TRUE)
  candidate_rows <- list()
  for (nm in candidate_fields) {
    vals <- as.character(meta[[nm]])
    if (length(unique(vals[!is.na(vals)])) <= 100L) {
      tt <- as.data.frame(table(vals, useNA = "ifany"), stringsAsFactors = FALSE)
      colnames(tt) <- c("value", "count")
      tt$field <- nm
      candidate_rows[[length(candidate_rows) + 1L]] <- tt[, c("field", "value", "count")]
    }
  }
  if (length(candidate_rows)) {
    write.table(do.call(rbind, candidate_rows), file.path(out_dir, "03_candidate_metadata_value_counts.tsv"),
                sep = "\t", quote = FALSE, row.names = FALSE)
  }
  required_fields <- c("manual_annotation_v3_l3_final", "donor.id", "stage_simple", "disease", "institute")
  missing_fields <- setdiff(required_fields, colnames(meta))
  if (length(missing_fields)) stop("Required metadata fields missing: ", paste(missing_fields, collapse = ";"))

  write.table(as.data.frame(table(meta$manual_annotation_v3_l3_final, useNA = "ifany")),
              file.path(out_dir, "03_annotation_counts_all_object.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  write.table(as.data.frame(table(meta$stage_simple, useNA = "ifany")),
              file.path(out_dir, "03_stage_counts.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  write.table(as.data.frame(table(meta$institute, meta$disease, useNA = "ifany")),
              file.path(out_dir, "03_disease_source_counts.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

  counts <- get_counts(obj)
  if (!inherits(counts, "sparseMatrix")) stop("RNA counts are not sparseMatrix")
  if (!identical(colnames(counts), rownames(meta))) stop("Counts columns and metadata rownames are not identical")
  if (!all(c("CASP1", "GPX4") %in% rownames(counts))) stop("CASP1 or GPX4 missing from RNA counts")

  mut_fields <- intersect(c("IDH2_R140", "IDH2_R172", "NRAS_G12", "NPM1_W288", "SRSF2_P95", "IDH1_R132"), colnames(meta))
  if (length(mut_fields)) {
    mt_mat <- vapply(mut_fields, function(nm) as.character(meta[[nm]]) == "MT", logical(nrow(meta)))
    if (is.null(dim(mt_mat))) mt_mat <- matrix(mt_mat, ncol = 1L)
    mutant_positive <- rowSums(mt_mat, na.rm = TRUE) > 0L
  } else {
    mutant_positive <- rep(FALSE, nrow(meta))
  }
  abnormal_clones <- c("gain_10", "gain_14", "gain_1q_8", "gain_6_10", "gain_8")
  if ("clone" %in% colnames(meta)) mutant_positive <- mutant_positive | as.character(meta$clone) %in% abnormal_clones
  meta$mutant_positive <- mutant_positive

  diagnosis_aml <- as.character(meta$stage_simple) == "diagnosis" &
    as.character(meta$disease) == "AML" & as.character(meta$institute) %in% c("NYU", "MSK")
  primary_labels <- as.character(meta$manual_annotation_v3_l3_final) %in% c("GMP", "CD14+ Mono", "CD16+ Mono")
  all_mask <- diagnosis_aml & primary_labels
  mutant_mask <- all_mask & meta$mutant_positive

  all_result <- build_pseudobulk(counts, meta, all_mask, "all_diagnosis", 8L)
  mut_result <- build_pseudobulk(counts, meta, mutant_mask, "mutant_positive", 4L)
  summaries <- rbind(all_result$summary, mut_result$summary)
  write.table(summaries, file.path(out_dir, "03_layer_gate_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

  if (is.null(all_result$object)) stop("All-diagnosis layer failed minimum paired-patient gate")
  saveRDS(all_result$object, file.path(out_dir, "03_pseudobulk_all_diagnosis.rds"), compress = "xz")
  con_all <- gzfile(file.path(out_dir, "03_selected_cell_metadata_all_diagnosis.tsv.gz"), open = "wt")
  write.table(all_result$cell_meta, con_all, sep = "\t", quote = FALSE, row.names = FALSE)
  close(con_all)
  if (!is.null(mut_result$object)) {
    saveRDS(mut_result$object, file.path(out_dir, "03_pseudobulk_mutant_positive.rds"), compress = "xz")
    con_mut <- gzfile(file.path(out_dir, "03_selected_cell_metadata_mutant_positive.tsv.gz"), open = "wt")
    write.table(mut_result$cell_meta, con_mut, sep = "\t", quote = FALSE, row.names = FALSE)
    close(con_mut)
  }

  target_rows <- match(c("CASP1", "GPX4"), rownames(all_result$object$counts))
  target_counts <- as.data.frame(as.matrix(all_result$object$counts[target_rows, , drop = FALSE]))
  target_counts$gene <- rownames(target_counts)
  target_counts <- target_counts[, c("gene", setdiff(colnames(target_counts), "gene"))]
  write.table(target_counts, file.path(out_dir, "03_target_raw_counts_all_diagnosis.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)

  object_summary <- data.frame(
    class = paste(class(obj), collapse = ";"),
    genes = nrow(obj),
    cells = ncol(obj),
    assays = paste(Assays(obj), collapse = ";"),
    metadata_columns = ncol(meta),
    object_size_bytes = as.numeric(object.size(obj)),
    mutation_fields_present = paste(mut_fields, collapse = ";"),
    clone_field_present = "clone" %in% colnames(meta),
    diagnosis_aml_cells = sum(diagnosis_aml),
    primary_label_cells = sum(all_mask),
    mutant_primary_label_cells = sum(mutant_mask),
    elapsed_seconds = as.numeric(difftime(Sys.time(), start_time, units = "secs")),
    R = as.character(getRversion()),
    Seurat = as.character(packageVersion("Seurat")),
    Matrix = as.character(packageVersion("Matrix")),
    stringsAsFactors = FALSE
  )
  write.table(object_summary, file.path(out_dir, "03_object_summary.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
  capture.output(sessionInfo(), file = file.path(out_dir, "03_sessionInfo.txt"))
  write_status("passed", "Object fields and all-diagnosis pseudobulk gate passed",
               list(cells = ncol(obj), genes = nrow(obj), eligible_all = all_result$summary$patients_eligible,
                    eligible_mutant = mut_result$summary$patients_eligible,
                    mutant_gate_pass = mut_result$summary$gate_pass))
  cat("Formal object gate passed\n")
  print(object_summary)
  print(summaries)
  rm(obj, counts)
  gc()
  TRUE
}, error = function(e) {
  message("FAILED: ", conditionMessage(e))
  write_status("failed", conditionMessage(e))
  FALSE
})

if (!isTRUE(result)) quit(status = 1L)

options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(edgeR)
  library(Matrix)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: Rscript 04_run_author_label_tests.R <output_dir>")
out_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)

protected <- file.path(out_dir, c(
  "04_author_label_target_results.tsv",
  "04_author_label_expression_by_patient.tsv",
  "04_author_label_test_status.tsv"
))
if (any(file.exists(protected))) stop("Refusing to overwrite existing formal author-label outputs")

pb_path <- file.path(out_dir, "03_pseudobulk_all_diagnosis.rds")
if (!file.exists(pb_path)) stop("Missing all-diagnosis pseudobulk RDS")
pb <- readRDS(pb_path)
counts <- pb$counts
meta <- pb$sample_meta
if (nrow(meta) != ncol(counts) || !identical(rownames(meta), colnames(counts))) stop("Counts/sample metadata mismatch")
meta$state <- factor(meta$state, levels = c("GMP", "Mono"))
meta$donor.id <- factor(meta$donor.id)
if (any(table(meta$donor.id, meta$state) != 1L)) stop("Expected one GMP and one Mono pseudobulk per donor")

keep <- rowSums(counts >= 5L) >= 4L
dge <- DGEList(counts = counts[keep, , drop = FALSE], samples = meta)
dge <- calcNormFactors(dge, method = "TMM")
logcpm_tmm <- cpm(dge, log = TRUE, prior.count = 0.5)
dge_cpm <- DGEList(counts = counts[keep, , drop = FALSE], samples = meta)
dge_cpm$samples$norm.factors <- 1
logcpm_cpm <- cpm(dge_cpm, log = TRUE, prior.count = 0.5)

targets <- c("CASP1", "GPX4")
if (!all(targets %in% rownames(logcpm_tmm))) stop("CASP1 or GPX4 absent after filtering")

analyze_one <- function(gene, expr, method, seed_offset) {
  df <- data.frame(
    donor.id = meta$donor.id,
    state = meta$state,
    value = as.numeric(expr[gene, ]),
    stringsAsFactors = FALSE
  )
  fit <- lm(value ~ donor.id + state, data = df)
  coef_tab <- summary(fit)$coefficients
  beta <- coef_tab["stateMono", "Estimate"]
  se <- coef_tab["stateMono", "Std. Error"]
  tval <- coef_tab["stateMono", "t value"]
  pval <- coef_tab["stateMono", "Pr(>|t|)"]
  df_res <- df.residual(fit)

  wide <- reshape(df, idvar = "donor.id", timevar = "state", direction = "wide")
  wide <- wide[order(wide$donor.id), ]
  diff <- wide$value.Mono - wide$value.GMP
  wt <- suppressWarnings(wilcox.test(diff, mu = 0, exact = FALSE))
  set.seed(20260825L + seed_offset)
  boot <- replicate(2000L, mean(sample(diff, length(diff), replace = TRUE)))
  ci <- as.numeric(quantile(boot, c(0.025, 0.975), names = FALSE, type = 7))

  loo_beta <- numeric(length(diff))
  loo_p <- numeric(length(diff))
  for (i in seq_along(diff)) {
    use <- as.character(df$donor.id) != as.character(wide$donor.id[i])
    d2 <- droplevels(df[use, ])
    f2 <- lm(value ~ donor.id + state, data = d2)
    sm2 <- summary(f2)$coefficients
    loo_beta[i] <- sm2["stateMono", "Estimate"]
    loo_p[i] <- sm2["stateMono", "Pr(>|t|)"]
  }

  list(
    result = data.frame(
      gene = gene,
      method = method,
      n_patients = length(diff),
      mean_gmp_logcpm = mean(wide$value.GMP),
      mean_mono_logcpm = mean(wide$value.Mono),
      mean_paired_difference = mean(diff),
      median_paired_difference = median(diff),
      positive_patients = sum(diff > 0),
      negative_patients = sum(diff < 0),
      state_beta = beta,
      state_se = se,
      state_t = tval,
      state_df = df_res,
      state_p = pval,
      wilcoxon_p = wt$p.value,
      bootstrap_ci_low = ci[1],
      bootstrap_ci_high = ci[2],
      loo_direction_positive_fraction = mean(loo_beta > 0),
      loo_p_lt_0_05_fraction = mean(loo_p < 0.05),
      direction = ifelse(beta > 0, "Mono_higher", "GMP_higher"),
      stringsAsFactors = FALSE
    ),
    expression = data.frame(
      gene = gene,
      method = method,
      donor.id = as.character(wide$donor.id),
      gmp_logcpm = wide$value.GMP,
      mono_logcpm = wide$value.Mono,
      paired_difference = diff,
      stringsAsFactors = FALSE
    ),
    bootstrap = data.frame(gene = gene, method = method, iteration = seq_along(boot),
                           mean_paired_difference = boot, stringsAsFactors = FALSE),
    loo = data.frame(gene = gene, method = method, omitted_patient = as.character(wide$donor.id),
                     state_beta = loo_beta, state_p = loo_p, stringsAsFactors = FALSE)
  )
}

all <- list()
counter <- 0L
for (method in c("TMM", "CPM")) {
  expr <- if (method == "TMM") logcpm_tmm else logcpm_cpm
  for (gene in targets) {
    counter <- counter + 1L
    all[[paste(method, gene, sep = "_")]] <- analyze_one(gene, expr, method, counter)
  }
}

results <- do.call(rbind, lapply(all, `[[`, "result"))
rownames(results) <- NULL
for (method in unique(results$method)) {
  ii <- which(results$method == method)
  results$state_fdr_bh[ii] <- p.adjust(results$state_p[ii], method = "BH")
}
results$primary_gate_pass <- with(results,
  gene == "CASP1" & method == "TMM" & n_patients >= 8 & direction == "Mono_higher" &
    state_p < 0.05 & bootstrap_ci_low > 0 & loo_direction_positive_fraction >= 0.80
)

expression <- do.call(rbind, lapply(all, `[[`, "expression"))
bootstrap <- do.call(rbind, lapply(all, `[[`, "bootstrap"))
loo <- do.call(rbind, lapply(all, `[[`, "loo"))
norm_factors <- data.frame(
  sample = colnames(counts),
  donor.id = as.character(meta$donor.id),
  state = as.character(meta$state),
  library_size = dge$samples$lib.size,
  tmm_norm_factor = dge$samples$norm.factors,
  effective_library_size = dge$samples$lib.size * dge$samples$norm.factors,
  stringsAsFactors = FALSE
)

write.table(results, file.path(out_dir, "04_author_label_target_results.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(expression, file.path(out_dir, "04_author_label_expression_by_patient.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(bootstrap, file.path(out_dir, "04_author_label_bootstrap.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(loo, file.path(out_dir, "04_author_label_loo.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(norm_factors, file.path(out_dir, "04_author_label_tmm_factors.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
saveRDS(list(dge = dge, logcpm_tmm = logcpm_tmm, logcpm_cpm = logcpm_cpm, meta = meta),
        file.path(out_dir, "04_author_label_analysis.rds"), compress = "xz")

status <- data.frame(
  status = "passed",
  patients = nlevels(meta$donor.id),
  pseudobulk_samples = nrow(meta),
  genes_input = nrow(counts),
  genes_kept = sum(keep),
  CASP1_primary_gate = results$primary_gate_pass[results$gene == "CASP1" & results$method == "TMM"],
  R = as.character(getRversion()),
  edgeR = as.character(packageVersion("edgeR")),
  stringsAsFactors = FALSE
)
write.table(status, file.path(out_dir, "04_author_label_test_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
print(results)
print(status)

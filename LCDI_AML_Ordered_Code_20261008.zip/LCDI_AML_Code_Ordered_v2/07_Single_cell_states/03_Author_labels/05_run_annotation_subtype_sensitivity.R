options(stringsAsFactors = FALSE, warn = 1)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
  library(edgeR)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 05_run_annotation_subtype_sensitivity.R <input_rds_gz> <output_dir>")
input_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)

protected <- file.path(out_dir, c("05_annotation_subtype_results.tsv", "05_annotation_subtype_status.tsv"))
if (any(file.exists(protected))) stop("Refusing to overwrite existing subtype sensitivity outputs")

get_counts <- function(obj) {
  assay <- obj[["RNA"]]
  if (inherits(assay, "Assay5")) {
    layers <- Layers(assay, search = "^counts")
    if (length(layers) != 1L) stop("Expected one RNA counts layer")
    return(LayerData(assay, layer = layers[[1]]))
  }
  GetAssayData(obj, assay = "RNA", layer = "counts")
}

analyze_pair <- function(counts, meta, target_label, comparison_name) {
  use0 <- as.character(meta$stage_simple) == "diagnosis" & as.character(meta$disease) == "AML" &
    as.character(meta$institute) %in% c("MSK", "NYU") &
    as.character(meta$manual_annotation_v3_l3_final) %in% c("GMP", target_label)
  m <- meta[use0, , drop = FALSE]
  m$state <- ifelse(as.character(m$manual_annotation_v3_l3_final) == "GMP", "GMP", "MonoSubtype")
  tab <- as.data.frame.matrix(table(m$donor.id, m$state))
  if (!"GMP" %in% colnames(tab)) tab$GMP <- 0L
  if (!"MonoSubtype" %in% colnames(tab)) tab$MonoSubtype <- 0L
  tab$donor.id <- rownames(tab)
  rownames(tab) <- NULL
  tab <- tab[, c("donor.id", "GMP", "MonoSubtype")]
  tab$comparison <- comparison_name
  tab$target_label <- target_label
  tab$eligible <- tab$GMP >= 20L & tab$MonoSubtype >= 20L
  eligible <- tab$donor.id[tab$eligible]
  if (length(eligible) < 4L) return(list(counts = tab, results = NULL))

  m <- m[m$donor.id %in% eligible, , drop = FALSE]
  cells <- rownames(m)
  idx <- match(cells, colnames(counts))
  if (anyNA(idx)) stop("Cell/count mismatch in ", comparison_name)
  groups <- paste(m$donor.id, m$state, sep = "__")
  levels_use <- as.vector(t(outer(sort(eligible), c("GMP", "MonoSubtype"), paste, sep = "__")))
  design <- sparseMatrix(i = seq_along(groups), j = as.integer(factor(groups, levels = levels_use)), x = 1,
                         dims = c(length(groups), length(levels_use)), dimnames = list(cells, levels_use))
  pb <- counts[, idx, drop = FALSE] %*% design
  sm <- data.frame(
    sample = colnames(pb),
    donor.id = factor(sub("__(GMP|MonoSubtype)$", "", colnames(pb))),
    state = factor(sub("^.*__", "", colnames(pb)), levels = c("GMP", "MonoSubtype")),
    stringsAsFactors = FALSE
  )
  keep <- rowSums(pb >= 5L) >= 4L
  dge <- DGEList(counts = pb[keep, , drop = FALSE], samples = sm)
  dge <- calcNormFactors(dge, method = "TMM")
  expr <- cpm(dge, log = TRUE, prior.count = 0.5)
  rows <- list()
  for (gene in c("CASP1", "GPX4")) {
    if (!gene %in% rownames(expr)) next
    df <- data.frame(donor.id = sm$donor.id, state = sm$state, value = as.numeric(expr[gene, ]))
    fit <- lm(value ~ donor.id + state, data = df)
    ct <- summary(fit)$coefficients["stateMonoSubtype", ]
    wide <- reshape(df, idvar = "donor.id", timevar = "state", direction = "wide")
    diff <- wide$value.MonoSubtype - wide$value.GMP
    rows[[length(rows) + 1L]] <- data.frame(
      comparison = comparison_name,
      target_label = target_label,
      gene = gene,
      n_patients = length(diff),
      mean_gmp_logcpm = mean(wide$value.GMP),
      mean_mono_logcpm = mean(wide$value.MonoSubtype),
      mean_paired_difference = mean(diff),
      median_paired_difference = median(diff),
      positive_patients = sum(diff > 0),
      negative_patients = sum(diff < 0),
      state_beta = unname(ct["Estimate"]),
      state_se = unname(ct["Std. Error"]),
      state_t = unname(ct["t value"]),
      state_p = unname(ct["Pr(>|t|)"]),
      wilcoxon_p = suppressWarnings(wilcox.test(diff, mu = 0, exact = FALSE)$p.value),
      stringsAsFactors = FALSE
    )
  }
  list(counts = tab, results = do.call(rbind, rows))
}

cat("Loading object for prespecified annotation subtype sensitivity\n")
outer_con <- gzfile(input_path, open = "rb")
inner_con <- gzcon(outer_con)
obj <- readRDS(inner_con)
close(inner_con)
if (!inherits(obj, "Seurat")) stop("Input is not Seurat")
meta <- obj[[]]
required <- c("manual_annotation_v3_l3_final", "donor.id", "stage_simple", "disease", "institute")
if (length(setdiff(required, colnames(meta)))) stop("Required metadata fields missing")
counts <- get_counts(obj)
if (!inherits(counts, "sparseMatrix")) stop("Counts are not sparse")

comparisons <- list(
  CD14_Mono_vs_GMP = "CD14+ Mono",
  CD16_Mono_vs_GMP = "CD16+ Mono",
  Immature_Mono_vs_GMP = "Immature Mono"
)
outs <- lapply(names(comparisons), function(nm) analyze_pair(counts, meta, comparisons[[nm]], nm))
count_tables <- do.call(rbind, lapply(outs, `[[`, "counts"))
result_tables <- Filter(Negate(is.null), lapply(outs, `[[`, "results"))
results <- if (length(result_tables)) do.call(rbind, result_tables) else data.frame()
if (nrow(results)) {
  results$state_fdr_bh <- ave(results$state_p, results$comparison, FUN = function(x) p.adjust(x, method = "BH"))
}
write.table(count_tables, file.path(out_dir, "05_annotation_subtype_patient_counts.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(results, file.path(out_dir, "05_annotation_subtype_results.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
status <- data.frame(status = "passed", comparisons_attempted = length(comparisons), comparisons_analyzed = length(result_tables),
                     result_rows = nrow(results), R = as.character(getRversion()), Seurat = as.character(packageVersion("Seurat")),
                     edgeR = as.character(packageVersion("edgeR")), stringsAsFactors = FALSE)
write.table(status, file.path(out_dir, "05_annotation_subtype_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
print(results)
print(status)
rm(obj, counts)
gc()
quit(save = "no", status = 0, runLast = FALSE)

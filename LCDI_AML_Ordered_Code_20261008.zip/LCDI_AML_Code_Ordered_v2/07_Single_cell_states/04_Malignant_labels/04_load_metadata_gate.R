args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 04_load_metadata_gate.R <final_object.rds> <out_dir>")
input_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")
}

cat("Loading final GSE230559 object for metadata-only gate\n")
con <- gzfile(input_path, open = "rb")
obj <- readRDS(con)
close(con)
if (!inherits(obj, "Seurat")) stop("Downloaded object is not a Seurat object")

meta <- obj[[]]
meta_columns <- data.frame(
  column = colnames(meta),
  class = vapply(meta, function(x) paste(class(x), collapse = ";"), character(1)),
  non_missing = vapply(meta, function(x) sum(!is.na(x)), integer(1)),
  unique_non_missing = vapply(meta, function(x) length(unique(x[!is.na(x)])), integer(1)),
  stringsAsFactors = FALSE
)
write_tsv(meta_columns, "04_metadata_columns.tsv")

candidate_fields <- unique(c(
  "manual_annotation_v3_l3_final", "manual_annotation_v3_l2_final",
  "donor.id", "stage_simple", "Timepoint", "disease", "institute", "institute_disease",
  "IDH2_R140", "IDH2_R172", "IDH1_R132", "NPM1_W288", "NRAS_G12", "SRSF2_P95",
  "clone", "clone_manual"
))
present <- intersect(candidate_fields, colnames(meta))
value_rows <- list()
for (field in present) {
  tab <- sort(table(meta[[field]], useNA = "ifany"), decreasing = TRUE)
  value_rows[[field]] <- data.frame(
    field = field,
    value = names(tab),
    n = as.integer(tab),
    stringsAsFactors = FALSE
  )
}
values <- if (length(value_rows)) do.call(rbind, value_rows) else data.frame(field=character(), value=character(), n=integer())
write_tsv(values, "04_candidate_field_value_counts.tsv")

required_core <- c("manual_annotation_v3_l3_final", "donor.id")
mutation_fields <- intersect(c("IDH2_R140", "IDH2_R172", "IDH1_R132", "NPM1_W288", "NRAS_G12", "SRSF2_P95"), colnames(meta))
clone_fields <- intersect(c("clone", "clone_manual"), colnames(meta))
time_fields <- intersect(c("stage_simple", "Timepoint"), colnames(meta))
disease_fields <- intersect(c("disease", "institute_disease"), colnames(meta))
gate_pass <- all(required_core %in% colnames(meta)) && length(time_fields) >= 1L &&
  length(disease_fields) >= 1L && (length(mutation_fields) >= 1L || length(clone_fields) >= 1L)

summary <- data.frame(
  object_class = paste(class(obj), collapse = ";"),
  genes = nrow(obj),
  cells = ncol(obj),
  assays = paste(Assays(obj), collapse = ";"),
  object_size_bytes = as.numeric(object.size(obj)),
  metadata_columns = ncol(meta),
  mutation_fields = paste(mutation_fields, collapse = ";"),
  clone_fields = paste(clone_fields, collapse = ";"),
  time_fields = paste(time_fields, collapse = ";"),
  disease_fields = paste(disease_fields, collapse = ";"),
  metadata_gate_pass = gate_pass,
  stringsAsFactors = FALSE
)
write_tsv(summary, "04_object_metadata_summary.tsv")

status <- data.frame(
  status = if (gate_pass) "passed" else "failed",
  message = if (gate_pass) "Required author labels, patient, time, disease and malignant-evidence fields are present" else "One or more frozen metadata gates failed",
  R = as.character(getRversion()),
  Seurat = as.character(packageVersion("Seurat")),
  Matrix = as.character(packageVersion("Matrix")),
  stringsAsFactors = FALSE
)
write_tsv(status, "04_metadata_gate_status.tsv")
print(summary)
print(status)
rm(meta, obj)
gc()
quit(save = "no", status = if (gate_pass) 0 else 2, runLast = FALSE)

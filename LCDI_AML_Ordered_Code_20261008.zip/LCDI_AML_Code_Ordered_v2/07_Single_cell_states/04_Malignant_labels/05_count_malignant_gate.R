args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 05_count_malignant_gate.R <final_object.rds> <out_dir>")
input_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)

suppressPackageStartupMessages(library(Seurat))

write_tsv <- function(x, name) {
  write.table(x, file.path(out_dir, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")
}

cat("Loading final object for frozen metadata count gate; target expression is not accessed\n")
con <- gzfile(input_path, open = "rb")
obj <- readRDS(con)
close(con)
if (!inherits(obj, "Seurat")) stop("Input is not a Seurat object")
meta <- obj[[]]

required <- c("manual_annotation_v3_l1_final", "donor.id", "stage_simple",
              "IDH2_R140", "IDH2_R172", "IDH1_R132", "NRAS_G12", "clone_manual")
missing_required <- setdiff(required, colnames(meta))
if (length(missing_required)) stop("Missing frozen fields: ", paste(missing_required, collapse = ","))

annotation_tab <- sort(table(meta$manual_annotation_v3_l1_final, useNA = "ifany"), decreasing = TRUE)
write_tsv(data.frame(annotation = names(annotation_tab), n = as.integer(annotation_tab)), "05_annotation_counts.tsv")

diagnosis <- meta$stage_simple == "diagnosis"
diagnosis[is.na(diagnosis)] <- FALSE
diagnosis_donors <- sort(table(meta$donor.id[diagnosis]), decreasing = TRUE)
donor_table <- data.frame(donor.id = names(diagnosis_donors), diagnosis_cells = as.integer(diagnosis_donors), stringsAsFactors = FALSE)
donor_table$aml_named = grepl("^AML[-_]", donor_table$donor.id)
write_tsv(donor_table, "05_diagnosis_donor_counts.tsv")

inst <- ifelse(is.na(meta$institute_disease), "NA", meta$institute_disease)
stage <- ifelse(is.na(meta$stage_simple), "NA", meta$stage_simple)
inst_stage <- as.data.frame.matrix(table(stage, inst))
inst_stage$stage_simple <- rownames(inst_stage)
rownames(inst_stage) <- NULL
write_tsv(inst_stage[, c("stage_simple", setdiff(colnames(inst_stage), "stage_simple"))], "05_institute_stage_crosstab.tsv")

direct_fields <- c("IDH2_R140", "IDH2_R172", "IDH1_R132", "NRAS_G12")
direct_mt <- Reduce(`|`, lapply(direct_fields, function(f) !is.na(meta[[f]]) & meta[[f]] == "MT"))
abnormal_clone_levels <- c("gain_6_10_clone", "NRAS_clone", "SRSF2_subclone")
abnormal_clone <- !is.na(meta$clone_manual) & meta$clone_manual %in% abnormal_clone_levels
union_positive <- direct_mt | abnormal_clone

evidence_combo <- ifelse(direct_mt & abnormal_clone, "direct_MT_and_abnormal_clone",
                         ifelse(direct_mt, "direct_MT_only",
                                ifelse(abnormal_clone, "abnormal_clone_only", "not_positive")))
evidence_tab <- as.data.frame(table(evidence_combo, useNA = "ifany"), stringsAsFactors = FALSE)
colnames(evidence_tab) <- c("evidence_category", "cells_all")
evidence_tab$cells_diagnosis <- vapply(evidence_tab$evidence_category, function(x) sum(evidence_combo == x & diagnosis), integer(1))
write_tsv(evidence_tab, "05_malignant_evidence_source_counts.tsv")

ann <- meta$manual_annotation_v3_l1_final
state <- ifelse(ann == "GMP", "GMP",
                ifelse(ann %in% c("CD14+ Mono", "CD16+ Mono"), "Mono", NA_character_))
layers <- list(
  union_positive = union_positive,
  direct_MT_only = direct_mt,
  abnormal_clone_only = abnormal_clone
)

patient_rows <- list()
gate_rows <- list()
for (layer_name in names(layers)) {
  selected <- diagnosis & layers[[layer_name]] & !is.na(state)
  tab <- as.data.frame.matrix(table(meta$donor.id[selected], state[selected]))
  if (!"GMP" %in% colnames(tab)) tab$GMP <- 0L
  if (!"Mono" %in% colnames(tab)) tab$Mono <- 0L
  tab$donor.id <- rownames(tab)
  rownames(tab) <- NULL
  tab <- tab[, c("donor.id", "GMP", "Mono")]
  tab$eligible <- tab$GMP >= 20L & tab$Mono >= 20L
  tab$layer <- layer_name
  patient_rows[[layer_name]] <- tab
  gate_rows[[layer_name]] <- data.frame(
    layer = layer_name,
    selected_cells = sum(selected),
    patients_with_any = nrow(tab),
    eligible_paired_patients = sum(tab$eligible),
    minimum_patients = 4L,
    gate_pass = sum(tab$eligible) >= 4L,
    stringsAsFactors = FALSE
  )
}
patient_counts <- do.call(rbind, patient_rows)
gate_summary <- do.call(rbind, gate_rows)
write_tsv(patient_counts, "05_patient_state_counts_by_evidence_layer.tsv")
write_tsv(gate_summary, "05_malignant_layer_gate_summary.tsv")

selected_union <- diagnosis & union_positive & !is.na(state)
selected_meta <- data.frame(
  cell = rownames(meta)[selected_union],
  donor.id = meta$donor.id[selected_union],
  author_annotation = ann[selected_union],
  state = state[selected_union],
  direct_MT = direct_mt[selected_union],
  abnormal_clone = abnormal_clone[selected_union],
  clone_manual = meta$clone_manual[selected_union],
  stringsAsFactors = FALSE
)
gz <- gzfile(file.path(out_dir, "05_selected_union_cell_metadata.tsv.gz"), open = "wt")
write.table(selected_meta, gz, sep = "\t", quote = FALSE, row.names = FALSE, na = "NA")
close(gz)

diagnosis_donor_gate <- nrow(donor_table) > 0L && all(donor_table$aml_named)
union_gate <- gate_summary$gate_pass[gate_summary$layer == "union_positive"]
status <- data.frame(
  status = if (diagnosis_donor_gate && union_gate) "passed" else "failed",
  diagnosis_cells = sum(diagnosis),
  diagnosis_donors = nrow(donor_table),
  diagnosis_donors_all_AML_named = diagnosis_donor_gate,
  union_positive_selected_cells = sum(selected_union),
  union_eligible_paired_patients = gate_summary$eligible_paired_patients[gate_summary$layer == "union_positive"],
  target_expression_accessed = FALSE,
  R = as.character(getRversion()),
  Seurat = as.character(packageVersion("Seurat")),
  stringsAsFactors = FALSE
)
write_tsv(status, "05_count_gate_status.tsv")
print(gate_summary)
print(status)
rm(meta, obj)
gc()
quit(save = "no", status = if (status$status == "passed") 0 else 2, runLast = FALSE)

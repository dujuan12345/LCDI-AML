args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 06_build_malignant_pseudobulk.R <final_object.rds> <out_dir>")
input_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)

suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

protected <- file.path(out_dir, c("06_malignant_pseudobulk.rds", "06_pseudobulk_status.tsv"))
if (any(file.exists(protected))) stop("Refusing to overwrite malignant pseudobulk outputs")

get_counts <- function(x) {
  GetAssayData(x, assay = "RNA", layer = "counts")
}

cat("Loading final object to build frozen malignant-evidence pseudobulk\n")
con <- gzfile(input_path, open = "rb")
obj <- readRDS(con)
close(con)
if (!inherits(obj, "Seurat")) stop("Input is not a Seurat object")
meta <- obj[[]]
counts <- get_counts(obj)
if (!inherits(counts, "sparseMatrix")) stop("RNA counts are not sparse")
if (!identical(colnames(counts), rownames(meta))) stop("Counts and metadata cell order mismatch")

diagnosis <- !is.na(meta$stage_simple) & meta$stage_simple == "diagnosis"
ann <- meta$manual_annotation_v3_l1_final
state <- ifelse(ann == "GMP", "GMP",
                ifelse(ann %in% c("CD14+ Mono", "CD16+ Mono"), "Mono", NA_character_))
direct_fields <- c("IDH2_R140", "IDH2_R172", "IDH1_R132", "NRAS_G12")
direct_mt <- Reduce(`|`, lapply(direct_fields, function(f) !is.na(meta[[f]]) & meta[[f]] == "MT"))
abnormal_clone <- !is.na(meta$clone_manual) & meta$clone_manual %in% c("gain_6_10_clone", "NRAS_clone", "SRSF2_subclone")
layers <- list(union_positive = direct_mt | abnormal_clone, direct_MT_only = direct_mt)

pb_layers <- list()
sample_rows <- list()
for (layer_name in names(layers)) {
  selected0 <- diagnosis & layers[[layer_name]] & !is.na(state)
  tab <- as.data.frame.matrix(table(meta$donor.id[selected0], state[selected0]))
  if (!"GMP" %in% colnames(tab)) tab$GMP <- 0L
  if (!"Mono" %in% colnames(tab)) tab$Mono <- 0L
  eligible <- sort(rownames(tab)[tab$GMP >= 20L & tab$Mono >= 20L])
  if (length(eligible) < 4L) stop("Layer ", layer_name, " has fewer than four paired patients")
  selected <- selected0 & meta$donor.id %in% eligible
  cells <- rownames(meta)[selected]
  groups <- paste(meta$donor.id[selected], state[selected], sep = "__")
  levels_use <- as.vector(t(outer(eligible, c("GMP", "Mono"), paste, sep = "__")))
  design <- sparseMatrix(
    i = seq_along(groups),
    j = as.integer(factor(groups, levels = levels_use)),
    x = 1,
    dims = c(length(groups), length(levels_use)),
    dimnames = list(cells, levels_use)
  )
  idx <- match(cells, colnames(counts))
  if (anyNA(idx)) stop("Selected cells not found in counts")
  pb <- counts[, idx, drop = FALSE] %*% design
  sm <- data.frame(
    sample = colnames(pb),
    donor.id = sub("__(GMP|Mono)$", "", colnames(pb)),
    state = sub("^.*__", "", colnames(pb)),
    cell_count = as.integer(table(factor(groups, levels = levels_use))),
    layer = layer_name,
    stringsAsFactors = FALSE
  )
  rownames(sm) <- sm$sample
  if (any(sm$cell_count < 20L)) stop("Pseudobulk cell-count threshold violated")
  pb_layers[[layer_name]] <- list(counts = pb, sample_meta = sm)
  sample_rows[[layer_name]] <- sm
}

saveRDS(pb_layers, file.path(out_dir, "06_malignant_pseudobulk.rds"), compress = "xz")
sample_table <- do.call(rbind, sample_rows)
rownames(sample_table) <- NULL
write.table(sample_table, file.path(out_dir, "06_pseudobulk_sample_metadata.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
status <- data.frame(
  status = "passed",
  genes = nrow(counts),
  layers = length(pb_layers),
  union_patients = nrow(pb_layers$union_positive$sample_meta) / 2L,
  direct_MT_patients = nrow(pb_layers$direct_MT_only$sample_meta) / 2L,
  union_cells = sum(pb_layers$union_positive$sample_meta$cell_count),
  direct_MT_cells = sum(pb_layers$direct_MT_only$sample_meta$cell_count),
  target_expression_inspected = FALSE,
  R = as.character(getRversion()),
  Seurat = as.character(packageVersion("Seurat")),
  Matrix = as.character(packageVersion("Matrix")),
  stringsAsFactors = FALSE
)
write.table(status, file.path(out_dir, "06_pseudobulk_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
print(status)
rm(meta, counts, obj)
gc()
quit(save = "no", status = 0, runLast = FALSE)

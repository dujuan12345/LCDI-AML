options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(edgeR)
  library(Matrix)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 1L) stop("Usage: Rscript 07_run_malignant_tests.R <out_dir>")
out_dir <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
protected <- file.path(out_dir, c("07_malignant_target_results.tsv", "07_malignant_test_status.tsv"))
if (any(file.exists(protected))) stop("Refusing to overwrite malignant-test outputs")

pb <- readRDS(file.path(out_dir, "06_malignant_pseudobulk.rds"))
targets <- c("CASP1", "GPX4")

analyze_one <- function(gene, expr, meta, method, layer, seed_offset) {
  df <- data.frame(donor.id = meta$donor.id, state = meta$state,
                   value = as.numeric(expr[gene, ]), stringsAsFactors = FALSE)
  fit <- lm(value ~ donor.id + state, data = df)
  ct <- summary(fit)$coefficients["stateMono", ]
  wide <- reshape(df, idvar = "donor.id", timevar = "state", direction = "wide")
  wide <- wide[order(wide$donor.id), ]
  diff <- wide$value.Mono - wide$value.GMP
  wt <- suppressWarnings(wilcox.test(diff, mu = 0, exact = FALSE))
  set.seed(20260825L + seed_offset)
  boot <- replicate(2000L, mean(sample(diff, length(diff), replace = TRUE)))
  ci <- as.numeric(quantile(boot, c(0.025, 0.975), names = FALSE, type = 7))
  loo_beta <- numeric(length(diff))
  loo_p <- numeric(length(diff))
  for (i in seq_along(diff)) {
    use <- as.character(df$donor.id) != as.character(wide$donor.id[i])
    d2 <- droplevels(df[use, ])
    f2 <- lm(value ~ donor.id + state, data = d2)
    s2 <- summary(f2)$coefficients
    loo_beta[i] <- s2["stateMono", "Estimate"]
    loo_p[i] <- s2["stateMono", "Pr(>|t|)"]
  }
  list(
    result = data.frame(
      layer = layer, gene = gene, method = method, n_patients = length(diff),
      mean_gmp_logcpm = mean(wide$value.GMP), mean_mono_logcpm = mean(wide$value.Mono),
      mean_paired_difference = mean(diff), median_paired_difference = median(diff),
      positive_patients = sum(diff > 0), negative_patients = sum(diff < 0),
      state_beta = unname(ct["Estimate"]), state_se = unname(ct["Std. Error"]),
      state_t = unname(ct["t value"]), state_df = df.residual(fit), state_p = unname(ct["Pr(>|t|)"]),
      wilcoxon_p = wt$p.value, bootstrap_ci_low = ci[1], bootstrap_ci_high = ci[2],
      loo_direction_positive_fraction = mean(loo_beta > 0), loo_p_lt_0_05_fraction = mean(loo_p < 0.05),
      direction = ifelse(unname(ct["Estimate"]) > 0, "Mono_higher", "GMP_higher"),
      stringsAsFactors = FALSE
    ),
    expression = data.frame(layer = layer, gene = gene, method = method,
      donor.id = as.character(wide$donor.id), gmp_logcpm = wide$value.GMP,
      mono_logcpm = wide$value.Mono, paired_difference = diff, stringsAsFactors = FALSE),
    bootstrap = data.frame(layer = layer, gene = gene, method = method,
      iteration = seq_along(boot), mean_paired_difference = boot, stringsAsFactors = FALSE),
    loo = data.frame(layer = layer, gene = gene, method = method,
      omitted_patient = as.character(wide$donor.id), state_beta = loo_beta, state_p = loo_p,
      stringsAsFactors = FALSE)
  )
}

all_results <- list(); all_expr <- list(); all_boot <- list(); all_loo <- list(); norm_rows <- list()
counter <- 0L
analysis_objects <- list()
for (layer in names(pb)) {
  counts <- pb[[layer]]$counts
  meta <- pb[[layer]]$sample_meta
  if (nrow(meta) != ncol(counts) || !identical(rownames(meta), colnames(counts))) stop("Counts/meta mismatch in ", layer)
  meta$state <- factor(meta$state, levels = c("GMP", "Mono"))
  meta$donor.id <- factor(meta$donor.id)
  if (any(table(meta$donor.id, meta$state) != 1L)) stop("Unpaired pseudobulk in ", layer)
  keep <- rowSums(counts >= 5L) >= 4L
  dge <- DGEList(counts = counts[keep, , drop = FALSE], samples = meta)
  dge <- calcNormFactors(dge, method = "TMM")
  log_tmm <- cpm(dge, log = TRUE, prior.count = 0.5)
  dge_cpm <- DGEList(counts = counts[keep, , drop = FALSE], samples = meta)
  dge_cpm$samples$norm.factors <- 1
  log_cpm <- cpm(dge_cpm, log = TRUE, prior.count = 0.5)
  if (!all(targets %in% rownames(log_tmm))) stop("Target absent after filtering in ", layer)
  for (method in c("TMM", "CPM")) {
    expr <- if (method == "TMM") log_tmm else log_cpm
    for (gene in targets) {
      counter <- counter + 1L
      z <- analyze_one(gene, expr, meta, method, layer, counter)
      key <- paste(layer, method, gene, sep = "_")
      all_results[[key]] <- z$result
      all_expr[[key]] <- z$expression
      all_boot[[key]] <- z$bootstrap
      all_loo[[key]] <- z$loo
    }
  }
  norm_rows[[layer]] <- data.frame(layer = layer, sample = colnames(counts),
    donor.id = as.character(meta$donor.id), state = as.character(meta$state),
    cell_count = meta$cell_count, library_size = dge$samples$lib.size,
    tmm_norm_factor = dge$samples$norm.factors,
    effective_library_size = dge$samples$lib.size * dge$samples$norm.factors,
    stringsAsFactors = FALSE)
  analysis_objects[[layer]] <- list(dge = dge, logcpm_tmm = log_tmm, logcpm_cpm = log_cpm, meta = meta, genes_kept = sum(keep))
}

results <- do.call(rbind, all_results); rownames(results) <- NULL
for (layer in unique(results$layer)) for (method in unique(results$method)) {
  ii <- which(results$layer == layer & results$method == method)
  results$state_fdr_bh[ii] <- p.adjust(results$state_p[ii], method = "BH")
}
results$primary_gate_pass <- with(results,
  gene == "CASP1" & method == "TMM" & n_patients >= 4 & direction == "Mono_higher" &
    state_p < 0.05 & bootstrap_ci_low > 0 & loo_direction_positive_fraction >= 0.90)

expression <- do.call(rbind, all_expr)
bootstrap <- do.call(rbind, all_boot)
loo <- do.call(rbind, all_loo)
norm_factors <- do.call(rbind, norm_rows)
write.table(results, file.path(out_dir, "07_malignant_target_results.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(expression, file.path(out_dir, "07_malignant_expression_by_patient.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(bootstrap, file.path(out_dir, "07_malignant_bootstrap.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(loo, file.path(out_dir, "07_malignant_loo.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
write.table(norm_factors, file.path(out_dir, "07_malignant_tmm_factors.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
saveRDS(analysis_objects, file.path(out_dir, "07_malignant_analysis.rds"), compress = "xz")

union_gate <- results$primary_gate_pass[results$layer == "union_positive" & results$gene == "CASP1" & results$method == "TMM"]
direct_gate <- results$primary_gate_pass[results$layer == "direct_MT_only" & results$gene == "CASP1" & results$method == "TMM"]
status <- data.frame(
  status = "passed", union_CASP1_gate = union_gate, direct_MT_CASP1_gate = direct_gate,
  malignant_specific_replication = union_gate && direct_gate,
  layers = length(pb), result_rows = nrow(results), R = as.character(getRversion()),
  edgeR = as.character(packageVersion("edgeR")), stringsAsFactors = FALSE)
write.table(status, file.path(out_dir, "07_malignant_test_status.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
print(results)
print(status)

options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({library(Seurat); library(Matrix); library(edgeR)})
args <- commandArgs(trailingOnly = TRUE)
if (length(args) != 2L) stop("Usage: Rscript 08_malignant_annotation_subtype_sensitivity.R <object> <out_dir>")
input_path <- normalizePath(args[[1]], winslash = "/", mustWork = TRUE)
out_dir <- normalizePath(args[[2]], winslash = "/", mustWork = TRUE)
if (file.exists(file.path(out_dir, "08_malignant_subtype_results.tsv"))) stop("Refusing to overwrite subtype results")

analyze <- function(counts, meta, positive, layer, target_label, comparison) {
  diagnosis <- !is.na(meta$stage_simple) & meta$stage_simple == "diagnosis"
  ann <- meta$manual_annotation_v3_l1_final
  state <- ifelse(ann == "GMP", "GMP", ifelse(ann == target_label, "MonoSubtype", NA_character_))
  selected0 <- diagnosis & positive & !is.na(state)
  tab <- as.data.frame.matrix(table(meta$donor.id[selected0], state[selected0]))
  if (!"GMP" %in% colnames(tab)) tab$GMP <- 0L
  if (!"MonoSubtype" %in% colnames(tab)) tab$MonoSubtype <- 0L
  tab$donor.id <- rownames(tab); rownames(tab) <- NULL
  tab$eligible <- tab$GMP >= 20L & tab$MonoSubtype >= 20L
  tab$layer <- layer; tab$comparison <- comparison; tab$target_label <- target_label
  eligible <- sort(tab$donor.id[tab$eligible])
  if (length(eligible) < 4L) return(list(counts = tab, results = NULL, expression = NULL))
  selected <- selected0 & meta$donor.id %in% eligible
  cells <- rownames(meta)[selected]
  groups <- paste(meta$donor.id[selected], state[selected], sep = "__")
  levels_use <- as.vector(t(outer(eligible, c("GMP", "MonoSubtype"), paste, sep = "__")))
  design <- sparseMatrix(i=seq_along(groups), j=as.integer(factor(groups, levels=levels_use)), x=1,
    dims=c(length(groups), length(levels_use)), dimnames=list(cells, levels_use))
  pb <- counts[, cells, drop=FALSE] %*% design
  sm <- data.frame(donor.id=factor(sub("__(GMP|MonoSubtype)$", "", colnames(pb))),
    state=factor(sub("^.*__", "", colnames(pb)), levels=c("GMP","MonoSubtype")), stringsAsFactors=FALSE)
  keep <- rowSums(pb >= 5L) >= 4L
  dge <- DGEList(counts=pb[keep,,drop=FALSE], samples=sm)
  dge <- calcNormFactors(dge, method="TMM")
  exprs <- list(TMM=cpm(dge, log=TRUE, prior.count=0.5))
  dge2 <- DGEList(counts=pb[keep,,drop=FALSE], samples=sm); dge2$samples$norm.factors <- 1
  exprs$CPM <- cpm(dge2, log=TRUE, prior.count=0.5)
  results <- list(); expressions <- list(); counter <- 0L
  for (method in names(exprs)) for (gene in c("CASP1","GPX4")) {
    counter <- counter + 1L
    ex <- exprs[[method]]
    df <- data.frame(donor.id=sm$donor.id, state=sm$state, value=as.numeric(ex[gene,]))
    fit <- lm(value ~ donor.id + state, data=df)
    ct <- summary(fit)$coefficients["stateMonoSubtype",]
    wide <- reshape(df, idvar="donor.id", timevar="state", direction="wide")
    wide <- wide[order(wide$donor.id),]
    diff <- wide$value.MonoSubtype - wide$value.GMP
    set.seed(20260825L + counter + sum(utf8ToInt(layer)) + sum(utf8ToInt(comparison)))
    boot <- replicate(2000L, mean(sample(diff, length(diff), replace=TRUE)))
    ci <- quantile(boot, c(.025,.975), names=FALSE)
    loo_beta <- loo_p <- numeric(length(diff))
    for(i in seq_along(diff)) {
      d2 <- droplevels(df[as.character(df$donor.id) != as.character(wide$donor.id[i]),])
      s2 <- summary(lm(value ~ donor.id + state, data=d2))$coefficients
      loo_beta[i] <- s2["stateMonoSubtype","Estimate"]
      loo_p[i] <- s2["stateMonoSubtype","Pr(>|t|)"]
    }
    results[[paste(method,gene)]] <- data.frame(layer=layer,comparison=comparison,target_label=target_label,
      gene=gene,method=method,n_patients=length(diff),mean_gmp_logcpm=mean(wide$value.GMP),
      mean_mono_logcpm=mean(wide$value.MonoSubtype),mean_paired_difference=mean(diff),
      median_paired_difference=median(diff),positive_patients=sum(diff>0),negative_patients=sum(diff<0),
      state_beta=unname(ct["Estimate"]),state_se=unname(ct["Std. Error"]),state_t=unname(ct["t value"]),
      state_df=df.residual(fit),state_p=unname(ct["Pr(>|t|)"]),
      wilcoxon_p=suppressWarnings(wilcox.test(diff,mu=0,exact=FALSE)$p.value),
      bootstrap_ci_low=ci[1],bootstrap_ci_high=ci[2],
      loo_direction_positive_fraction=mean(loo_beta>0),loo_p_lt_0_05_fraction=mean(loo_p<.05),
      stringsAsFactors=FALSE)
    expressions[[paste(method,gene)]] <- data.frame(layer=layer,comparison=comparison,gene=gene,method=method,
      donor.id=as.character(wide$donor.id),gmp_logcpm=wide$value.GMP,
      mono_logcpm=wide$value.MonoSubtype,paired_difference=diff,stringsAsFactors=FALSE)
  }
  list(counts=tab,results=do.call(rbind,results),expression=do.call(rbind,expressions))
}

cat("Loading final object for prespecified malignant subtype sensitivity\n")
con <- gzfile(input_path,"rb"); obj <- readRDS(con); close(con)
meta <- obj[[]]; counts <- GetAssayData(obj, assay="RNA", layer="counts")
direct_mt <- Reduce(`|`, lapply(c("IDH2_R140","IDH2_R172","IDH1_R132","NRAS_G12"), function(f) !is.na(meta[[f]]) & meta[[f]]=="MT"))
abnormal_clone <- !is.na(meta$clone_manual) & meta$clone_manual %in% c("gain_6_10_clone","NRAS_clone","SRSF2_subclone")
layers <- list(union_positive=direct_mt|abnormal_clone,direct_MT_only=direct_mt)
comparisons <- c(CD14_Mono_vs_GMP="CD14+ Mono",CD16_Mono_vs_GMP="CD16+ Mono")
outs <- list()
for(layer in names(layers)) for(comp in names(comparisons))
  outs[[paste(layer,comp)]] <- analyze(counts,meta,layers[[layer]],layer,comparisons[[comp]],comp)
count_tab <- do.call(rbind,lapply(outs,`[[`,"counts")); rownames(count_tab)<-NULL
res_list <- Filter(Negate(is.null),lapply(outs,`[[`,"results")); results <- do.call(rbind,res_list); rownames(results)<-NULL
expr_list <- Filter(Negate(is.null),lapply(outs,`[[`,"expression")); expression <- do.call(rbind,expr_list); rownames(expression)<-NULL
for(layer in unique(results$layer)) for(comp in unique(results$comparison)) for(method in unique(results$method)) {
  ii <- which(results$layer==layer & results$comparison==comp & results$method==method)
  if(length(ii)) results$state_fdr_bh[ii] <- p.adjust(results$state_p[ii],method="BH")
}
write.table(count_tab,file.path(out_dir,"08_malignant_subtype_patient_counts.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
write.table(results,file.path(out_dir,"08_malignant_subtype_results.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
write.table(expression,file.path(out_dir,"08_malignant_subtype_expression.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
status <- data.frame(status="passed",comparisons_attempted=length(layers)*length(comparisons),
  comparisons_analyzed=length(res_list),result_rows=nrow(results),R=as.character(getRversion()),
  Seurat=as.character(packageVersion("Seurat")),edgeR=as.character(packageVersion("edgeR")),stringsAsFactors=FALSE)
write.table(status,file.path(out_dir,"08_malignant_subtype_status.tsv"),sep="\t",quote=FALSE,row.names=FALSE)
print(results); print(status)
rm(meta,counts,obj);gc();quit(save="no",status=0,runLast=FALSE)

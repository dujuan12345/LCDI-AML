options(stringsAsFactors = FALSE, width = 180)
suppressPackageStartupMessages({
  library(SingleCellExperiment)
  library(SummarizedExperiment)
  library(slingshot)
  library(Matrix)
})

root <- "D:/26_01_AML"
out <- file.path(root, "_codex_audit", "chapter8_lightweight_supplements_20260802_v1")
dir.create(out, recursive = TRUE, showWarnings = FALSE)

marker_sets <- list(
  progenitor = c("CD34", "AVP", "CRHBP", "MEIS1", "HOPX", "PROM1", "MLLT3", "HLF", "KIT", "GATA2"),
  granulocytic = c("CSF3R", "FCGR3B", "CEACAM8", "S100A8", "S100A9", "ELANE", "CTSG", "AZU1", "LTF"),
  monocytic = c("LST1", "FCN1", "CTSD", "LILRB1", "CTSS", "FCGR3A"),
  dendritic = c("FCER1A", "CLEC10A", "CD1C", "GZMB", "JCHAIN")
)

pick <- function(fields, candidates, required = TRUE) {
  hit <- candidates[candidates %in% fields]
  if (length(hit)) return(hit[[1]])
  if (required) stop("No candidate field found: ", paste(candidates, collapse = ", "))
  NA_character_
}

aggregate_counts <- function(counts, ids) {
  ids <- factor(ids)
  mm <- sparse.model.matrix(~ 0 + ids)
  colnames(mm) <- levels(ids)
  pb <- counts %*% mm
  lib <- Matrix::colSums(pb)
  logcpm <- log2(t(t(as.matrix(pb)) / pmax(lib, 1)) * 1e6 + 1)
  list(logcpm = logcpm, library_size = lib)
}

extract_one <- function(path, dataset) {
  message("Reading ", dataset, ": ", path)
  sce <- readRDS(path)
  cd <- colData(sce)
  fields <- colnames(cd)
  get_field <- function(name) {
    value <- cd[[name]]
    if (is.factor(value)) as.character(value) else as.vector(value)
  }

  sample_field <- if (dataset == "adult") {
    pick(fields, c("orig.ident", "sample", "samples"))
  } else {
    pick(fields, c("samples", "sample", "orig.ident"))
  }
  group_field <- if (dataset == "adult") {
    pick(fields, c("source", "condition", "group"))
  } else {
    pick(fields, c("malignant", "source", "condition", "group"))
  }
  cluster_field <- if (dataset == "adult") {
    pick(fields, c("seurat_clusters", "cluster", "clusters"))
  } else {
    pick(fields, c("Cell_type_identity", "celltype", "cell_type", "seurat_clusters"))
  }
  celltype_field <- if (dataset == "adult") {
    pick(fields, c("CellType_ordered", "celltype", "cell_type", "annotation"))
  } else {
    pick(fields, c("Cell_type_identity", "Broad_cell_identity", "celltype", "cell_type"))
  }
  lcdi_field <- pick(fields, c("LCDI_score", "LCDI"))

  genes <- rownames(sce)
  marker_genes <- unique(unlist(marker_sets))
  marker_genes <- marker_genes[marker_genes %in% genes]
  logcounts <- assay(sce, "logcounts")
  counts <- assay(sce, "counts")

  marker_expr <- as.matrix(logcounts[marker_genes, , drop = FALSE])
  mpo <- if ("MPO" %in% genes) as.numeric(logcounts["MPO", ]) else rep(NA_real_, ncol(sce))
  umap <- reducedDim(sce, "UMAP")
  colnames(umap) <- c("UMAP1", "UMAP2")
  pt <- slingPseudotime(sce, na = TRUE)
  wt <- slingCurveWeights(sce)
  lineages <- slingLineages(sce)
  sling_clusters <- tryCatch(slingClusterLabels(sce), error = function(e) NULL)
  if (is.null(sling_clusters)) sling_clusters <- get_field(cluster_field)
  if (is.matrix(sling_clusters)) sling_clusters <- colnames(sling_clusters)[max.col(sling_clusters, ties.method = "first")]

  pb_ids <- paste(get_field(sample_field), get_field(group_field), sep = "|")
  pb <- aggregate_counts(counts, pb_ids)
  pb_meta <- data.frame(
    pb_id = colnames(pb$logcpm),
    sample = sub("\\|.*$", "", colnames(pb$logcpm)),
    group = sub("^[^|]*\\|", "", colnames(pb$logcpm)),
    library_size = as.numeric(pb$library_size),
    stringsAsFactors = FALSE
  )

  selected_meta <- data.frame(
    cell = colnames(sce),
    sample = as.character(get_field(sample_field)),
    group = as.character(get_field(group_field)),
    cluster = as.character(get_field(cluster_field)),
    celltype = as.character(get_field(celltype_field)),
    LCDI = as.numeric(get_field(lcdi_field)),
    MPO = mpo,
    stringsAsFactors = FALSE
  )
  if ("inflammation_group" %in% fields) selected_meta$inflammation_group <- as.character(get_field("inflammation_group"))

  compact <- list(
    dataset = dataset,
    source_path = normalizePath(path, winslash = "/"),
    dimensions = dim(sce),
    fields = list(sample = sample_field, group = group_field, cluster = cluster_field,
                  celltype = celltype_field, lcdi = lcdi_field),
    meta = selected_meta,
    umap = umap,
    marker_expr = marker_expr,
    marker_sets = marker_sets,
    pseudotime = pt,
    weights = wt,
    lineages = lineages,
    sling_clusters = as.character(sling_clusters),
    pseudobulk_logcpm = pb$logcpm,
    pseudobulk_meta = pb_meta
  )
  saveRDS(compact, file.path(out, paste0("01_", dataset, "_compact.rds")), compress = "xz")

  structure_lines <- c(
    paste0("dataset=", dataset),
    paste0("dimensions=", paste(dim(sce), collapse = "x")),
    paste0("sample_field=", sample_field),
    paste0("group_field=", group_field),
    paste0("cluster_field=", cluster_field),
    paste0("celltype_field=", celltype_field),
    paste0("lcdi_field=", lcdi_field),
    paste0("groups=", paste(names(sort(table(selected_meta$group), decreasing = TRUE)),
                              as.integer(sort(table(selected_meta$group), decreasing = TRUE)), sep = ":", collapse = ";")),
    paste0("clusters=", paste(unique(selected_meta$cluster), collapse = ";")),
    paste0("lineages=", paste(vapply(lineages, paste, collapse = "->", FUN.VALUE = character(1)), collapse = ";")),
    paste0("marker_genes=", paste(marker_genes, collapse = ";")),
    paste0("pseudobulk_columns=", ncol(pb$logcpm))
  )
  writeLines(structure_lines, file.path(out, paste0("01_", dataset, "_compact_summary.txt")), useBytes = TRUE)
  rm(sce, counts, logcounts, marker_expr, compact, pb); gc()
}

extract_one(file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J3_pseudotime/Cache/stage2_sce_with_slingshot.rds"), "adult")
extract_one(file.path(root, "AML_Lactylation_PCD/scRNA/GSE185381/J11_pseudotime/Cache/stage2_sce_with_slingshot_GSE185381_FIX.rds"), "pediatric")
writeLines(capture.output(sessionInfo()), file.path(out, "01_session_info.txt"), useBytes = TRUE)
cat("compact_extraction_passed\n")

options(stringsAsFactors = FALSE, width = 180)

root <- "D:/26_01_AML"
out <- file.path(root, "_codex_audit", "chapter8_lightweight_supplements_20260802_v1")
set.seed(20260802)

write_tsv <- function(x, name) write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, fileEncoding = "UTF-8")

make_edges <- function(lineages, centroids) {
  pairs <- unique(do.call(rbind, lapply(lineages, function(path) {
    if (length(path) < 2) return(NULL)
    cbind(head(path, -1), tail(path, -1))
  })))
  colnames(pairs) <- c("a", "b")
  keys <- apply(pairs, 1, function(z) paste(sort(z), collapse = "|"))
  pairs <- pairs[!duplicated(keys), , drop = FALSE]
  data.frame(
    a = pairs[, 1], b = pairs[, 2],
    weight = sqrt(rowSums((centroids[pairs[, 1], , drop = FALSE] - centroids[pairs[, 2], , drop = FALSE])^2)),
    stringsAsFactors = FALSE
  )
}

dijkstra <- function(nodes, edges, root_node) {
  dist <- setNames(rep(Inf, length(nodes)), nodes)
  dist[root_node] <- 0
  visited <- setNames(rep(FALSE, length(nodes)), nodes)
  while (any(!visited & is.finite(dist))) {
    current <- names(which.min(ifelse(visited, Inf, dist)))
    visited[current] <- TRUE
    hit <- edges$a == current | edges$b == current
    if (!any(hit)) next
    e <- edges[hit, , drop = FALSE]
    neighbor <- ifelse(e$a == current, e$b, e$a)
    alt <- dist[current] + e$weight
    improve <- alt < dist[neighbor]
    dist[neighbor[improve]] <- alt[improve]
  }
  dist
}

safe_cor <- function(x, y) {
  keep <- is.finite(x) & is.finite(y)
  if (sum(keep) < 3 || length(unique(x[keep])) < 2 || length(unique(y[keep])) < 2) return(NA_real_)
  suppressWarnings(cor(x[keep], y[keep], method = "spearman"))
}

analyze_root <- function(x) {
  meta <- x$meta
  clusters <- as.character(meta$cluster)
  nodes <- sort(unique(clusters))
  centroids <- do.call(rbind, lapply(nodes, function(z) colMeans(x$umap[clusters == z, , drop = FALSE])))
  rownames(centroids) <- nodes
  edges <- make_edges(x$lineages, centroids)
  degrees <- table(c(edges$a, edges$b))

  progenitor_genes <- intersect(x$marker_sets$progenitor, rownames(x$marker_expr))
  progenitor_score <- colMeans(x$marker_expr[progenitor_genes, , drop = FALSE])
  cluster_stats <- do.call(rbind, lapply(nodes, function(z) {
    idx <- clusters == z
    data.frame(cluster = z, n_cells = sum(idx), progenitor_score = mean(progenitor_score[idx], na.rm = TRUE),
               LCDI = mean(meta$LCDI[idx], na.rm = TRUE), MPO = mean(meta$MPO[idx], na.rm = TRUE),
               dominant_celltype = names(which.max(table(meta$celltype[idx]))),
               dominant_celltype_fraction = max(table(meta$celltype[idx])) / sum(idx), stringsAsFactors = FALSE)
  }))
  cluster_stats$progenitor_rank <- rank(-cluster_stats$progenitor_score, ties.method = "min")

  original_root <- as.character(x$lineages[[1]][1])
  if (x$dataset == "adult") {
    eligible <- cluster_stats[cluster_stats$n_cells >= 200, ]
    alternatives <- head(eligible$cluster[order(-eligible$progenitor_score)], 3)
    roots <- unique(c(original_root, alternatives))
  } else {
    roots <- intersect(c(original_root, "MPP_MEP", "MPP_GMP"), nodes)
  }

  root_rows <- lapply(roots, function(r) {
    dist <- dijkstra(nodes, edges, r)
    cell_dist <- dist[clusters]
    endpoints <- setdiff(names(degrees)[degrees == 1], r)
    cs <- cluster_stats[match(r, cluster_stats$cluster), ]
    data.frame(
      dataset = x$dataset, root = r, original_root = r == original_root,
      root_n_cells = cs$n_cells, root_progenitor_score = cs$progenitor_score,
      root_progenitor_rank = cs$progenitor_rank,
      cell_level_LCDI_rho = safe_cor(cell_dist, meta$LCDI),
      cluster_level_LCDI_rho = safe_cor(dist[cluster_stats$cluster], cluster_stats$LCDI),
      cell_level_MPO_rho = safe_cor(cell_dist, meta$MPO),
      cluster_level_MPO_rho = safe_cor(dist[cluster_stats$cluster], cluster_stats$MPO),
      endpoint_nodes = paste(endpoints, collapse = ";"),
      root_becomes_terminal_under_original = r %in% setdiff(names(degrees)[degrees == 1], original_root),
      original_root_becomes_terminal = original_root %in% endpoints,
      stringsAsFactors = FALSE
    )
  })
  list(root = do.call(rbind, root_rows), clusters = transform(cluster_stats, dataset = x$dataset), edges = transform(edges, dataset = x$dataset))
}

analyze_endpoints <- function(x, selected_lineages) {
  meta <- x$meta
  results <- list()
  gene_results <- list()
  composition <- list()
  counter <- 0
  for (lin in selected_lineages) {
    j <- match(lin, colnames(x$pseudotime))
    if (is.na(j)) next
    pt <- x$pseudotime[, j]
    wt <- x$weights[, j]
    usable <- is.finite(pt) & is.finite(wt) & wt >= 0.5
    q <- quantile(pt[usable], c(0.1, 0.9), na.rm = TRUE)
    phase <- rep(NA_character_, length(pt))
    phase[usable & pt <= q[1]] <- "early"
    phase[usable & pt >= q[2]] <- "late"
    for (set_name in names(x$marker_sets)) {
      genes <- intersect(x$marker_sets[[set_name]], rownames(x$marker_expr))
      if (!length(genes)) next
      score <- colMeans(x$marker_expr[genes, , drop = FALSE])
      overall_delta <- mean(score[phase == "late"], na.rm = TRUE) - mean(score[phase == "early"], na.rm = TRUE)
      sample_levels <- unique(meta$sample[!is.na(phase)])
      sample_delta <- sapply(sample_levels, function(s) {
        e <- !is.na(phase) & phase == "early" & meta$sample == s
        l <- !is.na(phase) & phase == "late" & meta$sample == s
        if (sum(e) < 5 || sum(l) < 5) return(NA_real_)
        mean(score[l], na.rm = TRUE) - mean(score[e], na.rm = TRUE)
      })
      sample_delta <- sample_delta[is.finite(sample_delta)]
      p <- if (length(sample_delta) >= 3) suppressWarnings(wilcox.test(sample_delta, mu = 0, exact = FALSE)$p.value) else NA_real_
      counter <- counter + 1
      results[[counter]] <- data.frame(
        dataset = x$dataset, lineage = lin, marker_set = set_name,
        n_early_cells = sum(phase == "early", na.rm = TRUE), n_late_cells = sum(phase == "late", na.rm = TRUE),
        n_paired_samples = length(sample_delta), overall_late_minus_early = overall_delta,
        sample_median_late_minus_early = if (length(sample_delta)) median(sample_delta) else NA_real_,
        sample_wilcox_p = p, genes = paste(genes, collapse = ";"), stringsAsFactors = FALSE)
    }
    for (gene in rownames(x$marker_expr)) {
      v <- x$marker_expr[gene, ]
      gene_results[[length(gene_results) + 1]] <- data.frame(
        dataset = x$dataset, lineage = lin, gene = gene,
        early_mean = mean(v[phase == "early"], na.rm = TRUE), late_mean = mean(v[phase == "late"], na.rm = TRUE),
        late_minus_early = mean(v[phase == "late"], na.rm = TRUE) - mean(v[phase == "early"], na.rm = TRUE),
        early_detected = mean(v[phase == "early"] > 0, na.rm = TRUE), late_detected = mean(v[phase == "late"] > 0, na.rm = TRUE),
        stringsAsFactors = FALSE)
    }
    for (ph in c("early", "late")) {
      idx <- !is.na(phase) & phase == ph
      tab_group <- prop.table(table(meta$group[idx]))
      tab_type <- prop.table(table(meta$celltype[idx]))
      composition[[length(composition) + 1]] <- data.frame(
        dataset = x$dataset, lineage = lin, phase = ph, n_cells = sum(idx, na.rm = TRUE),
        group_composition = paste(names(tab_group), sprintf("%.3f", as.numeric(tab_group)), sep = ":", collapse = ";"),
        top_celltypes = paste(head(names(sort(tab_type, decreasing = TRUE)), 5),
                              sprintf("%.3f", head(as.numeric(sort(tab_type, decreasing = TRUE)), 5)), sep = ":", collapse = ";"),
        stringsAsFactors = FALSE)
    }
  }
  result_df <- do.call(rbind, results)
  result_df$BH_FDR <- p.adjust(result_df$sample_wilcox_p, method = "BH")
  list(signatures = result_df, genes = do.call(rbind, gene_results), composition = do.call(rbind, composition))
}

make_boot_weights <- function(n, b) {
  w <- matrix(0, nrow = n, ncol = b)
  for (j in seq_len(b)) w[, j] <- tabulate(sample.int(n, n, replace = TRUE), nbins = n) / n
  w
}

tf_scores <- function(effect_matrix, network, tf_names) {
  point <- list()
  for (tf in tf_names) {
    net <- network[network$source == tf & network$target %in% rownames(effect_matrix), ]
    if (nrow(net) < 5) next
    net <- aggregate(mor ~ target, net, mean)
    e <- effect_matrix[net$target, , drop = FALSE]
    mor <- net$mor
    weighted_mean <- colSums(e * mor) / sum(abs(mor))
    centered_mor <- mor - mean(mor)
    ulm_slope <- colSums(e * centered_mor) / sum(centered_mor^2)
    vote <- colMeans(sign(e) == sign(mor)) - 0.5
    point[[tf]] <- list(n_targets = nrow(net), weighted_mean = weighted_mean, ulm_slope = ulm_slope, vote = vote)
  }
  point
}

analyze_tf <- function(x, network_path, summary_path, b = 500) {
  expr <- x$pseudobulk_logcpm
  meta <- x$pseudobulk_meta
  rownames(meta) <- meta$pb_id
  meta <- meta[colnames(expr), ]
  net <- read.csv(network_path, check.names = FALSE)
  net <- net[is.finite(net$mor), c("source", "target", "mor")]
  original <- read.csv(summary_path, check.names = FALSE)
  tf_names <- intersect(original$TF, unique(net$source))

  if (x$dataset == "adult") {
    ia <- which(meta$group == "AML")
    ib <- which(meta$group == "BM")
    point_effect <- rowMeans(expr[, ia, drop = FALSE]) - rowMeans(expr[, ib, drop = FALSE])
    effect_boot <- expr[, ia, drop = FALSE] %*% make_boot_weights(length(ia), b) -
      expr[, ib, drop = FALSE] %*% make_boot_weights(length(ib), b)
    original_diff <- setNames(original$AML_vs_BM_diff, original$TF)
    replicate_info <- paste0(length(ia), " AML pseudobulk samples vs ", length(ib), " BM pseudobulk samples")
  } else {
    malignant <- meta[meta$group == "malignant", ]
    micro <- meta[meta$group == "microenvironment", ]
    paired <- intersect(malignant$sample, micro$sample)
    ia <- match(paired, malignant$sample)
    ib <- match(paired, micro$sample)
    ma <- match(malignant$pb_id[ia], colnames(expr))
    mi <- match(micro$pb_id[ib], colnames(expr))
    diff <- expr[, ma, drop = FALSE] - expr[, mi, drop = FALSE]
    point_effect <- rowMeans(diff)
    effect_boot <- diff %*% make_boot_weights(ncol(diff), b)
    original_diff <- setNames(original$Malig_vs_Micro_diff, original$TF)
    replicate_info <- paste0(length(paired), " paired pediatric samples")
  }
  point_matrix <- matrix(point_effect, ncol = 1, dimnames = list(names(point_effect), "point"))
  point_scores <- tf_scores(point_matrix, net, tf_names)
  boot_scores <- tf_scores(effect_boot, net, tf_names)
  rows <- lapply(names(point_scores), function(tf) {
    p <- point_scores[[tf]]
    z <- boot_scores[[tf]]
    metric_rows <- lapply(c("weighted_mean", "ulm_slope", "vote"), function(metric) {
      boot <- z[[metric]]
      point <- p[[metric]][1]
      prop_pos <- mean(boot > 0)
      data.frame(
        dataset = x$dataset, TF = tf, metric = metric, n_targets = p$n_targets,
        score = point, bootstrap_lo = quantile(boot, 0.025), bootstrap_hi = quantile(boot, 0.975),
        bootstrap_positive_fraction = prop_pos,
        bootstrap_two_sided_p = min(1, 2 * min(prop_pos, 1 - prop_pos)),
        original_cell_level_difference = original_diff[[tf]], replicate_info = replicate_info,
        stringsAsFactors = FALSE)
    })
    do.call(rbind, metric_rows)
  })
  ans <- do.call(rbind, rows)
  ans$BH_FDR <- p.adjust(ans$bootstrap_two_sided_p, method = "BH")
  ans
}

adult <- readRDS(file.path(out, "01_adult_compact.rds"))
pediatric <- readRDS(file.path(out, "01_pediatric_compact.rds"))

adult_root <- analyze_root(adult)
pediatric_root <- analyze_root(pediatric)
write_tsv(rbind(adult_root$root, pediatric_root$root), "03_root_sensitivity.tsv")
write_tsv(rbind(adult_root$clusters, pediatric_root$clusters), "03_cluster_marker_summary.tsv")
write_tsv(rbind(adult_root$edges, pediatric_root$edges), "03_fixed_topology_edges.tsv")

adult_end <- analyze_endpoints(adult, c("Lineage1", "Lineage3", "Lineage4", "Lineage5"))
pediatric_end <- analyze_endpoints(pediatric, c("Lineage1", "Lineage2", "Lineage3", "Lineage4"))
write_tsv(rbind(adult_end$signatures, pediatric_end$signatures), "04_endpoint_signature_summary.tsv")
write_tsv(rbind(adult_end$genes, pediatric_end$genes), "04_endpoint_gene_summary.tsv")
write_tsv(rbind(adult_end$composition, pediatric_end$composition), "04_endpoint_composition.tsv")

adult_tf <- analyze_tf(
  adult,
  file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J5_decoupleR/Results/collectri_human_regulons.csv"),
  file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J5_decoupleR/Results/key_TF_activity_summary.csv")
)
pediatric_tf <- analyze_tf(
  pediatric,
  file.path(root, "AML_Lactylation_PCD/scRNA/GSE185381/J13_decoupleR/Results/collectri_human_regulons.csv"),
  file.path(root, "AML_Lactylation_PCD/scRNA/GSE185381/J13_decoupleR/Results/key_TF_activity_summary.csv")
)
write_tsv(rbind(adult_tf, pediatric_tf), "05_tf_pseudobulk_sensitivity.tsv")

summary <- c(
  "status=passed",
  "method_root=fixed saved Slingshot topology re-rooting on UMAP cluster-centroid edge lengths; no curve refit",
  "method_endpoint=early/late pseudotime deciles with lineage weight >=0.5; sample-paired signature deltas",
  "method_tf=CollecTRI target consistency on donor/sample pseudobulk using signed weighted mean, ULM slope and signed-target vote",
  "bootstrap=500; seed=20260802",
  "SCENIC=not run",
  paste0("adult_dimensions=", paste(adult$dimensions, collapse = "x")),
  paste0("pediatric_dimensions=", paste(pediatric$dimensions, collapse = "x"))
)
writeLines(summary, file.path(out, "03_05_analysis_summary.txt"), useBytes = TRUE)
writeLines(capture.output(sessionInfo()), file.path(out, "03_05_session_info.txt"), useBytes = TRUE)
cat("lightweight_sc_supplements_passed\n")

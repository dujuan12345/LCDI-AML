# Versioned adaptation; generator and original retained.
options(stringsAsFactors = FALSE, warn = 1, width = 180)

root <- "D:/26_01_AML"
mode <- commandArgs(trailingOnly=TRUE)[1]
stopifnot(mode %in% c("D0", "patient_mean"))
out <- file.path(root, "_codex_audit/upstream_repair_20260905_v1", paste0("state_", mode))
dir.create(out, showWarnings=FALSE)
adult_path <- file.path(root, "_codex_audit/chapter8_lightweight_supplements_20260802_v1/01_adult_compact.rds")
pediatric_path <- file.path(root, "_codex_audit/chapter8_lightweight_supplements_20260802_v1/01_pediatric_compact.rds")
geneset_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/genesets_used.rds")
seed <- 20260905L
B <- 2000L
set.seed(seed)

stopifnot(dir.exists(out), file.exists(adult_path), file.exists(pediatric_path), file.exists(geneset_path))
status_path <- file.path(out, "01_run_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed analysis: ", status_path)

log_con <- file(file.path(out, "01_run.log"), open = "wt", encoding = "UTF-8")
sink(log_con, split = TRUE)
sink(log_con, type = "message")
on.exit({
  try(sink(type = "message"), silent = TRUE)
  try(sink(), silent = TRUE)
  try(close(log_con), silent = TRUE)
}, add = TRUE)

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", row.names = FALSE, col.names = TRUE,
              quote = FALSE, na = "NA", fileEncoding = "UTF-8")
}

zscore <- function(x) {
  s <- sd(x, na.rm = TRUE)
  if (!is.finite(s) || s <= 0) return(rep(0, length(x)))
  as.numeric((x - mean(x, na.rm = TRUE)) / s)
}

safe_rho <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 4L || sd(x[ok]) == 0 || sd(y[ok]) == 0) return(NA_real_)
  suppressWarnings(cor(x[ok], y[ok], method = "spearman"))
}

safe_p <- function(x, y) {
  ok <- is.finite(x) & is.finite(y)
  if (sum(ok) < 4L || sd(x[ok]) == 0 || sd(y[ok]) == 0) return(NA_real_)
  suppressWarnings(cor.test(x[ok], y[ok], method = "spearman", exact = FALSE)$p.value)
}

quant <- function(x, p) {
  if (all(!is.finite(x))) return(NA_real_)
  as.numeric(quantile(x[is.finite(x)], p, names = FALSE, type = 8))
}

bh_within <- function(df, group_cols, p_col = "p_value") {
  df$fdr <- NA_real_
  key <- interaction(df[group_cols], drop = TRUE, lex.order = TRUE)
  for (lev in levels(key)) {
    idx <- which(key == lev & is.finite(df[[p_col]]))
    if (length(idx)) df$fdr[idx] <- p.adjust(df[[p_col]][idx], method = "BH")
  }
  df
}

beta <- c(CREB1 = 0.0925, SLC16A4 = -0.0636, GPX4 = -0.0721,
          CASP1 = -0.0106, MPO = -0.2095)
model_genes <- names(beta)
marker_map <- c(
  MPO = "MPO", ITGAM = "CD11b / ITGAM", CD14 = "CD14",
  FUT4 = "CD15 / FUT4", CD34 = "CD34", KIT = "CD117 / KIT", MKI67 = "Ki-67 / MKI67"
)
pathway_map <- c(
  HALLMARK_MYC_TARGETS_V1 = "MYC targets V1",
  HALLMARK_E2F_TARGETS = "E2F targets",
  HALLMARK_G2M_CHECKPOINT = "G2M checkpoint",
  HALLMARK_MTORC1_SIGNALING = "mTORC1 signaling",
  HALLMARK_OXIDATIVE_PHOSPHORYLATION = "Oxidative phosphorylation",
  HALLMARK_GLYCOLYSIS = "Glycolysis",
  HALLMARK_DNA_REPAIR = "DNA repair"
)
genesets <- readRDS(geneset_path)
stopifnot(all(names(pathway_map) %in% names(genesets)))

prepare_dataset <- function(path, dataset, target_group) {
  x <- readRDS(path)
  expr <- x$pseudobulk_logcpm
  meta <- x$pseudobulk_meta
  stopifnot(is.matrix(expr), is.data.frame(meta), identical(colnames(expr), meta$pb_id))
  if (anyDuplicated(meta$pb_id)) stop(dataset, ": duplicated pseudobulk ID")
  if (!all(c(model_genes, names(marker_map)) %in% rownames(expr))) stop(dataset, ": missing target genes")
  keep <- meta$group == target_group
  if (sum(keep) < 10L) stop(dataset, ": fewer than 10 target-group pseudobulks")
  expr <- expr[, keep, drop = FALSE]
  meta <- meta[keep, , drop = FALSE]
  stopifnot(identical(colnames(expr), meta$pb_id), !anyDuplicated(meta$sample))

  if (dataset == "adult") {
    idmap <- read.delim(file.path(root,"_codex_audit/unused_results_audit_20260905_v1/04_adult_sample_patient_mapping.tsv"),fileEncoding="UTF-8-BOM")
    meta$sample <- trimws(meta$sample)
    meta$patient <- idmap$patient[match(meta$sample,idmap$sample)]
    stopifnot(!anyNA(meta$patient),length(unique(meta$patient))==16L)
    meta$baseline <- grepl("-D0$", meta$sample)
    write_tsv(meta,"01_adult_visit_inclusion.tsv")
    if(mode == "D0") {
      expr <- expr[,meta$baseline,drop=FALSE]; meta<-meta[meta$baseline,,drop=FALSE]
    } else {
      patients<-unique(meta$patient)
      expr<-sapply(patients,function(p)rowMeans(expr[,meta$patient==p,drop=FALSE]))
      meta<-data.frame(pb_id=patients,sample=patients,patient=patients,group="AML",
                       library_size=sapply(patients,function(p)sum(meta$library_size[meta$patient==p])))
      colnames(expr)<-meta$pb_id
    }
    stopifnot(nrow(meta)==16L,!anyDuplicated(meta$patient),identical(colnames(expr),meta$pb_id))
  }
  needed <- unique(c(model_genes, names(marker_map), unlist(genesets[names(pathway_map)])))
  needed <- intersect(needed, rownames(expr))
  zmat <- t(apply(expr[needed, , drop = FALSE], 1, zscore))
  rownames(zmat) <- needed
  colnames(zmat) <- colnames(expr)

  score_raw <- as.numeric(t(zmat[model_genes, , drop = FALSE]) %*% beta)
  mpo_raw <- as.numeric(zmat["MPO", ] * beta["MPO"])
  nonmpo_raw <- as.numeric(t(zmat[setdiff(model_genes, "MPO"), , drop = FALSE]) %*% beta[setdiff(model_genes, "MPO")])
  if (max(abs(score_raw - mpo_raw - nonmpo_raw)) > 1e-12) stop(dataset, ": component decomposition failed")

  unit <- data.frame(
    dataset = dataset, sample = meta$sample, pb_id = meta$pb_id,
    group = meta$group, library_size = meta$library_size,
    LCDI_z = zscore(score_raw), MPO_risk_z = zscore(mpo_raw),
    nonMPO_risk_z = zscore(nonmpo_raw), stringsAsFactors = FALSE
  )

  endpoints <- list()
  coverage <- list()
  for (gene in names(marker_map)) {
    endpoints[[length(endpoints) + 1L]] <- data.frame(
      dataset = dataset, sample = meta$sample, endpoint_id = gene,
      endpoint = unname(marker_map[gene]), family = "marker",
      value = as.numeric(zmat[gene, ]), value_median_sensitivity = NA_real_,
      genes_available = 1L, genes_total = 1L,
      self_coupled = gene == "MPO", stringsAsFactors = FALSE
    )
  }
  for (set_id in names(pathway_map)) {
    original <- unique(as.character(genesets[[set_id]]))
    after_model_exclusion <- setdiff(original, model_genes)
    available <- intersect(after_model_exclusion, rownames(zmat))
    variable <- available[apply(zmat[available, , drop = FALSE], 1, sd) > 0]
    if (length(variable) < 15L) stop(dataset, ": insufficient genes for ", set_id)
    mean_score <- colMeans(zmat[variable, , drop = FALSE])
    median_score <- apply(zmat[variable, , drop = FALSE], 2, median)
    endpoints[[length(endpoints) + 1L]] <- data.frame(
      dataset = dataset, sample = meta$sample, endpoint_id = set_id,
      endpoint = unname(pathway_map[set_id]), family = "pathway",
      value = zscore(mean_score), value_median_sensitivity = zscore(median_score),
      genes_available = length(variable), genes_total = length(original),
      self_coupled = FALSE, stringsAsFactors = FALSE
    )
    coverage[[length(coverage) + 1L]] <- data.frame(
      dataset = dataset, endpoint_id = set_id, endpoint = unname(pathway_map[set_id]),
      genes_original = length(original), genes_after_model_exclusion = length(after_model_exclusion),
      genes_available = length(available), genes_variable = length(variable),
      excluded_model_genes = paste(intersect(original, model_genes), collapse = ";"),
      stringsAsFactors = FALSE
    )
  }

  endpoint_long <- do.call(rbind, endpoints)
  endpoint_wide <- reshape(endpoint_long[, c("sample", "endpoint_id", "value")],
                           idvar = "sample", timevar = "endpoint_id", direction = "wide")
  names(endpoint_wide) <- sub("^value\\.", "", names(endpoint_wide))
  unit <- merge(unit, endpoint_wide, by = "sample", all.x = TRUE, sort = FALSE)
  unit <- unit[match(meta$sample, unit$sample), ]
  stopifnot(identical(unit$sample, meta$sample), !anyNA(unit[, c("LCDI_z", "MPO_risk_z", "nonMPO_risk_z")]))

  qc <- data.frame(
    dataset = dataset, input_path = normalizePath(path, winslash = "/"),
    object_genes = nrow(x$pseudobulk_logcpm), object_pseudobulks = ncol(x$pseudobulk_logcpm),
    all_groups = paste(names(table(x$pseudobulk_meta$group)), as.integer(table(x$pseudobulk_meta$group)), sep = ":", collapse = ";"),
    target_group = target_group, included_units = nrow(unit), duplicate_sample_ids = anyDuplicated(unit$sample),
    missing_target_values = sum(!is.finite(as.matrix(unit[, c("LCDI_z", "MPO_risk_z", "nonMPO_risk_z", names(marker_map), names(pathway_map)), drop = FALSE]))),
    min_library_size = min(unit$library_size), median_library_size = median(unit$library_size),
    max_component_decomposition_error = max(abs(score_raw - mpo_raw - nonmpo_raw)),
    stringsAsFactors = FALSE
  )
  list(unit = unit, endpoint_long = endpoint_long, coverage = do.call(rbind, coverage), qc = qc)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
adult <- prepare_dataset(adult_path, "adult", "AML")
pediatric <- prepare_dataset(pediatric_path, "pediatric", "malignant")
units <- rbind(adult$unit, pediatric$unit)
endpoint_long <- rbind(adult$endpoint_long, pediatric$endpoint_long)
coverage <- rbind(adult$coverage, pediatric$coverage)
input_qc <- rbind(adult$qc, pediatric$qc)

association_rows <- list()
delta_rows <- list()
loo_rows <- list()
sensitivity_rows <- list()
predictors <- c("LCDI_z", "MPO_risk_z")

for (dataset in c("adult", "pediatric")) {
  u <- units[units$dataset == dataset, , drop = FALSE]
  e <- endpoint_long[endpoint_long$dataset == dataset, , drop = FALSE]
  for (endpoint_id in unique(e$endpoint_id)) {
    ee <- e[e$endpoint_id == endpoint_id, , drop = FALSE]
    ee <- ee[match(u$sample, ee$sample), ]
    stopifnot(identical(u$sample, ee$sample))
    y <- ee$value
    n <- length(y)
    boot_index <- replicate(B, sample.int(n, n, replace = TRUE), simplify = FALSE)
    boot_lcdi <- vapply(boot_index, function(ii) safe_rho(u$LCDI_z[ii], y[ii]), numeric(1))
    boot_mpo <- vapply(boot_index, function(ii) safe_rho(u$MPO_risk_z[ii], y[ii]), numeric(1))
    boot_delta <- abs(boot_lcdi) - abs(boot_mpo)

    for (pred in predictors) {
      x <- u[[pred]]
      rho <- safe_rho(x, y)
      p <- safe_p(x, y)
      boots <- if (pred == "LCDI_z") boot_lcdi else boot_mpo
      loo <- vapply(seq_len(n), function(i) safe_rho(x[-i], y[-i]), numeric(1))
      stable <- mean(sign(loo[is.finite(loo)]) == sign(rho))
      association_rows[[length(association_rows) + 1L]] <- data.frame(
        dataset = dataset, endpoint_id = endpoint_id, endpoint = ee$endpoint[1], family = ee$family[1],
        predictor = pred, n = n, rho = rho, p_value = p,
        bootstrap_ci_low = quant(boots, 0.025), bootstrap_ci_high = quant(boots, 0.975),
        loo_direction_stability = stable, loo_min_rho = min(loo, na.rm = TRUE), loo_max_rho = max(loo, na.rm = TRUE),
        genes_available = ee$genes_available[1], genes_total = ee$genes_total[1],
        self_coupled = ee$self_coupled[1], stringsAsFactors = FALSE
      )
      loo_rows[[length(loo_rows) + 1L]] <- data.frame(
        dataset = dataset, endpoint_id = endpoint_id, predictor = pred,
        omitted_sample = u$sample, rho = loo, stringsAsFactors = FALSE
      )
      if (ee$family[1] == "pathway") {
        ymed <- ee$value_median_sensitivity
        sensitivity_rows[[length(sensitivity_rows) + 1L]] <- data.frame(
          dataset = dataset, endpoint_id = endpoint_id, endpoint = ee$endpoint[1], predictor = pred,
          mean_z_rho = rho, median_z_rho = safe_rho(x, ymed),
          same_direction = sign(rho) == sign(safe_rho(x, ymed)), stringsAsFactors = FALSE
        )
      }
    }
    delta_p <- NA_real_ # No null-calibrated bootstrap hypothesis test was performed
    delta_rows[[length(delta_rows) + 1L]] <- data.frame(
      dataset = dataset, endpoint_id = endpoint_id, endpoint = ee$endpoint[1], family = ee$family[1], n = n,
      rho_LCDI = safe_rho(u$LCDI_z, y), rho_MPO = safe_rho(u$MPO_risk_z, y),
      delta_abs_rho = abs(safe_rho(u$LCDI_z, y)) - abs(safe_rho(u$MPO_risk_z, y)),
      bootstrap_ci_low = quant(boot_delta, 0.025), bootstrap_ci_high = quant(boot_delta, 0.975),
      bootstrap_p_value = min(delta_p, 1), self_coupled = ee$self_coupled[1], stringsAsFactors = FALSE
    )
  }
}

associations <- do.call(rbind, association_rows)
associations <- bh_within(associations, c("dataset", "predictor", "family"))
deltas <- do.call(rbind, delta_rows)
deltas <- bh_within(deltas, c("dataset", "family"), "bootstrap_p_value")
names(deltas)[names(deltas) == "fdr"] <- "bootstrap_fdr"
loo <- do.call(rbind, loo_rows)
sensitivity <- do.call(rbind, sensitivity_rows)

increment_rows <- list()
for (dataset in c("adult", "pediatric")) {
  u <- units[units$dataset == dataset, , drop = FALSE]
  e <- endpoint_long[endpoint_long$dataset == dataset & endpoint_long$family == "pathway", , drop = FALSE]
  for (endpoint_id in unique(e$endpoint_id)) {
    ee <- e[e$endpoint_id == endpoint_id, ]
    ee <- ee[match(u$sample, ee$sample), ]
    dat <- data.frame(y = ee$value, MPO = u$MPO_risk_z, nonMPO = u$nonMPO_risk_z)
    base <- lm(y ~ MPO, data = dat)
    full <- lm(y ~ MPO + nonMPO, data = dat)
    sm <- summary(full)$coefficients
    a <- anova(base, full)
    increment_rows[[length(increment_rows) + 1L]] <- data.frame(
      dataset = dataset, endpoint_id = endpoint_id, endpoint = ee$endpoint[1], n = nrow(dat),
      nonMPO_beta = sm["nonMPO", "Estimate"], nonMPO_se = sm["nonMPO", "Std. Error"],
      nonMPO_p_value = sm["nonMPO", "Pr(>|t|)"], incremental_F_p_value = a$`Pr(>F)`[2],
      adjusted_R2_base = summary(base)$adj.r.squared, adjusted_R2_full = summary(full)$adj.r.squared,
      delta_adjusted_R2 = summary(full)$adj.r.squared - summary(base)$adj.r.squared,
      stringsAsFactors = FALSE
    )
  }
}
increments <- do.call(rbind, increment_rows)
increments$nonMPO_fdr <- ave(increments$nonMPO_p_value, increments$dataset, FUN = function(x) p.adjust(x, "BH"))

meta_rows <- list()
for (pred in predictors) {
  for (endpoint_id in unique(associations$endpoint_id)) {
    z <- associations[associations$predictor == pred & associations$endpoint_id == endpoint_id, ]
    if (nrow(z) != 2L) next
    r <- pmax(pmin(z$rho, 0.999999), -0.999999)
    fisher <- atanh(r)
    w <- pmax(z$n - 3, 1)
    pooled <- sum(w * fisher) / sum(w)
    se <- sqrt(1 / sum(w))
    zz <- pooled / se
    meta_rows[[length(meta_rows) + 1L]] <- data.frame(
      endpoint_id = endpoint_id, endpoint = z$endpoint[1], family = z$family[1], predictor = pred,
      adult_rho = z$rho[z$dataset == "adult"], pediatric_rho = z$rho[z$dataset == "pediatric"],
      direction_consistent = sign(z$rho[1]) == sign(z$rho[2]),
      pooled_rho = tanh(pooled), ci_low = tanh(pooled - 1.96 * se), ci_high = tanh(pooled + 1.96 * se),
      p_value = 2 * pnorm(-abs(zz)), self_coupled = any(z$self_coupled), stringsAsFactors = FALSE
    )
  }
}
meta <- do.call(rbind, meta_rows)
meta <- bh_within(meta, c("predictor", "family"))

delta_wide <- reshape(deltas[, c("endpoint_id", "dataset", "delta_abs_rho", "bootstrap_ci_low", "bootstrap_ci_high")],
                      idvar = "endpoint_id", timevar = "dataset", direction = "wide")
delta_gate <- merge(unique(deltas[, c("endpoint_id", "endpoint", "family", "self_coupled")]), delta_wide, by = "endpoint_id")
delta_gate$both_positive <- delta_gate$delta_abs_rho.adult > 0 & delta_gate$delta_abs_rho.pediatric > 0
delta_gate$at_least_one_ci_above_zero <- delta_gate$bootstrap_ci_low.adult > 0 | delta_gate$bootstrap_ci_low.pediatric > 0
delta_gate$strict_LCDI_advantage <- delta_gate$both_positive & delta_gate$at_least_one_ci_above_zero & !delta_gate$self_coupled

gate <- data.frame(
  criterion = c(
    "cross_dataset_consistent_FDR_lt_0.05_nonself_endpoints",
    "strict_LCDI_advantage_nonself_endpoints",
    "strict_LCDI_advantage_pathways",
    "nonMPO_increment_FDR_lt_0.05_both_datasets",
    "all_pathway_median_sensitivity_same_direction"
  ),
  value = c(
    sum(meta$direction_consistent & meta$fdr < 0.05 & !meta$self_coupled, na.rm = TRUE),
    sum(delta_gate$strict_LCDI_advantage, na.rm = TRUE),
    sum(delta_gate$strict_LCDI_advantage & delta_gate$family == "pathway", na.rm = TRUE),
    sum(tapply(increments$nonMPO_fdr < 0.05, increments$endpoint_id, function(x) length(x) == 2L && all(x))),
    all(sensitivity$same_direction)
  ),
  interpretation = c(
    "Count across both predictors; direction-concordant fixed-effect associations",
    "Both datasets delta>0 and at least one bootstrap CI entirely above 0; MPO self-endpoint excluded",
    "Same strict criterion restricted to pathways",
    "Pathways with non-MPO conditional association at FDR<0.05 in both datasets",
    "Mean-z primary and median-z sensitivity correlations have the same direction"
  ),
  stringsAsFactors = FALSE
)

write_tsv(input_qc, "02_input_qc.tsv")
write_tsv(coverage, "03_pathway_gene_coverage.tsv")
write_tsv(units, "04_unit_level_scores_and_endpoints.tsv")
write_tsv(associations, "05_association_results.tsv")
write_tsv(deltas, "06_LCDI_vs_MPO_delta_results.tsv")
write_tsv(loo, "07_leave_one_unit_out.tsv")
write_tsv(sensitivity, "08_pathway_score_sensitivity.tsv")
write_tsv(increments, "09_nonMPO_increment_models.tsv")
write_tsv(meta, "10_cross_dataset_meta.tsv")
write_tsv(delta_gate, "11_LCDI_advantage_gate_by_endpoint.tsv")
write_tsv(gate, "12_overall_gate_summary.tsv")


saveRDS(list(units=units,endpoints=endpoint_long,associations=associations,deltas=deltas,
             increments=increments,meta=meta,gate=gate,seed=seed,bootstrap=B,mode=mode),
        file.path(out,"13_state_analysis_results.rds"))
capture.output(sessionInfo(),file=file.path(out,"14_session_info.txt"))
write_tsv(data.frame(status="passed_computational_checks",adult_n=16,pediatric_n=22,
                    mode=mode,seed=seed,bootstrap=B,inference_unit="independent patient"),"01_run_status.tsv")
cat("COMPLETE",mode,format(Sys.time()),"\n")
sink(type="message");sink();close(log_con)

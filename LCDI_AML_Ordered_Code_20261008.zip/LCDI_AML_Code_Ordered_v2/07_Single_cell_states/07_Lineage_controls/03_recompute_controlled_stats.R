options(stringsAsFactors = FALSE, warn = 1)

out <- "D:/26_01_AML/_codex_audit/lineage_decomposition_20260828_v2"
result <- readRDS(file.path(out, "14_lineage_decomposition_results.rds"))
records <- result$records
assoc <- result$associations
deltas <- result$deltas
increments <- result$increments
meta <- result$meta

rho <- function(x, y) suppressWarnings(cor(x, y, method = "spearman"))
residualize <- function(x, unit, lineage, include_unit = TRUE) {
  d <- data.frame(x = x, unit = factor(unit), lineage = factor(lineage))
  if (include_unit) residuals(lm(x ~ unit + lineage, data = d)) else residuals(lm(x ~ lineage, data = d))
}

raw_diff <- lineage_diff <- controlled_diff <- numeric()
for (i in seq_len(nrow(assoc))) {
  z <- records[records$dataset == assoc$dataset[i], , drop = FALSE]
  x <- z[[assoc$predictor[i]]]
  y <- z[[assoc$endpoint_id[i]]]
  raw_diff <- c(raw_diff, abs(rho(x, y) - assoc$raw_record_rho[i]))
  lineage_diff <- c(lineage_diff, abs(rho(
    residualize(x, z$unit, z$lineage, FALSE),
    residualize(y, z$unit, z$lineage, FALSE)
  ) - assoc$lineage_adjusted_rho[i]))
  controlled_diff <- c(controlled_diff, abs(rho(
    residualize(x, z$unit, z$lineage, TRUE),
    residualize(y, z$unit, z$lineage, TRUE)
  ) - assoc$patient_and_lineage_controlled_rho[i]))
}

delta_diff <- numeric()
for (i in seq_len(nrow(deltas))) {
  z <- records[records$dataset == deltas$dataset[i], , drop = FALSE]
  y <- residualize(z[[deltas$endpoint_id[i]]], z$unit, z$lineage, TRUE)
  r_lcdi <- rho(residualize(z$LCDI_z, z$unit, z$lineage, TRUE), y)
  r_mpo <- rho(residualize(z$MPO_risk_z, z$unit, z$lineage, TRUE), y)
  delta_diff <- c(delta_diff, abs((abs(r_lcdi) - abs(r_mpo)) - deltas$delta_abs_rho[i]))
}

increment_diff <- numeric()
for (i in seq_len(nrow(increments))) {
  z <- records[records$dataset == increments$dataset[i], , drop = FALSE]
  d <- data.frame(y = z[[increments$endpoint_id[i]]], unit = factor(z$unit), lineage = factor(z$lineage),
                  MPO = z$MPO_risk_z, nonMPO = z$nonMPO_risk_z)
  base <- lm(y ~ unit + lineage + MPO, data = d)
  full <- lm(y ~ unit + lineage + MPO + nonMPO, data = d)
  sm <- summary(full)$coefficients
  increment_diff <- c(increment_diff,
    abs(sm["nonMPO", "Estimate"] - increments$nonMPO_beta[i]),
    abs(sm["nonMPO", "Std. Error"] - increments$nonMPO_se[i]),
    abs(sm["nonMPO", "Pr(>|t|)"] - increments$nonMPO_p_value[i]),
    abs(summary(base)$adj.r.squared - increments$adjusted_R2_base[i]),
    abs(summary(full)$adj.r.squared - increments$adjusted_R2_full[i])
  )
}

meta_diff <- numeric()
for (i in seq_len(nrow(meta))) {
  r <- pmax(pmin(c(meta$adult_rho[i], meta$pediatric_rho[i]), 0.999999), -0.999999)
  w <- c(length(unique(records$unit[records$dataset == "adult"])) - 3,
         length(unique(records$unit[records$dataset == "pediatric"])) - 3)
  pooled <- sum(w * atanh(r)) / sum(w)
  meta_diff <- c(meta_diff, abs(tanh(pooled) - meta$pooled_rho[i]))
}

checks <- data.frame(
  check = c("raw_rho", "lineage_adjusted_rho", "patient_lineage_controlled_rho", "delta_abs_rho", "increment_models", "meta_pooled_rho"),
  max_abs_difference = c(max(raw_diff), max(lineage_diff), max(controlled_diff), max(delta_diff), max(increment_diff), max(meta_diff)),
  tolerance = rep(1e-12, 6), stringsAsFactors = FALSE
)
checks$passed <- checks$max_abs_difference < checks$tolerance
write.table(checks, file.path(out, "03_baseR_recalculation_checks.tsv"), sep = "\t", quote = FALSE, row.names = FALSE)
if (!all(checks$passed)) stop("Independent base R recalculation failed")
cat("BASE_R_RECALCULATION_PASSED\n")

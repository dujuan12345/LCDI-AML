# ============================================================
# phaseJ3_FIX_continue.R
# 接续修复: tradeSeq fitGAM NA 问题
# 
# 问题诊断:
#   slingshot 推断出 9 条 lineage (cluster 太分散)
#   每个细胞只在 1-3 条 lineage 上, 其他 lineage 的 pseudotime = NA
#   tradeSeq fitGAM 不能处理 NA
# 
# 修复策略:
#   1. 只用 Lineage 1 (主轨迹, 15,824 细胞) 做 tradeSeq
#   2. fitGAM 只用有完整 pseudotime 的细胞
#   3. 控制基因数 (从 1000 降到 200, 加速 5 倍)
#   4. nknots=5 (vs 默认 6, 加速一些)
# 
# 前提: myeloid_obj + sce 都在内存里 (J3 跑到 Stage 4 失败)
# ============================================================

cat("============================================================\n")
cat("Phase J3 接续修复: tradeSeq fitGAM NA 问题\n")
cat("============================================================\n\n")

if (!exists("myeloid_obj") || !exists("sce")) {
  cat("内存里没有 myeloid_obj/sce, 从缓存加载...\n")
  
  cache_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/J3_pseudotime/Cache"
  
  if (file.exists(file.path(cache_path, "stage1_myeloid_seurat.rds"))) {
    myeloid_obj <- readRDS(file.path(cache_path, "stage1_myeloid_seurat.rds"))
    cat(sprintf("✓ myeloid_obj: %d 细胞\n", ncol(myeloid_obj)))
  }
  
  if (file.exists(file.path(cache_path, "stage2_sce_with_slingshot.rds"))) {
    sce <- readRDS(file.path(cache_path, "stage2_sce_with_slingshot.rds"))
    cat("✓ sce 加载\n")
  }
}

# 路径
project_dir <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA"
output_dir <- file.path(project_dir, "J3_pseudotime")
res_path <- file.path(output_dir, "Results")
fig_path <- file.path(output_dir, "Figures")
data_path <- file.path(output_dir, "Data")
cache_path <- file.path(output_dir, "Cache")

suppressPackageStartupMessages({
  library(Seurat)
  library(SingleCellExperiment)
  library(slingshot)
  library(tradeSeq)
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(RColorBrewer)
  library(viridis)
})

LCDI_coef <- c(CREB1=0.0925, SLC16A4=-0.0636, GPX4=-0.0721, CASP1=-0.0106, MPO=-0.2095)
LCDI_genes <- names(LCDI_coef)

white_theme <- theme(
  plot.background = element_rect(fill = "white", color = NA),
  panel.background = element_rect(fill = "white"))

cache_stage4 <- file.path(cache_path, "stage4_tradeseq_fitGAM_lineage1.rds")

# ─────────────────────────────────────────────
# 检查诊断: 9 条 lineage NA 模式
# ─────────────────────────────────────────────
cat("\n── 诊断 lineage NA 模式 ──\n\n")

pseudotime_mat <- slingPseudotime(sce)
cell_weights <- slingCurveWeights(sce)

cat(sprintf("Pseudotime 矩阵: %d 细胞 × %d lineage\n",
            nrow(pseudotime_mat), ncol(pseudotime_mat)))

# 每条 lineage 多少有效细胞
cat("\n各 lineage 的细胞数 + NA 比例:\n")
for (i in 1:ncol(pseudotime_mat)) {
  n_valid <- sum(!is.na(pseudotime_mat[, i]))
  pct <- round(100 * n_valid / nrow(pseudotime_mat), 1)
  cat(sprintf("  Lineage %d: %d 有效, %.1f%% (NA: %d)\n",
              i, n_valid, pct, nrow(pseudotime_mat) - n_valid))
}

# 分析: 主轨迹 (Lineage 1)
cat("\n选择 Lineage 1 作为主轨迹 (覆盖最多细胞)\n")

# ─────────────────────────────────────────────
# 修复策略: 只用 Lineage 1 + 完整细胞
# ─────────────────────────────────────────────
cat("\n── 修复: 只用 Lineage 1 跑 tradeSeq ──\n\n")

# 提取 Lineage 1 的 pseudotime 和 weights
pt_l1 <- pseudotime_mat[, 1]
wt_l1 <- cell_weights[, 1]

# 找出有效细胞 (pseudotime 不为 NA)
valid_cells <- !is.na(pt_l1)
n_valid <- sum(valid_cells)
cat(sprintf("Lineage 1 有效细胞: %d / %d (%.1f%%)\n",
            n_valid, length(valid_cells),
            100 * n_valid / length(valid_cells)))

# 只保留有效细胞
pt_l1_clean <- pt_l1[valid_cells]
wt_l1_clean <- wt_l1[valid_cells]
valid_cell_names <- colnames(myeloid_obj)[valid_cells]

# ─────────────────────────────────────────────
# 准备 counts 矩阵 (只 valid 细胞)
# ─────────────────────────────────────────────
cat("\n── 准备 tradeSeq 输入 ──\n\n")

# 减少基因数: 5 LCDI + top 200 HVG (加速 5 倍)
hvg_top200 <- head(VariableFeatures(myeloid_obj), 200)
genes_for_ts <- unique(c(LCDI_genes, hvg_top200))
genes_for_ts <- intersect(genes_for_ts, rownames(myeloid_obj))

cat(sprintf("用于 tradeSeq 的基因: %d (5 LCDI + top 200 HVG)\n", 
            length(genes_for_ts)))

# 只取 valid cells 的 counts
counts_for_ts <- as.matrix(
  GetAssayData(myeloid_obj, layer = "counts")[genes_for_ts, valid_cell_names])

cat(sprintf("Counts 矩阵: %d 基因 × %d 细胞\n",
            nrow(counts_for_ts), ncol(counts_for_ts)))

# ─────────────────────────────────────────────
# 跑 fitGAM (单 lineage 版)
# ─────────────────────────────────────────────
if (file.exists(cache_stage4)) {
  cat("\n从缓存加载 fitGAM 结果...\n")
  sce_tradeseq <- readRDS(cache_stage4)
  cat("✓ tradeSeq 加载\n")
} else {
  cat("\n跑 fitGAM (单 lineage, ~10-20 分钟)...\n")
  cat(sprintf("  开始: %s\n", Sys.time()))
  
  set.seed(42)
  
  sce_tradeseq <- tryCatch({
    tradeSeq::fitGAM(
      counts = counts_for_ts,
      pseudotime = pt_l1_clean,        # 单 lineage 1D 向量
      cellWeights = wt_l1_clean,
      nknots = 5,                      # 减一个加速
      verbose = TRUE,
      parallel = FALSE
    )
  }, error = function(e) {
    cat(sprintf("\n仍失败: %s\n", e$message))
    cat("尝试更少基因 (只 5 LCDI)...\n")
    
    counts_lcdi <- counts_for_ts[LCDI_genes, ]
    tradeSeq::fitGAM(
      counts = counts_lcdi,
      pseudotime = pt_l1_clean,
      cellWeights = wt_l1_clean,
      nknots = 5,
      verbose = TRUE,
      parallel = FALSE
    )
  })
  
  cat(sprintf("  完成: %s\n", Sys.time()))
  cat("✓ fitGAM 完成\n")
  
  saveRDS(sce_tradeseq, cache_stage4)
  cat(sprintf("✓ 缓存: %s\n", cache_stage4))
}

# ─────────────────────────────────────────────
# associationTest
# ─────────────────────────────────────────────
cat("\n── associationTest: 找显著动态基因 ──\n\n")

assoc_res <- tradeSeq::associationTest(sce_tradeseq)
assoc_res$gene <- rownames(assoc_res)
assoc_res$padj <- p.adjust(assoc_res$pvalue, method = "BH")
assoc_res <- assoc_res %>% arrange(pvalue)

write.csv(assoc_res, file.path(res_path, "tradeSeq_associationTest.csv"),
          row.names = FALSE)

cat(sprintf("显著基因 (padj < 0.05): %d / %d\n",
            sum(assoc_res$padj < 0.05, na.rm=TRUE),
            nrow(assoc_res)))

cat("\nTop 20 动态基因:\n")
print(head(assoc_res[, c("gene", "waldStat", "pvalue", "padj")], 20))

# 5 LCDI 基因的结果
cat("\n5 LCDI 基因的动态性:\n")
lcdi_assoc <- assoc_res[assoc_res$gene %in% LCDI_genes, ]
print(lcdi_assoc[, c("gene", "waldStat", "pvalue", "padj")])

# ─────────────────────────────────────────────
# FigJ3e: Top 6 动态基因 plotSmoothers
# ─────────────────────────────────────────────
cat("\n── FigJ3e: Top 6 动态基因 plotSmoothers ──\n\n")

top_dynamic <- head(assoc_res$gene[assoc_res$gene %in% rownames(sce_tradeseq)], 6)
cat(sprintf("Top 6: %s\n", paste(top_dynamic, collapse=", ")))

plot_list_dyn <- list()
for (g in top_dynamic) {
  p_g <- tryCatch({
    tradeSeq::plotSmoothers(sce_tradeseq, 
                              counts = counts_for_ts,
                              gene = g) +
      ggtitle(g) +
      white_theme +
      theme(plot.title = element_text(hjust = 0.5, size = 11, face = "bold"))
  }, error = function(e) {
    cat(sprintf("  画 %s 失败: %s\n", g, e$message))
    NULL
  })
  if (!is.null(p_g)) plot_list_dyn[[g]] <- p_g
}

if (length(plot_list_dyn) > 0) {
  p_dyn <- wrap_plots(plot_list_dyn, ncol = 3) +
    plot_annotation(
      title = "Top 6 Dynamic Genes (sorted by tradeSeq waldStat)",
      theme = theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
                    plot.background = element_rect(fill = "white", color = NA)))
  
  ggsave(file.path(fig_path, "FigJ3e_top_dynamic_genes.pdf"), p_dyn,
         width = 14, height = 8, bg = "white")
  ggsave(file.path(fig_path, "FigJ3e_top_dynamic_genes.png"), p_dyn,
         width = 14, height = 8, dpi = 200, bg = "white")
  cat("✓ FigJ3e_top_dynamic_genes\n")
}

# ─────────────────────────────────────────────
# FigJ3f: 5 LCDI 基因 plotSmoothers ⭐⭐⭐
# ─────────────────────────────────────────────
cat("\n── FigJ3f: 5 LCDI 基因 plotSmoothers ──\n\n")

plot_list_lcdi <- list()
for (g in LCDI_genes) {
  if (!g %in% rownames(sce_tradeseq)) {
    cat(sprintf("  %s 不在 tradeSeq 输出, 跳过\n", g))
    next
  }
  p_g <- tryCatch({
    tradeSeq::plotSmoothers(sce_tradeseq, 
                              counts = counts_for_ts,
                              gene = g) +
      ggtitle(sprintf("%s (β = %+.4f)", g, LCDI_coef[g])) +
      white_theme +
      theme(plot.title = element_text(hjust = 0.5, size = 11, face = "bold"))
  }, error = function(e) {
    cat(sprintf("  画 %s 失败: %s\n", g, e$message))
    NULL
  })
  if (!is.null(p_g)) plot_list_lcdi[[g]] <- p_g
}

if (length(plot_list_lcdi) > 0) {
  p_lcdi_smooth <- wrap_plots(plot_list_lcdi, ncol = 3) +
    plot_annotation(
      title = "LCDI 5 Genes: tradeSeq Smoothed Expression along Pseudotime",
      theme = theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
                    plot.background = element_rect(fill = "white", color = NA)))
  
  ggsave(file.path(fig_path, "FigJ3f_5genes_smoothers.pdf"), p_lcdi_smooth,
         width = 14, height = 8, bg = "white")
  ggsave(file.path(fig_path, "FigJ3f_5genes_smoothers.png"), p_lcdi_smooth,
         width = 14, height = 8, dpi = 200, bg = "white")
  cat("✓ FigJ3f_5genes_smoothers\n")
}

# ─────────────────────────────────────────────
# FigJ3g: 双轨迹 normal vs malignant LCDI
# ─────────────────────────────────────────────
cat("\n── FigJ3g: normal vs malignant LCDI 沿伪时间 ──\n\n")

# 用 Lineage 1 的 valid 细胞
malig_pt_df <- data.frame(
  cell = valid_cell_names,
  pseudotime = pt_l1_clean,
  LCDI_score = myeloid_obj$LCDI_score[valid_cells],
  CellType = myeloid_obj$CellType[valid_cells],
  stringsAsFactors = FALSE
) %>%
  mutate(Group = case_when(
    grepl("-like$", CellType) ~ "malignant",
    TRUE ~ "normal"
  ))

cat(sprintf("Lineage 1 数据: %d 细胞\n", nrow(malig_pt_df)))
cat("Group 分布:\n")
print(table(malig_pt_df$Group))

p_dual_lcdi <- ggplot(malig_pt_df, 
                      aes(x = pseudotime, y = LCDI_score, color = Group)) +
  geom_point(size = 0.2, alpha = 0.2) +
  geom_smooth(method = "loess", span = 0.3, se = TRUE, linewidth = 1.2) +
  scale_color_manual(values = c("normal" = "#0072B2", "malignant" = "#D55E00")) +
  ggtitle("LCDI Score along Pseudotime (Lineage 1): Normal vs Malignant") +
  xlab("Pseudotime") + ylab("LCDI Score") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))

ggsave(file.path(fig_path, "FigJ3g_normal_vs_malig_LCDI.pdf"), p_dual_lcdi,
       width = 12, height = 6, bg = "white")
ggsave(file.path(fig_path, "FigJ3g_normal_vs_malig_LCDI.png"), p_dual_lcdi,
       width = 12, height = 6, dpi = 200, bg = "white")
cat("✓ FigJ3g_normal_vs_malig_LCDI\n")

# ─────────────────────────────────────────────
# 保存 + 总结
# ─────────────────────────────────────────────
cat("\n── 保存最终对象 ──\n\n")

saveRDS(myeloid_obj, file.path(data_path, "myeloid_obj_with_pseudotime.rds"))
cat("✓ myeloid_obj_with_pseudotime.rds\n")

cat("\n══════════════════════════════════════════════\n")
cat("Phase J3 完成\n")
cat("══════════════════════════════════════════════\n\n")

cat(sprintf("髓系细胞: %d\n", ncol(myeloid_obj)))
cat(sprintf("Lineage 数: %d (用主 Lineage 1 跑 tradeSeq)\n", ncol(pseudotime_mat)))
cat(sprintf("Lineage 1 细胞数: %d\n", n_valid))
cat(sprintf("\n动态基因 (padj<0.05): %d / %d\n",
            sum(assoc_res$padj < 0.05, na.rm=TRUE),
            nrow(assoc_res)))

# 5 LCDI 基因状态
cat("\n5 LCDI 基因动态性:\n")
for (i in 1:nrow(lcdi_assoc)) {
  cat(sprintf("  %s: waldStat=%.1f, padj=%.2e\n",
              lcdi_assoc$gene[i], lcdi_assoc$waldStat[i], lcdi_assoc$padj[i]))
}

cat("\n关键图:\n")
cat("  ⭐⭐⭐ FigJ3a (Stage 3 已生成)  髓系 UMAP + 轨迹 + LCDI\n")
cat("  ⭐⭐⭐ FigJ3b (Stage 3 已生成)  LCDI 沿伪时间\n")
cat("  ⭐⭐ FigJ3c (Stage 3 已生成)   5 基因沿伪时间\n")
cat("  ⭐ FigJ3d (Stage 3 已生成)    CellType 沿轴\n")
cat("  ⭐⭐⭐ FigJ3e (本次新生成)      Top 6 动态基因\n")
cat("  ⭐⭐⭐ FigJ3f (本次新生成)      5 LCDI 基因 GAM 平滑\n")
cat("  ⭐⭐⭐ FigJ3g (本次新生成)      normal vs malignant LCDI 双线\n")

cat(sprintf("\n输出: %s\n", output_dir))
cat("\n下一步: J4 关键细胞 + GSVA, 或 J9 GSE185381 验证\n")

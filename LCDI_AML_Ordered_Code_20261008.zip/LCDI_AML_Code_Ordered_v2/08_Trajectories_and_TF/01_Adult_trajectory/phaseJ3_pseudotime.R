# ============================================================
# phaseJ3_pseudotime.R
# Phase J3: 拟时序分析 (slingshot + tradeSeq)
# 
# 核心: 在髓系子集上推断分化轨迹, 投影 LCDI score 沿伪时间变化
# 
# 输入: D:/26_01_AML/AML_Lactylation_PCD/scRNA/J2_LCDI/Data/seurat_obj_with_LCDI.rds
# 输出: D:/26_01_AML/AML_Lactylation_PCD/scRNA/J3_pseudotime/
# 
# 流程:
#   Stage 1: 子集髓系 + 重新降维 (~5 分钟)
#   Stage 2: slingshot 推断轨迹 (~10 分钟)
#   Stage 3: 投影 LCDI + 5 基因沿伪时间 (~5 分钟)
#   Stage 4: tradeSeq 找动态基因 (~30-60 分钟, 计算密集!)
#   Stage 5: 双轨迹 normal vs malignant (~20 分钟)
# ============================================================

cat("============================================================\n")
cat("Phase J3: 拟时序分析 (slingshot + tradeSeq)\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

# ─────────────────────────────────────────────
# 路径
# ─────────────────────────────────────────────
project_dir <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA"
input_rds <- file.path(project_dir, "J2_LCDI/Data/seurat_obj_with_LCDI.rds")

output_dir <- file.path(project_dir, "J3_pseudotime")
res_path <- file.path(output_dir, "Results")
fig_path <- file.path(output_dir, "Figures")
data_path <- file.path(output_dir, "Data")
cache_path <- file.path(output_dir, "Cache")

for (p in c(output_dir, res_path, fig_path, data_path, cache_path)) {
  if (!dir.exists(p)) dir.create(p, recursive = TRUE)
}

setwd(project_dir)
options(future.globals.maxSize = 8 * 1024^3)

# ─────────────────────────────────────────────
# R 包
# ─────────────────────────────────────────────
suppressPackageStartupMessages({
  library(Seurat)
  library(SingleCellExperiment)
  library(slingshot)
  library(tradeSeq)
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(tidyr)
  library(RColorBrewer)
  library(viridis)
  library(BiocParallel)
})

cat("R 包就位:\n")
cat(sprintf("  Seurat: %s\n", packageVersion("Seurat")))
cat(sprintf("  slingshot: %s\n", packageVersion("slingshot")))
cat(sprintf("  tradeSeq: %s\n", packageVersion("tradeSeq")))

# 通用主题
white_theme <- theme(
  plot.background = element_rect(fill = "white", color = NA),
  panel.background = element_rect(fill = "white"))

# LCDI 系数
LCDI_coef <- c(CREB1=0.0925, SLC16A4=-0.0636, GPX4=-0.0721, CASP1=-0.0106, MPO=-0.2095)
LCDI_genes <- names(LCDI_coef)

# 缓存路径
cache_stage1 <- file.path(cache_path, "stage1_myeloid_seurat.rds")
cache_stage2 <- file.path(cache_path, "stage2_sce_with_slingshot.rds")
cache_stage4 <- file.path(cache_path, "stage4_tradeseq_fitGAM.rds")

# ============================================================
# Stage 1: 子集髓系 + 重新 PCA/UMAP (有缓存就跳过)
# ============================================================

if (file.exists(cache_stage1)) {
  cat("\n══ Stage 1: 从缓存加载髓系子集 ══\n\n")
  myeloid_obj <- readRDS(cache_stage1)
  cat(sprintf("✓ 髓系子集: %d 基因 × %d 细胞\n", 
              nrow(myeloid_obj), ncol(myeloid_obj)))
} else {
  cat("\n══ Stage 1: 子集髓系 + 重新降维 ══\n\n")
  
  # 加载完整 seurat
  cat("加载 J2 完整 seurat (含 LCDI)...\n")
  seurat_full <- readRDS(input_rds)
  cat(sprintf("✓ %d 基因 × %d 细胞\n", nrow(seurat_full), ncol(seurat_full)))
  
  # 髓系细胞类型
  myeloid_celltypes <- c(
    "HSC", "HSC-like", "Prog", "Prog-like",
    "GMP", "GMP-like", "ProMono", "ProMono-like",
    "Mono", "Mono-like", "cDC", "cDC-like", "pDC"
  )
  
  myeloid_celltypes <- intersect(myeloid_celltypes, unique(seurat_full$CellType))
  cat(sprintf("\n髓系 CellType: %s\n", paste(myeloid_celltypes, collapse=", ")))
  
  # 子集
  myeloid_cells <- which(seurat_full$CellType %in% myeloid_celltypes)
  cat(sprintf("髓系细胞: %d / %d (%.1f%%)\n",
              length(myeloid_cells), ncol(seurat_full),
              100 * length(myeloid_cells) / ncol(seurat_full)))
  
  myeloid_obj <- subset(seurat_full, cells = colnames(seurat_full)[myeloid_cells])
  cat(sprintf("✓ 髓系子集: %d 细胞\n", ncol(myeloid_obj)))
  
  rm(seurat_full); gc()
  
  # 重新跑 HVG + PCA + UMAP (子集独立)
  cat("\n重新跑降维 (子集)...\n")
  
  cat("FindVariableFeatures...\n")
  myeloid_obj <- FindVariableFeatures(myeloid_obj, selection.method = "vst",
                                        nfeatures = 2000, verbose = FALSE)
  
  cat("ScaleData...\n")
  myeloid_obj <- ScaleData(myeloid_obj, features = VariableFeatures(myeloid_obj),
                            verbose = FALSE)
  
  cat("RunPCA (npcs=30)...\n")
  myeloid_obj <- RunPCA(myeloid_obj, features = VariableFeatures(myeloid_obj),
                          npcs = 30, verbose = FALSE)
  
  cat("FindNeighbors + FindClusters...\n")
  myeloid_obj <- FindNeighbors(myeloid_obj, dims = 1:20, verbose = FALSE)
  myeloid_obj <- FindClusters(myeloid_obj, resolution = 0.5, verbose = FALSE)
  
  cat("RunUMAP...\n")
  myeloid_obj <- RunUMAP(myeloid_obj, dims = 1:20, verbose = FALSE)
  
  n_my_clu <- length(unique(myeloid_obj$seurat_clusters))
  cat(sprintf("✓ 子集聚类数: %d\n", n_my_clu))
  
  # 可视化子集 UMAP
  p_my_umap_ct <- DimPlot(myeloid_obj, reduction = "umap", group.by = "CellType",
                            label = TRUE, label.size = 3, repel = TRUE) +
    ggtitle("Myeloid Subset: van Galen CellType (re-embedded)") +
    white_theme
  
  p_my_umap_clu <- DimPlot(myeloid_obj, reduction = "umap", label = TRUE) +
    ggtitle(sprintf("Myeloid Subset: %d Clusters", n_my_clu)) +
    white_theme
  
  ggsave(file.path(fig_path, "FigJ3_pre_myeloid_UMAP.pdf"),
         p_my_umap_ct | p_my_umap_clu,
         width = 16, height = 7, bg = "white")
  ggsave(file.path(fig_path, "FigJ3_pre_myeloid_UMAP.png"),
         p_my_umap_ct | p_my_umap_clu,
         width = 16, height = 7, dpi = 200, bg = "white")
  cat("✓ FigJ3_pre_myeloid_UMAP\n")
  
  # 保存缓存
  saveRDS(myeloid_obj, cache_stage1)
  cat(sprintf("✓ Stage 1 缓存: %s\n", cache_stage1))
}

# ============================================================
# Stage 2: slingshot 推断轨迹
# ============================================================

if (file.exists(cache_stage2)) {
  cat("\n══ Stage 2: 从缓存加载 slingshot 结果 ══\n\n")
  sce <- readRDS(cache_stage2)
  cat("✓ slingshot 已加载\n")
} else {
  cat("\n══ Stage 2: slingshot 轨迹推断 ══\n\n")
  
  # 转换为 SCE
  cat("Seurat → SingleCellExperiment...\n")
  sce <- as.SingleCellExperiment(myeloid_obj)
  
  # ★ 关键: 用 PCA 跑 slingshot (UMAP 会扭曲, 论文不推荐)
  # start cluster: HSC 主导的 cluster
  
  # 找 HSC 占比最高的 cluster 作为起点
  hsc_cluster_table <- table(myeloid_obj$seurat_clusters,
                               myeloid_obj$CellType == "HSC")
  if ("TRUE" %in% colnames(hsc_cluster_table)) {
    hsc_pct <- hsc_cluster_table[, "TRUE"] / rowSums(hsc_cluster_table) * 100
    start_clus <- names(which.max(hsc_pct))
    cat(sprintf("HSC 占比最高的 cluster: %s (%.1f%% 是 HSC)\n",
                start_clus, max(hsc_pct)))
  } else {
    start_clus <- as.character(myeloid_obj$seurat_clusters[1])
    cat(sprintf("没找到 HSC, 用默认起点: %s\n", start_clus))
  }
  
  # 跑 slingshot
  cat("跑 slingshot (PCA 空间, 起点 = ", start_clus, ")...\n")
  
  sce <- slingshot(sce, 
                    clusterLabels = "seurat_clusters",
                    reducedDim = "PCA",
                    start.clus = start_clus,
                    approx_points = 150)  # 参数控制平滑程度
  
  cat("✓ slingshot 完成\n")
  
  # 检查输出
  pseudotime_mat <- slingPseudotime(sce)
  curve_weights <- slingCurveWeights(sce)
  n_lineages <- ncol(pseudotime_mat)
  
  cat(sprintf("\n推断出 %d 条 lineage\n", n_lineages))
  for (i in 1:n_lineages) {
    n_cells_lineage <- sum(!is.na(pseudotime_mat[, i]))
    cat(sprintf("  Lineage %d: %d 细胞, 伪时间范围 %.2f ~ %.2f\n",
                i, n_cells_lineage,
                min(pseudotime_mat[, i], na.rm=TRUE),
                max(pseudotime_mat[, i], na.rm=TRUE)))
  }
  
  # 加 pseudotime 到 myeloid_obj 的 metadata
  for (i in 1:n_lineages) {
    col_name <- paste0("pseudotime_lineage", i)
    myeloid_obj[[col_name]] <- pseudotime_mat[, i]
  }
  
  # 保存缓存
  saveRDS(sce, cache_stage2)
  cat(sprintf("✓ Stage 2 缓存: %s\n", cache_stage2))
}

# ============================================================
# Stage 3: 投影 LCDI + 5 基因沿伪时间 ⭐⭐⭐
# ============================================================

cat("\n══ Stage 3: LCDI + 5 基因沿伪时间投影 ══\n\n")

# 同步 metadata
pseudotime_mat <- slingPseudotime(sce)
n_lineages <- ncol(pseudotime_mat)

# 加 pseudotime 到 myeloid_obj
for (i in 1:n_lineages) {
  col_name <- paste0("pseudotime_lineage", i)
  myeloid_obj[[col_name]] <- pseudotime_mat[, i]
}

# 用 lineage 1 (主轨迹) 做主分析
myeloid_obj$pseudotime <- pseudotime_mat[, 1]

# ─── FigJ3a: 髓系 UMAP + 轨迹线 ───
cat("\n── FigJ3a: 髓系 UMAP + 轨迹 ──\n")

# 用 PCA 空间画轨迹 (slingshot 在 PCA 跑的)
# 但显示用 UMAP, 所以重画
umap_df <- as.data.frame(Embeddings(myeloid_obj, "umap"))
umap_df$pseudotime <- myeloid_obj$pseudotime
umap_df$CellType <- myeloid_obj$CellType
umap_df$LCDI_score <- myeloid_obj$LCDI_score

p_traj_umap <- ggplot(umap_df, aes(x = umap_1, y = umap_2, color = pseudotime)) +
  geom_point(size = 0.4, alpha = 0.7) +
  scale_color_viridis_c(option = "plasma", na.value = "lightgrey",
                          name = "Pseudotime") +
  ggtitle("Pseudotime Projection on Myeloid UMAP") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"))

p_traj_celltype <- ggplot(umap_df, aes(x = umap_1, y = umap_2, color = CellType)) +
  geom_point(size = 0.4, alpha = 0.7) +
  scale_color_manual(values = colorRampPalette(brewer.pal(11, "Spectral"))(length(unique(umap_df$CellType)))) +
  ggtitle("CellType (van Galen) on Myeloid UMAP") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"))

p_traj_lcdi <- ggplot(umap_df, aes(x = umap_1, y = umap_2, color = LCDI_score)) +
  geom_point(size = 0.4, alpha = 0.7) +
  scale_color_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                          midpoint = 0,
                          limits = quantile(umap_df$LCDI_score, c(0.05, 0.95)),
                          oob = scales::squish,
                          name = "LCDI") +
  ggtitle("LCDI Score on Myeloid UMAP") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"))

p_a_combined <- (p_traj_celltype | p_traj_umap) / (p_traj_lcdi | plot_spacer())

ggsave(file.path(fig_path, "FigJ3a_pseudotime_UMAP.pdf"), p_a_combined,
       width = 16, height = 12, bg = "white")
ggsave(file.path(fig_path, "FigJ3a_pseudotime_UMAP.png"), p_a_combined,
       width = 16, height = 12, dpi = 200, bg = "white")
cat("✓ FigJ3a_pseudotime_UMAP\n")

# ─── FigJ3b: LCDI 沿伪时间 ⭐⭐⭐ ───
cat("\n── FigJ3b: LCDI 沿伪时间 (论文 Fig 7E 候选) ──\n")

lcdi_pt_df <- data.frame(
  cell = colnames(myeloid_obj),
  pseudotime = myeloid_obj$pseudotime,
  LCDI_score = myeloid_obj$LCDI_score,
  CellType = myeloid_obj$CellType,
  stringsAsFactors = FALSE
) %>% filter(!is.na(pseudotime))

# 重要 CellType 标注 (用 median pseudotime 标位置)
ct_pt <- lcdi_pt_df %>%
  group_by(CellType) %>%
  summarise(med_pt = median(pseudotime),
            med_lcdi = median(LCDI_score),
            n = n()) %>%
  filter(n > 50) %>%
  arrange(med_pt)

p_lcdi_pt <- ggplot(lcdi_pt_df, aes(x = pseudotime, y = LCDI_score)) +
  geom_point(aes(color = CellType), size = 0.3, alpha = 0.4) +
  geom_smooth(method = "loess", span = 0.3, se = TRUE,
              color = "black", fill = "gray70") +
  scale_color_manual(values = colorRampPalette(brewer.pal(11, "Spectral"))(length(unique(lcdi_pt_df$CellType)))) +
  ggtitle("LCDI Score along Pseudotime (Lineage 1)") +
  xlab("Pseudotime (HSC → mature)") + ylab("LCDI Score") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
        legend.position = "right")

ggsave(file.path(fig_path, "FigJ3b_LCDI_along_pseudotime.pdf"), p_lcdi_pt,
       width = 12, height = 6, bg = "white")
ggsave(file.path(fig_path, "FigJ3b_LCDI_along_pseudotime.png"), p_lcdi_pt,
       width = 12, height = 6, dpi = 200, bg = "white")
cat("✓ FigJ3b_LCDI_along_pseudotime\n")

# ─── FigJ3c: 5 基因沿伪时间 ───
cat("\n── FigJ3c: 5 基因沿伪时间 ──\n")

expr_5g <- as.matrix(GetAssayData(myeloid_obj, layer = "data")[LCDI_genes, ])

gene_pt_list <- list()
for (g in LCDI_genes) {
  df_g <- data.frame(
    pseudotime = myeloid_obj$pseudotime,
    expression = expr_5g[g, ],
    CellType = myeloid_obj$CellType
  ) %>% filter(!is.na(pseudotime))
  
  p_g <- ggplot(df_g, aes(x = pseudotime, y = expression)) +
    geom_point(aes(color = CellType), size = 0.2, alpha = 0.3) +
    geom_smooth(method = "loess", span = 0.3, se = TRUE,
                color = "black", fill = "gray70") +
    scale_color_manual(values = colorRampPalette(brewer.pal(11, "Spectral"))(length(unique(df_g$CellType)))) +
    ggtitle(sprintf("%s (β = %+.4f)", g, LCDI_coef[g])) +
    xlab("Pseudotime") + ylab("Expression") +
    theme_bw() + white_theme +
    theme(plot.title = element_text(hjust = 0.5, size = 11, face = "bold"),
          legend.position = "none")
  gene_pt_list[[g]] <- p_g
}

p_5gene_pt <- wrap_plots(gene_pt_list, ncol = 3) +
  plot_annotation(
    title = "LCDI 5 Genes Expression along Pseudotime",
    theme = theme(plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
                  plot.background = element_rect(fill = "white", color = NA)))

ggsave(file.path(fig_path, "FigJ3c_5genes_along_pseudotime.pdf"), p_5gene_pt,
       width = 14, height = 8, bg = "white")
ggsave(file.path(fig_path, "FigJ3c_5genes_along_pseudotime.png"), p_5gene_pt,
       width = 14, height = 8, dpi = 200, bg = "white")
cat("✓ FigJ3c_5genes_along_pseudotime\n")

# ─── FigJ3d: CellType 沿伪时间 (boxplot) ───
cat("\n── FigJ3d: CellType 沿伪时间分布 ──\n")

# CellType 按 median pseudotime 排序
ct_order_pt <- lcdi_pt_df %>%
  group_by(CellType) %>%
  summarise(med = median(pseudotime), n = n()) %>%
  filter(n > 30) %>%
  arrange(med) %>%
  pull(CellType)

lcdi_pt_df$CellType_pt <- factor(lcdi_pt_df$CellType, levels = ct_order_pt)

p_ct_pt <- ggplot(lcdi_pt_df %>% filter(CellType %in% ct_order_pt),
                   aes(x = CellType_pt, y = pseudotime, fill = CellType_pt)) +
  geom_boxplot(outlier.size = 0.2, outlier.alpha = 0.3) +
  scale_fill_manual(values = colorRampPalette(brewer.pal(11, "Spectral"))(length(ct_order_pt))) +
  ggtitle("CellType along Pseudotime (sorted by median PT)") +
  xlab("Cell Type") + ylab("Pseudotime") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"),
        axis.text.x = element_text(angle = 45, hjust = 1, size = 10),
        legend.position = "none")

ggsave(file.path(fig_path, "FigJ3d_celltype_along_pseudotime.pdf"), p_ct_pt,
       width = 12, height = 6, bg = "white")
ggsave(file.path(fig_path, "FigJ3d_celltype_along_pseudotime.png"), p_ct_pt,
       width = 12, height = 6, dpi = 200, bg = "white")
cat("✓ FigJ3d_celltype_along_pseudotime\n")

# ============================================================
# Stage 4: tradeSeq 找动态基因 (计算密集!)
# ============================================================

cat("\n══ Stage 4: tradeSeq 动态基因分析 ══\n\n")

if (file.exists(cache_stage4)) {
  cat("从缓存加载 tradeSeq fitGAM 结果...\n")
  sce_tradeseq <- readRDS(cache_stage4)
  cat("✓ tradeSeq 已加载\n")
} else {
  
  cat("⚠️ 这步计算密集 (~30-60 分钟), 可中断后接续\n\n")
  
  # 严格过滤基因 (只保留高变 + LCDI 5 基因)
  hvg <- VariableFeatures(myeloid_obj)
  genes_for_tradeseq <- unique(c(LCDI_genes, head(hvg, 1000)))
  genes_for_tradeseq <- intersect(genes_for_tradeseq, rownames(myeloid_obj))
  
  cat(sprintf("用于 tradeSeq 的基因: %d (含 5 LCDI + top 1000 HVG)\n",
              length(genes_for_tradeseq)))
  
  counts_for_tradeseq <- as.matrix(
    GetAssayData(myeloid_obj, layer = "counts")[genes_for_tradeseq, ])
  
  # ★ 关键: fitGAM 直接喂 counts + pseudotime
  cat("\n跑 fitGAM (拟合负二项 GAM, 这步很慢)...\n")
  cat(sprintf("  开始时间: %s\n", Sys.time()))
  
  # 用 6 个 knots (默认), 单核
  set.seed(42)
  sce_tradeseq <- tryCatch({
    tradeSeq::fitGAM(
      counts = counts_for_tradeseq,
      pseudotime = pseudotime_mat,
      cellWeights = slingCurveWeights(sce),
      nknots = 6,
      verbose = TRUE,
      parallel = FALSE   # 单核稳定 (并行可能内存爆)
    )
  }, error = function(e) {
    cat(sprintf("\n⚠️ fitGAM 失败: %s\n", e$message))
    cat("尝试用更少基因 (只 5 LCDI)...\n")
    tradeSeq::fitGAM(
      counts = counts_for_tradeseq[LCDI_genes, ],
      pseudotime = pseudotime_mat,
      cellWeights = slingCurveWeights(sce),
      nknots = 6,
      verbose = TRUE,
      parallel = FALSE
    )
  })
  
  cat(sprintf("  完成时间: %s\n", Sys.time()))
  cat("✓ fitGAM 完成\n")
  
  saveRDS(sce_tradeseq, cache_stage4)
  cat(sprintf("✓ Stage 4 缓存: %s\n", cache_stage4))
}

# ─── associationTest: 找显著动态基因 ───
cat("\n── associationTest: 找沿伪时间显著变化的基因 ──\n")

assoc_res <- tradeSeq::associationTest(sce_tradeseq)
assoc_res$gene <- rownames(assoc_res)
assoc_res$padj <- p.adjust(assoc_res$pvalue, method = "BH")
assoc_res <- assoc_res %>% arrange(pvalue)

write.csv(assoc_res, file.path(res_path, "tradeSeq_associationTest.csv"),
          row.names = FALSE)

cat(sprintf("\n显著基因 (padj < 0.05): %d / %d\n",
            sum(assoc_res$padj < 0.05, na.rm=TRUE),
            nrow(assoc_res)))

cat("\nTop 20 动态基因:\n")
print(head(assoc_res[, c("gene", "waldStat", "pvalue", "padj")], 20))

# 5 LCDI 基因的结果
cat("\n5 LCDI 基因的动态性:\n")
lcdi_assoc <- assoc_res[assoc_res$gene %in% LCDI_genes, ]
print(lcdi_assoc[, c("gene", "waldStat", "pvalue", "padj")])

# ─── FigJ3e: Top 动态基因热图 ───
cat("\n── FigJ3e: Top 50 动态基因 plotSmoothers ──\n")

top_dynamic <- head(assoc_res$gene[assoc_res$gene %in% rownames(sce_tradeseq)], 6)
cat(sprintf("Top 6 动态基因: %s\n", paste(top_dynamic, collapse=", ")))

# 用 plotSmoothers 画 top 6
plot_list_dyn <- list()
for (g in top_dynamic) {
  p_g <- tryCatch({
    tradeSeq::plotSmoothers(sce_tradeseq, 
                              counts = as.matrix(GetAssayData(myeloid_obj, layer="counts")[rownames(sce_tradeseq), ]),
                              gene = g) +
      ggtitle(g) +
      white_theme +
      theme(plot.title = element_text(hjust = 0.5, size = 11, face = "bold"))
  }, error = function(e) {
    cat(sprintf("  画 %s 失败: %s\n", g, e$message))
    NULL
  })
  if (!is.null(p_g)) plot_list_dyn[[g]] <- p_g
}

if (length(plot_list_dyn) > 0) {
  p_dyn <- wrap_plots(plot_list_dyn, ncol = 3) +
    plot_annotation(
      title = "Top Dynamic Genes (sorted by tradeSeq waldStat)",
      theme = theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
                    plot.background = element_rect(fill = "white", color = NA)))
  
  ggsave(file.path(fig_path, "FigJ3e_top_dynamic_genes.pdf"), p_dyn,
         width = 14, height = 8, bg = "white")
  ggsave(file.path(fig_path, "FigJ3e_top_dynamic_genes.png"), p_dyn,
         width = 14, height = 8, dpi = 200, bg = "white")
  cat("✓ FigJ3e_top_dynamic_genes\n")
}

# ─── FigJ3f: 5 基因 plotSmoothers (论文专用) ───
cat("\n── FigJ3f: 5 LCDI 基因 plotSmoothers ──\n")

plot_list_lcdi <- list()
for (g in LCDI_genes) {
  if (!g %in% rownames(sce_tradeseq)) {
    cat(sprintf("  %s 不在 tradeSeq 结果里, 跳过\n", g))
    next
  }
  p_g <- tryCatch({
    tradeSeq::plotSmoothers(sce_tradeseq, 
                              counts = as.matrix(GetAssayData(myeloid_obj, layer="counts")[rownames(sce_tradeseq), ]),
                              gene = g) +
      ggtitle(sprintf("%s (β = %+.4f)", g, LCDI_coef[g])) +
      white_theme +
      theme(plot.title = element_text(hjust = 0.5, size = 11, face = "bold"))
  }, error = function(e) NULL)
  if (!is.null(p_g)) plot_list_lcdi[[g]] <- p_g
}

if (length(plot_list_lcdi) > 0) {
  p_lcdi_smooth <- wrap_plots(plot_list_lcdi, ncol = 3) +
    plot_annotation(
      title = "LCDI 5 Genes: tradeSeq Smoothed Expression",
      theme = theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"),
                    plot.background = element_rect(fill = "white", color = NA)))
  
  ggsave(file.path(fig_path, "FigJ3f_5genes_smoothers.pdf"), p_lcdi_smooth,
         width = 14, height = 8, bg = "white")
  ggsave(file.path(fig_path, "FigJ3f_5genes_smoothers.png"), p_lcdi_smooth,
         width = 14, height = 8, dpi = 200, bg = "white")
  cat("✓ FigJ3f_5genes_smoothers\n")
}

# ============================================================
# Stage 5: 双轨迹 normal vs malignant (可选, 复杂)
# ============================================================

cat("\n══ Stage 5: normal vs malignant LCDI 轨迹对比 ══\n\n")

# 简化版: 在主轨迹上, 分 normal/malignant 画 LCDI 曲线
malig_pt_df <- lcdi_pt_df %>%
  mutate(Group = case_when(
    grepl("-like$", CellType) ~ "malignant",
    TRUE ~ "normal"
  )) %>%
  filter(!is.na(pseudotime))

p_dual_lcdi <- ggplot(malig_pt_df, 
                      aes(x = pseudotime, y = LCDI_score, color = Group)) +
  geom_point(size = 0.2, alpha = 0.2) +
  geom_smooth(method = "loess", span = 0.3, se = TRUE, linewidth = 1.2) +
  scale_color_manual(values = c("normal" = "#0072B2", "malignant" = "#D55E00")) +
  ggtitle("LCDI Score along Pseudotime: Normal vs Malignant") +
  xlab("Pseudotime") + ylab("LCDI Score") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 14, face = "bold"))

ggsave(file.path(fig_path, "FigJ3g_normal_vs_malig_LCDI.pdf"), p_dual_lcdi,
       width = 12, height = 6, bg = "white")
ggsave(file.path(fig_path, "FigJ3g_normal_vs_malig_LCDI.png"), p_dual_lcdi,
       width = 12, height = 6, dpi = 200, bg = "white")
cat("✓ FigJ3g_normal_vs_malig_LCDI\n")

# ============================================================
# 保存 + 总结
# ============================================================

cat("\n── 保存最终结果 ──\n\n")

saveRDS(myeloid_obj, file.path(data_path, "myeloid_obj_with_pseudotime.rds"))
cat("✓ myeloid_obj_with_pseudotime.rds\n")

# 元数据
key_cols <- c("sample_id", "patient", "source",
              "CellType", "PredictionRefined_clean",
              "seurat_clusters", "LCDI_score",
              paste0("pseudotime_lineage", 1:n_lineages))
key_cols <- intersect(key_cols, colnames(myeloid_obj@meta.data))
write.csv(myeloid_obj@meta.data[, key_cols],
          file.path(res_path, "myeloid_metadata_with_pseudotime.csv"))

cat("\n══════════════════════════════════════════════\n")
cat("Phase J3 完成\n")
cat("══════════════════════════════════════════════\n\n")

cat(sprintf("髓系细胞: %d\n", ncol(myeloid_obj)))
cat(sprintf("Lineage 数: %d\n", n_lineages))
cat(sprintf("\n动态基因 (padj<0.05): %d / %d\n",
            sum(assoc_res$padj < 0.05, na.rm=TRUE),
            nrow(assoc_res)))

cat("\n关键图 (论文 Figure 7 候选):\n")
cat("  ⭐⭐⭐ FigJ3a_pseudotime_UMAP.pdf       髓系 UMAP + 轨迹\n")
cat("  ⭐⭐⭐ FigJ3b_LCDI_along_pseudotime.pdf  LCDI 沿伪时间 (Fig 7E)\n")
cat("  ⭐⭐ FigJ3c_5genes_along_pseudotime.pdf 5 基因沿伪时间\n")
cat("  ⭐⭐ FigJ3g_normal_vs_malig_LCDI.pdf    双轨迹对比\n")
cat("  ⭐ FigJ3d_celltype_along_pseudotime.pdf CellType 沿轴\n")
cat("  ⭐ FigJ3e_top_dynamic_genes.pdf         tradeSeq Top 6\n")
cat("  ⭐ FigJ3f_5genes_smoothers.pdf          tradeSeq 5 基因\n")

cat(sprintf("\n输出: %s\n", output_dir))
cat("\n下一步: J4 (关键细胞 marker + GSVA) 或 J7 (scTenifoldKnk)\n")

sink(file.path(res_path, "sessionInfo.txt"))
sessionInfo()
sink()

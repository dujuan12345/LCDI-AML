# ============================================================
# phaseJ10_GSE185381_LCDI.R
# Phase J10: GSE185381 儿童 AML LCDI 投影分析 (类似 J2)
# 
# 输入: D:/.../scRNA/GSE185381/J9_QC/Data/seurat_obj_clustered_GSE185381.rds
# 输出: D:/.../scRNA/GSE185381/J10_LCDI/
# 
# 核心目标:
#   1. 计算 LCDI score
#   2. LCDI UMAP 可视化
#   3. malignant vs microenvironment LCDI 对比 ⭐
#   4. ⭐⭐⭐ 关键: GMP / CD14+ / MPP_GMP 内 malig vs micro paired
#   5. inflammation_group 与 LCDI 关系 (新维度!)
#   6. LCDI vs occupancy_score 相关 (新维度!)
# 
# 与 GSE116256 (J2) 对比预期:
#   - 同样 GMP/ProMono malig LCDI > normal LCDI
#   - 同样 5 LCDI 基因表达模式
#   - 同样髓系区 LCDI 低
# ============================================================

cat("============================================================\n")
cat("Phase J10: GSE185381 LCDI 投影\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

# ─────────────────────────────────────────────
# 路径
# ─────────────────────────────────────────────
project_dir <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA"
input_rds <- file.path(project_dir, "GSE185381/J9_QC/Data/seurat_obj_clustered_GSE185381.rds")

output_dir <- file.path(project_dir, "GSE185381/J10_LCDI")
res_path <- file.path(output_dir, "Results")
fig_path <- file.path(output_dir, "Figures")
data_path <- file.path(output_dir, "Data")

for (p in c(output_dir, res_path, fig_path, data_path)) {
  if (!dir.exists(p)) dir.create(p, recursive = TRUE)
}

setwd(project_dir)

suppressPackageStartupMessages({
  library(Seurat)
  library(ggplot2)
  library(patchwork)
  library(dplyr)
  library(ggpubr)
  library(RColorBrewer)
  library(viridis)
})

cat(sprintf("✓ Seurat: %s\n\n", packageVersion("Seurat")))

white_theme <- theme(
  plot.background = element_rect(fill = "white", color = NA),
  panel.background = element_rect(fill = "white"))

# ─────────────────────────────────────────────
# 加载
# ─────────────────────────────────────────────
cat("── 加载 J9 seurat ──\n")
seurat_obj <- readRDS(input_rds)
cat(sprintf("✓ %d 基因 × %d 细胞\n", nrow(seurat_obj), ncol(seurat_obj)))

# LCDI 公式
LCDI_coef <- c(CREB1=0.0925, SLC16A4=-0.0636, GPX4=-0.0721, CASP1=-0.0106, MPO=-0.2095)
LCDI_genes <- names(LCDI_coef)

cat("\nLCDI 公式系数:\n")
for (g in LCDI_genes) {
  cat(sprintf("  %s: %+.4f\n", g, LCDI_coef[g]))
}

# 检查基因
cat("\n5 LCDI 基因检查:\n")
for (g in LCDI_genes) {
  if (g %in% rownames(seurat_obj)) {
    expr <- GetAssayData(seurat_obj, assay = "RNA", layer = "data")[g, ]
    pct_pos <- 100 * mean(expr > 0)
    cat(sprintf("  ✓ %s: %.1f%% 细胞表达\n", g, pct_pos))
  } else {
    cat(sprintf("  ✗ %s: 不在数据集\n", g))
  }
}

# ============================================================
# Step 1: 计算 LCDI score
# ============================================================
cat("\n══ Step 1: 计算 LCDI score ══\n\n")

expr_5g <- as.matrix(GetAssayData(seurat_obj, assay = "RNA", layer = "data")[LCDI_genes, ])

# LCDI = sum(beta_i × expr_i)
LCDI_score <- as.numeric(LCDI_coef %*% expr_5g)
seurat_obj$LCDI_score <- LCDI_score

cat("LCDI 统计:\n")
cat(sprintf("  范围: %.4f ~ %.4f\n", min(LCDI_score), max(LCDI_score)))
cat(sprintf("  均值: %.4f\n", mean(LCDI_score)))
cat(sprintf("  中位: %.4f\n", median(LCDI_score)))
cat("\n  分位数:\n")
print(round(quantile(LCDI_score, c(0, 0.05, 0.25, 0.5, 0.75, 0.95, 1)), 4))

# ============================================================
# Step 2: 5 基因 + LCDI UMAP
# ============================================================
cat("\n══ Step 2: 5 基因 + LCDI UMAP ══\n\n")

# 5 基因
cat("FigJ10a: 5 基因 UMAP\n")
plots_5g <- list()
for (g in LCDI_genes) {
  p <- FeaturePlot(seurat_obj, features = g, pt.size = 0.2, order = TRUE) +
    scale_color_gradient(low = "lightgrey", high = "#D73027") +
    ggtitle(sprintf("%s (β = %+.4f)", g, LCDI_coef[g])) +
    white_theme +
    theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))
  plots_5g[[g]] <- p
}

p_5g_combined <- wrap_plots(plots_5g, ncol = 3) +
  plot_annotation(
    title = "5 LCDI Genes Expression - GSE185381 pAML",
    theme = theme(plot.title = element_text(hjust = 0.5, size = 16, face = "bold"),
                  plot.background = element_rect(fill = "white", color = NA)))

ggsave(file.path(fig_path, "FigJ10a_5genes_UMAP.pdf"), p_5g_combined,
       width = 16, height = 10, bg = "white")
ggsave(file.path(fig_path, "FigJ10a_5genes_UMAP.png"), p_5g_combined,
       width = 16, height = 10, dpi = 200, bg = "white")
cat("✓ FigJ10a\n")

# LCDI UMAP (3 个色阶版本)
cat("\nFigJ10b: LCDI UMAP (3 色阶)\n")
q05 <- quantile(LCDI_score, 0.05)
q95 <- quantile(LCDI_score, 0.95)
cat(sprintf("Cap 范围 (5%%-95%%): %.4f ~ %.4f\n", q05, q95))

p_lcdi_viridis <- FeaturePlot(seurat_obj, features = "LCDI_score", pt.size = 0.3) +
  scale_color_viridis_c(option = "plasma", direction = -1,
                          limits = c(q05, q95), oob = scales::squish, name = "LCDI") +
  ggtitle("LCDI Score (viridis plasma)") +
  white_theme + theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"))

p_lcdi_bwr <- FeaturePlot(seurat_obj, features = "LCDI_score", pt.size = 0.3) +
  scale_color_gradient2(low = "#2166AC", mid = "white", high = "#B2182B",
                          midpoint = 0, limits = c(q05, q95),
                          oob = scales::squish, name = "LCDI") +
  ggtitle("LCDI Score (BWR, centered at 0)") +
  white_theme + theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"))

ggsave(file.path(fig_path, "FigJ10b_LCDI_UMAP.pdf"),
       p_lcdi_viridis | p_lcdi_bwr,
       width = 14, height = 6, bg = "white")
ggsave(file.path(fig_path, "FigJ10b_LCDI_UMAP.png"),
       p_lcdi_viridis | p_lcdi_bwr,
       width = 14, height = 6, dpi = 200, bg = "white")
cat("✓ FigJ10b\n")

# 单独保存 BWR (论文推荐)
ggsave(file.path(fig_path, "FigJ10b2_LCDI_UMAP_BWR.pdf"), p_lcdi_bwr,
       width = 8, height = 6.5, bg = "white")
ggsave(file.path(fig_path, "FigJ10b2_LCDI_UMAP_BWR.png"), p_lcdi_bwr,
       width = 8, height = 6.5, dpi = 200, bg = "white")
cat("✓ FigJ10b2 (BWR 单独)\n")

# ============================================================
# Step 3: malignant vs microenvironment LCDI ⭐⭐⭐
# ============================================================
cat("\n══ Step 3: malignant vs microenvironment LCDI ══\n\n")

if (!"malignant" %in% colnames(seurat_obj@meta.data)) {
  stop("malignant 列不存在!")
}

malig_data <- seurat_obj@meta.data %>%
  filter(malignant %in% c("malignant", "microenvironment"))

malig_data$Group <- factor(malig_data$malignant, 
                             levels = c("microenvironment", "malignant"))

cat(sprintf("用于分析: %d 细胞\n", nrow(malig_data)))
cat(sprintf("  malignant:        %d\n", sum(malig_data$Group == "malignant")))
cat(sprintf("  microenvironment: %d\n", sum(malig_data$Group == "microenvironment")))

# Wilcoxon 检验
w_test <- wilcox.test(LCDI_score ~ Group, data = malig_data)
cat(sprintf("\nWilcoxon p-value: %.3e\n", w_test$p.value))

# 中位数差异
med_micro <- median(malig_data$LCDI_score[malig_data$Group == "microenvironment"])
med_malig <- median(malig_data$LCDI_score[malig_data$Group == "malignant"])
cat(sprintf("microenv median: %.4f\n", med_micro))
cat(sprintf("malignant median: %.4f\n", med_malig))
cat(sprintf("差异 (malig - micro): %+.4f\n", med_malig - med_micro))

# Panel A: 全细胞
p_panelA <- ggplot(malig_data, aes(x = Group, y = LCDI_score, fill = Group)) +
  geom_violin(alpha = 0.6, scale = "width") +
  geom_boxplot(width = 0.15, outlier.size = 0.2, outlier.alpha = 0.3,
               fill = "white", alpha = 0.9) +
  scale_fill_manual(values = c("microenvironment" = "#0072B2", 
                                 "malignant" = "#D55E00")) +
  stat_compare_means(method = "wilcox.test", label = "p.format",
                     label.x.npc = 0.4, label.y.npc = 0.95, size = 4) +
  ylim(c(quantile(malig_data$LCDI_score, 0.005), 
         quantile(malig_data$LCDI_score, 0.995))) +
  ggtitle(sprintf("A. All cells (n=%d)", nrow(malig_data))) +
  xlab(NULL) + ylab("LCDI Score") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
        legend.position = "none",
        axis.text = element_text(size = 11))

# Panel B: 髓系子集
myeloid_broad <- c("HSC", "MPP", "GMP", "Granulocyte", 
                     "CD14+ monocyte", "CD16+ monocyte", "HLA-II+ monocyte",
                     "CD11c+", "cDC1", "cDC2", "DC precursor", "pDC",
                     "MEP", "Megakaryocyte", "Ery")
myeloid_data <- malig_data %>% filter(Broad_cell_identity %in% myeloid_broad)

p_panelB <- ggplot(myeloid_data, aes(x = Group, y = LCDI_score, fill = Group)) +
  geom_violin(alpha = 0.6, scale = "width") +
  geom_boxplot(width = 0.15, outlier.size = 0.2, outlier.alpha = 0.3,
               fill = "white", alpha = 0.9) +
  scale_fill_manual(values = c("microenvironment" = "#0072B2", 
                                 "malignant" = "#D55E00")) +
  stat_compare_means(method = "wilcox.test", label = "p.format",
                     label.x.npc = 0.4, label.y.npc = 0.95, size = 4) +
  ylim(c(quantile(myeloid_data$LCDI_score, 0.005), 
         quantile(myeloid_data$LCDI_score, 0.995))) +
  ggtitle(sprintf("B. Myeloid subset (n=%d)", nrow(myeloid_data))) +
  xlab(NULL) + ylab("LCDI Score") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
        legend.position = "none")

# Panel C: 各 Broad CellType 内 paired ⭐⭐⭐
key_celltypes <- c("HSC", "MPP", "GMP", "Granulocyte", "CD14+ monocyte")
key_celltypes <- intersect(key_celltypes, unique(malig_data$Broad_cell_identity))

paired_data <- malig_data %>% filter(Broad_cell_identity %in% key_celltypes)
paired_data$Broad_cell_identity <- factor(paired_data$Broad_cell_identity,
                                            levels = key_celltypes)

# 每个细胞类型各组的 n
ct_n <- paired_data %>%
  group_by(Broad_cell_identity, Group) %>%
  summarise(n = n(), .groups = "drop")
cat("\n各 CellType × Group 细胞数:\n")
print(ct_n)

p_panelC <- ggplot(paired_data, aes(x = Group, y = LCDI_score, fill = Group)) +
  geom_violin(alpha = 0.6, scale = "width") +
  geom_boxplot(width = 0.15, outlier.size = 0.2, outlier.alpha = 0.3,
               fill = "white", alpha = 0.9) +
  scale_fill_manual(values = c("microenvironment" = "#0072B2", 
                                 "malignant" = "#D55E00")) +
  facet_wrap(~ Broad_cell_identity, nrow = 1, scales = "free_y") +
  stat_compare_means(method = "wilcox.test", label = "p.format",
                     label.x.npc = 0.3, label.y.npc = 0.95, size = 3) +
  ggtitle("C. Within-celltype: malignant vs microenvironment") +
  xlab(NULL) + ylab("LCDI Score") +
  theme_bw() + white_theme +
  theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"),
        legend.position = "none",
        axis.text.x = element_text(angle = 30, hjust = 1, size = 8),
        strip.background = element_rect(fill = "gray90"),
        strip.text = element_text(face = "bold", size = 10))

# 拼图
p_combined <- (p_panelA | p_panelB) / p_panelC

ggsave(file.path(fig_path, "FigJ10c_LCDI_byMalignant.pdf"), p_combined,
       width = 16, height = 11, bg = "white")
ggsave(file.path(fig_path, "FigJ10c_LCDI_byMalignant.png"), p_combined,
       width = 16, height = 11, dpi = 200, bg = "white")
cat("✓ FigJ10c\n")

# 单独 Panel C (论文核心)
ggsave(file.path(fig_path, "FigJ10c2_LCDI_paired.pdf"), p_panelC,
       width = 16, height = 5, bg = "white")
ggsave(file.path(fig_path, "FigJ10c2_LCDI_paired.png"), p_panelC,
       width = 16, height = 5, dpi = 200, bg = "white")
cat("✓ FigJ10c2 (论文核心)\n")

# ============================================================
# Step 4: 各 CellType 内统计 + 表
# ============================================================
cat("\n══ Step 4: 各细胞类型 LCDI 统计 ══\n\n")

ct_stats <- paired_data %>%
  group_by(Broad_cell_identity, Group) %>%
  summarise(LCDI_mean = mean(LCDI_score),
            LCDI_median = median(LCDI_score),
            n = n(), .groups = "drop") %>%
  tidyr::pivot_wider(names_from = Group, 
                       values_from = c(LCDI_mean, LCDI_median, n))

cat("统计:\n")
for (ct in key_celltypes) {
  sub_data <- paired_data %>% filter(Broad_cell_identity == ct)
  if (nrow(sub_data) < 10) next
  
  micro_med <- median(sub_data$LCDI_score[sub_data$Group == "microenvironment"], 
                       na.rm=TRUE)
  malig_med <- median(sub_data$LCDI_score[sub_data$Group == "malignant"],
                       na.rm=TRUE)
  
  if (is.na(micro_med) || is.na(malig_med)) next
  
  w <- wilcox.test(LCDI_score ~ Group, data = sub_data)
  cat(sprintf("  %-25s micro=%.4f, malig=%.4f, diff=%+.4f, p=%.3e\n",
              ct, micro_med, malig_med, malig_med - micro_med, w$p.value))
}

write.csv(ct_stats, file.path(res_path, "celltype_LCDI_stats.csv"), row.names = FALSE)

# ============================================================
# Step 5: inflammation_group 与 LCDI (新维度!)
# ============================================================
cat("\n══ Step 5: inflammation_group 与 LCDI ══\n\n")

if ("inflammation_group" %in% colnames(seurat_obj@meta.data)) {
  infl_table <- table(seurat_obj$inflammation_group, useNA = "always")
  cat("inflammation_group 分布:\n")
  print(infl_table)
  
  infl_data <- seurat_obj@meta.data %>%
    filter(!is.na(inflammation_group), inflammation_group != "")
  
  if (nrow(infl_data) > 100 && length(unique(infl_data$inflammation_group)) >= 2) {
    p_infl <- ggplot(infl_data, 
                      aes(x = inflammation_group, y = LCDI_score, 
                          fill = inflammation_group)) +
      geom_violin(alpha = 0.6, scale = "width") +
      geom_boxplot(width = 0.15, outlier.size = 0.2, outlier.alpha = 0.3,
                   fill = "white", alpha = 0.9) +
      scale_fill_brewer(palette = "Set2") +
      stat_compare_means(method = "kruskal.test", size = 4) +
      ggtitle("LCDI by Inflammation Group (Lasry 2023)") +
      xlab("Inflammation Group") + ylab("LCDI Score") +
      theme_bw() + white_theme +
      theme(plot.title = element_text(hjust = 0.5, size = 13, face = "bold"),
            legend.position = "none",
            axis.text.x = element_text(angle = 30, hjust = 1))
    
    ggsave(file.path(fig_path, "FigJ10d_LCDI_inflammation.pdf"), p_infl,
           width = 8, height = 6, bg = "white")
    ggsave(file.path(fig_path, "FigJ10d_LCDI_inflammation.png"), p_infl,
           width = 8, height = 6, dpi = 200, bg = "white")
    cat("✓ FigJ10d\n")
  }
} else {
  cat("⚠️ 没有 inflammation_group 列\n")
}

# ============================================================
# Step 6: occupancy_score 与 LCDI 相关
# ============================================================
cat("\n══ Step 6: occupancy_score 与 LCDI 相关 ══\n\n")

if ("occupancy_score" %in% colnames(seurat_obj@meta.data)) {
  occ_data <- seurat_obj@meta.data %>%
    filter(!is.na(occupancy_score)) %>%
    mutate(occupancy_score = as.numeric(occupancy_score))
  
  if (nrow(occ_data) > 100) {
    cor_test <- cor.test(occ_data$occupancy_score, occ_data$LCDI_score)
    cat(sprintf("Pearson r = %.4f, p = %.3e\n", cor_test$estimate, cor_test$p.value))
    
    # 散点图
    p_occ <- ggplot(occ_data, aes(x = occupancy_score, y = LCDI_score)) +
      geom_point(size = 0.3, alpha = 0.3, color = "#666666") +
      geom_smooth(method = "loess", color = "#D73027", se = TRUE) +
      ggtitle(sprintf("LCDI vs Occupancy Score (r=%.3f, p=%.2e)",
                       cor_test$estimate, cor_test$p.value)) +
      xlab("Occupancy Score (Lasry 2023)") + ylab("LCDI Score") +
      theme_bw() + white_theme +
      theme(plot.title = element_text(hjust = 0.5, size = 12, face = "bold"))
    
    ggsave(file.path(fig_path, "FigJ10e_LCDI_occupancy.pdf"), p_occ,
           width = 8, height = 6, bg = "white")
    ggsave(file.path(fig_path, "FigJ10e_LCDI_occupancy.png"), p_occ,
           width = 8, height = 6, dpi = 200, bg = "white")
    cat("✓ FigJ10e\n")
  }
}

# ============================================================
# 保存 + 总结
# ============================================================
cat("\n── 保存最终对象 ──\n")
saveRDS(seurat_obj, file.path(data_path, "seurat_obj_with_LCDI_GSE185381.rds"))
cat("✓ seurat_obj_with_LCDI_GSE185381.rds\n")

# 元数据
key_cols <- c("samples", "Broad_cell_identity", "Cell_type_identity",
              "malignant", "CNV_pos", "inflammation_group", "occupancy_score",
              "seurat_clusters", "LCDI_score",
              LCDI_genes, "nFeature_RNA", "nCount_RNA")
key_cols <- intersect(key_cols, colnames(seurat_obj@meta.data))
write.csv(seurat_obj@meta.data[, key_cols],
          file.path(res_path, "cell_metadata_with_LCDI.csv"))

cat("\n══════════════════════════════════════════════\n")
cat("Phase J10 完成\n")
cat("══════════════════════════════════════════════\n\n")

cat(sprintf("总细胞: %d\n", ncol(seurat_obj)))
cat(sprintf("LCDI 范围: %.4f ~ %.4f\n", 
            min(seurat_obj$LCDI_score), max(seurat_obj$LCDI_score)))

cat(sprintf("\nMalignant vs microenv (全细胞):\n"))
cat(sprintf("  Wilcoxon p = %.3e\n", w_test$p.value))
cat(sprintf("  中位数差异 = %+.4f\n", med_malig - med_micro))

cat("\n关键图 (与 GSE116256 对应):\n")
cat("  ⭐⭐⭐ FigJ10c2_LCDI_paired.pdf      各 CellType paired (论文核心)\n")
cat("  ⭐⭐⭐ FigJ10b2_LCDI_UMAP_BWR.pdf   LCDI UMAP\n")
cat("  ⭐⭐ FigJ10c_LCDI_byMalignant.pdf  3 panel\n")
cat("  ⭐ FigJ10a_5genes_UMAP.pdf        5 基因\n")
cat("  ⭐ FigJ10d_LCDI_inflammation.pdf  炎症分组 (新)\n")
cat("  ⭐ FigJ10e_LCDI_occupancy.pdf     occupancy 相关 (新)\n")

cat(sprintf("\n输出: %s\n", output_dir))
cat("\n下一步: J11 GSE116256 vs GSE185381 一致性验证\n")

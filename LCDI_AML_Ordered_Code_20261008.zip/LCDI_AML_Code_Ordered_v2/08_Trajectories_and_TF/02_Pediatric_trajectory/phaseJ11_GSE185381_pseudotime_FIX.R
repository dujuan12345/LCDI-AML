# =============================================================================
# phaseJ11_GSE185381_pseudotime_FIX.R
# -----------------------------------------------------------------------------
# 修复诊断:
#   - 原脚本用 seurat_clusters (34 个), 起点 cluster HSC 占比仅 12.6%
#   - slingshot MST 路径复杂度爆炸, 1 小时无动静
# 
# 修复:
#   1. 改用 Cell_type_identity 作为 clusterLabels (14 类纯净细胞类型)
#   2. 起点指定 = "HSC" (天然 100% 纯)
#   3. PCA dims 降到 20 (从 30)
#   4. approx_points = 150 (限制 curve 拟合复杂度)
#   5. omega = TRUE (自适应 lambda, 加速收敛)
# 
# 预期: 15-25 分钟跑完 Stage 2
# 
# 使用: 直接 source 该文件, 它从 Stage 1 缓存接续, 不重跑 Stage 1
# =============================================================================

cat("============================================================\n")
cat("J11 修复脚本: slingshot 用 Cell_type_identity\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

suppressPackageStartupMessages({
  library(Seurat)
  library(slingshot)
  library(tradeSeq)
  library(SingleCellExperiment)
  library(ggplot2)
  library(dplyr)
  library(viridis)
})

utils_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/utils_pvalue_format.R"
if (file.exists(utils_path)) source(utils_path)

# 路径
ROOT_DIR  <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE185381"
OUT_DIR   <- file.path(ROOT_DIR, "J11_pseudotime")
DATA_DIR  <- file.path(OUT_DIR, "Data")
CACHE_DIR <- file.path(OUT_DIR, "Cache")
FIG_DIR   <- file.path(OUT_DIR, "Figures")
TAB_DIR   <- file.path(OUT_DIR, "Tables")

stage1_cache  <- file.path(CACHE_DIR, "stage1_myeloid_seurat_GSE185381.rds")
stage2_cache  <- file.path(CACHE_DIR, "stage2_sce_with_slingshot_GSE185381_FIX.rds")  # 新缓存, 不覆盖

options(future.globals.maxSize = 16 * 1024^3)

# ─────────────────────────────────────────────
# 加载 Stage 1 (复用)
# ─────────────────────────────────────────────
cat("══ 加载 Stage 1 缓存 ══\n\n")
myeloid_obj <- readRDS(stage1_cache)
cat(sprintf("✓ 髓系 Seurat: %d cells × %d genes\n", ncol(myeloid_obj), nrow(myeloid_obj)))
cat(sprintf("✓ Cell_type_identity 类数: %d\n", length(unique(myeloid_obj$Cell_type_identity))))

# 检查 HSC 类是否存在
ct_table <- table(myeloid_obj$Cell_type_identity)
cat("\nCell_type_identity 分布:\n")
print(sort(ct_table, decreasing = TRUE))

# 选定起点 (优先 HSC, 退而求其次 MPP_MEP 或最未分化的)
candidate_start <- c("HSC", "MPP", "MPP_MEP", "MPP_GMP")
start_celltype <- NULL
for (c in candidate_start) {
  if (c %in% names(ct_table) && ct_table[c] >= 100) {
    start_celltype <- c
    break
  }
}
if (is.null(start_celltype)) {
  stop("❌ 找不到合适起点细胞类型 (HSC/MPP/MPP_MEP/MPP_GMP 任一)")
}
cat(sprintf("\n✓ 起点细胞类型: %s (n=%d, 占 %.1f%%)\n",
            start_celltype, ct_table[start_celltype],
            100 * ct_table[start_celltype] / sum(ct_table)))

# ─────────────────────────────────────────────
# Stage 2 修复版: 用 Cell_type_identity 作 cluster, dims=20
# ─────────────────────────────────────────────
cat("\n══ Stage 2 (修复版): slingshot 轨迹推断 ══\n\n")

if (file.exists(stage2_cache)) {
  cat("✓ 修复版 Stage 2 缓存已存在, 加载\n")
  sce <- readRDS(stage2_cache)
} else {
  cat("Seurat → SingleCellExperiment...\n")
  
  # 重做 PCA 用 20 dims (而非 30), 加速 MST 计算
  cat("重新降维 (dims=20, 加速 slingshot)...\n")
  myeloid_obj <- RunPCA(myeloid_obj, npcs = 20, verbose = FALSE)
  
  sce <- as.SingleCellExperiment(myeloid_obj)
  
  # 用 Cell_type_identity 作 cluster, 而非 seurat_clusters
  cluster_labels <- as.character(colData(sce)$Cell_type_identity)
  
  cat(sprintf("Cluster (Cell_type_identity) 数: %d\n", length(unique(cluster_labels))))
  cat(sprintf("起点 cluster: %s (100%% %s)\n", start_celltype, start_celltype))
  
  # 跑 slingshot, 参数加速
  cat("\n跑 slingshot (PCA 20-dim, Cell_type_identity, approx_points=150)...\n")
  cat(sprintf("开始时间: %s\n", Sys.time()))
  
  set.seed(42)
  t0 <- Sys.time()
  sce <- slingshot(sce,
                   clusterLabels = cluster_labels,
                   reducedDim = "PCA",
                   start.clus = start_celltype,
                   approx_points = 150,    # 限制 curve 复杂度
                   omega = TRUE,           # 自适应 lambda
                   omega_scale = 1.5)      # 适度松弛, 允许多个 end
  t1 <- Sys.time()
  cat(sprintf("结束时间: %s (耗时 %.1f 分钟)\n", t1, as.numeric(difftime(t1, t0, units = "mins"))))
  
  saveRDS(sce, stage2_cache)
  cat(sprintf("✓ 修复版 Stage 2 缓存: %s\n", stage2_cache))
}

# 检查 lineage 数
pst_mat <- slingPseudotime(sce)
n_lin <- ncol(pst_mat)
cat(sprintf("\n✓ 推断 %d 条 lineage\n", n_lin))

lineage_summary <- data.frame(
  lineage = paste0("L", 1:n_lin),
  n_cells_with_pst = sapply(1:n_lin, function(i) sum(!is.na(pst_mat[, i]))),
  pst_min = sapply(1:n_lin, function(i) min(pst_mat[, i], na.rm = TRUE)),
  pst_max = sapply(1:n_lin, function(i) max(pst_mat[, i], na.rm = TRUE))
)
for (i in 1:n_lin) {
  cat(sprintf("  Lineage %d: %d 细胞, 伪时间 %.2f ~ %.2f\n",
              i, lineage_summary$n_cells_with_pst[i],
              lineage_summary$pst_min[i], lineage_summary$pst_max[i]))
}
write.csv(lineage_summary, file.path(TAB_DIR, "J11_lineage_summary.csv"), row.names = FALSE)

# 注入 pseudotime
for (i in 1:n_lin) {
  myeloid_obj[[paste0("pseudotime_lineage", i)]] <- pst_mat[, i]
}
myeloid_obj$pseudotime <- pst_mat[, 1]

# ─────────────────────────────────────────────
# Stage 3: LCDI + 5 基因投影 (与原脚本相同)
# ─────────────────────────────────────────────
cat("\n══ Stage 3: LCDI + 5 基因沿伪时间投影 ══\n\n")

# Lineage LCDI Spearman 表
lin_lcdi_stats <- data.frame()
for (i in 1:n_lin) {
  cells_in_lin <- which(!is.na(pst_mat[, i]))
  if (length(cells_in_lin) < 100) next
  pst_v <- pst_mat[cells_in_lin, i]
  lcdi_v <- myeloid_obj$LCDI_score[cells_in_lin]
  ok <- !is.na(lcdi_v)
  if (sum(ok) < 100) next
  ct_res <- suppressWarnings(cor.test(pst_v[ok], lcdi_v[ok], method = "spearman"))
  lin_lcdi_stats <- rbind(lin_lcdi_stats, data.frame(
    lineage = paste0("L", i),
    n_cells = sum(ok),
    spearman_rho = ct_res$estimate,
    p_value = ct_res$p.value
  ))
}
write.csv(lin_lcdi_stats, file.path(TAB_DIR, "J11_lineage_LCDI_correlation.csv"), row.names = FALSE)
cat("Lineage LCDI vs pseudotime Spearman:\n")
print(lin_lcdi_stats)

# FigJ11b: LCDI vs pseudotime (L1 主轴)
df_lcdi <- data.frame(
  pseudotime = myeloid_obj$pseudotime,
  LCDI_score = myeloid_obj$LCDI_score,
  CellType = myeloid_obj$Cell_type_identity
)
df_lcdi <- df_lcdi[!is.na(df_lcdi$pseudotime) & !is.na(df_lcdi$LCDI_score), ]
rho_L1 <- suppressWarnings(cor.test(df_lcdi$pseudotime, df_lcdi$LCDI_score, method = "spearman"))
rho_label <- sprintf("L1: rho = %.3f, %s", rho_L1$estimate,
                     if (exists("format_pval")) format_pval(rho_L1$p.value) else sprintf("p = %.2e", rho_L1$p.value))

p_lcdi <- ggplot(df_lcdi, aes(x = pseudotime, y = LCDI_score)) +
  geom_point(aes(color = CellType), alpha = 0.3, size = 0.3) +
  geom_smooth(method = "loess", color = "black", linewidth = 1.2, se = TRUE) +
  scale_color_viridis_d(option = "turbo") +
  labs(title = "J11b: GSE185381 LCDI 沿伪时间",
       subtitle = rho_label,
       x = "Pseudotime (L1, HSC start)", y = "LCDI score") +
  theme_minimal(base_size = 13) +
  guides(color = guide_legend(override.aes = list(size = 3, alpha = 1)))
ggsave(file.path(FIG_DIR, "FigJ11b_LCDI_along_pseudotime.png"),
       p_lcdi, width = 12, height = 7, dpi = 300)
cat("✓ FigJ11b_LCDI_along_pseudotime\n")

# FigJ11c: 5 基因
lcdi_genes <- c("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")
gene_present <- lcdi_genes[lcdi_genes %in% rownames(myeloid_obj)]
cat(sprintf("\nLCDI 5 基因在数据中: %d/5\n", length(gene_present)))

if (length(gene_present) >= 3) {
  expr_mat <- GetAssayData(myeloid_obj, assay = "RNA", layer = "data")[gene_present, ]
  df_5g <- data.frame()
  for (g in gene_present) {
    df_g <- data.frame(
      pseudotime = myeloid_obj$pseudotime,
      expression = as.numeric(expr_mat[g, ]),
      gene = g
    )
    df_g <- df_g[!is.na(df_g$pseudotime), ]
    df_5g <- rbind(df_5g, df_g)
  }
  p_5g <- ggplot(df_5g, aes(x = pseudotime, y = expression)) +
    geom_smooth(method = "loess", se = TRUE, color = "steelblue") +
    facet_wrap(~ gene, scales = "free_y", ncol = 3) +
    labs(title = "J11c: GSE185381 LCDI 5 基因沿伪时间",
         x = "Pseudotime (L1)", y = "Expression") +
    theme_minimal(base_size = 12)
  ggsave(file.path(FIG_DIR, "FigJ11c_5genes_along_pseudotime.png"),
         p_5g, width = 12, height = 7, dpi = 300)
  cat("✓ FigJ11c_5genes_along_pseudotime\n")
}

# FigJ11d: CellType 沿伪时间
df_ct <- data.frame(
  pseudotime = myeloid_obj$pseudotime,
  CellType = myeloid_obj$Cell_type_identity
)
df_ct <- df_ct[!is.na(df_ct$pseudotime), ]
p_ct <- ggplot(df_ct, aes(x = pseudotime, fill = CellType)) +
  geom_density(alpha = 0.6, position = "fill") +
  scale_fill_viridis_d(option = "turbo") +
  labs(title = "J11d: CellType 沿伪时间分布",
       x = "Pseudotime (L1)", y = "Density (proportion)") +
  theme_minimal(base_size = 13)
ggsave(file.path(FIG_DIR, "FigJ11d_celltype_along_pseudotime.png"),
       p_ct, width = 12, height = 7, dpi = 300)
cat("✓ FigJ11d_celltype_along_pseudotime\n")

# FigJ11e: malignant 双轨迹
cat("\n── FigJ11e: malignant vs microenvironment 双轨迹 ──\n")
malig_col <- NULL
for (cand in c("inflammation_group", "Malignant", "malignant", "AML_status")) {
  if (cand %in% colnames(myeloid_obj@meta.data)) {
    malig_col <- cand
    break
  }
}

if (!is.null(malig_col)) {
  cat(sprintf("使用 '%s' 列\n", malig_col))
  print(table(myeloid_obj@meta.data[[malig_col]]))
  
  df_dual <- data.frame(
    pseudotime = myeloid_obj$pseudotime,
    LCDI_score = myeloid_obj$LCDI_score,
    status = myeloid_obj@meta.data[[malig_col]]
  )
  df_dual <- df_dual[!is.na(df_dual$pseudotime) & !is.na(df_dual$LCDI_score) & !is.na(df_dual$status), ]
  
  status_levels <- unique(df_dual$status)
  rho_per_status <- sapply(status_levels, function(s) {
    sub <- df_dual[df_dual$status == s, ]
    if (nrow(sub) < 30) return(NA)
    suppressWarnings(cor(sub$pseudotime, sub$LCDI_score, method = "spearman"))
  })
  cat("\n每组 LCDI vs pseudotime Spearman rho:\n")
  print(rho_per_status)
  
  p_dual <- ggplot(df_dual, aes(x = pseudotime, y = LCDI_score, color = status, fill = status)) +
    geom_smooth(method = "loess", se = TRUE, linewidth = 1.3, alpha = 0.2) +
    scale_color_manual(values = c("#E64B35", "#3182BD", "#1F7D3F", "#888888")[1:length(status_levels)]) +
    scale_fill_manual(values = c("#E64B35", "#3182BD", "#1F7D3F", "#888888")[1:length(status_levels)]) +
    labs(title = sprintf("J11e: GSE185381 %s 双轨迹 (核心图)", malig_col),
         subtitle = "对应 J3g (成人 normal vs malignant)",
         x = "Pseudotime (L1)", y = "LCDI score") +
    theme_minimal(base_size = 13) +
    theme(legend.position = "top")
  ggsave(file.path(FIG_DIR, "FigJ11e_dual_trajectory_LCDI.png"),
         p_dual, width = 12, height = 7, dpi = 300)
  cat("✓ FigJ11e_dual_trajectory_LCDI\n")
  
  write.csv(data.frame(status = status_levels, spearman_rho = rho_per_status),
            file.path(TAB_DIR, "J11_dual_trajectory_correlation.csv"), row.names = FALSE)
}

# 保存中间对象
saveRDS(myeloid_obj, file.path(DATA_DIR, "myeloid_obj_with_pseudotime_GSE185381.rds"))
cat("\n✓ Stage 3 完成\n")

# ─────────────────────────────────────────────
# Stage 4 跳过 (放到后续单独跑, 不阻塞主流程)
# ─────────────────────────────────────────────
cat("\n══ Stage 4: 暂跳过 (tradeSeq 单独后续跑) ══\n")
cat("如需 tradeSeq: source J11_stage4_tradeseq.R\n")

# ─────────────────────────────────────────────
# 总结
# ─────────────────────────────────────────────
cat("\n══ J11 总结 ══\n\n")
summary_lines <- c(
  sprintf("Phase J11 (修复版) 完成: %s", Sys.time()),
  sprintf("髓系子集: %d cells × %d genes", ncol(myeloid_obj), nrow(myeloid_obj)),
  sprintf("Cluster (Cell_type_identity): %d", length(unique(myeloid_obj$Cell_type_identity))),
  sprintf("起点: %s (n=%d)", start_celltype, ct_table[start_celltype]),
  sprintf("Lineage 数: %d", n_lin),
  sprintf("L1 主轴 LCDI vs pseudotime rho: %.3f, p = %.2e", rho_L1$estimate, rho_L1$p.value),
  "",
  "Lineage 详情:",
  utils::capture.output(print(lin_lcdi_stats))
)
if (exists("rho_per_status")) {
  summary_lines <- c(summary_lines, "",
    "双轨迹组 LCDI rho:",
    sapply(names(rho_per_status), function(s) sprintf("  %s: %.3f", s, rho_per_status[[s]])))
}
summary_lines <- c(summary_lines, "",
                   "vs J3 (成人 GSE116256) 对照:",
                   "  - J3 4 主轴 rho: -0.160, -0.501, -0.235, -0.270 (全部下降)",
                   "  - J3 双轨迹: normal -0.5, malignant -0.2 (恶性 LCDI 平台高)")

writeLines(summary_lines, file.path(OUT_DIR, "J11_summary.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")

cat("\n============================================================\n")
cat("✅ Phase J11 修复版完成 (Stage 1-3)\n")
cat("Stage 4 tradeSeq 待后续单独跑\n")
cat("============================================================\n")

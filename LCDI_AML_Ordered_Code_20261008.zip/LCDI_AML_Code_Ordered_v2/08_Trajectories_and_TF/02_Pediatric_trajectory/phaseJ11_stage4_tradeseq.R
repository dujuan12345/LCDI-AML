# =============================================================================
# phaseJ11_stage4_tradeseq.R
# -----------------------------------------------------------------------------
# Phase J11 Stage 4: tradeSeq 动态基因分析 (儿童 GSE185381)
# 
# 设计原则 (基于 J3 经验):
#   1. 不跑 9 条 lineage 全量, 只用 L1 主轴 + L3 GMP 阻滞 (A' 框架核心 2 lineage)
#   2. 细胞分层抽样到 ~15,000 (与 J3 规模相当, 避免 90+ min 等待)
#   3. 基因 505 个 (5 LCDI + Top 500 HVG, 比 J3 的 1004 少一半)
#   4. fitGAM nknots=6 (与 J3 一致)
#   5. parallel=FALSE (Windows 兼容)
#   6. 每步缓存, 崩溃可恢复
#   7. p 值 annotate (复用 J3 utils_pvalue_format.R)
# 
# 输入: D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE185381/J11_pseudotime/
#         Cache/stage2_sce_with_slingshot_GSE185381_FIX.rds
#         Data/myeloid_obj_with_pseudotime_GSE185381.rds
# 
# 输出: 同目录 Cache/ + Tables/ + Figures/
# 
# 预估时间: 抽样后 ~45-60 min (vs 全量 90-180 min)
# =============================================================================

cat("============================================================\n")
cat("Phase J11 Stage 4: tradeSeq (GSE185381 儿童, 抽样版)\n")
cat(sprintf("时间: %s\n", Sys.time()))
cat("============================================================\n\n")

suppressPackageStartupMessages({
  library(Seurat)
  library(slingshot)
  library(tradeSeq)
  library(SingleCellExperiment)
  library(ggplot2)
  library(dplyr)
})

# utils
utils_path <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/utils_pvalue_format.R"
if (file.exists(utils_path)) source(utils_path)

# 路径
ROOT     <- "D:/26_01_AML/AML_Lactylation_PCD/scRNA/GSE185381/J11_pseudotime"
SCE_RDS  <- file.path(ROOT, "Cache/stage2_sce_with_slingshot_GSE185381_FIX.rds")
SEU_RDS  <- file.path(ROOT, "Data/myeloid_obj_with_pseudotime_GSE185381.rds")
CACHE    <- file.path(ROOT, "Cache")
FIG_DIR  <- file.path(ROOT, "Figures")
TAB_DIR  <- file.path(ROOT, "Tables")

options(future.globals.maxSize = 16 * 1024^3)
set.seed(42)

# ─────────────────────────────────────────────
# Step 1: 加载 + 下采样
# ─────────────────────────────────────────────
cat("══ Step 1: 加载数据 + 分层下采样 ══\n\n")

step1_cache <- file.path(CACHE, "stage4_step1_subsampled.rds")

if (file.exists(step1_cache)) {
  cat("✓ 加载 Step 1 缓存\n")
  step1 <- readRDS(step1_cache)
  myeloid_obj <- step1$myeloid_obj
  sampled_cells <- step1$sampled_cells
  rm(step1); gc(verbose = FALSE)
} else {
  cat("加载 myeloid_obj (含 pseudotime)...\n")
  myeloid_obj <- readRDS(SEU_RDS)
  cat(sprintf("✓ %d cells × %d genes\n", ncol(myeloid_obj), nrow(myeloid_obj)))
  
  # ── 分层抽样到 15,000 cells (按 Cell_type_identity) ──
  TARGET_N <- 15000
  meta <- myeloid_obj@meta.data
  ct_counts <- table(meta$Cell_type_identity)
  cat(sprintf("\n原始 cell type 分布 (n=%d):\n", ncol(myeloid_obj)))
  print(sort(ct_counts, decreasing = TRUE))
  
  # 按比例分层抽样, 每类最少保留 50 (小群体不被丢)
  total <- sum(ct_counts)
  alloc <- pmax(50, round(as.numeric(ct_counts) / total * TARGET_N))
  alloc <- pmin(alloc, as.numeric(ct_counts))  # 不超过原有数量
  names(alloc) <- names(ct_counts)
  
  cat(sprintf("\n分层抽样目标 (~%d cells):\n", TARGET_N))
  print(sort(alloc, decreasing = TRUE))
  
  sampled_cells <- c()
  for (ct in names(alloc)) {
    ct_cells <- rownames(meta)[meta$Cell_type_identity == ct]
    if (length(ct_cells) > alloc[[ct]]) {
      ct_cells <- sample(ct_cells, alloc[[ct]])
    }
    sampled_cells <- c(sampled_cells, ct_cells)
  }
  cat(sprintf("\n实际抽样: %d cells (%.1f%% 原始)\n",
              length(sampled_cells), 100 * length(sampled_cells) / ncol(myeloid_obj)))
  
  saveRDS(list(myeloid_obj = myeloid_obj, sampled_cells = sampled_cells),
          step1_cache)
  cat(sprintf("✓ Step 1 缓存: %s\n", step1_cache))
}

# ─────────────────────────────────────────────
# Step 2: 准备 fitGAM 输入 (counts + pseudotime + cellWeights)
# ─────────────────────────────────────────────
cat("\n══ Step 2: 准备 fitGAM 输入 (L1 主轴 + L3 GMP 阻滞) ══\n\n")

step2_cache <- file.path(CACHE, "stage4_step2_fitGAM_input.rds")

if (file.exists(step2_cache)) {
  cat("✓ 加载 Step 2 缓存\n")
  step2 <- readRDS(step2_cache)
  count_mat <- step2$count_mat
  pst_mat <- step2$pst_mat
  weights_mat <- step2$weights_mat
  use_genes <- step2$use_genes
  rm(step2); gc(verbose = FALSE)
} else {
  # 在抽样细胞上同时有 L1 和 L3 pseudotime 的细胞
  meta <- myeloid_obj@meta.data[sampled_cells, ]
  pst_L1 <- meta$pseudotime_lineage1
  pst_L3 <- meta$pseudotime_lineage3
  
  # tradeSeq 接受 NA, 但需细胞至少一条 lineage 有 pseudotime
  has_any <- !is.na(pst_L1) | !is.na(pst_L3)
  cat(sprintf("抽样细胞中至少一条 lineage 有 pseudotime: %d / %d\n",
              sum(has_any), length(sampled_cells)))
  sampled_cells <- sampled_cells[has_any]
  pst_L1 <- pst_L1[has_any]
  pst_L3 <- pst_L3[has_any]
  
  pst_mat <- cbind(L1 = pst_L1, L3 = pst_L3)
  rownames(pst_mat) <- sampled_cells
  
  # cellWeights: 1 if cell in that lineage, 0 if not (slingshot 默认逻辑)
  weights_mat <- cbind(
    L1 = as.numeric(!is.na(pst_L1)),
    L3 = as.numeric(!is.na(pst_L3))
  )
  rownames(weights_mat) <- sampled_cells
  
  # 把 NA 在 pst_mat 中填 0 (tradeSeq 要求, 但 weight=0 会忽略这些)
  pst_mat[is.na(pst_mat)] <- 0
  
  cat(sprintf("\nfitGAM 输入维度:\n"))
  cat(sprintf("  pseudotime: %d cells × %d lineages\n", nrow(pst_mat), ncol(pst_mat)))
  cat(sprintf("  weights:    %d cells × %d lineages\n", nrow(weights_mat), ncol(weights_mat)))
  cat(sprintf("  L1 有效细胞: %d, L3 有效细胞: %d\n",
              sum(weights_mat[,"L1"] > 0), sum(weights_mat[,"L3"] > 0)))
  
  # ── 基因选择: 5 LCDI + Top 500 HVG ──
  lcdi_genes <- c("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")
  gene_present <- lcdi_genes[lcdi_genes %in% rownames(myeloid_obj)]
  cat(sprintf("\nLCDI 5 基因在数据: %d/5\n", length(gene_present)))
  
  hvg <- head(VariableFeatures(myeloid_obj), 500)
  use_genes <- unique(c(gene_present, hvg))
  use_genes <- use_genes[use_genes %in% rownames(myeloid_obj)]
  cat(sprintf("用于 fitGAM 的基因: %d (5 LCDI + Top 500 HVG, 去重)\n", length(use_genes)))
  
  # 取 counts 矩阵 (注意 Seurat v5: layer="counts")
  count_mat <- GetAssayData(myeloid_obj, assay = "RNA", layer = "counts")[use_genes, sampled_cells]
  cat(sprintf("counts 矩阵: %d genes × %d cells, sparse class: %s\n",
              nrow(count_mat), ncol(count_mat), class(count_mat)[1]))
  
  saveRDS(list(count_mat = count_mat, pst_mat = pst_mat,
               weights_mat = weights_mat, use_genes = use_genes),
          step2_cache)
  cat(sprintf("✓ Step 2 缓存: %s\n", step2_cache))
  
  # 释放 myeloid_obj (40+ MB, 之后不用)
  rm(myeloid_obj); gc(verbose = FALSE)
}

# ─────────────────────────────────────────────
# Step 3: fitGAM 拟合 (主体, 慢)
# ─────────────────────────────────────────────
cat("\n══ Step 3: fitGAM 拟合 NB GAM ══\n")
cat("⚠️ 这步计算密集 (~45-60 min, 已抽样到 15k cells)\n\n")

fit_cache <- file.path(CACHE, "stage4_fitGAM_J11.rds")

if (file.exists(fit_cache)) {
  cat("✓ 加载 fitGAM 缓存\n")
  fit_gam <- readRDS(fit_cache)
} else {
  cat(sprintf("开始 fitGAM (%d genes × %d cells, 2 lineages)...\n",
              nrow(count_mat), ncol(count_mat)))
  cat(sprintf("开始时间: %s\n", Sys.time()))
  
  t0 <- Sys.time()
  fit_gam <- tryCatch({
    fitGAM(counts = count_mat,
           pseudotime = pst_mat,
           cellWeights = weights_mat,
           nknots = 6,
           verbose = TRUE,
           parallel = FALSE)
  }, error = function(e) {
    cat(sprintf("\n❌ fitGAM 失败: %s\n", e$message))
    cat("可能原因: counts 含 NA / pseudotime 含 Inf / lineage 重叠不足\n")
    NULL
  })
  t1 <- Sys.time()
  cat(sprintf("\n结束时间: %s (耗时 %.1f min)\n", t1,
              as.numeric(difftime(t1, t0, units = "mins"))))
  
  if (!is.null(fit_gam)) {
    saveRDS(fit_gam, fit_cache)
    cat(sprintf("✓ fitGAM 缓存: %s\n", fit_cache))
  } else {
    stop("fitGAM 失败, 中止")
  }
}

# ─────────────────────────────────────────────
# Step 4: associationTest (沿伪时间显著基因)
# ─────────────────────────────────────────────
cat("\n══ Step 4: associationTest (找沿伪时间显著基因) ══\n\n")

assoc_csv <- file.path(TAB_DIR, "J11_tradeseq_associationTest.csv")

# 全局 associationTest (lineage-agnostic, 任一 lineage 显著就算)
assoc_global <- associationTest(fit_gam)
assoc_global$gene <- rownames(assoc_global)
assoc_global$padj <- p.adjust(assoc_global$pvalue, method = "BH")
assoc_global <- assoc_global[order(assoc_global$pvalue), ]

# annotate p 值 (复用 J3 工具)
if (exists("format_pval")) {
  assoc_global$pvalue_label <- sapply(assoc_global$pvalue, function(p) {
    if (is.na(p)) return("NA")
    if (p == 0) return("<2.2e-308")
    format_pval(p)
  })
  assoc_global$padj_label <- sapply(assoc_global$padj, function(p) {
    if (is.na(p)) return("NA")
    if (p == 0) return("<2.2e-308")
    format_pval(p)
  })
}

# 统计 0 值 (J3 经验: 数值下溢需 annotate)
n_zero_p <- sum(assoc_global$pvalue == 0, na.rm = TRUE)
n_zero_padj <- sum(assoc_global$padj == 0, na.rm = TRUE)
cat(sprintf("数值下溢: pvalue=0 共 %d 行, padj=0 共 %d 行 (已 annotate)\n",
            n_zero_p, n_zero_padj))

write.csv(assoc_global, assoc_csv, row.names = FALSE)
cat(sprintf("✓ %s\n", assoc_csv))

# Per-lineage associationTest
cat("\nPer-lineage associationTest (L1 + L3 分别):\n")
assoc_perlin <- associationTest(fit_gam, lineages = TRUE)
assoc_perlin$gene <- rownames(assoc_perlin)
# Per-lineage 返回多列, 提取关键
if ("waldStat_1" %in% colnames(assoc_perlin)) {
  assoc_perlin$pvalue_L1 <- assoc_perlin$pvalue_1
  assoc_perlin$pvalue_L3 <- assoc_perlin$pvalue_2
  assoc_perlin$padj_L1 <- p.adjust(assoc_perlin$pvalue_L1, method = "BH")
  assoc_perlin$padj_L3 <- p.adjust(assoc_perlin$pvalue_L3, method = "BH")
}
write.csv(assoc_perlin, file.path(TAB_DIR, "J11_tradeseq_associationTest_perLineage.csv"),
          row.names = FALSE)
cat(sprintf("✓ J11_tradeseq_associationTest_perLineage.csv\n"))

# ─────────────────────────────────────────────
# Step 5: 5 LCDI 基因关键结果
# ─────────────────────────────────────────────
cat("\n══ Step 5: 5 LCDI 基因 tradeSeq 结果 ══\n\n")

lcdi_genes <- c("CREB1", "SLC16A4", "GPX4", "CASP1", "MPO")
lcdi_in_data <- intersect(lcdi_genes, rownames(assoc_global))

cat("5 LCDI 基因全局 associationTest:\n")
lcdi_global <- assoc_global[match(lcdi_in_data, assoc_global$gene), ]
key_cols <- c("gene", "waldStat", "df", "pvalue", "padj")
key_cols <- intersect(c(key_cols, "pvalue_label", "padj_label"), colnames(lcdi_global))
print(lcdi_global[, key_cols])

write.csv(lcdi_global, file.path(TAB_DIR, "J11_tradeseq_5LCDI_global.csv"), row.names = FALSE)

if ("pvalue_L1" %in% colnames(assoc_perlin)) {
  cat("\n5 LCDI 基因 per-lineage:\n")
  lcdi_perlin <- assoc_perlin[match(lcdi_in_data, assoc_perlin$gene), ]
  perlin_cols <- intersect(c("gene", "waldStat_1", "pvalue_L1", "padj_L1",
                              "waldStat_2", "pvalue_L3", "padj_L3"),
                            colnames(lcdi_perlin))
  print(lcdi_perlin[, perlin_cols])
  write.csv(lcdi_perlin, file.path(TAB_DIR, "J11_tradeseq_5LCDI_perLineage.csv"),
            row.names = FALSE)
}

# ─────────────────────────────────────────────
# Step 6: 出图 FigJ11i (5 基因 GAM smoothers, L1 + L3)
# ─────────────────────────────────────────────
cat("\n══ Step 6: FigJ11i — 5 基因 GAM smoothers ══\n\n")

p_list <- list()
for (g in lcdi_in_data) {
  p_g <- tryCatch({
    plotSmoothers(fit_gam, counts = count_mat, gene = g) +
      ggtitle(sprintf("%s (J11, 抽样 15k)", g)) +
      theme_minimal(base_size = 10)
  }, error = function(e) {
    cat(sprintf("  ⚠ plotSmoothers %s 失败: %s\n", g, e$message))
    NULL
  })
  if (!is.null(p_g)) p_list[[g]] <- p_g
}

if (length(p_list) > 0) {
  library(patchwork)
  combined <- wrap_plots(p_list, ncol = 3)
  ggsave(file.path(FIG_DIR, "FigJ11i_5genes_smoothers.png"),
         combined, width = 14, height = 9, dpi = 300)
  cat("✓ FigJ11i_5genes_smoothers\n")
}

# ─────────────────────────────────────────────
# 总结
# ─────────────────────────────────────────────
cat("\n══ J11 Stage 4 tradeSeq 完成 ══\n\n")

summary_lines <- c(
  sprintf("J11 Stage 4 tradeSeq 完成: %s", Sys.time()),
  sprintf("抽样 cells: %d (从 45,015 髓系)", ncol(count_mat)),
  sprintf("用于拟合基因: %d (5 LCDI + Top 500 HVG)", nrow(count_mat)),
  sprintf("Lineages: L1 (HSC→Mature) + L3 (HSC→GMP arrest)"),
  sprintf("显著基因 (padj<0.05, global): %d", sum(assoc_global$padj < 0.05, na.rm = TRUE)),
  sprintf("数值下溢: pvalue=0 共 %d, padj=0 共 %d (已 annotate)", n_zero_p, n_zero_padj),
  "",
  "5 LCDI 基因 padj (与 J3 对照):"
)
for (i in seq_len(nrow(lcdi_global))) {
  summary_lines <- c(summary_lines,
    sprintf("  %s: waldStat=%.1f, padj=%s",
            lcdi_global$gene[i],
            lcdi_global$waldStat[i],
            if ("padj_label" %in% colnames(lcdi_global)) lcdi_global$padj_label[i]
            else sprintf("%.2e", lcdi_global$padj[i])))
}
summary_lines <- c(summary_lines, "",
                   "vs J3 (成人) tradeSeq 对照:",
                   "  MPO     Wald=2150, padj<2.2e-308 (重算 1.1e-464)",
                   "  ELANE   Wald=1880, padj<2.2e-308 (重算 4.9e-406)",
                   "  全部 5 LCDI 基因在 J3 中 padj<2.2e-308")

writeLines(summary_lines, file.path(ROOT, "J11_stage4_tradeseq_summary.txt"))
cat(paste(summary_lines, collapse = "\n"), "\n")

cat("\n============================================================\n")
cat("✅ J11 Stage 4 tradeSeq 完成\n")
cat("输出:\n")
cat("  - Tables/J11_tradeseq_associationTest.csv (全局)\n")
cat("  - Tables/J11_tradeseq_associationTest_perLineage.csv (L1+L3)\n")
cat("  - Tables/J11_tradeseq_5LCDI_global.csv\n")
cat("  - Tables/J11_tradeseq_5LCDI_perLineage.csv\n")
cat("  - Figures/FigJ11i_5genes_smoothers.png\n")
cat("  - J11_stage4_tradeseq_summary.txt\n")
cat("============================================================\n")

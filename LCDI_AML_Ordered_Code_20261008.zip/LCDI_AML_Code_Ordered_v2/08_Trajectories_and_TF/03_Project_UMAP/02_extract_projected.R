options(stringsAsFactors=FALSE)
suppressPackageStartupMessages({library(SingleCellExperiment);library(slingshot)})
root <- 'D:/26_01_AML'
out <- file.path(root,'_codex_audit/figure5B_umap_20260907_v1')
paths <- c(adult='AML_Lactylation_PCD/scRNA/GSE116256/J3_pseudotime/Cache/stage2_sce_with_slingshot.rds',pediatric='AML_Lactylation_PCD/scRNA/GSE185381/J11_pseudotime/Cache/stage2_sce_with_slingshot_GSE185381_FIX.rds')
for(ds in names(paths)) {
 cat('READ',ds,'\n');flush.console()
 sce <- readRDS(file.path(root,paths[[ds]]))
 compact <- readRDS(file.path(root,paste0('_codex_audit/chapter8_lightweight_supplements_20260802_v1/01_',ds,'_compact.rds')))
 xy <- reducedDim(sce,'UMAP');stopifnot(ncol(xy)==2,identical(colnames(sce),compact$meta$cell),isTRUE(all.equal(unname(xy),unname(compact$umap))))
 cells <- data.frame(compact$meta,UMAP1=xy[,1],UMAP2=xy[,2])
 write.table(cells,file.path(out,paste0('03_',ds,'_cells.tsv')),sep='\t',row.names=FALSE,quote=FALSE)
 original_curves <- slingCurves(sce); cat('original dimensions',ncol(original_curves[[1]]$s),'UMAP embedding with fixed pseudotime', '\n'); projected <- embedCurves(sce, newDimRed='UMAP', approx_points=200); stopifnot(isTRUE(all.equal(slingPseudotime(projected),slingPseudotime(sce)))); curves <- slingCurves(projected);lines <- slingLineages(sce)
 stopifnot(identical(lines,compact$lineages))
 output <- list()
 for(j in seq_along(curves)) {
  cr <- curves[[j]]; stopifnot(ncol(cr$s)==2)
  coords <- cr$s[cr$ord,,drop=FALSE]
  output[[j]] <- data.frame(lineage=paste0('L',j),order=seq_len(nrow(coords)),UMAP1=coords[,1],UMAP2=coords[,2])
 }
 write.table(do.call(rbind,output),file.path(out,paste0('03_',ds,'_curves.tsv')),sep='\t',row.names=FALSE,quote=FALSE)
 write.table(data.frame(lineage=paste0('L',seq_along(lines)),clusters=vapply(lines,paste,collapse=' -> ',FUN.VALUE=character(1))),file.path(out,paste0('03_',ds,'_lineages.tsv')),sep='\t',row.names=FALSE,quote=FALSE)
 cat('EXTRACTED',ds,nrow(cells),'cells',length(curves),'curves\n');flush.console()
 rm(sce,compact,xy,cells,curves,lines,output);gc()
}
writeLines(capture.output(sessionInfo()),file.path(out,'02_R_session.txt'))
cat('COMPLETE no refit\n')


options(stringsAsFactors=FALSE)
root <- 'D:/26_01_AML';out<-file.path(root,'_codex_audit/figure5_B_gene_trial_20260907_v1')
scores<-read.delim(file.path(root,'_codex_audit/upstream_repair_20260905_v1/state_D0/04_unit_level_scores_and_endpoints.tsv'),check.names=FALSE,fileEncoding='UTF-8-BOM')
genes<-unique(c('MEIS1','NRIP1','MSI2','ELANE','AZU1','LYZ','MNDA','CD14','MPO','ITGAM','FUT4','CD34','KIT','MKI67','CREB1','SLC16A4','GPX4','CASP1'))
results<-list()
for(ds in c('adult','pediatric')) {
 x<-readRDS(file.path(root,paste0('_codex_audit/chapter8_lightweight_supplements_20260802_v1/01_',ds,'_compact.rds')))
 m<-x$pseudobulk_logcpm;s<-scores[scores$dataset==ds,,drop=FALSE]
 stopifnot(is.matrix(m),all(genes %in% rownames(m)),all(s$pb_id %in% colnames(m)),!anyDuplicated(s$pb_id),nrow(s)==if(ds=='adult') 16 else 22)
 z<-m[genes,s$pb_id,drop=FALSE];stopifnot(all(is.finite(z)))
 results[[ds]]<-cbind(s[,c('dataset','sample','pb_id','LCDI_z','MPO_risk_z')],as.data.frame(t(z),check.names=FALSE))
}
write.table(do.call(rbind,results),file.path(out,'02_patient_logCPM.tsv'),sep='\t',quote=FALSE,row.names=FALSE,fileEncoding='UTF-8')
capture.output(sessionInfo(),file=file.path(out,'02_R_session.txt'))
cat('EXTRACTED 38 PATIENTS 18 GENES\n')

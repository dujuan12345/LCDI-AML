from pathlib import Path
import json,subprocess,sys,hashlib
import pandas as pd,numpy as np,scipy
from scipy.stats import spearmanr,rankdata
R=Path(r'D:\26_01_AML');O=Path(__file__).parent
cmd=[r'D:\R-4.5.2\bin\x64\Rscript.exe','--vanilla',str(O/'01_extract.R')]
with (O/'01_extract.log').open('wb') as f:proc=subprocess.run(cmd,stdout=f,stderr=subprocess.STDOUT)
(O/'01_command.json').write_text(json.dumps({'command':cmd,'exit_code':proc.returncode},indent=2),encoding='utf-8');assert proc.returncode==0
d=pd.read_csv(O/'02_patient_logCPM.tsv',sep='\t');assert len(d)==38 and not d.duplicated(['dataset','sample']).any()
new=['MEIS1','NRIP1','MSI2','ELANE','AZU1','LYZ','MNDA','CD14'];old=['MPO','ITGAM','CD14','FUT4','CD34','KIT','MKI67'];union=list(dict.fromkeys(new+old));assert len(union)==14
beta={'CREB1':.0925,'SLC16A4':-.0636,'GPX4':-.0721,'CASP1':-.0106,'MPO':-.2095};rows=[];rng=np.random.default_rng(20260907);qc={};redund=[]
def bh(p):
 p=np.array(p);ix=np.argsort(p);v=np.minimum.accumulate((p[ix]*len(p)/np.arange(1,len(p)+1))[::-1])[::-1];z=np.zeros(len(p));z[ix]=np.minimum(v,1);return z
for ds in ['adult','pediatric']:
 s=d[d.dataset==ds].copy();n=len(s);zmat=(s[list(beta)]-s[list(beta)].mean())/s[list(beta)].std(ddof=1);score=zmat.to_numpy()@np.array(list(beta.values()));score=(score-score.mean())/score.std(ddof=1);err=float(abs(score-s.LCDI_z).max());assert err<1e-8
 qc[ds]={'n':n,'score_error':err,'missing_expression':int(s[union].isna().sum().sum())}
 draws=rng.integers(0,n,size=(2000,n))
 corr=s[new].corr(method='spearman')
 for i,g in enumerate(new):
  for h in new[i+1:]:redund.append({'dataset':ds,'gene1':g,'gene2':h,'rho':corr.loc[g,h]})
 for pred in ['LCDI_z','MPO_risk_z']:
  x=s[pred].to_numpy();rx=rankdata(x[draws],axis=1);rx-=rx.mean(1,keepdims=True)
  for g in union:
   y=s[g].to_numpy();rho,p=spearmanr(x,y);ry=rankdata(y[draws],axis=1);ry-=ry.mean(1,keepdims=True);den=np.sqrt((rx*rx).sum(1)*(ry*ry).sum(1));boot=np.divide((rx*ry).sum(1),den,out=np.full(2000,np.nan),where=den>0);valid=boot[np.isfinite(boot)];assert len(valid)>=1900
   ci=np.quantile(valid,[.025,.975],method='median_unbiased');loo=np.array([spearmanr(np.delete(x,k),np.delete(y,k)).statistic for k in range(n)])
   rows.append({'dataset':ds,'endpoint_id':g,'endpoint':g,'family':'literature_representative_gene','predictor':pred,'n':n,'rho':rho,'p_value':p,'bootstrap_ci_low':ci[0],'bootstrap_ci_high':ci[1],'bootstrap_valid':len(valid),'loo_direction_stability':float(np.mean(np.sign(loo)==np.sign(rho))),'loo_min_rho':float(loo.min()),'loo_max_rho':float(loo.max()),'self_coupled':g in beta,'new_panel':g in new,'old_family':g in old})
all=pd.DataFrame(rows)
for (ds,pred),sub in all.groupby(['dataset','predictor']):
 all.loc[sub.index,'fdr_union14']=bh(sub.p_value)
 for flag,col in [('new_panel','fdr'),('old_family','fdr_old7')]:
  ii=sub.index[sub[flag]];all.loc[ii,col]=bh(all.loc[ii,'p_value'])
orig=pd.read_csv(R/'_codex_audit/upstream_repair_20260905_v1/state_D0/05_association_results.tsv',sep='\t');oldcheck=all[all.old_family].merge(orig,on=['dataset','endpoint_id','predictor'],suffixes=('_new','_old'))
for a,b in [('rho_new','rho_old'),('p_value_new','p_value_old'),('fdr_old7','fdr_old')]:assert np.max(np.abs(oldcheck[a]-oldcheck[b]))<1e-10,(a,b)
newtable=all[all.new_panel].copy();newtable['order']=newtable.endpoint_id.map({g:i for i,g in enumerate(new)});newtable=newtable.sort_values(['dataset','order','predictor']).drop(columns='order')
newtable.to_csv(O/'03_new_gene_associations.tsv',sep='\t',index=False,encoding='utf-8-sig');all.to_csv(O/'03_all14_comparison.tsv',sep='\t',index=False,encoding='utf-8-sig');pd.DataFrame(redund).to_csv(O/'03_gene_redundancy.tsv',sep='\t',index=False,encoding='utf-8-sig')
qc.update({'passed':True,'seed':20260907,'bootstrap':2000,'old_28_associations_reproduced':len(oldcheck)==28,'new_gene_family':8,'comparison_union_family':14,'python':sys.version,'numpy':np.__version__,'scipy':scipy.__version__,'pandas':pd.__version__})
(O/'04_analysis_QC.json').write_text(json.dumps(qc,indent=2),encoding='utf-8');print(newtable[['dataset','endpoint_id','predictor','rho','p_value','fdr','fdr_union14','loo_direction_stability']].to_string(index=False))

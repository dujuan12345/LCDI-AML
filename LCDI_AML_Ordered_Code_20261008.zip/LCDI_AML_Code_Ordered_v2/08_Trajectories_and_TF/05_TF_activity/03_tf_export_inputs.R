options(stringsAsFactors=FALSE)
root<-'D:/26_01_AML';task<-file.path(root,'_codex_audit/upstream_repair_20260905_v1');out<-file.path(task,'tf');dir.create(out,showWarnings=FALSE)
w<-function(x,n)write.table(x,file.path(out,n),sep='\t',quote=FALSE,row.names=FALSE,na='NA')
for(ds in c('adult','pediatric')) {
 p<-readRDS(file.path(root,'_codex_audit/tf_triangulation_sgs10_20260904_v1/inputs',paste0(ds,'_fixed_tf_input_v1.rds')))
 m<-as.data.frame(p$metadata);stopifnot(identical(colnames(p$counts),m$cell_id),!anyDuplicated(m$cell_id))
 m$biological_id<-if(ds=='adult')m$patient else m$samples
 m$source_corrected<-m$source_fixed
 if(ds=='adult')m$source_corrected[m$patient%in%c('OCI-AML3','MUTZ3')]<-'cell_line'
 m$include_primary<-m$source_corrected!='cell_line';w(m,paste0(ds,'_cell_metadata_corrected.tsv'))
 cat(ds,'cells',nrow(m),'included',sum(m$include_primary),'\n')
 rm(p);gc()
}
capture.output(sessionInfo(),file=file.path(out,'export_session_info.txt'))

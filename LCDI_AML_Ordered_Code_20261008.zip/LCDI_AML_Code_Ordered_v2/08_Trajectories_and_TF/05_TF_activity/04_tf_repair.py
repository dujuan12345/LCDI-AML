from pathlib import Path
import csv,gzip,json,platform,sys
import numpy as np
import pandas as pd
R=Path('D:/26_01_AML'); TASK=R/'_codex_audit/upstream_repair_20260905_v1';OUT=TASK/'tf';BASE=R/'_codex_audit/tf_triangulation_sgs10_20260904_v1';SERVER=BASE/'server_return'
MYC=['MYC','MAX','E2F1','E2F2','E2F3','E2F4','TFDP1'];IFN=['STAT1','STAT2','IRF1','IRF2','IRF7','IRF9']
assert not (OUT/'COMPLETE').exists()
def write(x,n):x.to_csv(OUT/n,sep='\t',index=False)
def robust(v):
 s=1.4826*np.median(np.abs(v));s=s if s>1e-12 else np.std(v,ddof=1)
 return np.clip(v/s,-3,3)
allrows=[];sens=[];qc=[]
for ds,key,j in [('adult','adult_GSE116256','GSE116256/J5_decoupleR'),('pediatric','pediatric_GSE185381','GSE185381/J13_decoupleR')]:
 meta=pd.read_csv(OUT/f'{ds}_cell_metadata_corrected.tsv',sep='\t').set_index('cell_id',drop=False)
 case='AML' if ds=='adult' else 'malignant';ctrl='BM' if ds=='adult' else 'microenvironment'
 print('BEGIN',ds,flush=True)
 path=R/'AML_Lactylation_PCD/scRNA'/j/'Results/TF_activity_cell_level.csv.gz'
 with gzip.open(path,'rt',encoding='utf-8-sig',newline='') as f:
  reader=csv.reader(f);cells=next(reader)[1:];assert len(cells)==len(set(cells));assert set(cells)==set(meta.index)
  m=meta.loc[cells].copy();m['unit']=m.biological_id+'__'+m.celltype_fixed+'__'+m.source_corrected
  units=list(dict.fromkeys(m.unit));indices=[np.flatnonzero(m.unit.values==u) for u in units]
  unitmeta=m.groupby('unit',sort=False).agg(sample_id=('biological_id','first'),source=('source_corrected','first'),n_cells=('cell_id','size')).loc[units].reset_index()
  sample_keys=list(dict.fromkeys(unitmeta.sample_id+'__'+unitmeta.source));ukey=unitmeta.sample_id+'__'+unitmeta.source
  sm=unitmeta.assign(sample_source=ukey).groupby('sample_source',sort=False).agg(sample_id=('sample_id','first'),source=('source','first'),n_cells=('n_cells','sum'),n_units=('unit','size')).loc[sample_keys].reset_index()
  rows=[];pooled=[];d0rows=[]
  valid=m.source_corrected.isin([case,ctrl]);ci=(m.source_corrected==case).values;bi=(m.source_corrected==ctrl).values
  oldbi=(m.source_fixed==ctrl).values
  d0indices=[];d0keys=[]
  if ds=='adult':
   d0=m.source_corrected.eq(ctrl)|(m.source_corrected.eq(case)&m.timepoint.eq('D0'))
   for u in units:
    ii=np.flatnonzero((m.unit.values==u)&d0.values)
    if len(ii):d0indices.append(ii);d0keys.append(u)
  for row in reader:
   tf=row[0];v=np.asarray(row[1:],dtype=float);assert len(v)==len(cells) and np.isfinite(v).all()
   uv=np.array([v[ii].mean() for ii in indices]);sv=[uv[(ukey==k).values].mean() for k in sample_keys]
   rows.append([tf]+sv)
   pooled.append([tf,float(v[ci].mean()-v[oldbi].mean()),float(v[ci].mean()-v[bi].mean())])
   if ds=='adult':
    du=pd.DataFrame({'unit':d0keys,'v':[v[ii].mean() for ii in d0indices]}).merge(unitmeta,on='unit')
    dsv=du.groupby(['sample_id','source']).v.mean().reset_index()
    d0rows.append([tf,float(dsv.loc[dsv.source.eq(case),'v'].mean()-dsv.loc[dsv.source.eq(ctrl),'v'].mean())])
 act=pd.DataFrame(rows,columns=['TF']+sample_keys).set_index('TF');write(act.reset_index(),f'{ds}_ULM_patient_activity.tsv');write(sm,f'{ds}_ULM_patient_metadata.tsv')
 pooled=pd.DataFrame(pooled,columns=['TF','old_cell_weighted_difference','corrected_cell_weighted_difference']);write(pooled,f'{ds}_ULM_source_only_correction.tsv')
 if ds=='adult':write(pd.DataFrame(d0rows,columns=['TF','difference']),f'{ds}_ULM_D0_sensitivity.tsv')
 oldpooled=pd.read_csv(R/'AML_Lactylation_PCD/scRNA'/j/'Results/TF_activity_by_source.csv',index_col=0)
 oldcalc=pooled.set_index('TF').old_cell_weighted_difference
 err=float(np.max(np.abs(oldcalc-(oldpooled[case]-oldpooled[ctrl]).reindex(oldcalc.index))));assert err<1e-8
 qc.append(dict(cohort=ds,check='ULM_cached_cell_scores_reproduce_original',value=err))
 methods={'decoupleR':(act,sm)}
 for method,folder,af,mf in [('VIPER','viper','viper_activity_by_sample.tsv','viper_sample_metadata.tsv'),('SCENIC','scenic','regulon_auc_by_sample.tsv','regulon_auc_sample_metadata.tsv')]:
  a=pd.read_csv(SERVER/f'{folder}_{key}'/af,sep='\t',index_col=0)
  mm=pd.read_csv(SERVER/f'{folder}_{key}'/mf,sep='\t')
  if ds=='adult':mm.loc[mm.sample_id.isin(['OCI-AML3','MUTZ3']),'source']='cell_line'
  assert list(a.columns)==mm.sample_source.tolist()
  if method=='SCENIC':
   a.index=a.index.str.replace(r'(_extended)?\s*\(.*$', '',regex=True)
   a=a.groupby(level=0,sort=False).mean()
  methods[method]=(a,mm)
 for method,(a,mm) in methods.items():
  keep=mm.source.isin([case,ctrl]);mm=mm.loc[keep].copy();a=a.loc[:,mm.sample_source]
  c=mm.source.eq(case).values;b=mm.source.eq(ctrl).values
  assert mm.loc[c,'sample_id'].is_unique and mm.loc[b,'sample_id'].is_unique
  diff=a.loc[:,c].mean(axis=1)-a.loc[:,b].mean(axis=1)
  rows=pd.DataFrame({'TF':a.index,'difference':diff.values,'cohort':ds.title(),'method':method,'n_case':sum(c),'n_control':sum(b),'effect_z':robust(diff.values),'inference':'descriptive_patient_mean_difference'})
  rows['direction']=np.sign(rows.difference).astype(int);allrows.append(rows)
  write(mm,f'{ds}_{method}_corrected_comparison_metadata.tsv')
  if ds=='adult':
   for tag,bsel,csel in [('controls_min20cells',b&(mm.n_cells.values>=20),c)]+[(f'omit_{sample}',b&mm.sample_id.ne(sample).values,c) for sample in mm.loc[b,'sample_id']]:
    d=a.loc[:,csel].mean(axis=1)-a.loc[:,bsel].mean(axis=1)
    ss=pd.DataFrame({'TF':a.index,'difference':d.values,'primary_difference':diff.values,'method':method,'sensitivity':tag,'n_case':sum(csel),'n_control':sum(bsel)})
    ss['same_direction']=np.sign(ss.difference)==np.sign(ss.primary_difference);sens.append(ss)
  else:
   cases=mm.loc[c].set_index('sample_id');controls=mm.loc[b].set_index('sample_id');pairs=cases.index.intersection(controls.index)
   qc.append(dict(cohort=ds,check=method+'_matched_source_pairs',value=len(pairs)))
   if len(pairs):
    pairdiff=a[cases.loc[pairs,'sample_source']].to_numpy()-a[controls.loc[pairs,'sample_source']].to_numpy()
    pdiff=pd.DataFrame({'TF':a.index,'paired_mean_difference':pairdiff.mean(axis=1),'pairs':len(pairs),'same_direction':np.sign(pairdiff.mean(axis=1))==np.sign(diff.values)})
    write(pdiff,f'{ds}_{method}_paired_sensitivity.tsv')
 if ds=='adult':
  disc=pd.read_csv(SERVER/f'scenic_{key}'/'discovery_cell_manifest.tsv',sep='\t').merge(meta[['cell_id','source_corrected','biological_id']].reset_index(drop=True),on='cell_id',validate='one_to_one')
  disc['role']='frozen_unsupervised_network_discovery';write(disc,'adult_SCENIC_discovery_sources_corrected.tsv')
  qc.append(dict(cohort=ds,check='OCI_cells_in_frozen_SCENIC_discovery',value=sum(disc.source_corrected=='cell_line')))
 data=None
alltf=pd.concat(allrows,ignore_index=True);write(alltf,'01_all_corrected_TF_effects.tsv')
display=alltf[alltf.TF.isin(MYC+IFN)].copy();display['program']=np.where(display.TF.isin(MYC),'MYC/E2F','IFN/STAT/IRF');write(display,'02_display_corrected_TF_effects.tsv')
old=pd.read_csv(BASE/'14_display_tf_method_effects.tsv',sep='\t');comp=old.merge(display,on=['cohort','method','TF','program'],how='outer',suffixes=('_old','_new'));comp['direction_changed']=comp.direction_old!=comp.direction_new;write(comp,'03_display_before_after.tsv')
sen=pd.concat(sens,ignore_index=True);write(sen,'04_all_adult_control_sensitivity.tsv');write(sen[sen.TF.isin(MYC+IFN)],'04_display_adult_control_sensitivity.tsv')
summ=display.groupby(['cohort','method','program']).direction.agg(available='size',higher=lambda x:sum(x>0),lower=lambda x:sum(x<0)).reset_index();write(summ,'05_program_summary.tsv');write(pd.DataFrame(qc),'06_QC.tsv')
(OUT/'environment.json').write_text(json.dumps({'python':sys.version,'numpy':np.__version__,'pandas':pd.__version__,'conda_activated':False,'VIPER':'frozen cached activity; no local package; original scaling retained','SCENIC':'frozen discovered regulons; cell line excluded from clinical comparison'},indent=2),encoding='utf-8')
(OUT/'COMPLETE').write_text('passed_computational_checks; descriptive source-corrected contrasts conditional on frozen activity\n')
print(summ.to_string(index=False));print('COMPLETE')

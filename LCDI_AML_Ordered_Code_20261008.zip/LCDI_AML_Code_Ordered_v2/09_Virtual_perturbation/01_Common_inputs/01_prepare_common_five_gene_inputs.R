options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

root <- "D:/26_01_AML"
out <- Sys.getenv(
  "LCDI_VP_PREP_OUT",
  unset = file.path(root, "_codex_audit/five_gene_virtual_perturbation_server_20260831_v1/prepared_inputs")
)
source_prep <- file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1/prepared_inputs_v3")
frozen_cells_path <- file.path(source_prep, "02_cell_manifest.tsv")
adult_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J2_LCDI/Data/seurat_obj_with_LCDI.rds")
pediatric_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE185381/J10_LCDI/Data/seurat_obj_with_LCDI_GSE185381.rds")

seed <- 20260831L
target_genes <- c("CASP1", "MPO", "CREB1", "GPX4", "SLC16A4")
run_targets <- c("CREB1", "GPX4")
n_network_genes <- 5000L
set.seed(seed)

dir.create(out, recursive = TRUE, showWarnings = FALSE)
status_path <- file.path(out, "01_prepare_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed preparation: ", status_path)
stopifnot(file.exists(frozen_cells_path), file.exists(adult_path), file.exists(pediatric_path))

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

frozen_cells <- read.delim(frozen_cells_path, check.names = FALSE)
stopifnot(all(c("dataset", "cell", "patient", "original_label") %in% names(frozen_cells)))

process_dataset <- function(path, dataset) {
  cat("Loading", dataset, path, "\n")
  obj <- readRDS(path)
  stopifnot(inherits(obj, "Seurat"), "RNA" %in% names(obj@assays))
  manifest <- frozen_cells[frozen_cells$dataset == dataset, , drop = FALSE]
  stopifnot(nrow(manifest) > 0L, !anyDuplicated(manifest$cell))

  counts_all <- LayerData(obj[["RNA"]], layer = "counts")
  stopifnot(all(manifest$cell %in% colnames(counts_all)), all(target_genes %in% rownames(counts_all)))
  counts <- counts_all[, manifest$cell, drop = FALSE]

  tmp <- CreateSeuratObject(counts = counts, assay = "RNA", min.cells = 0, min.features = 0)
  tmp <- NormalizeData(tmp, normalization.method = "LogNormalize", scale.factor = 10000, verbose = FALSE)
  tmp <- FindVariableFeatures(tmp, selection.method = "vst", nfeatures = n_network_genes, verbose = FALSE)
  hvgs <- VariableFeatures(tmp)
  selected_genes <- unique(c(target_genes, setdiff(hvgs, target_genes)))
  if (length(selected_genes) < n_network_genes) {
    fallback <- setdiff(rownames(counts)[order(Matrix::rowSums(counts > 0), decreasing = TRUE)], selected_genes)
    selected_genes <- c(selected_genes, head(fallback, n_network_genes - length(selected_genes)))
  }
  selected_genes <- selected_genes[seq_len(n_network_genes)]
  stopifnot(length(selected_genes) == n_network_genes, all(target_genes %in% selected_genes))
  network_counts <- counts[selected_genes, , drop = FALSE]

  old_counts_path <- file.path(source_prep, paste0("02_", dataset, "_balanced_monocytic_5000gene_counts.rds"))
  old_counts <- readRDS(old_counts_path)
  stopifnot(identical(colnames(network_counts), colnames(old_counts)))

  detection <- do.call(rbind, lapply(target_genes, function(gene) {
    positive <- as.numeric(network_counts[gene, ] > 0)
    patient_positive <- tapply(positive, manifest$patient, sum)
    data.frame(
      dataset = dataset,
      gene = gene,
      cells = ncol(network_counts),
      patients = length(unique(manifest$patient)),
      detected_cells = sum(positive),
      detection_rate = mean(positive),
      total_counts = sum(network_counts[gene, ]),
      patients_with_ge5_detected_cells = sum(patient_positive >= 5L),
      gate_detected_cells_ge25 = sum(positive) >= 25L,
      gate_detection_rate_ge005 = mean(positive) >= 0.05,
      gate_patients_ge5 = sum(patient_positive >= 5L) >= 5L,
      formal_target_gate = if (gene %in% run_targets) {
        sum(positive) >= 25L && mean(positive) >= 0.05 && sum(patient_positive >= 5L) >= 5L
      } else {
        NA
      },
      stringsAsFactors = FALSE
    )
  }))

  gene_manifest <- data.frame(
    dataset = dataset,
    rank = seq_along(selected_genes),
    gene = selected_genes,
    forced_LCDI_gene = selected_genes %in% target_genes,
    detected_cells = as.numeric(Matrix::rowSums(network_counts > 0)),
    total_counts = as.numeric(Matrix::rowSums(network_counts)),
    stringsAsFactors = FALSE
  )
  qc <- data.frame(
    dataset = dataset,
    source_object = normalizePath(path, winslash = "/"),
    genes = nrow(network_counts),
    cells = ncol(network_counts),
    patients = length(unique(manifest$patient)),
    frozen_cell_order_identical = identical(colnames(network_counts), manifest$cell),
    old_gene_overlap = length(intersect(rownames(network_counts), rownames(old_counts))),
    all_five_LCDI_genes_present = all(target_genes %in% rownames(network_counts)),
    sparse_matrix = inherits(network_counts, "sparseMatrix"),
    nonnegative = min(network_counts) >= 0,
    integer_counts = all(network_counts@x == floor(network_counts@x)),
    stringsAsFactors = FALSE
  )
  qc$gate_pass <- with(qc,
    genes == n_network_genes & frozen_cell_order_identical & all_five_LCDI_genes_present &
      sparse_matrix & nonnegative & integer_counts
  ) && all(detection$formal_target_gate[detection$gene %in% run_targets])

  saveRDS(network_counts,
          file.path(out, paste0("01_", dataset, "_balanced_monocytic_common5_5000gene_counts.rds")),
          compress = "xz")
  rm(obj, counts_all, counts, tmp, network_counts, old_counts)
  gc()
  list(qc = qc, detection = detection, genes = gene_manifest, cells = manifest)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
adult <- process_dataset(adult_path, "adult")
pediatric <- process_dataset(pediatric_path, "pediatric")
qc <- rbind(adult$qc, pediatric$qc)
detection <- rbind(adult$detection, pediatric$detection)
write_tsv(qc, "01_input_qc.tsv")
write_tsv(detection, "01_target_detection.tsv")
write_tsv(rbind(adult$genes, pediatric$genes), "01_gene_manifest.tsv")
write_tsv(rbind(adult$cells, pediatric$cells), "01_cell_manifest.tsv")
capture.output(sessionInfo(), file = file.path(out, "01_session_info.txt"))
all_pass <- all(qc$gate_pass)
write_tsv(data.frame(
  field = c("status", "completed", "seed", "all_datasets_pass", "R_version", "Seurat_version", "Matrix_version"),
  value = c(ifelse(all_pass, "passed", "failed"), format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
            seed, all_pass, as.character(getRversion()), as.character(packageVersion("Seurat")),
            as.character(packageVersion("Matrix"))),
  stringsAsFactors = FALSE
), "01_prepare_status.tsv")
print(as.data.frame(qc))
print(as.data.frame(detection))
cat("Gate status:", ifelse(all_pass, "passed", "failed"), "\n")
if (!all_pass) quit(save = "no", status = 2, runLast = FALSE)

clean_exit_dll <- Sys.getenv("LCDI_CLEAN_EXIT_DLL", unset = "")
if (nzchar(clean_exit_dll)) {
  flush.console()
  dll <- dyn.load(clean_exit_dll)
  .C(getNativeSymbolInfo("clean_exit", PACKAGE = dll), as.integer(0))
}

options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(scTenifoldKnk)
  library(Matrix)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 3L) {
  stop("Usage: Rscript 02_run_virtual_perturbation_server.R <adult|pediatric> <CREB1|GPX4> <formal|smoke>")
}
dataset <- match.arg(args[[1]], c("adult", "pediatric"))
target <- match.arg(args[[2]], c("CREB1", "GPX4"))
mode <- match.arg(args[[3]], c("formal", "smoke"))

base_out <- Sys.getenv("LCDI_VP_BASE", unset = "")
if (!nzchar(base_out)) stop("LCDI_VP_BASE is required")
prep <- file.path(base_out, "prepared_inputs")
run_out <- file.path(base_out, if (mode == "formal") "formal_runs" else "smoke_test")
dir.create(run_out, recursive = TRUE, showWarnings = FALSE)

seed_map <- c(
  smoke_adult_CREB1 = 2026083111L,
  smoke_adult_GPX4 = 2026083112L,
  smoke_pediatric_CREB1 = 2026083113L,
  smoke_pediatric_GPX4 = 2026083114L,
  formal_adult_CREB1 = 2026083151L,
  formal_adult_GPX4 = 2026083152L,
  formal_pediatric_CREB1 = 2026083153L,
  formal_pediatric_GPX4 = 2026083154L
)
run_id <- paste(mode, dataset, target, sep = "_")
seed <- unname(seed_map[[run_id]])
if (is.null(seed) || is.na(seed)) stop("Unknown run id: ", run_id)
set.seed(seed)

input_path <- file.path(prep, paste0("01_", dataset, "_balanced_monocytic_common5_5000gene_counts.rds"))
cell_manifest_path <- file.path(prep, "01_cell_manifest.tsv")
stopifnot(file.exists(input_path), file.exists(cell_manifest_path), dir.exists(run_out))
prefix <- paste0(ifelse(mode == "formal", "02", "smoke"), "_", dataset, "_", target)
status_path <- file.path(run_out, paste0(prefix, "_status.tsv"))
if (file.exists(status_path)) stop("Refusing to overwrite completed run: ", status_path)

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

counts <- readRDS(input_path)
lcdi_genes <- c("CASP1", "MPO", "CREB1", "GPX4", "SLC16A4")
stopifnot(inherits(counts, "Matrix"), all(lcdi_genes %in% rownames(counts)))
if (mode == "smoke") {
  keep <- unique(c(lcdi_genes, setdiff(rownames(counts), lcdi_genes)[seq_len(495L)]))
  counts <- counts[keep, seq_len(min(300L, ncol(counts))), drop = FALSE]
}
counts <- counts[c(target, setdiff(rownames(counts), target)), , drop = FALSE]
target_detected <- sum(counts[target, ] > 0)
target_rate <- target_detected / ncol(counts)
if (target_detected < 25L) stop(target, " detected in fewer than 25 cells")

params <- if (mode == "formal") {
  list(nNet = 10L, nCells = 500L, nComp = 3L, nCores = 8L)
} else {
  list(nNet = 2L, nCells = 100L, nComp = 2L, nCores = 2L)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Run:", run_id, "seed:", seed, "\n")
cat("Input:", nrow(counts), "genes x", ncol(counts), "cells\n")
cat("Target detection:", target_detected, sprintf("(%.4f)", target_rate), "\n")
cat("Parameters:", paste(names(params), unlist(params), sep = "=", collapse = "; "), "\n")
start_time <- Sys.time()

dense_counts <- as.matrix(counts)
storage.mode(dense_counts) <- "numeric"
result <- scTenifoldKnk::scTenifoldKnk(
  countMatrix = dense_counts,
  qc = FALSE,
  gKO = target,
  nc_nNet = params$nNet,
  nc_nCells = min(params$nCells, ncol(dense_counts)),
  nc_nComp = params$nComp,
  nc_scaleScores = TRUE,
  nc_symmetric = FALSE,
  nc_q = 0.9,
  td_K = 3,
  td_maxIter = 1000,
  td_maxError = 1e-5,
  td_nDecimal = 3,
  ma_nDim = 2,
  nCores = params$nCores
)
elapsed_minutes <- as.numeric(difftime(Sys.time(), start_time, units = "mins"))
stopifnot(is.list(result), "diffRegulation" %in% names(result), nrow(result$diffRegulation) == nrow(dense_counts))

dr <- result$diffRegulation
stopifnot(all(c("gene", "distance", "Z", "FC", "p.value", "p.adj") %in% colnames(dr)))
dr_no_target <- dr[dr$gene != target, , drop = FALSE]
cell_manifest <- read.delim(cell_manifest_path, check.names = FALSE)
summary <- data.frame(
  dataset = dataset,
  target = target,
  mode = mode,
  genes = nrow(dense_counts),
  cells = ncol(dense_counts),
  patients = length(unique(cell_manifest$patient[cell_manifest$dataset == dataset])),
  target_detected_cells = target_detected,
  target_detection_rate = target_rate,
  FDR05_excluding_target = sum(dr_no_target$p.adj < 0.05, na.rm = TRUE),
  P05_excluding_target = sum(dr_no_target$p.value < 0.05, na.rm = TRUE),
  elapsed_minutes = elapsed_minutes,
  seed = seed,
  nc_nNet = params$nNet,
  nc_nCells = min(params$nCells, ncol(dense_counts)),
  nc_nComp = params$nComp,
  nCores = params$nCores,
  scTenifoldKnk_version = as.character(packageVersion("scTenifoldKnk")),
  R_version = as.character(getRversion()),
  stringsAsFactors = FALSE
)

saveRDS(result, file.path(run_out, paste0(prefix, "_result.rds")), compress = "xz")
write_tsv(dr, file.path(run_out, paste0(prefix, "_diffRegulation.tsv")))
ord <- order(dr_no_target$p.adj, -abs(dr_no_target$Z))
write_tsv(dr_no_target[ord[seq_len(min(100L, length(ord)))], , drop = FALSE],
          file.path(run_out, paste0(prefix, "_top100.tsv")))
write_tsv(summary, file.path(run_out, paste0(prefix, "_summary.tsv")))
capture.output(sessionInfo(), file = file.path(run_out, paste0(prefix, "_session_info.txt")))
write_tsv(data.frame(
  field = c("status", "completed", "dataset", "target", "mode", "elapsed_minutes", "seed"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), dataset, target, mode,
            elapsed_minutes, seed),
  stringsAsFactors = FALSE
), status_path)
cat("Completed:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
print(as.data.frame(summary))


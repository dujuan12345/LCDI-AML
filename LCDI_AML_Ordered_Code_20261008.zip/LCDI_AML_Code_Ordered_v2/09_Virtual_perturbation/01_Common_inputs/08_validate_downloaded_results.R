options(stringsAsFactors = FALSE, warn = 1)

root <- "D:/26_01_AML"
base <- file.path(root, "_codex_audit/five_gene_virtual_perturbation_server_20260831_v1")
download <- file.path(base, "downloaded_server_results")
run_dir <- file.path(download, "formal_runs")
out_path <- file.path(base, "09_downloaded_result_validation.tsv")
status_path <- file.path(base, "09_downloaded_result_validation_status.tsv")
if (file.exists(out_path) || file.exists(status_path)) stop("Refusing to overwrite completed validation")

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

datasets <- c("adult", "pediatric")
targets <- c("CREB1", "GPX4")
required_dr <- c("gene", "distance", "Z", "FC", "p.value", "p.adj")
rows <- list()

for (dataset in datasets) {
  for (target in targets) {
    prefix <- paste0("02_", dataset, "_", target)
    rds_path <- file.path(run_dir, paste0(prefix, "_result.rds"))
    dr_path <- file.path(run_dir, paste0(prefix, "_diffRegulation.tsv"))
    summary_path <- file.path(run_dir, paste0(prefix, "_summary.tsv"))
    status_file <- file.path(run_dir, paste0(prefix, "_status.tsv"))
    stopifnot(file.exists(rds_path), file.exists(dr_path), file.exists(summary_path), file.exists(status_file))

    result <- readRDS(rds_path)
    dr <- read.delim(dr_path, check.names = FALSE)
    sm <- read.delim(summary_path, check.names = FALSE)
    st <- read.delim(status_file, check.names = FALSE)
    result_dr <- result$diffRegulation

    checks <- c(
      result_is_list = is.list(result),
      result_has_diffRegulation = "diffRegulation" %in% names(result),
      result_rows_5000 = !is.null(result_dr) && nrow(result_dr) == 5000L,
      tsv_rows_5000 = nrow(dr) == 5000L,
      required_columns = all(required_dr %in% names(dr)),
      no_duplicate_gene = !anyDuplicated(dr$gene),
      target_present = target %in% dr$gene,
      no_na_gene = !anyNA(dr$gene),
      no_na_p = !anyNA(dr$p.value),
      no_na_fdr = !anyNA(dr$p.adj),
      p_range = all(dr$p.value >= 0 & dr$p.value <= 1),
      fdr_range = all(dr$p.adj >= 0 & dr$p.adj <= 1),
      result_tsv_gene_identical = identical(as.character(result_dr$gene), as.character(dr$gene)),
      result_tsv_p_tolerance = isTRUE(all.equal(as.numeric(result_dr$p.value), dr$p.value, tolerance = 1e-12)),
      summary_one_row = nrow(sm) == 1L,
      summary_dimensions = nrow(sm) == 1L && sm$genes == 5000L && sm$cells == ifelse(dataset == "adult", 1699L, 3070L),
      summary_target = nrow(sm) == 1L && sm$target == target && sm$dataset == dataset,
      status_passed = any(st$field == "status" & st$value == "passed")
    )

    rows[[length(rows) + 1L]] <- data.frame(
      dataset = dataset,
      target = target,
      genes = nrow(dr),
      P05_excluding_target = sum(dr$p.value < 0.05 & dr$gene != target),
      FDR05_excluding_target = sum(dr$p.adj < 0.05 & dr$gene != target),
      checks_total = length(checks),
      checks_passed = sum(checks),
      all_pass = all(checks),
      failed_checks = paste(names(checks)[!checks], collapse = ";"),
      stringsAsFactors = FALSE
    )
    rm(result, result_dr, dr)
    gc()
  }
}

validation <- do.call(rbind, rows)
all_pass <- all(validation$all_pass)
write_tsv(validation, out_path)
write_tsv(data.frame(
  field = c("status", "completed", "runs", "checks_total", "checks_passed", "R_version"),
  value = c(ifelse(all_pass, "passed", "failed"), format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
            nrow(validation), sum(validation$checks_total), sum(validation$checks_passed), as.character(getRversion())),
  stringsAsFactors = FALSE
), status_path)
capture.output(sessionInfo(), file = file.path(base, "09_downloaded_result_validation_session_info.txt"))
print(as.data.frame(validation))
if (!all_pass) quit(save = "no", status = 2, runLast = FALSE)


options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(Seurat)
  library(Matrix)
})

root <- "D:/26_01_AML"
out <- Sys.getenv(
  "CASP1_VP_PREP_OUT",
  unset = file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1")
)
seed <- 20260829L
max_cells_per_patient <- 300L
min_cells_per_patient <- 20L
target_genes <- c("CASP1", "MPO")
n_network_genes <- 5000L
set.seed(seed)

adult_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J2_LCDI/Data/seurat_obj_with_LCDI.rds")
pediatric_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE185381/J10_LCDI/Data/seurat_obj_with_LCDI_GSE185381.rds")
stopifnot(dir.exists(out), file.exists(adult_path), file.exists(pediatric_path))
status_path <- file.path(out, "02_prepare_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed gate: ", status_path)

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

process_dataset <- function(path, dataset) {
  cat("Loading", dataset, path, "\n")
  obj <- readRDS(path)
  stopifnot(inherits(obj, "Seurat"), "RNA" %in% names(obj@assays))
  meta <- obj[[]]

  if (dataset == "adult") {
    required <- c("source", "timepoint", "PredictionRefined_clean", "patient", "CellType_ordered")
    stopifnot(all(required %in% colnames(meta)))
    keep0 <- meta$source == "AML" & meta$timepoint == "D0" &
      meta$PredictionRefined_clean == "malignant" &
      meta$CellType_ordered %in% c("ProMono-like", "Mono-like")
    patient <- as.character(meta$patient)
    label <- as.character(meta$CellType_ordered)
  } else {
    required <- c("ap_aml_age", "malignant", "samples", "Broad_cell_identity")
    stopifnot(all(required %in% colnames(meta)))
    keep0 <- meta$ap_aml_age == "pediatric_AML" & meta$malignant == "malignant" &
      meta$Broad_cell_identity %in% c("CD14+ monocyte", "HLA-II+ monocyte", "CD16+ monocyte")
    patient <- as.character(meta$samples)
    label <- as.character(meta$Broad_cell_identity)
  }
  keep0 <- keep0 & !is.na(patient) & nzchar(patient)
  cells0 <- rownames(meta)[keep0]
  patient0 <- patient[keep0]
  label0 <- label[keep0]
  patient_n <- table(patient0)
  eligible <- names(patient_n[patient_n >= min_cells_per_patient])
  keep1 <- patient0 %in% eligible
  cells1 <- cells0[keep1]
  patient1 <- patient0[keep1]
  label1 <- label0[keep1]
  if (length(eligible) < 1L) stop(dataset, ": no eligible patients")

  set.seed(seed + ifelse(dataset == "adult", 1L, 2L))
  selected <- unlist(lapply(sort(eligible), function(id) {
    z <- cells1[patient1 == id]
    if (length(z) > max_cells_per_patient) sample(z, max_cells_per_patient, replace = FALSE) else z
  }), use.names = FALSE)
  selected <- sort(selected)
  selected_patient <- patient[match(selected, rownames(meta))]
  selected_label <- label[match(selected, rownames(meta))]

  counts_all <- LayerData(obj[["RNA"]], layer = "counts")
  stopifnot(all(selected %in% colnames(counts_all)), all(target_genes %in% rownames(counts_all)))
  counts <- counts_all[, selected, drop = FALSE]
  detected <- Matrix::rowSums(counts[target_genes, , drop = FALSE] > 0)
  totals <- Matrix::rowSums(counts[target_genes, , drop = FALSE])

  tmp <- CreateSeuratObject(counts = counts, assay = "RNA", min.cells = 0, min.features = 0)
  tmp <- NormalizeData(tmp, normalization.method = "LogNormalize", scale.factor = 10000, verbose = FALSE)
  tmp <- FindVariableFeatures(tmp, selection.method = "vst", nfeatures = n_network_genes, verbose = FALSE)
  hvgs <- VariableFeatures(tmp)
  selected_genes <- unique(c(target_genes, setdiff(hvgs, target_genes)))
  if (length(selected_genes) < n_network_genes) {
    fallback <- setdiff(rownames(counts)[order(Matrix::rowSums(counts > 0), decreasing = TRUE)], selected_genes)
    selected_genes <- c(selected_genes, head(fallback, n_network_genes - length(selected_genes)))
  }
  selected_genes <- selected_genes[seq_len(n_network_genes)]
  stopifnot(length(selected_genes) == n_network_genes, all(target_genes %in% selected_genes))
  network_counts <- counts[selected_genes, , drop = FALSE]

  cell_manifest <- data.frame(
    dataset = dataset, cell = colnames(network_counts), patient = selected_patient,
    original_label = selected_label, stringsAsFactors = FALSE
  )
  patient_manifest <- as.data.frame(table(cell_manifest$patient), stringsAsFactors = FALSE)
  names(patient_manifest) <- c("patient", "selected_cells")
  original_manifest <- as.data.frame(patient_n, stringsAsFactors = FALSE)
  names(original_manifest) <- c("patient", "original_eligible_lineage_cells")
  patient_manifest <- merge(original_manifest, patient_manifest, by = "patient", all.x = TRUE)
  patient_manifest$selected_cells[is.na(patient_manifest$selected_cells)] <- 0L
  patient_manifest$dataset <- dataset

  gene_manifest <- data.frame(
    dataset = dataset, rank = seq_along(selected_genes), gene = selected_genes,
    forced_target = selected_genes %in% target_genes,
    detected_cells = as.numeric(Matrix::rowSums(network_counts > 0)),
    total_counts = as.numeric(Matrix::rowSums(network_counts)), stringsAsFactors = FALSE
  )

  qc <- data.frame(
    dataset = dataset, input_path = normalizePath(path, winslash = "/"),
    object_genes = nrow(obj), object_cells = ncol(obj),
    target_lineage_cells_before_patient_gate = length(cells0),
    eligible_patients = length(eligible), cells_after_patient_gate = length(cells1),
    balanced_cells = ncol(network_counts), network_genes = nrow(network_counts),
    min_selected_cells_per_patient = min(table(selected_patient)),
    median_selected_cells_per_patient = median(table(selected_patient)),
    max_selected_cells_per_patient = max(table(selected_patient)),
    CASP1_detected_cells = unname(detected["CASP1"]),
    CASP1_detection_rate = unname(detected["CASP1"] / ncol(network_counts)),
    CASP1_total_counts = unname(totals["CASP1"]),
    MPO_detected_cells = unname(detected["MPO"]),
    MPO_detection_rate = unname(detected["MPO"] / ncol(network_counts)),
    MPO_total_counts = unname(totals["MPO"]), stringsAsFactors = FALSE
  )
  qc$gate_patients <- qc$eligible_patients >= 5
  qc$gate_cells <- qc$balanced_cells >= 1000
  qc$gate_CASP1_detected <- qc$CASP1_detected_cells >= 25 & qc$CASP1_detection_rate >= 0.05
  qc$gate_MPO_detected <- qc$MPO_detected_cells >= 25
  qc$gate_genes <- qc$network_genes == n_network_genes
  qc$gate_pass <- with(qc, gate_patients & gate_cells & gate_CASP1_detected & gate_MPO_detected & gate_genes)

  saveRDS(network_counts, file.path(out, paste0("02_", dataset, "_balanced_monocytic_5000gene_counts.rds")), compress = "xz")
  rm(obj, counts_all, counts, tmp, network_counts)
  gc()
  list(qc = qc, cells = cell_manifest, patients = patient_manifest, genes = gene_manifest)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
adult <- process_dataset(adult_path, "adult")
pediatric <- process_dataset(pediatric_path, "pediatric")
qc <- rbind(adult$qc, pediatric$qc)
write_tsv(qc, "02_input_gate.tsv")
write_tsv(rbind(adult$patients, pediatric$patients), "02_patient_balance.tsv")
write_tsv(rbind(adult$cells, pediatric$cells), "02_cell_manifest.tsv")
write_tsv(rbind(adult$genes, pediatric$genes), "02_gene_manifest.tsv")
capture.output(sessionInfo(), file = file.path(out, "02_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "seed", "all_datasets_pass", "R_version", "Seurat_version"),
  value = c(ifelse(all(qc$gate_pass), "passed", "failed"), format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
            seed, all(qc$gate_pass), as.character(getRversion()), as.character(packageVersion("Seurat"))),
  stringsAsFactors = FALSE
), "02_prepare_status.tsv")
cat("Gate status:", ifelse(all(qc$gate_pass), "passed", "failed"), "\n")
print(qc)
if (!all(qc$gate_pass)) quit(save = "no", status = 2, runLast = FALSE)

# R 4.5.2 can crash while unloading Seurat/Matrix DLLs built under R 4.5.3.
# The optional project-local DLL exits only after every output and status file is closed.
clean_exit_dll <- Sys.getenv("LCDI_CLEAN_EXIT_DLL", unset = "")
if (nzchar(clean_exit_dll)) {
  flush.console()
  dll <- dyn.load(clean_exit_dll)
  .C(getNativeSymbolInfo("clean_exit", PACKAGE = dll), as.integer(0))
}

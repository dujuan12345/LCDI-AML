options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(scTenifoldKnk)
  library(Matrix)
})

args <- commandArgs(trailingOnly = TRUE)
if (length(args) < 2L) stop("Usage: Rscript 03_run_virtual_perturbation.R <adult|pediatric> <CASP1|MPO> [formal|smoke]")
dataset <- match.arg(args[[1]], c("adult", "pediatric"))
target <- match.arg(args[[2]], c("CASP1", "MPO"))
mode <- if (length(args) >= 3L) match.arg(args[[3]], c("formal", "smoke")) else "formal"

root <- "D:/26_01_AML"
base_out <- file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1")
prep <- file.path(base_out, "prepared_inputs_v3")
run_out <- if (mode == "formal") file.path(base_out, "formal_runs") else file.path(base_out, "smoke_test")
if (!dir.exists(run_out)) dir.create(run_out, recursive = TRUE, showWarnings = FALSE)

seed_map <- c(adult_CASP1 = 202608291L, adult_MPO = 202608292L,
              pediatric_CASP1 = 202608293L, pediatric_MPO = 202608294L)
run_id <- paste(dataset, target, sep = "_")
seed <- unname(seed_map[[run_id]])
if (is.null(seed) || is.na(seed)) stop("Unknown run id: ", run_id)
set.seed(seed)

input_path <- file.path(prep, paste0("02_", dataset, "_balanced_monocytic_5000gene_counts.rds"))
stopifnot(file.exists(input_path), dir.exists(run_out))
prefix <- paste0(ifelse(mode == "formal", "03", "smoke"), "_", dataset, "_", target)
status_path <- file.path(run_out, paste0(prefix, "_status.tsv"))
if (file.exists(status_path)) stop("Refusing to overwrite completed run: ", status_path)

write_tsv <- function(x, path) {
  write.table(x, path, sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

counts <- readRDS(input_path)
stopifnot(inherits(counts, "Matrix"), all(c("CASP1", "MPO") %in% rownames(counts)))
if (mode == "smoke") {
  keep <- unique(c(target, setdiff(rownames(counts), target)[seq_len(499L)]))
  counts <- counts[keep, seq_len(min(300L, ncol(counts))), drop = FALSE]
}
counts <- counts[c(target, setdiff(rownames(counts), target)), , drop = FALSE]
target_detected <- sum(counts[target, ] > 0)
target_rate <- target_detected / ncol(counts)
if (target_detected < 25L) stop(target, " detected in fewer than 25 cells")

params <- if (mode == "formal") {
  list(nNet = 10L, nCells = 500L, nComp = 3L, nCores = 8L)
} else {
  list(nNet = 2L, nCells = 100L, nComp = 2L, nCores = 2L)
}

cat("Start:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
cat("Run:", run_id, "mode:", mode, "seed:", seed, "\n")
cat("Input:", nrow(counts), "genes x", ncol(counts), "cells\n")
cat("Target detection:", target_detected, sprintf("(%.4f)", target_rate), "\n")
cat("Parameters:", paste(names(params), unlist(params), sep = "=", collapse = "; "), "\n")
start_time <- Sys.time()

dense_counts <- as.matrix(counts)
storage.mode(dense_counts) <- "numeric"
result <- scTenifoldKnk::scTenifoldKnk(
  countMatrix = dense_counts,
  qc = FALSE,
  gKO = target,
  nc_nNet = params$nNet,
  nc_nCells = min(params$nCells, ncol(dense_counts)),
  nc_nComp = params$nComp,
  nc_scaleScores = TRUE,
  nc_symmetric = FALSE,
  nc_q = 0.9,
  td_K = 3,
  td_maxIter = 1000,
  td_maxError = 1e-5,
  td_nDecimal = 3,
  ma_nDim = 2,
  nCores = params$nCores
)
elapsed_minutes <- as.numeric(difftime(Sys.time(), start_time, units = "mins"))
stopifnot(is.list(result), "diffRegulation" %in% names(result), nrow(result$diffRegulation) == nrow(dense_counts))

dr <- result$diffRegulation
stopifnot(all(c("gene", "distance", "Z", "FC", "p.value", "p.adj") %in% colnames(dr)))
dr_no_target <- dr[dr$gene != target, , drop = FALSE]
summary <- data.frame(
  dataset = dataset, target = target, mode = mode,
  genes = nrow(dense_counts), cells = ncol(dense_counts),
  patients = length(unique(read.delim(file.path(prep, "02_cell_manifest.tsv"), check.names = FALSE)$patient[
    read.delim(file.path(prep, "02_cell_manifest.tsv"), check.names = FALSE)$dataset == dataset
  ])),
  target_detected_cells = target_detected, target_detection_rate = target_rate,
  FDR05_excluding_target = sum(dr_no_target$p.adj < 0.05, na.rm = TRUE),
  P05_excluding_target = sum(dr_no_target$p.value < 0.05, na.rm = TRUE),
  elapsed_minutes = elapsed_minutes, seed = seed,
  nc_nNet = params$nNet, nc_nCells = min(params$nCells, ncol(dense_counts)),
  nc_nComp = params$nComp, nCores = params$nCores,
  scTenifoldKnk_version = as.character(packageVersion("scTenifoldKnk")),
  R_version = as.character(getRversion()), stringsAsFactors = FALSE
)

saveRDS(result, file.path(run_out, paste0(prefix, "_result.rds")), compress = "xz")
write_tsv(dr, file.path(run_out, paste0(prefix, "_diffRegulation.tsv")))
write_tsv(dr_no_target[order(dr_no_target$p.adj, -abs(dr_no_target$Z)), ][seq_len(min(100L, nrow(dr_no_target))), ],
          file.path(run_out, paste0(prefix, "_top100.tsv")))
write_tsv(summary, file.path(run_out, paste0(prefix, "_summary.tsv")))
capture.output(sessionInfo(), file = file.path(run_out, paste0(prefix, "_session_info.txt")))
write_tsv(data.frame(
  field = c("status", "completed", "dataset", "target", "mode", "elapsed_minutes", "seed"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), dataset, target, mode,
            elapsed_minutes, seed), stringsAsFactors = FALSE
), status_path)
cat("Completed:", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "\n")
print(summary)

rm(dense_counts, counts)
gc()
clean_exit_dll <- Sys.getenv("LCDI_CLEAN_EXIT_DLL", unset = "")
if (nzchar(clean_exit_dll)) {
  flush.console()
  dll <- dyn.load(clean_exit_dll)
  .C(getNativeSymbolInfo("clean_exit", PACKAGE = dll), as.integer(0))
}


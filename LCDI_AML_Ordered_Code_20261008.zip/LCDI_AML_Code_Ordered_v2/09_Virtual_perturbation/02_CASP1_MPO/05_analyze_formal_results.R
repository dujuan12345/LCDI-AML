options(stringsAsFactors = FALSE, warn = 1)

root <- "D:/26_01_AML"
out <- file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1")
run_dir <- file.path(out, "formal_runs")
geneset_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/genesets_used.rds")
stopifnot(dir.exists(run_dir), file.exists(geneset_path))
status_path <- file.path(out, "05_analysis_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed analysis: ", status_path)

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

read_dr <- function(dataset, target) {
  path <- file.path(run_dir, paste0("03_", dataset, "_", target, "_diffRegulation.tsv"))
  status <- file.path(run_dir, paste0("03_", dataset, "_", target, "_status.tsv"))
  stopifnot(file.exists(path), file.exists(status))
  x <- read.delim(path, check.names = FALSE)
  stopifnot(all(c("gene", "Z", "p.value", "p.adj") %in% colnames(x)), !anyDuplicated(x$gene))
  x$dataset <- dataset
  x$target <- target
  x
}

datasets <- c("adult", "pediatric")
targets <- c("CASP1", "MPO")
dr <- setNames(lapply(as.vector(outer(datasets, targets, paste, sep = "_")), function(id) {
  z <- strsplit(id, "_", fixed = TRUE)[[1]]
  read_dr(z[1], z[2])
}), as.vector(outer(datasets, targets, paste, sep = "_")))

rank_percentile <- function(z) {
  if (length(z) <= 1L) return(rep(NA_real_, length(z)))
  (rank(z, ties.method = "average", na.last = "keep") - 1) / (sum(is.finite(z)) - 1)
}

for (id in names(dr)) dr[[id]]$rank_percentile <- rank_percentile(dr[[id]]$Z)
excluded_targets <- c("CASP1", "MPO")

# Cross-dataset rank reproducibility for each target.
cross_rows <- list()
overlap_rows <- list()
for (target in targets) {
  a <- dr[[paste0("adult_", target)]]
  p <- dr[[paste0("pediatric_", target)]]
  universe <- intersect(setdiff(a$gene, excluded_targets), setdiff(p$gene, excluded_targets))
  aa <- a[match(universe, a$gene), ]
  pp <- p[match(universe, p$gene), ]
  ct <- suppressWarnings(cor.test(aa$Z, pp$Z, method = "spearman", exact = FALSE))
  sig_a <- intersect(universe, a$gene[a$p.adj < 0.05])
  sig_p <- intersect(universe, p$gene[p$p.adj < 0.05])
  sig_overlap <- intersect(sig_a, sig_p)
  top_a <- head(aa$gene[order(-aa$Z)], 50L)
  top_p <- head(pp$gene[order(-pp$Z)], 50L)
  top_overlap <- intersect(top_a, top_p)
  hyper_p <- phyper(length(top_overlap) - 1L, length(top_a), length(universe) - length(top_a), length(top_p), lower.tail = FALSE)
  cross_rows[[length(cross_rows) + 1L]] <- data.frame(
    target = target, matched_genes = length(universe), spearman_rho = unname(ct$estimate), spearman_p = ct$p.value,
    adult_FDR05 = length(sig_a), pediatric_FDR05 = length(sig_p), FDR05_overlap = length(sig_overlap),
    top50_overlap = length(top_overlap), top50_hypergeometric_p = hyper_p,
    stringsAsFactors = FALSE
  )
  overlap_rows[[length(overlap_rows) + 1L]] <- data.frame(
    target = rep(target, length(sig_overlap)), overlap_type = rep("FDR05", length(sig_overlap)),
    gene = sig_overlap, stringsAsFactors = FALSE
  )
  overlap_rows[[length(overlap_rows) + 1L]] <- data.frame(
    target = rep(target, length(top_overlap)), overlap_type = rep("top50", length(top_overlap)),
    gene = top_overlap, stringsAsFactors = FALSE
  )
}
cross <- do.call(rbind, cross_rows)
cross$rank_fdr <- p.adjust(cross$spearman_p, "BH")
cross$top50_overlap_fdr <- p.adjust(cross$top50_hypergeometric_p, "BH")
overlaps <- do.call(rbind, overlap_rows)

# Prespecified gene sets. scTenifoldKnk Z is a perturbation magnitude, not signed expression change.
all_sets <- readRDS(geneset_path)
hallmark_names <- c(
  "HALLMARK_INFLAMMATORY_RESPONSE", "HALLMARK_TNFA_SIGNALING_VIA_NFKB",
  "HALLMARK_IL6_JAK_STAT3_SIGNALING", "HALLMARK_APOPTOSIS",
  "HALLMARK_MYC_TARGETS_V1", "HALLMARK_E2F_TARGETS", "HALLMARK_G2M_CHECKPOINT",
  "HALLMARK_OXIDATIVE_PHOSPHORYLATION", "HALLMARK_GLYCOLYSIS", "HALLMARK_MTORC1_SIGNALING"
)
stopifnot(all(hallmark_names %in% names(all_sets)))
gene_sets <- all_sets[hallmark_names]
gene_sets$CUSTOM_PYROPTOSIS <- c("CASP4", "CASP5", "GSDMD", "GSDME", "PYCARD", "NLRP3", "AIM2", "NLRC4", "IL1B", "IL18", "GBP1", "GBP2", "IRF1")
gene_sets$CUSTOM_INFLAMMASOME <- c("NLRP3", "AIM2", "NLRC4", "PYCARD", "GSDMD", "IL1B", "IL18", "NEK7", "MEFV")
gene_sets$CUSTOM_MYELOID_DIFFERENTIATION <- c("ELANE", "PRTN3", "CTSG", "CEBPA", "SPI1", "ITGAM", "CD14", "FUT4", "CSF1R", "LILRB1", "FCGR3A", "S100A8", "S100A9", "LST1")

enrichment_rows <- list()
for (id in names(dr)) {
  x <- dr[[id]]
  x <- x[!x$gene %in% excluded_targets, ]
  for (set_name in names(gene_sets)) {
    members <- intersect(unique(gene_sets[[set_name]]), x$gene)
    nonmembers <- setdiff(x$gene, members)
    if (length(members) < 5L) {
      enrichment_rows[[length(enrichment_rows) + 1L]] <- data.frame(
        dataset = x$dataset[1], target = x$target[1], gene_set = set_name,
        available_members = length(members), mean_rank_percentile = NA_real_, median_Z = NA_real_,
        wilcoxon_p = NA_real_, stringsAsFactors = FALSE
      )
      next
    }
    wt <- suppressWarnings(wilcox.test(x$Z[match(members, x$gene)], x$Z[match(nonmembers, x$gene)],
                                       alternative = "greater", exact = FALSE))
    enrichment_rows[[length(enrichment_rows) + 1L]] <- data.frame(
      dataset = x$dataset[1], target = x$target[1], gene_set = set_name,
      available_members = length(members),
      mean_rank_percentile = mean(x$rank_percentile[match(members, x$gene)], na.rm = TRUE),
      median_Z = median(x$Z[match(members, x$gene)], na.rm = TRUE),
      wilcoxon_p = wt$p.value, stringsAsFactors = FALSE
    )
  }
}
enrichment <- do.call(rbind, enrichment_rows)
enrichment$enrichment_fdr <- ave(enrichment$wilcoxon_p, interaction(enrichment$dataset, enrichment$target),
                                 FUN = function(p) p.adjust(p, "BH"))

# Replicated pathways for CASP1 and MPO separately.
replicated_rows <- list()
for (target in targets) {
  z <- enrichment[enrichment$target == target, ]
  for (set_name in names(gene_sets)) {
    q <- z[z$gene_set == set_name, ]
    stopifnot(nrow(q) == 2L)
    replicated_rows[[length(replicated_rows) + 1L]] <- data.frame(
      target = target, gene_set = set_name,
      adult_mean_percentile = q$mean_rank_percentile[q$dataset == "adult"],
      adult_fdr = q$enrichment_fdr[q$dataset == "adult"],
      pediatric_mean_percentile = q$mean_rank_percentile[q$dataset == "pediatric"],
      pediatric_fdr = q$enrichment_fdr[q$dataset == "pediatric"],
      replicated_enrichment = all(is.finite(q$mean_rank_percentile)) && all(is.finite(q$enrichment_fdr)) &&
        all(q$mean_rank_percentile > 0.5 & q$enrichment_fdr < 0.05),
      stringsAsFactors = FALSE
    )
  }
}
replicated <- do.call(rbind, replicated_rows)

# Paired CASP1-versus-MPO pathway comparison within each dataset.
contrast_rows <- list()
for (dataset in datasets) {
  c1 <- dr[[paste0(dataset, "_CASP1")]]
  mp <- dr[[paste0(dataset, "_MPO")]]
  universe <- intersect(setdiff(c1$gene, excluded_targets), setdiff(mp$gene, excluded_targets))
  for (set_name in names(gene_sets)) {
    members <- intersect(unique(gene_sets[[set_name]]), universe)
    if (length(members) < 5L) next
    c_rank <- c1$rank_percentile[match(members, c1$gene)]
    m_rank <- mp$rank_percentile[match(members, mp$gene)]
    wt <- suppressWarnings(wilcox.test(c_rank, m_rank, paired = TRUE, alternative = "greater", exact = FALSE))
    contrast_rows[[length(contrast_rows) + 1L]] <- data.frame(
      dataset = dataset, gene_set = set_name, available_members = length(members),
      CASP1_mean_percentile = mean(c_rank), MPO_mean_percentile = mean(m_rank),
      delta_mean_percentile = mean(c_rank - m_rank), paired_wilcoxon_p = wt$p.value,
      stringsAsFactors = FALSE
    )
  }
}
contrast <- do.call(rbind, contrast_rows)
contrast$contrast_fdr <- ave(contrast$paired_wilcoxon_p, contrast$dataset, FUN = function(p) p.adjust(p, "BH"))

# Prespecified genes for transparent targeted inspection.
pre_genes <- c("GSDMD", "PYCARD", "IL1B", "IL18", "NLRP3", "AIM2", "NLRC4",
               "ITGAM", "CD14", "FUT4", "CD34", "KIT", "MPO", "CEBPA", "SPI1", "MKI67")
pre_rows <- list()
for (id in names(dr)) {
  x <- dr[[id]]
  z <- x[x$gene %in% pre_genes, c("dataset", "target", "gene", "Z", "p.value", "p.adj", "rank_percentile")]
  z$rank_descending <- rank(-x$Z, ties.method = "min")[match(z$gene, x$gene)]
  pre_rows[[length(pre_rows) + 1L]] <- z
}
preselected <- do.call(rbind, pre_rows)

casp_cross <- cross[cross$target == "CASP1", ]
casp_replicated <- replicated[replicated$target == "CASP1" & replicated$replicated_enrichment, ]
contrast_wide <- reshape(contrast[, c("dataset", "gene_set", "delta_mean_percentile", "contrast_fdr")],
                         idvar = "gene_set", timevar = "dataset", direction = "wide")
distinct_both <- contrast_wide$delta_mean_percentile.adult > 0 & contrast_wide$delta_mean_percentile.pediatric > 0 &
  contrast_wide$contrast_fdr.adult < 0.05 & contrast_wide$contrast_fdr.pediatric < 0.05
primary_gate <- is.finite(casp_cross$spearman_rho) && casp_cross$spearman_rho >= 0.20 && casp_cross$rank_fdr < 0.05 &&
  nrow(casp_replicated) >= 1L
decision <- data.frame(
  criterion = c("CASP1_cross_dataset_rank_rho_ge_0.20_and_FDR_lt_0.05",
                "CASP1_FDR05_overlap_genes", "CASP1_replicated_prespecified_gene_sets",
                "CASP1_gene_sets_distinct_from_MPO_in_both_datasets",
                "primary_gate_pass", "patient_sensitivity_required_before_main_text", "main_text_ready"),
  value = c(casp_cross$spearman_rho >= 0.20 && casp_cross$rank_fdr < 0.05,
            casp_cross$FDR05_overlap, nrow(casp_replicated), sum(distinct_both, na.rm = TRUE),
            primary_gate, primary_gate, FALSE),
  stringsAsFactors = FALSE
)

write_tsv(cross, "05_cross_dataset_rank_reproducibility.tsv")
write_tsv(overlaps, "05_overlap_genes.tsv")
write_tsv(enrichment, "05_gene_set_enrichment.tsv")
write_tsv(replicated, "05_replicated_gene_set_gate.tsv")
write_tsv(contrast, "05_CASP1_vs_MPO_gene_set_contrast.tsv")
write_tsv(contrast_wide, "05_CASP1_vs_MPO_contrast_cross_dataset.tsv")
write_tsv(preselected, "05_preselected_gene_ranks.tsv")
write_tsv(decision, "05_overall_decision.tsv")
saveRDS(list(cross = cross, overlaps = overlaps, enrichment = enrichment, replicated = replicated,
             contrast = contrast, contrast_wide = contrast_wide, preselected = preselected,
             decision = decision, gene_sets = gene_sets), file.path(out, "05_analysis_results.rds"), compress = "xz")
capture.output(sessionInfo(), file = file.path(out, "05_session_info.txt"))
write_tsv(data.frame(
  field = c("status", "completed", "CASP1_rank_rho", "CASP1_rank_fdr", "CASP1_FDR_overlap",
            "CASP1_replicated_gene_sets", "primary_gate_pass", "main_text_ready"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), casp_cross$spearman_rho,
            casp_cross$rank_fdr, casp_cross$FDR05_overlap, nrow(casp_replicated), primary_gate, FALSE),
  stringsAsFactors = FALSE
), "05_analysis_status.tsv")
cat("Analysis completed\n")
print(cross)
print(decision)

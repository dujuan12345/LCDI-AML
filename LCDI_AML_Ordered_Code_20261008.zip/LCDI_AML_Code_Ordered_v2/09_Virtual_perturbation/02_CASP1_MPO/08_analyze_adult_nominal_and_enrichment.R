options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(AnnotationDbi)
})

root <- "D:/26_01_AML"
out <- file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1")
run_dir <- file.path(out, "formal_runs")
geneset_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/genesets_used.rds")
status_path <- file.path(out, "08_adult_enrichment_status.tsv")
if (file.exists(status_path)) stop("Refusing to overwrite completed adult enrichment: ", status_path)
stopifnot(file.exists(geneset_path), dir.exists(run_dir))

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}

as_df <- function(x) {
  if (is.null(x)) return(data.frame())
  as.data.frame(x)
}

targets <- c("CASP1", "MPO")
all_sets <- readRDS(geneset_path)
kegg_names <- grep("^KEGG_", names(all_sets), value = TRUE)
stopifnot(length(kegg_names) >= 100L)
kegg_term2gene <- do.call(rbind, lapply(kegg_names, function(term) {
  data.frame(term = term, gene = unique(all_sets[[term]]), stringsAsFactors = FALSE)
}))
kegg_term2name <- data.frame(term = kegg_names, name = sub("^KEGG_", "", kegg_names), stringsAsFactors = FALSE)

candidate_rows <- list()
go_ora_rows <- list()
kegg_ora_rows <- list()
go_gsea_rows <- list()
kegg_gsea_rows <- list()
summary_rows <- list()

for (target in targets) {
  path <- file.path(run_dir, paste0("03_adult_", target, "_diffRegulation.tsv"))
  x <- read.delim(path, check.names = FALSE)
  stopifnot(nrow(x) == 5000L, !anyDuplicated(x$gene), target %in% x$gene)
  universe_x <- x[!x$gene %in% c("CASP1", "MPO"), ]
  candidates <- universe_x[universe_x$p.value < 0.05, ]
  candidates$target <- target
  candidates$nominal_P05 <- TRUE
  candidates$FDR05 <- candidates$p.adj < 0.05
  candidate_rows[[length(candidate_rows) + 1L]] <- candidates[, c("target", "gene", "distance", "Z", "FC", "p.value", "p.adj", "nominal_P05", "FDR05")]

  mapping <- suppressMessages(AnnotationDbi::select(
    org.Hs.eg.db, keys = unique(universe_x$gene), keytype = "SYMBOL", columns = c("SYMBOL", "ENTREZID")
  ))
  mapping <- mapping[!is.na(mapping$ENTREZID) & nzchar(mapping$ENTREZID), ]
  mapping <- mapping[!duplicated(mapping$SYMBOL), ]
  universe_entrez <- unique(mapping$ENTREZID)
  candidate_entrez <- unique(mapping$ENTREZID[match(candidates$gene, mapping$SYMBOL, nomatch = 0L)])
  candidate_entrez <- candidate_entrez[!is.na(candidate_entrez) & nzchar(candidate_entrez)]

  go_ora <- enrichGO(
    gene = candidate_entrez, universe = universe_entrez, OrgDb = org.Hs.eg.db,
    keyType = "ENTREZID", ont = "BP", pAdjustMethod = "BH",
    pvalueCutoff = 1, qvalueCutoff = 1, minGSSize = 5, maxGSSize = 500, readable = TRUE
  )
  go_ora_df <- as_df(go_ora)
  if (nrow(go_ora_df)) {
    go_ora_df$target <- target
    go_ora_rows[[length(go_ora_rows) + 1L]] <- go_ora_df
  }

  kegg_ora <- enricher(
    gene = candidates$gene, universe = universe_x$gene,
    TERM2GENE = kegg_term2gene, TERM2NAME = kegg_term2name,
    pAdjustMethod = "BH", pvalueCutoff = 1, qvalueCutoff = 1,
    minGSSize = 5, maxGSSize = 500
  )
  kegg_ora_df <- as_df(kegg_ora)
  if (nrow(kegg_ora_df)) {
    kegg_ora_df$target <- target
    kegg_ora_rows[[length(kegg_ora_rows) + 1L]] <- kegg_ora_df
  }

  rank_symbol <- universe_x$Z
  names(rank_symbol) <- universe_x$gene
  rank_symbol <- sort(rank_symbol, decreasing = TRUE)
  map_rank <- mapping[match(names(rank_symbol), mapping$SYMBOL), ]
  ok <- !is.na(map_rank$ENTREZID) & nzchar(map_rank$ENTREZID)
  rank_entrez_df <- data.frame(ENTREZID = map_rank$ENTREZID[ok], score = rank_symbol[ok], stringsAsFactors = FALSE)
  rank_entrez_df <- rank_entrez_df[order(-rank_entrez_df$score), ]
  rank_entrez_df <- rank_entrez_df[!duplicated(rank_entrez_df$ENTREZID), ]
  rank_entrez <- rank_entrez_df$score
  names(rank_entrez) <- rank_entrez_df$ENTREZID

  set.seed(202608300L + match(target, targets))
  go_gsea <- gseGO(
    geneList = rank_entrez, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = "BP",
    minGSSize = 10, maxGSSize = 500, pvalueCutoff = 1,
    pAdjustMethod = "BH", eps = 0, verbose = FALSE, seed = TRUE, by = "fgsea"
  )
  go_gsea_df <- as_df(go_gsea)
  if (nrow(go_gsea_df)) {
    go_gsea_df$target <- target
    go_gsea_rows[[length(go_gsea_rows) + 1L]] <- go_gsea_df
  }

  set.seed(202608310L + match(target, targets))
  kegg_gsea <- GSEA(
    geneList = rank_symbol, TERM2GENE = kegg_term2gene, TERM2NAME = kegg_term2name,
    minGSSize = 10, maxGSSize = 500, pvalueCutoff = 1,
    pAdjustMethod = "BH", eps = 0, verbose = FALSE, seed = TRUE, by = "fgsea"
  )
  kegg_gsea_df <- as_df(kegg_gsea)
  if (nrow(kegg_gsea_df)) {
    kegg_gsea_df$target <- target
    kegg_gsea_rows[[length(kegg_gsea_rows) + 1L]] <- kegg_gsea_df
  }

  summary_rows[[length(summary_rows) + 1L]] <- data.frame(
    target = target, tested_genes = nrow(universe_x), P05_genes = nrow(candidates),
    FDR05_genes = sum(candidates$FDR05), mapped_universe_entrez = length(universe_entrez),
    mapped_candidate_entrez = length(candidate_entrez),
    GO_ORA_terms = nrow(go_ora_df), GO_ORA_P05 = sum(go_ora_df$pvalue < 0.05),
    GO_ORA_FDR05 = sum(go_ora_df$p.adjust < 0.05),
    KEGG_ORA_terms = nrow(kegg_ora_df), KEGG_ORA_P05 = sum(kegg_ora_df$pvalue < 0.05),
    KEGG_ORA_FDR05 = sum(kegg_ora_df$p.adjust < 0.05),
    GO_GSEA_terms = nrow(go_gsea_df), GO_GSEA_P05 = sum(go_gsea_df$pvalue < 0.05),
    GO_GSEA_FDR05 = sum(go_gsea_df$p.adjust < 0.05),
    KEGG_GSEA_terms = nrow(kegg_gsea_df), KEGG_GSEA_P05 = sum(kegg_gsea_df$pvalue < 0.05),
    KEGG_GSEA_FDR05 = sum(kegg_gsea_df$p.adjust < 0.05),
    stringsAsFactors = FALSE
  )
}

bind_or_empty <- function(x) if (length(x)) do.call(rbind, x) else data.frame()
candidates <- bind_or_empty(candidate_rows)
go_ora <- bind_or_empty(go_ora_rows)
kegg_ora <- bind_or_empty(kegg_ora_rows)
go_gsea <- bind_or_empty(go_gsea_rows)
kegg_gsea <- bind_or_empty(kegg_gsea_rows)
summary <- do.call(rbind, summary_rows)

write_tsv(candidates, "08_adult_P05_candidate_genes.tsv")
write_tsv(go_ora, "08_adult_GO_ORA_all.tsv")
write_tsv(kegg_ora, "08_adult_KEGG_ORA_all.tsv")
write_tsv(go_gsea, "08_adult_GO_GSEA_all.tsv")
write_tsv(kegg_gsea, "08_adult_KEGG_GSEA_all.tsv")
write_tsv(summary, "08_adult_enrichment_summary.tsv")
write_tsv(data.frame(
  field = c("status", "completed", "candidate_threshold", "strict_threshold",
            "external_downloads", "R_version", "clusterProfiler_version"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "p.value<0.05",
            "p.adj<0.05", "none", as.character(getRversion()), as.character(packageVersion("clusterProfiler"))),
  stringsAsFactors = FALSE
), "08_adult_enrichment_status.tsv")
capture.output(sessionInfo(), file = file.path(out, "08_adult_enrichment_session_info.txt"))
cat("Adult GO/KEGG analysis completed\n")
print(summary)

clean_exit_dll <- Sys.getenv("LCDI_CLEAN_EXIT_DLL", unset = "")
if (nzchar(clean_exit_dll)) {
  flush.console()
  dll <- dyn.load(clean_exit_dll)
  .C(getNativeSymbolInfo("clean_exit", PACKAGE = dll), as.integer(0))
}

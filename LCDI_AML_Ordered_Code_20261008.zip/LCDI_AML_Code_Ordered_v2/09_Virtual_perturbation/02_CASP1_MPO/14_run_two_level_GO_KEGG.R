options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(AnnotationDbi)
})

root <- "D:/26_01_AML"
task_dir <- file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1")
run_dir <- file.path(task_dir, "formal_runs")
out <- file.path(task_dir, "two_level_GO_KEGG_v1")
geneset_path <- file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/genesets_used.rds")
status_path <- file.path(out, "14_status.tsv")
if (!dir.exists(out)) dir.create(out, recursive = TRUE, showWarnings = FALSE)
if (file.exists(status_path)) stop("Refusing to overwrite completed analysis: ", status_path)
stopifnot(dir.exists(run_dir), file.exists(geneset_path))

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}
bind_or_empty <- function(x) if (length(x)) do.call(rbind, x) else data.frame()
as_df <- function(x) if (is.null(x)) data.frame() else as.data.frame(x)

datasets <- c("adult", "pediatric")
targets <- c("CASP1", "MPO")
all_sets <- readRDS(geneset_path)
kegg_names <- grep("^KEGG_", names(all_sets), value = TRUE)
stopifnot(length(kegg_names) >= 100L)
kegg_term2gene <- do.call(rbind, lapply(kegg_names, function(term) {
  data.frame(term = term, gene = unique(all_sets[[term]]), stringsAsFactors = FALSE)
}))
kegg_term2name <- data.frame(term = kegg_names, name = sub("^KEGG_", "", kegg_names), stringsAsFactors = FALSE)

candidate_rows <- list()
go_ora_rows <- list()
kegg_ora_rows <- list()
go_gsea_rows <- list()
kegg_gsea_rows <- list()
summary_rows <- list()

for (dataset in datasets) {
  for (target in targets) {
    path <- file.path(run_dir, paste0("03_", dataset, "_", target, "_diffRegulation.tsv"))
    x <- read.delim(path, check.names = FALSE)
    stopifnot(nrow(x) == 5000L, !anyDuplicated(x$gene), target %in% x$gene)
    universe_x <- x[!x$gene %in% c("CASP1", "MPO"), , drop = FALSE]
    candidates <- universe_x[universe_x$p.value < 0.05, , drop = FALSE]
    candidates$dataset <- dataset
    candidates$target <- target
    candidates$nominal_P05 <- TRUE
    candidates$FDR05 <- candidates$p.adj < 0.05
    candidate_rows[[length(candidate_rows) + 1L]] <- candidates[, c(
      "dataset", "target", "gene", "distance", "Z", "FC", "p.value", "p.adj", "nominal_P05", "FDR05"
    )]

    mapping <- suppressMessages(AnnotationDbi::select(
      org.Hs.eg.db, keys = unique(universe_x$gene), keytype = "SYMBOL", columns = c("SYMBOL", "ENTREZID")
    ))
    mapping <- mapping[!is.na(mapping$ENTREZID) & nzchar(mapping$ENTREZID), , drop = FALSE]
    mapping <- mapping[!duplicated(mapping$SYMBOL), , drop = FALSE]
    universe_entrez <- unique(mapping$ENTREZID)
    candidate_entrez <- unique(mapping$ENTREZID[match(candidates$gene, mapping$SYMBOL, nomatch = 0L)])
    candidate_entrez <- candidate_entrez[!is.na(candidate_entrez) & nzchar(candidate_entrez)]

    go_ora_df <- data.frame()
    if (length(candidate_entrez)) {
      go_ora_df <- as_df(enrichGO(
        gene = candidate_entrez, universe = universe_entrez, OrgDb = org.Hs.eg.db,
        keyType = "ENTREZID", ont = "BP", pAdjustMethod = "BH",
        pvalueCutoff = 1, qvalueCutoff = 1, minGSSize = 5, maxGSSize = 500, readable = TRUE
      ))
    }
    if (nrow(go_ora_df)) {
      go_ora_df$dataset <- dataset
      go_ora_df$target <- target
      go_ora_rows[[length(go_ora_rows) + 1L]] <- go_ora_df
    }

    kegg_ora_df <- data.frame()
    if (nrow(candidates)) {
      kegg_ora_df <- as_df(enricher(
        gene = candidates$gene, universe = universe_x$gene,
        TERM2GENE = kegg_term2gene, TERM2NAME = kegg_term2name,
        pAdjustMethod = "BH", pvalueCutoff = 1, qvalueCutoff = 1,
        minGSSize = 5, maxGSSize = 500
      ))
    }
    if (nrow(kegg_ora_df)) {
      kegg_ora_df$dataset <- dataset
      kegg_ora_df$target <- target
      kegg_ora_rows[[length(kegg_ora_rows) + 1L]] <- kegg_ora_df
    }

    rank_symbol <- universe_x$Z
    names(rank_symbol) <- universe_x$gene
    rank_symbol <- sort(rank_symbol, decreasing = TRUE)
    map_rank <- mapping[match(names(rank_symbol), mapping$SYMBOL), , drop = FALSE]
    ok <- !is.na(map_rank$ENTREZID) & nzchar(map_rank$ENTREZID)
    rank_entrez_df <- data.frame(
      ENTREZID = map_rank$ENTREZID[ok], score = unname(rank_symbol[ok]), stringsAsFactors = FALSE
    )
    rank_entrez_df <- rank_entrez_df[order(-rank_entrez_df$score), , drop = FALSE]
    rank_entrez_df <- rank_entrez_df[!duplicated(rank_entrez_df$ENTREZID), , drop = FALSE]
    rank_entrez <- rank_entrez_df$score
    names(rank_entrez) <- rank_entrez_df$ENTREZID

    seed_base <- 202608310L + 100L * match(dataset, datasets) + 10L * match(target, targets)
    set.seed(seed_base)
    go_gsea_df <- as_df(gseGO(
      geneList = rank_entrez, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = "BP",
      minGSSize = 10, maxGSSize = 500, pvalueCutoff = 1,
      pAdjustMethod = "BH", eps = 0, verbose = FALSE, seed = TRUE, by = "fgsea"
    ))
    if (nrow(go_gsea_df)) {
      go_gsea_df$dataset <- dataset
      go_gsea_df$target <- target
      go_gsea_rows[[length(go_gsea_rows) + 1L]] <- go_gsea_df
    }

    set.seed(seed_base + 1L)
    kegg_gsea_df <- as_df(GSEA(
      geneList = rank_symbol, TERM2GENE = kegg_term2gene, TERM2NAME = kegg_term2name,
      minGSSize = 10, maxGSSize = 500, pvalueCutoff = 1,
      pAdjustMethod = "BH", eps = 0, verbose = FALSE, seed = TRUE, by = "fgsea"
    ))
    if (nrow(kegg_gsea_df)) {
      kegg_gsea_df$dataset <- dataset
      kegg_gsea_df$target <- target
      kegg_gsea_rows[[length(kegg_gsea_rows) + 1L]] <- kegg_gsea_df
    }

    summary_rows[[length(summary_rows) + 1L]] <- data.frame(
      dataset = dataset, target = target,
      tested_genes = nrow(universe_x), P05_genes = nrow(candidates),
      FDR05_genes = sum(candidates$FDR05), mapped_universe_entrez = length(universe_entrez),
      mapped_candidate_entrez = length(candidate_entrez),
      GO_ORA_terms = nrow(go_ora_df), GO_ORA_P05 = sum(go_ora_df$pvalue < 0.05),
      GO_ORA_FDR05 = sum(go_ora_df$p.adjust < 0.05),
      KEGG_ORA_terms = nrow(kegg_ora_df), KEGG_ORA_P05 = sum(kegg_ora_df$pvalue < 0.05),
      KEGG_ORA_FDR05 = sum(kegg_ora_df$p.adjust < 0.05),
      GO_GSEA_terms = nrow(go_gsea_df), GO_GSEA_P05 = sum(go_gsea_df$pvalue < 0.05),
      GO_GSEA_FDR05 = sum(go_gsea_df$p.adjust < 0.05),
      KEGG_GSEA_terms = nrow(kegg_gsea_df), KEGG_GSEA_P05 = sum(kegg_gsea_df$pvalue < 0.05),
      KEGG_GSEA_FDR05 = sum(kegg_gsea_df$p.adjust < 0.05),
      stringsAsFactors = FALSE
    )
  }
}

candidates <- bind_or_empty(candidate_rows)
go_ora <- bind_or_empty(go_ora_rows)
kegg_ora <- bind_or_empty(kegg_ora_rows)
go_gsea <- bind_or_empty(go_gsea_rows)
kegg_gsea <- bind_or_empty(kegg_gsea_rows)
summary <- do.call(rbind, summary_rows)

replicate_terms <- function(tab, source, gsea = FALSE) {
  if (!nrow(tab)) return(data.frame())
  rows <- list()
  for (target in targets) {
    a <- tab[tab$dataset == "adult" & tab$target == target, , drop = FALSE]
    p <- tab[tab$dataset == "pediatric" & tab$target == target, , drop = FALSE]
    ids <- intersect(a$ID, p$ID)
    if (!length(ids)) next
    a <- a[match(ids, a$ID), , drop = FALSE]
    p <- p[match(ids, p$ID), , drop = FALSE]
    replicated <- a$p.adjust < 0.05 & p$p.adjust < 0.05
    same_direction <- rep(NA, length(ids))
    if (gsea) {
      same_direction <- sign(a$NES) == sign(p$NES)
      replicated <- replicated & same_direction
    }
    rows[[length(rows) + 1L]] <- data.frame(
      source = source, target = target, ID = ids, Description = a$Description,
      adult_p = a$pvalue, adult_fdr = a$p.adjust,
      pediatric_p = p$pvalue, pediatric_fdr = p$p.adjust,
      adult_NES = if (gsea) a$NES else NA_real_,
      pediatric_NES = if (gsea) p$NES else NA_real_,
      same_NES_sign = same_direction, replicated_FDR05 = replicated,
      stringsAsFactors = FALSE
    )
  }
  bind_or_empty(rows)
}

replicated <- bind_or_empty(list(
  replicate_terms(go_ora, "GO_ORA", FALSE),
  replicate_terms(kegg_ora, "KEGG_ORA", FALSE),
  replicate_terms(go_gsea, "GO_GSEA", TRUE),
  replicate_terms(kegg_gsea, "KEGG_GSEA", TRUE)
))

write_tsv(candidates, "14_candidate_genes.tsv")
write_tsv(go_ora, "14_GO_ORA_all.tsv")
write_tsv(kegg_ora, "14_KEGG_ORA_all.tsv")
write_tsv(go_gsea, "14_GO_GSEA_all.tsv")
write_tsv(kegg_gsea, "14_KEGG_GSEA_all.tsv")
write_tsv(summary, "14_enrichment_summary.tsv")
write_tsv(replicated, "14_cross_dataset_term_replication.tsv")
write_tsv(data.frame(
  field = c("status", "completed", "candidate_threshold", "strict_threshold",
            "analysis_levels", "datasets", "external_downloads", "R_version",
            "clusterProfiler_version", "org_Hs_eg_db_version"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"), "p.value<0.05",
            "p.adj<0.05", "ORA;ranked_GSEA", "adult;pediatric", "none",
            as.character(getRversion()), as.character(packageVersion("clusterProfiler")),
            as.character(packageVersion("org.Hs.eg.db"))), stringsAsFactors = FALSE
), "14_status.tsv")
capture.output(sessionInfo(), file = file.path(out, "14_session_info.txt"))
cat("Two-level adult/pediatric GO/KEGG analysis completed\n")
print(summary)

clean_exit_dll <- Sys.getenv("LCDI_CLEAN_EXIT_DLL", unset = "")
if (nzchar(clean_exit_dll)) {
  flush.console()
  dll <- dyn.load(clean_exit_dll)
  .C(getNativeSymbolInfo("clean_exit", PACKAGE = dll), as.integer(0))
}

# ---- Windows R CLI safety header ----
options(
  cli.width = 100L,
  cli.condition_width = 100L,
  width = 100L
)

Sys.setenv(
  R_CLI_DYNAMIC = "false",
  R_CLI_NUM_COLORS = "1",
  NO_COLOR = "1"
)
# ---- end Windows R CLI safety header ----
options(stringsAsFactors = FALSE, warn = 1)
suppressPackageStartupMessages({
  library(clusterProfiler)
  library(org.Hs.eg.db)
  library(AnnotationDbi)
  library(BiocParallel)
})

# Windows safety: fgsea otherwise uses the first registered BiocParallel
# backend, which creates many Rscript workers on this 32-core workstation.
serial_param <- BiocParallel::SerialParam()
BiocParallel::register(serial_param, default = TRUE)
options(mc.cores = 1L)
Sys.setenv(OMP_NUM_THREADS = "1", OPENBLAS_NUM_THREADS = "1", MKL_NUM_THREADS = "1")
stopifnot(BiocParallel::bpnworkers(BiocParallel::bpparam()) == 1L)

root <- Sys.getenv("LCDI_ROOT", unset = "D:/26_01_AML")
out <- Sys.getenv(
  "LCDI_INTEGRATION_OUT",
  unset = file.path(root, "_codex_audit/four_target_virtual_perturbation_integration_20260901_v1")
)
old_run_dir <- Sys.getenv(
  "LCDI_OLD_RUN_DIR",
  unset = file.path(root, "_codex_audit/casp1_virtual_perturbation_20260829_v1/formal_runs")
)
new_run_dir <- Sys.getenv(
  "LCDI_NEW_RUN_DIR",
  unset = file.path(root, paste0(
    "_codex_audit/five_gene_virtual_perturbation_server_20260831_v1/",
    "downloaded_server_results/formal_runs"
  ))
)
geneset_path <- Sys.getenv(
  "LCDI_GENESET_PATH",
  unset = file.path(root, "AML_Lactylation_PCD/scRNA/GSE116256/J4_GSVA/Cache/genesets_used.rds")
)
status_path <- file.path(out, "01_status.tsv")
if (!dir.exists(out)) dir.create(out, recursive = TRUE, showWarnings = FALSE)
if (file.exists(status_path)) stop("Refusing to overwrite completed analysis: ", status_path)
stopifnot(dir.exists(old_run_dir), dir.exists(new_run_dir), file.exists(geneset_path))

datasets <- c("adult", "pediatric")
targets <- c("MPO", "CASP1", "GPX4", "CREB1")
all_perturbed_targets <- targets
levels <- c(strict_FDR05 = "p.adj < 0.05", exploratory_P05 = "p.value < 0.05")

write_tsv <- function(x, name) {
  write.table(x, file.path(out, name), sep = "\t", quote = FALSE, row.names = FALSE, na = "")
}
bind_or_empty <- function(x) {
  x <- x[vapply(x, function(z) is.data.frame(z) && nrow(z) >= 0L, logical(1))]
  if (!length(x)) return(data.frame())
  all_names <- unique(unlist(lapply(x, names), use.names = FALSE))
  filled <- lapply(x, function(z) {
    missing <- setdiff(all_names, names(z))
    for (nm in missing) z[[nm]] <- NA
    z[, all_names, drop = FALSE]
  })
  do.call(rbind, filled)
}
as_df <- function(x) if (is.null(x)) data.frame() else as.data.frame(x)

run_path <- function(dataset, target) {
  if (target %in% c("CASP1", "MPO")) {
    file.path(old_run_dir, paste0("03_", dataset, "_", target, "_diffRegulation.tsv"))
  } else {
    file.path(new_run_dir, paste0("02_", dataset, "_", target, "_diffRegulation.tsv"))
  }
}

cat("Loading eight network result tables\n")
runs <- list()
input_rows <- list()
for (dataset in datasets) {
  for (target in targets) {
    path <- run_path(dataset, target)
    stopifnot(file.exists(path))
    x <- read.delim(path, check.names = FALSE)
    stopifnot(nrow(x) == 5000L, !anyDuplicated(x$gene), target %in% x$gene,
              all(c("gene", "distance", "Z", "FC", "p.value", "p.adj") %in% names(x)),
              !anyNA(x$p.value), !anyNA(x$p.adj))
    x$dataset <- dataset
    x$target <- target
    x$nominal_P05 <- x$p.value < 0.05
    x$strict_FDR05 <- x$p.adj < 0.05
    x$is_perturbed_target_gene <- x$gene %in% all_perturbed_targets
    runs[[paste(dataset, target, sep = "_")]] <- x
    input_rows[[length(input_rows) + 1L]] <- data.frame(
      dataset = dataset, target = target, input_path = normalizePath(path, winslash = "/"),
      genes = nrow(x), P05_excluding_self = sum(x$p.value < 0.05 & x$gene != target),
      FDR05_excluding_self = sum(x$p.adj < 0.05 & x$gene != target), stringsAsFactors = FALSE
    )
  }
}
inputs <- do.call(rbind, input_rows)
all_results <- do.call(rbind, lapply(runs, function(x) {
  x[, c("dataset", "target", "gene", "distance", "Z", "FC", "p.value", "p.adj",
        "nominal_P05", "strict_FDR05", "is_perturbed_target_gene")]
}))
rownames(all_results) <- NULL

all_sets <- readRDS(geneset_path)
kegg_names <- grep("^KEGG_", names(all_sets), value = TRUE)
stopifnot(length(kegg_names) >= 100L)
kegg_term2gene <- do.call(rbind, lapply(kegg_names, function(term) {
  data.frame(term = term, gene = unique(all_sets[[term]]), stringsAsFactors = FALSE)
}))
kegg_term2name <- data.frame(term = kegg_names, name = sub("^KEGG_", "", kegg_names), stringsAsFactors = FALSE)

all_symbols <- unique(all_results$gene)
mapping_all <- suppressMessages(AnnotationDbi::select(
  org.Hs.eg.db, keys = all_symbols, keytype = "SYMBOL", columns = c("SYMBOL", "ENTREZID")
))
mapping_all <- mapping_all[!is.na(mapping_all$ENTREZID) & nzchar(mapping_all$ENTREZID), , drop = FALSE]
mapping_all <- mapping_all[!duplicated(mapping_all$SYMBOL), , drop = FALSE]

candidate_rows <- list()
go_ora_rows <- list()
kegg_ora_rows <- list()
go_gsea_rows <- list()
kegg_gsea_rows <- list()
summary_rows <- list()

cat("Running two gene thresholds and two enrichment levels\n")
for (dataset in datasets) {
  for (target in targets) {
    run_id <- paste(dataset, target, sep = "_")
    x <- runs[[run_id]]
    universe_x <- x[!x$gene %in% all_perturbed_targets, , drop = FALSE]
    mapping <- mapping_all[mapping_all$SYMBOL %in% universe_x$gene, , drop = FALSE]
    universe_entrez <- unique(mapping$ENTREZID)

    lane_ora_summary <- list()
    for (level_name in names(levels)) {
      keep <- if (level_name == "strict_FDR05") universe_x$p.adj < 0.05 else universe_x$p.value < 0.05
      candidates <- universe_x[keep, , drop = FALSE]
      candidate_rows[[length(candidate_rows) + 1L]] <- data.frame(
        dataset = dataset, target = target, significance_level = level_name,
        threshold = unname(levels[[level_name]]),
        candidates[, c("gene", "distance", "Z", "FC", "p.value", "p.adj")],
        stringsAsFactors = FALSE
      )

      candidate_entrez <- unique(mapping$ENTREZID[match(candidates$gene, mapping$SYMBOL, nomatch = 0L)])
      candidate_entrez <- candidate_entrez[!is.na(candidate_entrez) & nzchar(candidate_entrez)]

      go_df <- data.frame()
      if (length(candidate_entrez)) {
        go_df <- as_df(enrichGO(
          gene = candidate_entrez, universe = universe_entrez, OrgDb = org.Hs.eg.db,
          keyType = "ENTREZID", ont = "BP", pAdjustMethod = "BH",
          pvalueCutoff = 1, qvalueCutoff = 1, minGSSize = 5, maxGSSize = 500, readable = TRUE
        ))
      }
      if (nrow(go_df)) {
        go_df$dataset <- dataset
        go_df$target <- target
        go_df$significance_level <- level_name
        go_ora_rows[[length(go_ora_rows) + 1L]] <- go_df
      }

      kegg_df <- data.frame()
      if (nrow(candidates)) {
        kegg_df <- as_df(enricher(
          gene = candidates$gene, universe = universe_x$gene,
          TERM2GENE = kegg_term2gene, TERM2NAME = kegg_term2name,
          pAdjustMethod = "BH", pvalueCutoff = 1, qvalueCutoff = 1,
          minGSSize = 5, maxGSSize = 500
        ))
      }
      if (nrow(kegg_df)) {
        kegg_df$dataset <- dataset
        kegg_df$target <- target
        kegg_df$significance_level <- level_name
        kegg_ora_rows[[length(kegg_ora_rows) + 1L]] <- kegg_df
      }

      lane_ora_summary[[level_name]] <- data.frame(
        significance_level = level_name,
        candidate_genes = nrow(candidates),
        mapped_candidate_entrez = length(candidate_entrez),
        GO_ORA_terms = nrow(go_df), GO_ORA_P05 = sum(go_df$pvalue < 0.05),
        GO_ORA_FDR05 = sum(go_df$p.adjust < 0.05),
        KEGG_ORA_terms = nrow(kegg_df), KEGG_ORA_P05 = sum(kegg_df$pvalue < 0.05),
        KEGG_ORA_FDR05 = sum(kegg_df$p.adjust < 0.05), stringsAsFactors = FALSE
      )
    }

    rank_symbol <- universe_x$Z
    names(rank_symbol) <- universe_x$gene
    rank_symbol <- sort(rank_symbol, decreasing = TRUE)
    map_rank <- mapping_all[match(names(rank_symbol), mapping_all$SYMBOL), , drop = FALSE]
    ok <- !is.na(map_rank$ENTREZID) & nzchar(map_rank$ENTREZID)
    rank_entrez_df <- data.frame(ENTREZID = map_rank$ENTREZID[ok], score = unname(rank_symbol[ok]))
    rank_entrez_df <- rank_entrez_df[order(-rank_entrez_df$score), , drop = FALSE]
    rank_entrez_df <- rank_entrez_df[!duplicated(rank_entrez_df$ENTREZID), , drop = FALSE]
    rank_entrez <- rank_entrez_df$score
    names(rank_entrez) <- rank_entrez_df$ENTREZID

    seed_base <- 202609010L + 100L * match(dataset, datasets) + 10L * match(target, targets)
    set.seed(seed_base)
    go_gsea_df <- as_df(gseGO(
      geneList = rank_entrez, OrgDb = org.Hs.eg.db, keyType = "ENTREZID", ont = "BP",
      minGSSize = 10, maxGSSize = 500, pvalueCutoff = 1, pAdjustMethod = "BH",
      eps = 0, verbose = FALSE, seed = TRUE, by = "fgsea",
      BPPARAM = serial_param
    ))
    if (nrow(go_gsea_df)) {
      go_gsea_df$dataset <- dataset
      go_gsea_df$target <- target
      go_gsea_rows[[length(go_gsea_rows) + 1L]] <- go_gsea_df
    }

    set.seed(seed_base + 1L)
    kegg_gsea_df <- as_df(GSEA(
      geneList = rank_symbol, TERM2GENE = kegg_term2gene, TERM2NAME = kegg_term2name,
      minGSSize = 10, maxGSSize = 500, pvalueCutoff = 1, pAdjustMethod = "BH",
      eps = 0, verbose = FALSE, seed = TRUE, by = "fgsea",
      BPPARAM = serial_param
    ))
    if (nrow(kegg_gsea_df)) {
      kegg_gsea_df$dataset <- dataset
      kegg_gsea_df$target <- target
      kegg_gsea_rows[[length(kegg_gsea_rows) + 1L]] <- kegg_gsea_df
    }

    lane_summary <- do.call(rbind, lane_ora_summary)
    lane_summary$dataset <- dataset
    lane_summary$target <- target
    lane_summary$tested_genes <- nrow(universe_x)
    lane_summary$mapped_universe_entrez <- length(universe_entrez)
    lane_summary$GO_GSEA_terms <- nrow(go_gsea_df)
    lane_summary$GO_GSEA_P05 <- sum(go_gsea_df$pvalue < 0.05)
    lane_summary$GO_GSEA_FDR05 <- sum(go_gsea_df$p.adjust < 0.05)
    lane_summary$KEGG_GSEA_terms <- nrow(kegg_gsea_df)
    lane_summary$KEGG_GSEA_P05 <- sum(kegg_gsea_df$pvalue < 0.05)
    lane_summary$KEGG_GSEA_FDR05 <- sum(kegg_gsea_df$p.adjust < 0.05)
    summary_rows[[length(summary_rows) + 1L]] <- lane_summary
  }
}

candidates <- bind_or_empty(candidate_rows)
go_ora <- bind_or_empty(go_ora_rows)
kegg_ora <- bind_or_empty(kegg_ora_rows)
go_gsea <- bind_or_empty(go_gsea_rows)
kegg_gsea <- bind_or_empty(kegg_gsea_rows)
enrichment_summary <- do.call(rbind, summary_rows)

pair_rows <- list()
overlap_rows <- list()
for (dataset in datasets) {
  pairs <- combn(targets, 2L, simplify = FALSE)
  for (pair in pairs) {
    a <- runs[[paste(dataset, pair[[1]], sep = "_")]]
    b <- runs[[paste(dataset, pair[[2]], sep = "_")]]
    common <- setdiff(intersect(a$gene, b$gene), all_perturbed_targets)
    aa <- a[match(common, a$gene), , drop = FALSE]
    bb <- b[match(common, b$gene), , drop = FALSE]
    ct <- suppressWarnings(cor.test(aa$Z, bb$Z, method = "spearman", exact = FALSE))
    pair_rows[[length(pair_rows) + 1L]] <- data.frame(
      comparison_scope = "within_dataset", dataset = dataset,
      target1 = pair[[1]], target2 = pair[[2]], common_genes = length(common),
      spearman_rho = unname(ct$estimate), p_value = ct$p.value, stringsAsFactors = FALSE
    )
    for (level_name in names(levels)) {
      sa <- if (level_name == "strict_FDR05") aa$gene[aa$p.adj < 0.05] else aa$gene[aa$p.value < 0.05]
      sb <- if (level_name == "strict_FDR05") bb$gene[bb$p.adj < 0.05] else bb$gene[bb$p.value < 0.05]
      inter <- intersect(sa, sb)
      uni <- union(sa, sb)
      hp <- phyper(length(inter) - 1L, length(sa), length(common) - length(sa), length(sb), lower.tail = FALSE)
      overlap_rows[[length(overlap_rows) + 1L]] <- data.frame(
        comparison_scope = "within_dataset", dataset = dataset, target = NA_character_,
        target1 = pair[[1]], target2 = pair[[2]], significance_level = level_name,
        universe = length(common), set1 = length(sa), set2 = length(sb), intersection = length(inter),
        same_sign_intersection = NA_integer_,
        union = length(uni), jaccard = ifelse(length(uni), length(inter) / length(uni), NA_real_),
        hypergeom_p = hp, stringsAsFactors = FALSE
      )
    }
  }
}
pairwise_cor <- do.call(rbind, pair_rows)
pairwise_cor$FDR <- ave(pairwise_cor$p_value, pairwise_cor$dataset, FUN = function(z) p.adjust(z, "BH"))

cross_rows <- list()
for (target in targets) {
  a <- runs[[paste("adult", target, sep = "_")]]
  p <- runs[[paste("pediatric", target, sep = "_")]]
  common <- setdiff(intersect(a$gene, p$gene), all_perturbed_targets)
  aa <- a[match(common, a$gene), , drop = FALSE]
  pp <- p[match(common, p$gene), , drop = FALSE]
  ct <- suppressWarnings(cor.test(aa$Z, pp$Z, method = "spearman", exact = FALSE))
  cross_rows[[length(cross_rows) + 1L]] <- data.frame(
    comparison_scope = "cross_dataset", dataset = "adult_vs_pediatric",
    target1 = target, target2 = target, common_genes = length(common),
    spearman_rho = unname(ct$estimate), p_value = ct$p.value, stringsAsFactors = FALSE
  )
  for (level_name in names(levels)) {
    sa <- if (level_name == "strict_FDR05") aa$gene[aa$p.adj < 0.05] else aa$gene[aa$p.value < 0.05]
    sp <- if (level_name == "strict_FDR05") pp$gene[pp$p.adj < 0.05] else pp$gene[pp$p.value < 0.05]
    inter <- intersect(sa, sp)
    uni <- union(sa, sp)
    same_sign <- inter[sign(aa$Z[match(inter, aa$gene)]) == sign(pp$Z[match(inter, pp$gene)])]
    hp <- phyper(length(inter) - 1L, length(sa), length(common) - length(sa), length(sp), lower.tail = FALSE)
    overlap_rows[[length(overlap_rows) + 1L]] <- data.frame(
      comparison_scope = "cross_dataset", dataset = "adult_vs_pediatric", target = target,
      target1 = target, target2 = target, significance_level = level_name,
      universe = length(common), set1 = length(sa), set2 = length(sp), intersection = length(inter),
      same_sign_intersection = length(same_sign), union = length(uni),
      jaccard = ifelse(length(uni), length(inter) / length(uni), NA_real_),
      hypergeom_p = hp, stringsAsFactors = FALSE
    )
  }
}
cross_cor <- do.call(rbind, cross_rows)
cross_cor$FDR <- p.adjust(cross_cor$p_value, "BH")
gene_overlap <- bind_or_empty(overlap_rows)
gene_overlap$hypergeom_FDR <- ave(
  gene_overlap$hypergeom_p,
  interaction(gene_overlap$comparison_scope, gene_overlap$dataset, gene_overlap$significance_level, drop = TRUE),
  FUN = function(z) p.adjust(z, "BH")
)

replicate_terms <- function(tab, source, gsea = FALSE) {
  if (!nrow(tab)) return(data.frame())
  level_values <- if (gsea) "ranked_all" else unique(tab$significance_level)
  rows <- list()
  for (target in targets) {
    for (level_name in level_values) {
      tt <- if (gsea) tab[tab$target == target, , drop = FALSE] else {
        tab[tab$target == target & tab$significance_level == level_name, , drop = FALSE]
      }
      a <- tt[tt$dataset == "adult", , drop = FALSE]
      p <- tt[tt$dataset == "pediatric", , drop = FALSE]
      ids <- intersect(a$ID, p$ID)
      if (!length(ids)) next
      a <- a[match(ids, a$ID), , drop = FALSE]
      p <- p[match(ids, p$ID), , drop = FALSE]
      same_direction <- if (gsea) sign(a$NES) == sign(p$NES) else rep(NA, length(ids))
      rep_p <- a$pvalue < 0.05 & p$pvalue < 0.05
      rep_fdr <- a$p.adjust < 0.05 & p$p.adjust < 0.05
      if (gsea) {
        rep_p <- rep_p & same_direction
        rep_fdr <- rep_fdr & same_direction
      }
      rows[[length(rows) + 1L]] <- data.frame(
        source = source, target = target, significance_level = level_name,
        ID = ids, Description = a$Description,
        adult_p = a$pvalue, adult_fdr = a$p.adjust,
        pediatric_p = p$pvalue, pediatric_fdr = p$p.adjust,
        adult_NES = if (gsea) a$NES else NA_real_,
        pediatric_NES = if (gsea) p$NES else NA_real_,
        same_NES_sign = same_direction,
        replicated_P05 = rep_p, replicated_FDR05 = rep_fdr,
        stringsAsFactors = FALSE
      )
    }
  }
  bind_or_empty(rows)
}

term_replication <- bind_or_empty(list(
  replicate_terms(go_ora, "GO_ORA", FALSE),
  replicate_terms(kegg_ora, "KEGG_ORA", FALSE),
  replicate_terms(go_gsea, "GO_GSEA", TRUE),
  replicate_terms(kegg_gsea, "KEGG_GSEA", TRUE)
))

top_core_rows <- list()
top_core_summary <- list()
for (scope in c(datasets, "all_eight")) {
  use_runs <- if (scope == "all_eight") runs else runs[startsWith(names(runs), paste0(scope, "_"))]
  common <- Reduce(intersect, lapply(use_runs, function(x) x$gene))
  common <- setdiff(common, all_perturbed_targets)
  core <- data.frame(gene = common, stringsAsFactors = FALSE)
  for (nm in names(use_runs)) {
    x <- use_runs[[nm]]
    z <- x$Z[match(common, x$gene)]
    pct <- rank(-z, ties.method = "average") / length(z)
    core[[paste0("percentile_", nm)]] <- pct
    core[[paste0("top25_", nm)]] <- pct <= 0.25
  }
  top_cols <- grep("^top25_", names(core), value = TRUE)
  pct_cols <- grep("^percentile_", names(core), value = TRUE)
  core$top25_count <- rowSums(core[, top_cols, drop = FALSE])
  core$mean_percentile <- rowMeans(core[, pct_cols, drop = FALSE])
  core$scope <- scope
  top_core_rows[[length(top_core_rows) + 1L]] <- core
  nlanes <- length(use_runs)
  observed <- sum(core$top25_count == nlanes)
  expected <- length(common) * (0.25 ^ nlanes)
  top_core_summary[[length(top_core_summary) + 1L]] <- data.frame(
    scope = scope, lanes = nlanes, common_genes = length(common),
    all_lane_top25_genes = observed, independence_expected = expected,
    enrichment_over_independence = ifelse(expected > 0, observed / expected, NA_real_),
    stringsAsFactors = FALSE
  )
}
top_core <- bind_or_empty(top_core_rows)
top_core_summary <- do.call(rbind, top_core_summary)

write_tsv(inputs, "01_input_manifest.tsv")
write_tsv(all_results, "01_all_eight_network_gene_results.tsv")
write_tsv(candidates, "01_candidate_genes_two_levels.tsv")
write_tsv(go_ora, "01_GO_ORA_two_gene_levels.tsv")
write_tsv(kegg_ora, "01_KEGG_ORA_two_gene_levels.tsv")
write_tsv(go_gsea, "01_GO_GSEA_full_rank.tsv")
write_tsv(kegg_gsea, "01_KEGG_GSEA_full_rank.tsv")
write_tsv(enrichment_summary, "01_enrichment_summary.tsv")
write_tsv(pairwise_cor, "01_within_dataset_target_rank_correlations.tsv")
write_tsv(cross_cor, "01_cross_dataset_target_rank_correlations.tsv")
write_tsv(gene_overlap, "01_significant_gene_set_overlaps.tsv")
write_tsv(term_replication, "01_cross_dataset_term_replication.tsv")
write_tsv(top_core, "01_top_quartile_core_gene_metrics.tsv")
write_tsv(top_core_summary, "01_top_quartile_core_summary.tsv")

write_tsv(data.frame(
  field = c("status", "completed", "gene_significance_levels", "enrichment_levels",
            "datasets", "targets", "SLC16A4_handling", "external_downloads", "R_version",
            "clusterProfiler_version", "org_Hs_eg_db_version"),
  value = c("passed", format(Sys.time(), "%Y-%m-%d %H:%M:%S %z"),
            "strict_FDR05;exploratory_P05", "candidate_ORA;full_rank_GSEA",
            paste(datasets, collapse = ";"), paste(targets, collapse = ";"),
            "low_detection_boundary_no_network", "none", as.character(getRversion()),
            as.character(packageVersion("clusterProfiler")), as.character(packageVersion("org.Hs.eg.db"))),
  stringsAsFactors = FALSE
), "01_status.tsv")
capture.output(sessionInfo(), file = file.path(out, "01_session_info.txt"))
cat("Four-target integration and two-level GO/KEGG completed\n")
print(as.data.frame(enrichment_summary))
print(as.data.frame(cross_cor))
print(as.data.frame(top_core_summary))

clean_exit_dll <- Sys.getenv("LCDI_CLEAN_EXIT_DLL", unset = "")
if (nzchar(clean_exit_dll)) {
  flush.console()
  dll <- dyn.load(clean_exit_dll)
  .C(getNativeSymbolInfo("clean_exit", PACKAGE = dll), as.integer(0))
}

from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib.pyplot as plt
import numpy as np
import pandas as pd
from scipy.stats import hypergeom


ROOT = Path(r"D:\26_01_AML")
OUT = ROOT / "_codex_audit" / "mpo_anchored_shared_distinct_20260901_v1"
INTEGRATION = ROOT / "_codex_audit" / "four_target_virtual_perturbation_integration_20260901_v1"
SERVER = INTEGRATION / "server_return" / "four_target_virtual_perturbation_integration_20260901_v1"
TARGETS = ["CASP1", "GPX4", "CREB1"]
ALL_TARGETS = {"MPO", "CASP1", "GPX4", "CREB1"}
DATASETS = ["adult", "pediatric"]
GENE_LEVELS = {
    "exploratory_P05": ("p.value", 0.05),
    "strict_FDR05": ("p.adj", 0.05),
}
TERM_LEVELS = {
    "term_P05": ("pvalue", 0.05),
    "term_FDR05": ("p.adjust", 0.05),
}


def read_tsv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t", low_memory=False)


def bh_adjust(values: pd.Series) -> pd.Series:
    values = pd.to_numeric(values, errors="coerce")
    out = pd.Series(np.nan, index=values.index, dtype=float)
    ok = values.notna()
    p = values[ok].to_numpy(dtype=float)
    if not len(p):
        return out
    order = np.argsort(p)
    ranked = p[order]
    adjusted = ranked * len(p) / np.arange(1, len(p) + 1)
    adjusted = np.minimum.accumulate(adjusted[::-1])[::-1]
    adjusted = np.minimum(adjusted, 1.0)
    restored = np.empty_like(adjusted)
    restored[order] = adjusted
    out.loc[ok] = restored
    return out


def overlap_p(universe: int, set1: int, set2: int, intersection: int) -> float:
    if universe <= 0 or set1 < 0 or set2 < 0:
        return np.nan
    return float(hypergeom.sf(intersection - 1, universe, set1, set2))


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


checks: list[dict[str, object]] = []


def check(name: str, passed: bool, detail: object) -> None:
    checks.append({"check": name, "passed": bool(passed), "detail": str(detail)})


all8 = read_tsv(SERVER / "01_all_eight_network_gene_results.tsv")
check("eight_network_lanes", all8.groupby(["dataset", "target"]).ngroups == 8, all8.groupby(["dataset", "target"]).ngroups)
check("each_network_5000_genes", all8.groupby(["dataset", "target"]).size().eq(5000).all(), all8.groupby(["dataset", "target"]).size().to_dict())
check("no_duplicate_gene_within_network", not all8.duplicated(["dataset", "target", "gene"]).any(), int(all8.duplicated(["dataset", "target", "gene"]).sum()))

# Gene-level MPO-anchored categories.
gene_summary_rows: list[dict[str, object]] = []
gene_member_rows: list[dict[str, object]] = []
gene_category_sets: dict[tuple[str, str, str, str], set[str]] = {}
gene_universes: dict[tuple[str, str], set[str]] = {}

for dataset in DATASETS:
    mpo = all8[(all8.dataset == dataset) & (all8.target == "MPO") & ~all8.gene.isin(ALL_TARGETS)].copy()
    for target in TARGETS:
        tar = all8[(all8.dataset == dataset) & (all8.target == target) & ~all8.gene.isin(ALL_TARGETS)].copy()
        universe = set(mpo.gene) & set(tar.gene)
        gene_universes[(dataset, target)] = universe
        m = tar[tar.gene.isin(universe)].merge(
            mpo[mpo.gene.isin(universe)], on="gene", suffixes=("_target", "_MPO")
        )
        for level, (column, threshold) in GENE_LEVELS.items():
            tset = set(m.loc[m[f"{column}_target"] < threshold, "gene"])
            mset = set(m.loc[m[f"{column}_MPO"] < threshold, "gene"])
            categories = {
                "shared_with_MPO": tset & mset,
                "target_only_at_threshold": tset - mset,
                "MPO_only_at_threshold": mset - tset,
            }
            for category, genes in categories.items():
                gene_category_sets[(dataset, target, level, category)] = genes
                for gene in sorted(genes):
                    row = m[m.gene == gene].iloc[0]
                    gene_member_rows.append({
                        "dataset": dataset,
                        "comparison": f"{target}_vs_MPO",
                        "target": target,
                        "gene_level": level,
                        "category": category,
                        "gene": gene,
                        "target_Z": row.Z_target,
                        "target_p": row["p.value_target"],
                        "target_FDR": row["p.adj_target"],
                        "MPO_Z": row.Z_MPO,
                        "MPO_p": row["p.value_MPO"],
                        "MPO_FDR": row["p.adj_MPO"],
                    })
            inter = categories["shared_with_MPO"]
            union = tset | mset
            gene_summary_rows.append({
                "dataset": dataset,
                "comparison": f"{target}_vs_MPO",
                "target": target,
                "gene_level": level,
                "universe": len(universe),
                "target_significant": len(tset),
                "MPO_significant": len(mset),
                "shared_with_MPO": len(inter),
                "target_only_at_threshold": len(categories["target_only_at_threshold"]),
                "MPO_only_at_threshold": len(categories["MPO_only_at_threshold"]),
                "union": len(union),
                "jaccard": len(inter) / len(union) if union else np.nan,
                "overlap_p": overlap_p(len(universe), len(tset), len(mset), len(inter)),
            })

gene_summary = pd.DataFrame(gene_summary_rows)
gene_summary["overlap_FDR"] = gene_summary.groupby(["dataset", "gene_level"], group_keys=False)["overlap_p"].apply(bh_adjust)
gene_members = pd.DataFrame(gene_member_rows)
gene_summary.to_csv(OUT / "01_mpo_anchored_gene_overlap.tsv", sep="\t", index=False)
gene_members.to_csv(OUT / "02_mpo_anchored_gene_category_members.tsv", sep="\t", index=False)

check("gene_category_partition", (
    gene_summary.target_significant
    == gene_summary.shared_with_MPO + gene_summary.target_only_at_threshold
).all(), "target partition")
for dataset in DATASETS:
    for target in ["MPO", *TARGETS]:
        lane = all8[(all8.dataset == dataset) & (all8.target == target) & ~all8.gene.isin(ALL_TARGETS)]
        pset = set(lane.loc[lane["p.value"] < 0.05, "gene"])
        fdrset = set(lane.loc[lane["p.adj"] < 0.05, "gene"])
        check(
            f"gene_FDR_set_subset_of_P_set_{dataset}_{target}",
            fdrset <= pset,
            f"FDR={len(fdrset)}; P={len(pset)}; violations={len(fdrset - pset)}",
        )

# Adult-pediatric replication of MPO-anchored gene categories.
gene_cross_rows: list[dict[str, object]] = []
gene_cross_member_rows: list[dict[str, object]] = []
for target in TARGETS:
    universe = gene_universes[("adult", target)] & gene_universes[("pediatric", target)]
    for level in GENE_LEVELS:
        for category in ["shared_with_MPO", "target_only_at_threshold", "MPO_only_at_threshold"]:
            aset = gene_category_sets[("adult", target, level, category)] & universe
            pset = gene_category_sets[("pediatric", target, level, category)] & universe
            inter = aset & pset
            gene_cross_rows.append({
                "comparison": f"{target}_vs_MPO",
                "target": target,
                "gene_level": level,
                "category": category,
                "universe": len(universe),
                "adult_genes": len(aset),
                "pediatric_genes": len(pset),
                "replicated_genes": len(inter),
                "jaccard": len(inter) / len(aset | pset) if (aset | pset) else np.nan,
                "overlap_p": overlap_p(len(universe), len(aset), len(pset), len(inter)),
            })
            for gene in sorted(inter):
                gene_cross_member_rows.append({
                    "comparison": f"{target}_vs_MPO",
                    "target": target,
                    "gene_level": level,
                    "category": category,
                    "gene": gene,
                })
gene_cross = pd.DataFrame(gene_cross_rows)
gene_cross["overlap_FDR"] = gene_cross.groupby(["gene_level", "category"], group_keys=False)["overlap_p"].apply(bh_adjust)
gene_cross.to_csv(OUT / "03_cross_dataset_gene_category_replication.tsv", sep="\t", index=False)
pd.DataFrame(gene_cross_member_rows).to_csv(OUT / "04_cross_dataset_gene_category_members.tsv", sep="\t", index=False)

# Pathway-level MPO-anchored categories.
term_sources = {
    "GO_ORA": read_tsv(SERVER / "01_GO_ORA_two_gene_levels.tsv"),
    "KEGG_ORA": read_tsv(SERVER / "01_KEGG_ORA_two_gene_levels.tsv"),
    "GO_GSEA": read_tsv(SERVER / "01_GO_GSEA_full_rank.tsv"),
    "KEGG_GSEA": read_tsv(SERVER / "01_KEGG_GSEA_full_rank.tsv"),
}
path_summary_rows: list[dict[str, object]] = []
path_member_rows: list[dict[str, object]] = []
path_category_sets: dict[tuple[str, str, str, str, str, str], set[str]] = {}
path_universes: dict[tuple[str, str, str, str], set[str]] = {}

for source, table in term_sources.items():
    is_gsea = source.endswith("GSEA")
    input_levels = ["ranked_all"] if is_gsea else ["exploratory_P05", "strict_FDR05"]
    for input_level in input_levels:
        lane_table = table.copy() if is_gsea else table[table.significance_level == input_level].copy()
        for dataset in DATASETS:
            mpo = lane_table[(lane_table.dataset == dataset) & (lane_table.target == "MPO")].copy()
            for target in TARGETS:
                tar = lane_table[(lane_table.dataset == dataset) & (lane_table.target == target)].copy()
                universe = set(mpo.ID) & set(tar.ID)
                path_universes[(dataset, target, source, input_level)] = universe
                mt = tar[tar.ID.isin(universe)].merge(
                    mpo[mpo.ID.isin(universe)], on="ID", suffixes=("_target", "_MPO")
                )
                for term_level, (column, threshold) in TERM_LEVELS.items():
                    tset = set(mt.loc[mt[f"{column}_target"] < threshold, "ID"])
                    mset = set(mt.loc[mt[f"{column}_MPO"] < threshold, "ID"])
                    both = tset & mset
                    if is_gsea:
                        sign_map = mt.set_index("ID")
                        shared = {
                            term for term in both
                            if np.sign(sign_map.loc[term, "NES_target"]) == np.sign(sign_map.loc[term, "NES_MPO"])
                        }
                        opposite = both - shared
                    else:
                        shared = both
                        opposite = set()
                    categories = {
                        "shared_with_MPO": shared,
                        "target_only_at_threshold": tset - mset,
                        "MPO_only_at_threshold": mset - tset,
                        "both_significant_opposite_NES": opposite,
                    }
                    for category, terms in categories.items():
                        path_category_sets[(dataset, target, source, input_level, term_level, category)] = terms
                        for term in sorted(terms):
                            row = mt[mt.ID == term].iloc[0]
                            path_member_rows.append({
                                "dataset": dataset,
                                "comparison": f"{target}_vs_MPO",
                                "target": target,
                                "source": source,
                                "candidate_input_level": input_level,
                                "term_level": term_level,
                                "category": category,
                                "ID": term,
                                "Description": row.get("Description_target", row.get("Description_MPO", "")),
                                "target_p": row.pvalue_target,
                                "target_FDR": row["p.adjust_target"],
                                "target_NES": row.get("NES_target", np.nan),
                                "MPO_p": row.pvalue_MPO,
                                "MPO_FDR": row["p.adjust_MPO"],
                                "MPO_NES": row.get("NES_MPO", np.nan),
                            })
                    union = tset | mset
                    path_summary_rows.append({
                        "dataset": dataset,
                        "comparison": f"{target}_vs_MPO",
                        "target": target,
                        "source": source,
                        "candidate_input_level": input_level,
                        "term_level": term_level,
                        "tested_common_terms": len(universe),
                        "target_significant": len(tset),
                        "MPO_significant": len(mset),
                        "shared_with_MPO": len(shared),
                        "target_only_at_threshold": len(categories["target_only_at_threshold"]),
                        "MPO_only_at_threshold": len(categories["MPO_only_at_threshold"]),
                        "both_significant_opposite_NES": len(opposite),
                        "union": len(union),
                        "jaccard": len(shared) / len(union) if union else np.nan,
                        "overlap_p": overlap_p(len(universe), len(tset), len(mset), len(both)),
                    })

path_summary = pd.DataFrame(path_summary_rows)
path_summary["overlap_FDR"] = path_summary.groupby(
    ["dataset", "source", "candidate_input_level", "term_level"], group_keys=False
)["overlap_p"].apply(bh_adjust)
path_members = pd.DataFrame(path_member_rows)
path_summary.to_csv(OUT / "05_mpo_anchored_pathway_overlap.tsv", sep="\t", index=False)
path_members.to_csv(OUT / "06_mpo_anchored_pathway_category_members.tsv", sep="\t", index=False)

check("pathway_target_partition", (
    path_summary.target_significant
    == path_summary.shared_with_MPO
    + path_summary.target_only_at_threshold
    + path_summary.both_significant_opposite_NES
).all(), "GSEA opposite NES retained separately")

# Adult-pediatric replication of MPO-anchored pathway categories.
path_cross_rows: list[dict[str, object]] = []
path_cross_member_rows: list[dict[str, object]] = []
for source in term_sources:
    is_gsea = source.endswith("GSEA")
    input_levels = ["ranked_all"] if is_gsea else ["exploratory_P05", "strict_FDR05"]
    for input_level in input_levels:
        for target in TARGETS:
            universe = (
                path_universes[("adult", target, source, input_level)]
                & path_universes[("pediatric", target, source, input_level)]
            )
            for term_level in TERM_LEVELS:
                for category in ["shared_with_MPO", "target_only_at_threshold", "MPO_only_at_threshold", "both_significant_opposite_NES"]:
                    aset = path_category_sets[("adult", target, source, input_level, term_level, category)] & universe
                    pset = path_category_sets[("pediatric", target, source, input_level, term_level, category)] & universe
                    inter = aset & pset
                    path_cross_rows.append({
                        "comparison": f"{target}_vs_MPO",
                        "target": target,
                        "source": source,
                        "candidate_input_level": input_level,
                        "term_level": term_level,
                        "category": category,
                        "tested_common_terms": len(universe),
                        "adult_terms": len(aset),
                        "pediatric_terms": len(pset),
                        "replicated_terms": len(inter),
                        "jaccard": len(inter) / len(aset | pset) if (aset | pset) else np.nan,
                        "overlap_p": overlap_p(len(universe), len(aset), len(pset), len(inter)),
                    })
                    for term in sorted(inter):
                        rows = path_members[
                            (path_members.target == target)
                            & (path_members.source == source)
                            & (path_members.candidate_input_level == input_level)
                            & (path_members.term_level == term_level)
                            & (path_members.category == category)
                            & (path_members.ID == term)
                        ]
                        desc = rows.Description.iloc[0] if len(rows) else ""
                        path_cross_member_rows.append({
                            "comparison": f"{target}_vs_MPO",
                            "target": target,
                            "source": source,
                            "candidate_input_level": input_level,
                            "term_level": term_level,
                            "category": category,
                            "ID": term,
                            "Description": desc,
                        })

path_cross = pd.DataFrame(path_cross_rows)
path_cross["overlap_FDR"] = path_cross.groupby(
    ["source", "candidate_input_level", "term_level", "category"], group_keys=False
)["overlap_p"].apply(bh_adjust)
path_cross.to_csv(OUT / "07_cross_dataset_pathway_category_replication.tsv", sep="\t", index=False)
pd.DataFrame(path_cross_member_rows).to_csv(OUT / "08_cross_dataset_pathway_category_members.tsv", sep="\t", index=False)

# Compact target summary.
summary_rows: list[dict[str, object]] = []
for target in TARGETS:
    for evidence_level, gene_level, term_level in [
        ("nominal_P", "exploratory_P05", "term_P05"),
        ("FDR", "strict_FDR05", "term_FDR05"),
    ]:
        g = gene_cross[(gene_cross.target == target) & (gene_cross.gene_level == gene_level)]
        g_shared = g[g.category == "shared_with_MPO"].iloc[0]
        g_distinct = g[g.category == "target_only_at_threshold"].iloc[0]
        pg = path_cross[
            (path_cross.target == target)
            & (path_cross.candidate_input_level == "ranked_all")
            & (path_cross.term_level == term_level)
            & (path_cross.source.isin(["GO_GSEA", "KEGG_GSEA"]))
        ]
        summary_rows.append({
            "target": target,
            "evidence_level": evidence_level,
            "adult_pediatric_replicated_shared_genes": int(g_shared.replicated_genes),
            "shared_gene_overlap_FDR": g_shared.overlap_FDR,
            "adult_pediatric_replicated_target_only_genes": int(g_distinct.replicated_genes),
            "target_only_gene_overlap_FDR": g_distinct.overlap_FDR,
            "adult_pediatric_replicated_shared_GSEA_terms": int(pg[pg.category == "shared_with_MPO"].replicated_terms.sum()),
            "adult_pediatric_replicated_target_only_GSEA_terms": int(pg[pg.category == "target_only_at_threshold"].replicated_terms.sum()),
        })
compact = pd.DataFrame(summary_rows)
compact.to_csv(OUT / "09_mpo_anchored_compact_summary.tsv", sep="\t", index=False)

# Audit figure.
plt.rcParams.update({"font.family": "DejaVu Sans", "font.size": 9})
fig, axes = plt.subplots(2, 2, figsize=(12.4, 9.0), constrained_layout=True)
colors = {"shared_with_MPO": "#9e9e9e", "target_only_at_threshold": "#4c78a8"}

def grouped_gene_panel(ax, level: str, title: str) -> None:
    rows = gene_summary[gene_summary.gene_level == level].copy()
    positions = np.arange(6)
    labels = [f"{d}\n{t}" for d in ["Adult", "Ped."] for t in TARGETS]
    ordered = []
    for dataset in DATASETS:
        for target in TARGETS:
            ordered.append(rows[(rows.dataset == dataset) & (rows.target == target)].iloc[0])
    shared = np.array([r.shared_with_MPO for r in ordered], dtype=float)
    distinct = np.array([r.target_only_at_threshold for r in ordered], dtype=float)
    ax.bar(positions, shared, color=colors["shared_with_MPO"], label="Shared with MPO")
    ax.bar(positions, distinct, bottom=shared, color=colors["target_only_at_threshold"], label="Target only at threshold")
    for i, (s, d) in enumerate(zip(shared, distinct)):
        ax.text(i, s + d + max(1, (shared + distinct).max() * 0.02), f"{int(s)}+{int(d)}", ha="center", fontsize=8)
    ax.set_xticks(positions, labels)
    ax.set_ylabel("Genes")
    ax.set_title(title)
    ax.legend(frameon=False, fontsize=8)
    ax.spines[["top", "right"]].set_visible(False)


grouped_gene_panel(axes[0, 0], "exploratory_P05", "A  Nominal-P gene structure versus MPO")
grouped_gene_panel(axes[0, 1], "strict_FDR05", "B  FDR gene structure versus MPO")

ax = axes[1, 0]
x = np.arange(len(TARGETS))
width = 0.18
for offset, (level, category, label, color) in enumerate([
    ("exploratory_P05", "shared_with_MPO", "Shared, P", "#bdbdbd"),
    ("exploratory_P05", "target_only_at_threshold", "Target only, P", "#9ecae1"),
    ("strict_FDR05", "shared_with_MPO", "Shared, FDR", "#636363"),
    ("strict_FDR05", "target_only_at_threshold", "Target only, FDR", "#2166ac"),
]):
    vals = [int(gene_cross[(gene_cross.target == t) & (gene_cross.gene_level == level) & (gene_cross.category == category)].replicated_genes.iloc[0]) for t in TARGETS]
    ax.bar(x + (offset - 1.5) * width, vals, width=width, label=label, color=color)
ax.set_xticks(x, TARGETS)
ax.set_ylabel("Adult–pediatric replicated genes")
ax.set_title("C  Cross-dataset gene-category stability")
ax.legend(frameon=False, fontsize=8, ncol=2)
ax.spines[["top", "right"]].set_visible(False)

ax = axes[1, 1]
x = np.arange(len(TARGETS))
for offset, (level, category, label, color) in enumerate([
    ("term_P05", "shared_with_MPO", "Shared GSEA, P", "#bdbdbd"),
    ("term_P05", "target_only_at_threshold", "Target-only GSEA, P", "#fdbb84"),
    ("term_FDR05", "shared_with_MPO", "Shared GSEA, FDR", "#636363"),
    ("term_FDR05", "target_only_at_threshold", "Target-only GSEA, FDR", "#e34a33"),
]):
    vals = []
    for target in TARGETS:
        rows = path_cross[
            (path_cross.target == target)
            & (path_cross.candidate_input_level == "ranked_all")
            & (path_cross.term_level == level)
            & (path_cross.category == category)
            & (path_cross.source.isin(["GO_GSEA", "KEGG_GSEA"]))
        ]
        vals.append(int(rows.replicated_terms.sum()))
    ax.bar(x + (offset - 1.5) * width, vals, width=width, label=label, color=color)
ax.set_xticks(x, TARGETS)
ax.set_ylabel("Adult–pediatric replicated terms")
ax.set_title("D  Full-rank pathway structure versus MPO")
ax.legend(frameon=False, fontsize=8, ncol=2)
ax.spines[["top", "right"]].set_visible(False)

fig.suptitle("MPO-anchored shared and distinct virtual network responses", fontsize=14, fontweight="bold")
fig.text(
    0.5,
    -0.01,
    "P: nominal P < 0.05; FDR: BH-adjusted < 0.05. Target-only is threshold-specific and not a formal interaction. "
    "GSEA Z/NES reflects perturbation rank, not expression direction.",
    ha="center",
    fontsize=8,
)
fig.savefig(OUT / "Figure_MPO_anchored_shared_distinct_v1.png", dpi=300, bbox_inches="tight")
fig.savefig(OUT / "Figure_MPO_anchored_shared_distinct_v1.pdf", bbox_inches="tight")
plt.close(fig)

# Validation and result summary.
check("all_gene_comparisons_present", len(gene_summary) == 12, len(gene_summary))
check("all_gene_cross_comparisons_present", len(gene_cross) == 18, len(gene_cross))
check("all_pathway_sources_present", set(path_summary.source) == set(term_sources), sorted(path_summary.source.unique()))
check("both_term_thresholds_present", set(path_summary.term_level) == set(TERM_LEVELS), sorted(path_summary.term_level.unique()))
check("SLC16A4_not_imputed", "SLC16A4" not in set(all8.target), sorted(all8.target.unique()))

checks_df = pd.DataFrame(checks)
checks_df.to_csv(OUT / "10_validation_checks.tsv", sep="\t", index=False)
failed = checks_df[~checks_df.passed]
validation = {
    "status": "passed" if failed.empty else "failed",
    "checks_total": int(len(checks_df)),
    "checks_passed": int(checks_df.passed.sum()),
    "checks_failed": int(len(failed)),
}
(OUT / "10_validation_summary.json").write_text(json.dumps(validation, ensure_ascii=False, indent=2), encoding="utf-8")

result = {
    "status": validation["status"],
    "question": "shared_and_distinct_non_MPO_targets_relative_to_MPO",
    "targets_compared_to_MPO": TARGETS,
    "gene_evidence_levels": list(GENE_LEVELS),
    "term_evidence_levels": list(TERM_LEVELS),
    "compact_summary": compact.to_dict(orient="records"),
    "SLC16A4": "no_valid_network_low_detection_no_imputation",
    "boundary": "Target-only at a threshold is not a formal target-by-MPO interaction or causal proof.",
}
(OUT / "10_result_summary.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8")

manifest_rows = []
for path in sorted(p for p in OUT.rglob("*") if p.is_file() and p.name != "11_sha256_manifest.tsv"):
    manifest_rows.append({"relative_path": path.relative_to(OUT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)})
pd.DataFrame(manifest_rows).to_csv(OUT / "11_sha256_manifest.tsv", sep="\t", index=False)

if not failed.empty:
    raise SystemExit(f"Validation failed: {failed.to_dict(orient='records')}")

print(json.dumps(validation, ensure_ascii=False))
print(compact.to_string(index=False))

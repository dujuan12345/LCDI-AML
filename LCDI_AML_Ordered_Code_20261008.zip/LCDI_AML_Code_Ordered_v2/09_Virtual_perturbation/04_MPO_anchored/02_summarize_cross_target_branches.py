from __future__ import annotations

import hashlib
import json
from pathlib import Path

import pandas as pd


OUT = Path(r"D:\26_01_AML\_codex_audit\mpo_anchored_shared_distinct_20260901_v1")
TARGETS = ["CASP1", "GPX4", "CREB1"]


def read_tsv(name: str) -> pd.DataFrame:
    return pd.read_csv(OUT / name, sep="\t", low_memory=False)


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open("rb") as handle:
        for block in iter(lambda: handle.read(1024 * 1024), b""):
            h.update(block)
    return h.hexdigest().upper()


path_members = read_tsv("08_cross_dataset_pathway_category_members.tsv")
gene_members = read_tsv("04_cross_dataset_gene_category_members.tsv")

gsea = path_members[
    (path_members.candidate_input_level == "ranked_all")
    & path_members.source.isin(["GO_GSEA", "KEGG_GSEA"])
    & path_members.category.isin(["shared_with_MPO", "target_only_at_threshold"])
].copy()
gsea["term_key"] = gsea.source + "|" + gsea.ID

branch_rows: list[dict[str, object]] = []
branch_summary_rows: list[dict[str, object]] = []
for term_level in ["term_P05", "term_FDR05"]:
    for category in ["shared_with_MPO", "target_only_at_threshold"]:
        x = gsea[(gsea.term_level == term_level) & (gsea.category == category)].copy()
        sets = {target: set(x.loc[x.target == target, "term_key"]) for target in TARGETS}
        universe = set().union(*sets.values())
        for key in sorted(universe):
            present = [target for target in TARGETS if key in sets[target]]
            row = x[x.term_key == key].iloc[0]
            branch_rows.append({
                "term_level": term_level,
                "category": category,
                "source": row.source,
                "ID": row.ID,
                "Description": row.Description,
                "target_count": len(present),
                "targets": ";".join(present),
                "CASP1": "CASP1" in present,
                "GPX4": "GPX4" in present,
                "CREB1": "CREB1" in present,
            })
        all_three = sets["CASP1"] & sets["GPX4"] & sets["CREB1"]
        branch_summary_rows.append({
            "term_level": term_level,
            "category": category,
            "CASP1_terms": len(sets["CASP1"]),
            "GPX4_terms": len(sets["GPX4"]),
            "CREB1_terms": len(sets["CREB1"]),
            "CASP1_GPX4_shared": len(sets["CASP1"] & sets["GPX4"]),
            "CASP1_CREB1_shared": len(sets["CASP1"] & sets["CREB1"]),
            "GPX4_CREB1_shared": len(sets["GPX4"] & sets["CREB1"]),
            "all_three_shared": len(all_three),
            "CASP1_unique": len(sets["CASP1"] - sets["GPX4"] - sets["CREB1"]),
            "GPX4_unique": len(sets["GPX4"] - sets["CASP1"] - sets["CREB1"]),
            "CREB1_unique": len(sets["CREB1"] - sets["CASP1"] - sets["GPX4"]),
            "union": len(universe),
        })

branch_members = pd.DataFrame(branch_rows)
branch_summary = pd.DataFrame(branch_summary_rows)
branch_members.to_csv(OUT / "12_cross_target_GSEA_branch_members.tsv", sep="\t", index=False)
branch_summary.to_csv(OUT / "12_cross_target_GSEA_branch_summary.tsv", sep="\t", index=False)

# Cross-target sharing among adult-pediatric replicated gene categories.
gene_rows: list[dict[str, object]] = []
for level in ["exploratory_P05", "strict_FDR05"]:
    for category in ["shared_with_MPO", "target_only_at_threshold"]:
        x = gene_members[(gene_members.gene_level == level) & (gene_members.category == category)]
        sets = {target: set(x.loc[x.target == target, "gene"]) for target in TARGETS}
        for gene in sorted(set().union(*sets.values())):
            present = [target for target in TARGETS if gene in sets[target]]
            gene_rows.append({
                "gene_level": level,
                "category": category,
                "gene": gene,
                "target_count": len(present),
                "targets": ";".join(present),
            })
pd.DataFrame(gene_rows).to_csv(OUT / "12_cross_target_gene_branch_members.tsv", sep="\t", index=False)

checks = [
    {
        "check": "four_GSEA_evidence_category_combinations",
        "passed": len(branch_summary) == 4,
        "detail": len(branch_summary),
    },
    {
        "check": "branch_member_counts_match_union",
        "passed": all(
            len(branch_members[(branch_members.term_level == row.term_level) & (branch_members.category == row.category)]) == row.union
            for row in branch_summary.itertuples(index=False)
        ),
        "detail": "member rows versus union",
    },
    {
        "check": "FDR_target_only_counts_match_compact_summary",
        "passed": (
            branch_summary[(branch_summary.term_level == "term_FDR05") & (branch_summary.category == "target_only_at_threshold")][
                ["CASP1_terms", "GPX4_terms", "CREB1_terms"]
            ].iloc[0].tolist()
            == [22, 40, 0]
        ),
        "detail": "CASP1/GPX4/CREB1=22/40/0",
    },
]
checks_df = pd.DataFrame(checks)
checks_df.to_csv(OUT / "12_validation_checks.tsv", sep="\t", index=False)
summary = {
    "status": "passed" if checks_df.passed.all() else "failed",
    "checks_total": len(checks_df),
    "checks_passed": int(checks_df.passed.sum()),
    "checks_failed": int((~checks_df.passed).sum()),
}
(OUT / "12_validation_summary.json").write_text(json.dumps(summary, indent=2), encoding="utf-8")

if not checks_df.passed.all():
    raise SystemExit(checks_df[~checks_df.passed].to_dict(orient="records"))

manifest_rows = []
for path in sorted(p for p in OUT.rglob("*") if p.is_file() and p.name != "13_sha256_manifest_final.tsv"):
    manifest_rows.append({"relative_path": path.relative_to(OUT).as_posix(), "bytes": path.stat().st_size, "sha256": sha256(path)})
pd.DataFrame(manifest_rows).to_csv(OUT / "13_sha256_manifest_final.tsv", sep="\t", index=False)

print(json.dumps(summary))
print(branch_summary.to_string(index=False))

from __future__ import annotations

import csv
import json
import re
import sys
from pathlib import Path

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(r"D:\26_01_AML\_codex_audit\clinical_qpcr_recovery_20260814_v1")
INVENTORY = ROOT / "03_xlsx_ooxml_inventory.json"
TABLE_DIR = ROOT / "xlsx_tables"


def coord(ref: str) -> tuple[int, int]:
    match = re.fullmatch(r"([A-Z]+)(\d+)", ref)
    if not match:
        raise ValueError(ref)
    col = 0
    for char in match.group(1):
        col = col * 26 + ord(char) - 64
    return int(match.group(2)), col


def safe_name(name: str) -> str:
    return re.sub(r"[^0-9A-Za-z\u4e00-\u9fff_-]+", "_", name)


def main() -> None:
    data = json.loads(INVENTORY.read_text(encoding="utf-8"))
    TABLE_DIR.mkdir(parents=True, exist_ok=True)
    preview = {}
    formula_rows = []
    for sheet in data["sheets"]:
        matrix = [[""] * sheet["max_col_seen"] for _ in range(sheet["max_row_seen"])]
        for cell in sheet["cells"]:
            row, col = coord(cell["ref"])
            matrix[row - 1][col - 1] = "" if cell["cached_value"] is None else str(cell["cached_value"])
            if cell["formula"] is not None:
                formula_rows.append(
                    [sheet["name"], cell["ref"], cell["formula"], cell["cached_value"], cell["style"]]
                )
        out_path = TABLE_DIR / f"{safe_name(sheet['name'])}.tsv"
        with out_path.open("w", encoding="utf-8-sig", newline="") as handle:
            csv.writer(handle, delimiter="\t", lineterminator="\n").writerows(matrix)
        preview[sheet["name"]] = [
            {"row": idx + 1, "values": [value for value in row if value != ""][:24]}
            for idx, row in enumerate(matrix[:14])
            if any(value != "" for value in row)
        ]

    with (ROOT / "06_xlsx_formulas.tsv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.writer(handle, delimiter="\t", lineterminator="\n")
        writer.writerow(["sheet", "cell", "formula", "cached_value", "style"])
        writer.writerows(formula_rows)
    (ROOT / "07_xlsx_sheet_previews.json").write_text(
        json.dumps(preview, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "status": "passed",
        "sheets_written": len(data["sheets"]),
        "formula_rows": len(formula_rows),
        "previews": preview,
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

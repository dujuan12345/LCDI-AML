from __future__ import annotations

import csv
import json
import math
import re
import sys
from pathlib import Path
from xml.etree import ElementTree as ET

import numpy as np
from scipy import stats

sys.stdout.reconfigure(encoding="utf-8")

ROOT = Path(r"D:\26_01_AML\_codex_audit\clinical_qpcr_recovery_20260814_v1")
SOURCE = Path(r"D:\电脑管家迁移文件\xwechat_files\wxid_913cjq0lvmfd32_3e57\msg\file\2026-06\骨髓项目二复测")
INVENTORY = ROOT / "03_xlsx_ooxml_inventory.json"

SHEETS = {
    "GAPDH_initial": ("结果分析-GAPDH", "GAPDH"),
    "GAPDH_retest": ("GAPDH复测", "GAPDH"),
    "ACTB_initial": ("结果分析-ACTB", "ACTB"),
    "ACTB_retest": ("ACTB复测", "ACTB"),
}
GENE_ROWS = {"MPO": 3, "CREB1": 4, "CASP1": 5, "SLC16A4": 6, "GPX4": 7}
NORMALIZED_ROWS = {"MPO": 23, "CREB1": 24, "CASP1": 25, "SLC16A4": 26, "GPX4": 27}
PATIENT_BLOCKS = ["B", "E", "H", "K", "N", "Q", "T", "W", "Z", "AC"]
GROUPS = ["control"] * 5 + ["disease"] * 5


def col_to_num(col: str) -> int:
    value = 0
    for char in col:
        value = value * 26 + ord(char) - 64
    return value


def num_to_col(value: int) -> str:
    out = ""
    while value:
        value, rem = divmod(value - 1, 26)
        out = chr(65 + rem) + out
    return out


def numeric(cell_map: dict, ref: str) -> float | None:
    cell = cell_map.get(ref)
    if cell is None or cell["cached_value"] in (None, ""):
        return None
    try:
        return float(cell["cached_value"])
    except (TypeError, ValueError):
        return None


def bh_adjust(pvalues: list[float | None]) -> list[float | None]:
    valid = [(idx, p) for idx, p in enumerate(pvalues) if p is not None and math.isfinite(p)]
    out: list[float | None] = [None] * len(pvalues)
    if not valid:
        return out
    ranked = sorted(valid, key=lambda item: item[1])
    m = len(ranked)
    running = 1.0
    for rank_from_end in range(m - 1, -1, -1):
        idx, p = ranked[rank_from_end]
        rank = rank_from_end + 1
        running = min(running, p * m / rank)
        out[idx] = min(1.0, running)
    return out


def welch_summary(control: list[float], disease: list[float]) -> dict:
    if len(control) < 2 or len(disease) < 2:
        return {"welch_p": None, "mannwhitney_p": None, "log2fc": None, "fold_change": None,
                "log2fc_ci_low": None, "log2fc_ci_high": None,
                "fold_ci_low": None, "fold_ci_high": None}
    c = np.asarray(control, dtype=float)
    d = np.asarray(disease, dtype=float)
    welch = stats.ttest_ind(d, c, equal_var=False, alternative="two-sided")
    mann = stats.mannwhitneyu(d, c, alternative="two-sided", method="exact")
    delta = float(np.mean(d) - np.mean(c))
    var_c = float(np.var(c, ddof=1))
    var_d = float(np.var(d, ddof=1))
    se2 = var_c / len(c) + var_d / len(d)
    se = math.sqrt(se2)
    df = se2 * se2 / ((var_c / len(c)) ** 2 / (len(c) - 1) + (var_d / len(d)) ** 2 / (len(d) - 1))
    critical = float(stats.t.ppf(0.975, df))
    delta_low, delta_high = delta - critical * se, delta + critical * se
    log2fc = -delta
    log2fc_low, log2fc_high = -delta_high, -delta_low
    return {
        "welch_p": float(welch.pvalue),
        "mannwhitney_p": float(mann.pvalue),
        "log2fc": log2fc,
        "fold_change": 2.0 ** log2fc,
        "log2fc_ci_low": log2fc_low,
        "log2fc_ci_high": log2fc_high,
        "fold_ci_low": 2.0 ** log2fc_low,
        "fold_ci_high": 2.0 ** log2fc_high,
    }


def extract_patient_values(sheet: dict, reference: str) -> list[dict]:
    cell_map = {cell["ref"]: cell for cell in sheet["cells"]}
    rows = []
    for patient_idx, (start_col, group) in enumerate(zip(PATIENT_BLOCKS, GROUPS), start=1):
        start_num = col_to_num(start_col)
        cols = [num_to_col(start_num + offset) for offset in range(3)]
        ref_values = [numeric(cell_map, f"{col}8") for col in cols]
        ref_values = [value for value in ref_values if value is not None]
        for gene, row_num in GENE_ROWS.items():
            target_values = [numeric(cell_map, f"{col}{row_num}") for col in cols]
            target_values = [value for value in target_values if value is not None]
            target_mean = float(np.mean(target_values)) if target_values else None
            reference_mean = float(np.mean(ref_values)) if ref_values else None
            delta_ct = target_mean - reference_mean if target_mean is not None and reference_mean is not None else None
            rows.append({
                "sheet": sheet["name"],
                "reference": reference,
                "sample_id": f"C{patient_idx}" if group == "control" else f"D{patient_idx - 5}",
                "group": group,
                "gene": gene,
                "target_n_technical": len(target_values),
                "target_ct_mean": target_mean,
                "target_ct_sd": float(np.std(target_values, ddof=1)) if len(target_values) >= 2 else None,
                "reference_n_technical": len(ref_values),
                "reference_ct_mean": reference_mean,
                "reference_ct_sd": float(np.std(ref_values, ddof=1)) if len(ref_values) >= 2 else None,
                "delta_ct": delta_ct,
                "relative_expression": 2.0 ** (-delta_ct) if delta_ct is not None else None,
                "target_ct_ge_35": target_mean is not None and target_mean >= 35.0,
            })
    return rows


def summarize_patient_values(label: str, rows: list[dict]) -> list[dict]:
    summary = []
    for gene in GENE_ROWS:
        gene_rows = [row for row in rows if row["gene"] == gene and row["delta_ct"] is not None]
        control = [row["delta_ct"] for row in gene_rows if row["group"] == "control"]
        disease = [row["delta_ct"] for row in gene_rows if row["group"] == "disease"]
        test = welch_summary(control, disease)
        summary.append({
            "analysis": label,
            "reference": rows[0]["reference"],
            "gene": gene,
            "n_control_biological": len(control),
            "n_disease_biological": len(disease),
            "mean_delta_ct_control": float(np.mean(control)) if control else None,
            "mean_delta_ct_disease": float(np.mean(disease)) if disease else None,
            "median_delta_ct_control": float(np.median(control)) if control else None,
            "median_delta_ct_disease": float(np.median(disease)) if disease else None,
            "target_ct_ge_35_control": sum(row["target_ct_ge_35"] for row in gene_rows if row["group"] == "control"),
            "target_ct_ge_35_disease": sum(row["target_ct_ge_35"] for row in gene_rows if row["group"] == "disease"),
            **test,
        })
    fdr = bh_adjust([row["welch_p"] for row in summary])
    mann_fdr = bh_adjust([row["mannwhitney_p"] for row in summary])
    for row, value, mann_value in zip(summary, fdr, mann_fdr):
        row["welch_bh_fdr"] = value
        row["mannwhitney_bh_fdr"] = mann_value
    return summary


def combined_reference_summary(label: str, actb_rows: list[dict], gapdh_rows: list[dict]) -> list[dict]:
    lookup_actb = {(row["sample_id"], row["gene"]): row for row in actb_rows}
    lookup_gapdh = {(row["sample_id"], row["gene"]): row for row in gapdh_rows}
    summary = []
    for gene in GENE_ROWS:
        control, disease = [], []
        flags = {"control": 0, "disease": 0}
        for patient_idx, group in enumerate(GROUPS, start=1):
            sample_id = f"C{patient_idx}" if group == "control" else f"D{patient_idx - 5}"
            a = lookup_actb.get((sample_id, gene))
            g = lookup_gapdh.get((sample_id, gene))
            if not a or not g or a["target_ct_mean"] is None or a["reference_ct_mean"] is None or g["reference_ct_mean"] is None:
                continue
            combined_ref_ct = (a["reference_ct_mean"] + g["reference_ct_mean"]) / 2.0
            delta_ct = a["target_ct_mean"] - combined_ref_ct
            (control if group == "control" else disease).append(delta_ct)
            if a["target_ct_mean"] >= 35.0:
                flags[group] += 1
        test = welch_summary(control, disease)
        summary.append({
            "analysis": label,
            "reference": "ACTB_GAPDH_geometric_mean_exploratory",
            "gene": gene,
            "n_control_biological": len(control),
            "n_disease_biological": len(disease),
            "mean_delta_ct_control": float(np.mean(control)) if control else None,
            "mean_delta_ct_disease": float(np.mean(disease)) if disease else None,
            "median_delta_ct_control": float(np.median(control)) if control else None,
            "median_delta_ct_disease": float(np.median(disease)) if disease else None,
            "target_ct_ge_35_control": flags["control"],
            "target_ct_ge_35_disease": flags["disease"],
            **test,
        })
    fdr = bh_adjust([row["welch_p"] for row in summary])
    mann_fdr = bh_adjust([row["mannwhitney_p"] for row in summary])
    for row, value, mann_value in zip(summary, fdr, mann_fdr):
        row["welch_bh_fdr"] = value
        row["mannwhitney_bh_fdr"] = mann_value
    return summary


def reference_qc(label: str, rows: list[dict]) -> dict:
    unique = {}
    for row in rows:
        unique[row["sample_id"]] = {
            "group": row["group"],
            "mean": row["reference_ct_mean"],
            "sd": row["reference_ct_sd"],
        }
    control = [value["mean"] for value in unique.values() if value["group"] == "control"]
    disease = [value["mean"] for value in unique.values() if value["group"] == "disease"]
    test = stats.ttest_ind(disease, control, equal_var=False)
    return {
        "analysis": label,
        "reference": rows[0]["reference"],
        "n_control": len(control),
        "n_disease": len(disease),
        "mean_ct_control": float(np.mean(control)),
        "mean_ct_disease": float(np.mean(disease)),
        "disease_minus_control_ct": float(np.mean(disease) - np.mean(control)),
        "welch_p": float(test.pvalue),
        "median_technical_sd": float(np.median([value["sd"] for value in unique.values()])),
        "max_technical_sd": float(np.max([value["sd"] for value in unique.values()])),
        "sample_means": {key: value["mean"] for key, value in unique.items()},
    }


def compare_reference_runs(reference: str, initial: dict, retest: dict) -> dict:
    keys = sorted(initial["sample_means"])
    x = np.asarray([initial["sample_means"][key] for key in keys], dtype=float)
    y = np.asarray([retest["sample_means"][key] for key in keys], dtype=float)
    diff = y - x
    pearson = stats.pearsonr(x, y)
    spearman = stats.spearmanr(x, y)
    paired = stats.ttest_rel(y, x)
    return {
        "reference": reference,
        "n_samples": len(keys),
        "pearson_r": float(pearson.statistic),
        "pearson_p": float(pearson.pvalue),
        "spearman_rho": float(spearman.statistic),
        "spearman_p": float(spearman.pvalue),
        "mean_retest_minus_initial_ct": float(np.mean(diff)),
        "mean_absolute_difference_ct": float(np.mean(np.abs(diff))),
        "max_absolute_difference_ct": float(np.max(np.abs(diff))),
        "paired_t_p": float(paired.pvalue),
        "per_sample_difference": {key: float(value) for key, value in zip(keys, diff)},
    }


def local_name(tag: str) -> str:
    return tag.rsplit("}", 1)[-1]


def title_text(node: ET.Element) -> str:
    return "".join(part.text or "" for part in node.iter() if local_name(part.tag) in {"Title", "TextAlign"}).strip()


def parse_prism(path: Path, reference: str) -> list[dict]:
    root = ET.parse(path).getroot()
    rows = []
    for table in root.iter():
        if local_name(table.tag) != "Table":
            continue
        title_node = next((child for child in table if local_name(child.tag) == "Title"), None)
        gene = "".join(title_node.itertext()).strip() if title_node is not None else table.attrib.get("ID")
        columns = []
        for column in table:
            if local_name(column.tag) != "YColumn":
                continue
            col_title = next((child for child in column if local_name(child.tag) == "Title"), None)
            group = "".join(col_title.itertext()).strip() if col_title is not None else ""
            values = [float(node.text) for node in column.iter() if local_name(node.tag) == "d" and node.text]
            columns.append((group, values))
        if len(columns) != 2:
            continue
        control, disease = columns[0][1], columns[1][1]
        equal = stats.ttest_ind(disease, control, equal_var=True)
        welch = stats.ttest_ind(disease, control, equal_var=False)
        mann = stats.mannwhitneyu(disease, control, alternative="two-sided", method="auto")
        rows.append({
            "reference": reference,
            "gene": gene,
            "n_values_control": len(control),
            "n_values_disease": len(disease),
            "expected_biological_n_control": 5 if gene != "CASP1" else 1,
            "expected_biological_n_disease": 5 if gene != "CASP1" else 1,
            "technical_values_per_biological_sample": 3,
            "mean_control": float(np.mean(control)),
            "mean_disease": float(np.mean(disease)),
            "student_t_p": float(equal.pvalue),
            "welch_t_p": float(welch.pvalue),
            "mannwhitney_p": float(mann.pvalue),
            "pseudoreplication": True,
        })
    return rows


def technical_replicate_audit_from_sheet(label: str, sheet: dict) -> list[dict]:
    cell_map = {cell["ref"]: cell for cell in sheet["cells"]}
    control_cols = [num_to_col(value) for value in range(col_to_num("B"), col_to_num("P") + 1)]
    disease_cols = [num_to_col(value) for value in range(col_to_num("Q"), col_to_num("AE") + 1)]
    rows = []
    for gene, row_num in NORMALIZED_ROWS.items():
        control = [numeric(cell_map, f"{col}{row_num}") for col in control_cols]
        disease = [numeric(cell_map, f"{col}{row_num}") for col in disease_cols]
        control = [value for value in control if value is not None]
        disease = [value for value in disease if value is not None]
        equal = stats.ttest_ind(disease, control, equal_var=True) if len(control) >= 2 and len(disease) >= 2 else None
        welch = stats.ttest_ind(disease, control, equal_var=False) if len(control) >= 2 and len(disease) >= 2 else None
        rows.append({
            "analysis": label,
            "gene": gene,
            "n_values_control": len(control),
            "n_values_disease": len(disease),
            "biological_n_control": 5 if gene != "CASP1" else 1,
            "biological_n_disease": 5 if gene != "CASP1" else 1,
            "mean_control": float(np.mean(control)) if control else None,
            "mean_disease": float(np.mean(disease)) if disease else None,
            "student_t_p": float(equal.pvalue) if equal is not None else None,
            "welch_t_p": float(welch.pvalue) if welch is not None else None,
            "pseudoreplication": True,
        })
    return rows


def write_tsv(path: Path, rows: list[dict], exclude: set[str] | None = None) -> None:
    exclude = exclude or set()
    columns = [key for key in rows[0] if key not in exclude]
    with path.open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, delimiter="\t", fieldnames=columns, lineterminator="\n")
        writer.writeheader()
        for row in rows:
            writer.writerow({key: row.get(key) for key in columns})


def main() -> None:
    workbook = json.loads(INVENTORY.read_text(encoding="utf-8"))
    sheet_lookup = {sheet["name"]: sheet for sheet in workbook["sheets"]}
    patient_rows_by_label = {}
    all_patient_rows = []
    all_summary = []
    reference_rows = []
    reference_by_label = {}
    for label, (sheet_name, reference) in SHEETS.items():
        patient_rows = extract_patient_values(sheet_lookup[sheet_name], reference)
        patient_rows_by_label[label] = patient_rows
        all_patient_rows.extend(patient_rows)
        all_summary.extend(summarize_patient_values(label, patient_rows))
        qc = reference_qc(label, patient_rows)
        reference_rows.append({key: value for key, value in qc.items() if key != "sample_means"})
        reference_by_label[label] = qc

    all_summary.extend(combined_reference_summary(
        "dual_reference_initial_exploratory",
        patient_rows_by_label["ACTB_initial"],
        patient_rows_by_label["GAPDH_initial"],
    ))
    all_summary.extend(combined_reference_summary(
        "dual_reference_retest_exploratory",
        patient_rows_by_label["ACTB_retest"],
        patient_rows_by_label["GAPDH_retest"],
    ))

    run_comparisons = [
        compare_reference_runs("ACTB", reference_by_label["ACTB_initial"], reference_by_label["ACTB_retest"]),
        compare_reference_runs("GAPDH", reference_by_label["GAPDH_initial"], reference_by_label["GAPDH_retest"]),
    ]

    prism_rows = []
    prism_rows.extend(parse_prism(SOURCE / "ACTB统计分析" / "6.23统计分析2.pzfx", "ACTB_retest"))
    prism_rows.extend(parse_prism(SOURCE / "GAPDH统计分析" / "6.23统计分析1.pzfx", "GAPDH_retest"))
    all_graph_rows = []
    for label, (sheet_name, _) in SHEETS.items():
        all_graph_rows.extend(technical_replicate_audit_from_sheet(label, sheet_lookup[sheet_name]))

    write_tsv(ROOT / "11_patient_level_qpcr_values.tsv", all_patient_rows)
    write_tsv(ROOT / "12_patient_level_qpcr_summary.tsv", all_summary)
    write_tsv(ROOT / "13_reference_gene_qc.tsv", reference_rows)
    write_tsv(ROOT / "14_prism_technical_replicate_audit.tsv", prism_rows)
    write_tsv(ROOT / "14b_all_graph_technical_replicate_audit.tsv", all_graph_rows)
    (ROOT / "15_reference_run_reproducibility.json").write_text(
        json.dumps(run_comparisons, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    result = {
        "status": "passed",
        "patient_level_summary": all_summary,
        "reference_qc": reference_rows,
        "reference_run_reproducibility": run_comparisons,
        "prism_technical_replicate_audit": prism_rows,
        "all_graph_technical_replicate_audit": all_graph_rows,
    }
    (ROOT / "16_qpcr_analysis_summary.json").write_text(
        json.dumps(result, ensure_ascii=False, indent=2), encoding="utf-8"
    )
    print(json.dumps({
        "status": "passed",
        "patient_level_rows": len(all_patient_rows),
        "summary_rows": len(all_summary),
        "nominal_welch_p_lt_0_05": [
            {"analysis": row["analysis"], "gene": row["gene"], "p": row["welch_p"], "fdr": row["welch_bh_fdr"]}
            for row in all_summary if row["welch_p"] is not None and row["welch_p"] < 0.05
        ],
        "reference_run_reproducibility": run_comparisons,
        "prism_rows": len(prism_rows),
        "all_graph_rows": len(all_graph_rows),
    }, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

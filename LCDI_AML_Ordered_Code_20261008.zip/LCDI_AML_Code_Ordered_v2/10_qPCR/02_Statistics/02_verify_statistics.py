from pathlib import Path
import csv,json,math,sys
import numpy as np
import scipy
from scipy import stats
P=Path(__file__).parent;S=P.parent/'clinical_qpcr_recovery_20260814_v1'
read=lambda p:list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
v=read(S/'11_patient_level_qpcr_values.tsv');s=read(S/'12_patient_level_qpcr_summary.tsv')
mapping={'GAPDH_initial':'结果分析-GAPDH','ACTB_initial':'结果分析-ACTB','GAPDH_retest':'GAPDH复测','ACTB_retest':'ACTB复测'}
def get(analysis,g,group):
    def vals(sheet):return {r['sample_id']:float(r['delta_ct']) for r in v if r['sheet']==sheet and r['gene']==g and r['group']==group and r['delta_ct']}
    if analysis.startswith('dual'):
        suffix='initial' if 'initial' in analysis else 'retest';a=vals(mapping['ACTB_'+suffix]);b=vals(mapping['GAPDH_'+suffix]);return np.array([(a[k]+b[k])/2 for k in a if k in b])
    return np.array(list(vals(mapping[analysis]).values()))
checks=[]
for analysis in dict.fromkeys(r['analysis'] for r in s):
    testable=[]
    for r in [r for r in s if r['analysis']==analysis]:
        a=get(analysis,r['gene'],'control');b=get(analysis,r['gene'],'disease')
        assert len(a)==int(r['n_control_biological']) and len(b)==int(r['n_disease_biological'])
        if r['gene']=='CASP1':assert len(a)==len(b)==1 and r['welch_p']=='' and r['log2fc']=='';continue
        est=np.mean(a)-np.mean(b);va=np.var(a,ddof=1)/len(a);vb=np.var(b,ddof=1)/len(b);df=(va+vb)**2/(va**2/(len(a)-1)+vb**2/(len(b)-1));width=stats.t.ppf(.975,df)*math.sqrt(va+vb)
        expected={'log2fc':est,'fold_change':2**est,'log2fc_ci_low':est-width,'log2fc_ci_high':est+width,'welch_p':stats.ttest_ind(a,b,equal_var=False).pvalue,'mannwhitney_p':stats.mannwhitneyu(a,b,alternative='two-sided',method='exact').pvalue}
        for k,x in expected.items():assert abs(float(r[k])-x)<1e-9,(analysis,r['gene'],k)
        testable.append(r);checks.append(analysis+'/'+r['gene'])
    for pk,fk in [('welch_p','welch_bh_fdr'),('mannwhitney_p','mannwhitney_bh_fdr')]:
        ordered=sorted(testable,key=lambda r:float(r[pk]));running=1
        for i in range(3,-1,-1):
            r=ordered[i];running=min(running,float(r[pk])*4/(i+1));assert abs(running-float(r[fk]))<1e-9
result={'passed':True,'checks':checks,'environment':{'python':sys.version,'executable':sys.executable,'scipy':scipy.__version__,'numpy':np.__version__,'Conda':'base interpreter called directly; no conda activation'}}
(P/'02_statistics_verification.json').write_text(json.dumps(result,indent=2),encoding='utf-8')
print('Statistical verification passed: 24 estimates, 48 P values, 48 BH-FDR values and 24 confidence intervals.')

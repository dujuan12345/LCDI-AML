options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages(library(metafor))
out<-file.path(getwd(),'review_addendum_4plus1_20260911');dest<-file.path(out,'01_cohort_heterogeneity')
d<-read.delim(file.path(dest,'cohort_effects.tsv'))
d$yi<-log(d$hr);d$sei<-(log(d$upper)-log(d$lower))/(2*1.96)
# All inputs are Wald intervals recomputed from the same frozen per-SD Cox specification.
stopifnot(max(abs(d$sei/d$se-qnorm(.975)/1.96))<1e-10)
sets<-list(PRIMARY_META=c('TARGET','BeatAML2','GSE71014','GSE106291'),A_postfreeze=c('BeatAML2','GSE71014'),B_plus_historical=c('TARGET','BeatAML2','GSE71014','GSE106291','GSE10358'),C_plus_records=c('TARGET','BeatAML2','GSE71014','GSE10358','GPL570'))
rr<-list();ff<-list()
for(s in names(sets))for(test in c('z','knha')) {
 dd<-d[match(sets[[s]],d$dataset),];stopifnot(!any(dd$dataset%in%c('TCGA','GPL96')))
 fit<-rma(yi=dd$yi,sei=dd$sei,method='REML',test=test);pr<-predict(fit,transf=exp)
 rr[[length(rr)+1]]<-data.frame(set=s,CI_method=test,k=nrow(dd),datasets=paste(dd$dataset,collapse=';'),pooled_HR=pr$pred,lower=pr$ci.lb,upper=pr$ci.ub,p=fit$pval,tau2=fit$tau2,I2=fit$I2,Q=fit$QE,Q_p=fit$QEp,prediction_lower=pr$pi.lb,prediction_upper=pr$pi.ub)
 ff[[paste(s,test,sep='_')]]<-fit
}
write.table(do.call(rbind,rr),file.path(dest,'random_effects_meta_audited.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
write.table(d,file.path(dest,'meta_input_effects_audited.tsv'),sep='\t',quote=FALSE,row.names=FALSE)
saveRDS(ff,file.path(dest,'meta_models_audited.rds'))
writeLines(capture.output(sessionInfo()),file.path(dest,'session_audited.txt'))
cat('ANALYSIS_LOGIC_PASS\nRESULT_AUDIT_PASS\nSUCCESS\n')

options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages(library(survival))
root<-getwd(); out<-file.path(root,'review_addendum_4plus1_20260911')
w<-function(x,p) write.table(x,file.path(out,p),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
z1<-function(x) as.numeric((x-mean(x))/sd(x))
src<-'AML_Lactylation_PCD/data/processed/mime/clean/B_cohort_data_5cohorts_clinical_v2.rds'
objs<-readRDS(src)
f<-read.csv('AML_Lactylation_PCD/results/tables/mime/clean/E_LCDI_formula.csv')
g<-as.character(f$Gene); beta<-setNames(f$Coefficient,g)
stopifnot(all(beta[c('CREB1','SLC16A4','GPX4','CASP1','MPO')]==c(.0925,-.0636,-.0721,-.0106,-.2095)))
datasets<-c('GPL96','GPL570','GSE10358','TCGA','TARGET','BeatAML2','GSE71014','GSE106291')
roles<-c('Coefficient fitting','Auxiliary record evaluation','Historical transfer','Feature selection and development','Patient evaluation','Strict independent replication','Additional external evaluation','Additional external evaluation')
units<-c('expression_record','expression_record','patient_mapping_under_audit','patient','patient','patient','patient','patient')
all<-list(); raw<-list(); missing<-list(); vars<-list(); audit<-list(); dist<-list(); metrics<-list()
for(i in seq_along(datasets)) {
 name<-datasets[i]
 if(i<=5) {
  o<-objs[[i]]; e<-if(i==5) o$expr_5[g,,drop=FALSE] else o$expr_raw[g,,drop=FALSE]
  s<-as.data.frame(o$surv); s<-s[match(colnames(e),s$sample_id),,drop=FALSE]
  t<-if(i==5) s$os_days else s$OS.time; event<-if(i==5) s$os_status else s$OS
  pid<-if(i==5) s$case_id else if(i==4) substr(s$sample_id,1,12) else s$sample_id
  zs<-if(i==5) e else sweep(sweep(e,1,f$Mean_GPL96,'-'),1,f$SD_GPL96,'/')
  branch<-if(i==5) 'saved_TARGET_within_gene_z' else 'frozen_GPL96_mean_sd_C0561'
  input<-src
 } else {
  input<-paste0('_codex_audit/external_survival_validation_20260804_v1/prepared_inputs/',name,'_survival_input.tsv')
  s<-read.delim(input,check.names=FALSE,na.strings=c('','NA'),quote='')
  e<-t(as.matrix(s[,g])); colnames(e)<-s$sample_id
  zs<-t(apply(e,1,z1)); t<-s$time_days; event<-s$status;pid<-s$subject_id
  branch<-'frozen_within_cohort_gene_z'
 }
 stopifnot(identical(colnames(e),as.character(s$sample_id)),!anyDuplicated(s$sample_id),all(is.finite(e)),all(t>0),all(event%in%c(0,1)))
 if(i>=4) stopifnot(!anyDuplicated(pid))
 d<-data.frame(dataset=name,sample_id=s$sample_id,patient_id=pid,time=as.numeric(t),status=as.integer(event))
 for(j in seq_along(g)) d[[paste0('Z_',g[j])]]<-zs[j,]
 d$MPO_component<-as.numeric(zs['MPO',]*beta['MPO'])
 d$nonMPO_component<-as.numeric(crossprod(beta[g[g!='MPO']],zs[g[g!='MPO'],,drop=FALSE]))
 d$LCDI<-d$MPO_component+d$nonMPO_component
 d$MPO_risk<-z1(d$MPO_component);d$nonMPO_SD<-z1(d$nonMPO_component);d$LCDI_SD<-z1(d$LCDI)
 d$legacy_raw_LCDI<-as.numeric(crossprod(beta,e));d$legacy_raw_nonMPO<-as.numeric(crossprod(beta[g[g!='MPO']],e[g[g!='MPO'],,drop=FALSE]))
 stopifnot(max(abs(d$LCDI-as.numeric(crossprod(beta,zs))))<1e-12)
 all[[name]]<-d;raw[[name]]<-s
 fit<-coxph(Surv(time,status)~LCDI_SD,d,x=TRUE);ci<-exp(confint(fit));cidx<-concordance(Surv(time,status)~LCDI, d,reverse=TRUE)$concordance
 metrics[[i]]<-data.frame(dataset=name,n=nrow(d),events=sum(event),hr=exp(coef(fit)),lower=ci[1],upper=ci[2],se=sqrt(vcov(fit)[1]),p=summary(fit)$coef[1,5],cindex=cidx,ph_p=cox.zph(fit)$table[1,3],followup_reverse_KM=unname(summary(survfit(Surv(time,1-status)~1,d))$table['median']))
 audit[[i]]<-data.frame(dataset=name,true_role=roles[i],n=nrow(d),events=sum(event),analysis_unit=units[i],unique_patient_status=if(i<=2)'NOT_RECOVERED_CROSS_GSE_MAPPING_INFERRED' else if(i==3)'NOT_RECOVERED_PENDING_METADATA' else 'UNIQUE_ID_VERIFIED',platform=c('GPL96','GPL570','GPL570','RNAseq','RNAseq','RNAseq','GPL10558','RNAseq')[i],score_normalization_branch=branch,included_primary_meta=i>=5,included_sensitivity_meta=i%in%c(2,3,5:8),exclusion_reason=if(i==1)'DEVELOPMENT' else if(i==2)'RECORD_LEVEL_JOINT_PREPROCESSING' else if(i==3)'HISTORICAL_MAPPING_PENDING' else if(i==4)'DEVELOPMENT' else 'NA',input_path=file.path(root,input))
 missing[[i]]<-data.frame(dataset=name,variable=names(s),n=nrow(s),missing=vapply(s,function(x)sum(is.na(x)|as.character(x)==''),integer(1)))
 for(v in names(s)) {xx<-s[[v]];vars[[length(vars)+1]]<-data.frame(dataset=name,variable=v,class=class(xx)[1],coding=if(length(unique(na.omit(xx)))<=20) paste(unique(na.omit(xx)),collapse=';') else 'CONTINUOUS_OR_IDENTIFIER')}
 for(j in seq_along(g))dist[[length(dist)+1]]<-data.frame(dataset=name,gene=g[j],detected=TRUE,mean=mean(e[j,]),sd=sd(e[j,]),variance=var(e[j,]),q25=quantile(e[j,],.25),median=median(e[j,]),q75=quantile(e[j,],.75),scale=if(i==5)'saved_gene_z' else 'processed_expression')
 w(d,paste0('10_tables/',name,'_frozen_components.tsv'))
}
mm<-do.call(rbind,metrics);stopifnot(abs(mm$cindex[mm$dataset=='TCGA']-.561022120518688)<1e-12)
w(mm,'01_cohort_heterogeneity/cohort_effects.tsv');w(do.call(rbind,audit),'01_cohort_heterogeneity/cohort_role_audit.tsv')
w(do.call(rbind,missing),'04_reporting_audit/missingness.tsv');w(do.call(rbind,vars),'04_reporting_audit/variable_coding.tsv');w(do.call(rbind,dist),'01_cohort_heterogeneity/five_gene_distributions.tsv')
saveRDS(list(data=all,metadata=raw,formula=f),file.path(out,'10_tables/prepared_cohorts.rds'))
writeLines(capture.output(sessionInfo()),file.path(out,'11_logs/prepare_session.txt'))
cat('ANALYSIS_LOGIC_PASS\nRESULT_AUDIT_PASS\nSUCCESS\n')

options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages({library(survival);library(timeROC)})
out<-file.path(getwd(),'review_addendum_4plus1_20260911');dest<-file.path(out,'02_mpo_nonmpo_increment')
obj<-readRDS(file.path(out,'10_tables/prepared_cohorts.rds'));B<-1000L;base_seed<-2026091120L
w<-function(x,p)write.table(x,file.path(dest,p),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
metric<-function(d,lp) {
 cc<-concordance(Surv(time,status)~lp,d,reverse=TRUE)$concordance
 aa<-timeROC(T=d$time,delta=d$status,marker=lp,cause=1,weighting='marginal',times=c(1,3,5)*365.25,iid=FALSE)$AUC
 c(C=cc,AUC1=aa[1],AUC3=aa[2],AUC5=aa[3])
}
fits<-function(d)list(coxph(Surv(time,status)~MPO_risk,d,x=TRUE,singular.ok=FALSE),coxph(Surv(time,status)~MPO_risk+nonMPO_SD,d,x=TRUE,singular.ok=FALSE))
perf<-function(ff,d)lapply(ff,function(f)metric(d,as.numeric(predict(f,newdata=d,type='lp'))))
cond<-list();point<-list();boot_summary<-list();ph<-list();allrep<-list();indices<-list();fail<-list();support<-list()
for(i in seq_along(obj$data)) {
 name<-names(obj$data)[i];d<-obj$data[[i]];ff<-fits(d);pp<-perf(ff,d);st<-summary(ff[[2]]);ci<-exp(confint(ff[[2]]))
 lrt<-2*(as.numeric(logLik(ff[[2]]))-as.numeric(logLik(ff[[1]])))
 cond[[i]]<-data.frame(dataset=name,n=nrow(d),events=sum(d$status),hr=exp(coef(ff[[2]])[2]),lower=ci[2,1],upper=ci[2,2],p=st$coef[2,5],lrt=lrt,df=1,lrt_p=pchisq(lrt,1,lower.tail=FALSE),analysis_family=if(name%in%c('TARGET','BeatAML2','GSE71014','GSE106291'))'primary_external_4' else if(name=='GSE10358')'historical_sensitivity' else 'development_record_sensitivity')
 for(m in 1:2) {zz<-cox.zph(ff[[m]])$table;ph[[length(ph)+1]]<-data.frame(dataset=name,model=paste0('M',m-1),term=rownames(zz),chisq=zz[,1],df=zz[,2],p=zz[,3])}
 for(y in c(1,3,5)) support[[length(support)+1]]<-data.frame(dataset=name,year=y,n_at_risk=sum(d$time>=y*365.25),deaths_by_time=sum(d$status==1&d$time<=y*365.25))
 set.seed(base_seed+i);ind<-replicate(B,sample.int(nrow(d),nrow(d),replace=TRUE));indices[[name]]<-ind
 rr<-matrix(NA_real_,B,16,dimnames=list(NULL,c(paste0('M0_',names(pp[[1]])),paste0('M1_',names(pp[[1]])),paste0('delta_',names(pp[[1]])),paste0('optimism_delta_',names(pp[[1]])))))
 for(b in seq_len(B)) {
  db<-d[ind[,b],,drop=FALSE]
  ans<-tryCatch({fb<-fits(db);pb<-perf(fb,db);po<-perf(fb,d);c(pb[[1]],pb[[2]],pb[[2]]-pb[[1]],(pb[[2]]-pb[[1]])-(po[[2]]-po[[1]]))},error=function(e){fail[[length(fail)+1]]<<-data.frame(dataset=name,iteration=b,message=conditionMessage(e));rep(NA_real_,16)})
  rr[b,]<-ans
 }
 allrep[[i]]<-data.frame(dataset=name,iteration=1:B,rr,check.names=FALSE)
 for(j in 1:4) {
  delta<-pp[[2]][j]-pp[[1]][j];vv<-rr[,8+j];valid<-is.finite(vv)
  adequate<-sum(valid)>=.95*B && is.finite(delta)
  q<-if(adequate)quantile(vv[valid],c(.025,.975)) else c(NA_real_,NA_real_);corr<-if(adequate)delta-mean(rr[,12+j],na.rm=TRUE) else NA_real_
  pboot<-if(adequate)(1+sum(abs(vv[valid]-delta)>=abs(delta)))/(1+sum(valid)) else NA_real_
  point[[length(point)+1]]<-data.frame(dataset=name,metric=names(pp[[1]])[j],M0=pp[[1]][j],M1=pp[[2]][j],delta=delta,lower=q[1],upper=q[2],centered_bootstrap_p=pboot,valid=sum(valid),optimism_corrected_delta=corr,interpretation=if(adequate)'apparent_refitted_paired_bootstrap' else 'NOT_ESTIMABLE_INSUFFICIENT_BOOTSTRAP_SUPPORT',seed=base_seed+i)
  for(m in 1:2){vv<-rr[,(m-1)*4+j];qq<-if(sum(is.finite(vv))>=.95*B)quantile(vv,c(.025,.975),na.rm=TRUE) else c(NA_real_,NA_real_);boot_summary[[length(boot_summary)+1]]<-data.frame(dataset=name,model=paste0('M',m-1),metric=names(pp[[1]])[j],point=pp[[m]][j],lower=qq[1],upper=qq[2],valid=sum(is.finite(vv)))}
 }
 cat(name,'COMPLETE',B,'paired replicates\n')
}
cc<-do.call(rbind,cond);cc$FDR<-NA_real_;cc$LRT_FDR<-NA_real_
for(f in unique(cc$analysis_family)){ix<-cc$analysis_family==f;cc$FDR[ix]<-p.adjust(cc$p[ix],'BH');cc$LRT_FDR[ix]<-p.adjust(cc$lrt_p[ix],'BH')}
dd<-do.call(rbind,point);dd$family<-ifelse(dd$dataset%in%c('TARGET','BeatAML2','GSE71014','GSE106291'),ifelse(dd$metric=='C','external_delta_C_4','external_delta_AUC_12'),'sensitivity_discrimination');dd$FDR<-ave(dd$centered_bootstrap_p,dd$family,FUN=function(x)p.adjust(x,'BH'))
w(cc,'conditional_survival.tsv');w(dd,'paired_increment.tsv');w(do.call(rbind,boot_summary),'model_performance_intervals.tsv');w(do.call(rbind,ph),'PH_diagnostics.tsv');w(do.call(rbind,support),'timepoint_support.tsv');w(do.call(rbind,allrep),'paired_bootstrap_replicates.tsv')
saveRDS(indices,file.path(dest,'paired_resample_indices.rds'))
if(length(fail))w(do.call(rbind,fail),'failed_iterations.tsv') else writeLines('NONE',file.path(dest,'failed_iterations.txt'))
# Historical raw-expression branch is a prespecified sensitivity, never the C=0.561 baseline.
legacy<-lapply(c('GPL96','GPL570','GSE10358','TCGA'),function(n){d<-obj$data[[n]];d$nonMPO_SD<-as.numeric(scale(d$legacy_raw_nonMPO));f<-fits(d);ci<-exp(confint(f[[2]]));data.frame(dataset=n,branch='legacy_raw_expression',hr=exp(coef(f[[2]])[2]),lower=ci[2,1],upper=ci[2,2],p=summary(f[[2]])$coef[2,5],lrt_p=pchisq(2*diff(c(logLik(f[[1]]),logLik(f[[2]]))),1,lower.tail=FALSE))})
w(do.call(rbind,legacy),'legacy_branch_conditional_sensitivity.tsv')
writeLines(capture.output(sessionInfo()),file.path(dest,'session.txt'))
stopifnot(all(cc$df==1),nrow(dd)==32)
cat('ANALYSIS_LOGIC_PASS\nRESULT_AUDIT_PASS\nSUCCESS\n')

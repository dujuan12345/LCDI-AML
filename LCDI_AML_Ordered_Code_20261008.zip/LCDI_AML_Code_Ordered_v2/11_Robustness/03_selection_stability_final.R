options(stringsAsFactors=FALSE,warn=1)
suppressPackageStartupMessages({library(survival);library(glmnet);library(limma)})
root<-getwd();out<-file.path(root,'review_addendum_4plus1_20260911'); dest<-file.path(out,'03_selection_stability')
args<-commandArgs(TRUE);mode<-if(length(args))args[1] else 'preflight';B<-if(mode=='formal')1000L else 200L
w<-function(x,p)write.table(x,file.path(dest,p),sep='\t',row.names=FALSE,quote=FALSE,na='NA')
base<-'AML_Lactylation_PCD/data/'
tc<-readRDS(paste0(base,'TCGA/TCGAbiolinks/processed/TCGA_LAML_PanCancer.rds'))
normal<-readRDS(paste0(base,'normal_control/normal_control_GSE42519_CD34only.rds'))
gs<-readRDS(paste0(base,'gene_sets/raw/lactylation_pcd_combined_raw.rds'))
old<-readRDS(paste0(base,'processed/survival/lasso_cv_fit.rds'))
frozen17<-rownames(old$glmnet.fit$beta);frozen5<-c('CREB1','SLC16A4','GPX4','CASP1','MPO')
lact<-toupper(gs$GeneSymbol[gs$GeneCategory==gs$GeneCategory[match('EP300',gs$GeneSymbol)]])
pcd<-toupper(gs$GeneSymbol[gs$GeneCategory==gs$GeneCategory[match('MPO',gs$GeneSymbol)]])
rownames(tc$expr_matrix)<-toupper(rownames(tc$expr_matrix));rownames(normal$expr_matrix)<-toupper(rownames(normal$expr_matrix))
common<-Reduce(intersect,list(rownames(tc$expr_matrix),rownames(normal$expr_matrix),toupper(gs$GeneSymbol)))
tx<-tc$expr_matrix[common,,drop=FALSE];nx<-normal$expr_matrix[common,,drop=FALSE]
if(max(tx,na.rm=TRUE)>50)tx<-log2(tx+1)
if(max(nx,na.rm=TRUE)>50)nx<-log2(nx+1)
group<-factor(c(rep('AML',ncol(tx)),rep('Normal',ncol(nx))),levels=c('Normal','AML'))
deg<-topTable(eBayes(lmFit(cbind(tx,nx),model.matrix(~group))),coef=2,number=Inf,adjust.method='fdr')
early<-rownames(deg)[which(abs(deg$logFC)>1 & deg$adj.P.Val<.05)]
sid<-substr(colnames(tx),1,12);ix<-match(sid,tc$survival_data$patient_id)
valid<-!is.na(ix);ss<-tc$survival_data[ix[valid],];xx<-t(tx[,valid,drop=FALSE])
keep<-!is.na(ss$time_days)&ss$time_days>0;ss<-ss[keep,];xx<-xx[keep,,drop=FALSE]
stopifnot(nrow(xx)==149,sum(ss$status)==92,!anyDuplicated(ss$patient_id),length(common)==106,length(early)==89,all(is.finite(xx[,early])))
select_early<-function(ii) {
 pp<-vapply(early,function(g) {v<-xx[ii,g];if(max(v)>50)v<-log2(v+1);fit<-coxph(Surv(ss$time_days[ii]/30.44,ss$status[ii])~v);summary(fit)$coef[1,5]},numeric(1))
 s2<-early[order(pp)][pp[order(pp)]<.05 & !is.na(pp[order(pp)])]
 li<-intersect(intersect(s2,lact),rownames(nx));pi<-intersect(intersect(s2,pcd),rownames(nx));s3<-s2
 if(length(li)>0 && length(pi)>0) {
  cr<-cor(t(nx[li,,drop=FALSE]),t(nx[pi,,drop=FALSE]),method='pearson',use='pairwise.complete.obs')
  tt<-cr*sqrt(ncol(nx)-2)/sqrt(pmax(1-cr^2,1e-10));pv<-2*pt(-abs(tt),df=ncol(nx)-2)
  ij<-which(!is.na(cr)&abs(cr)>.6&pv<.05,arr.ind=TRUE)
  correlated<-if(nrow(ij))unique(colnames(cr)[ij[order(-abs(cr[ij])),2]]) else character()
  s3<-unique(c(intersect(s2,lact),intersect(correlated,s2)))
 }
 list(s2=s2,s3=s3)
}
scale_x<-function(x){sdx<-apply(x,2,sd,na.rm=TRUE);sdx[sdx==0]<-1;x<-scale(x,center=colMeans(x,na.rm=TRUE),scale=sdx);x[is.na(x)]<-0;x}
initial<-select_early(seq_len(nrow(xx)))
stopifnot(length(initial$s2)==26,identical(initial$s3,frozen17))
set.seed(123);full<-cv.glmnet(scale_x(xx[,frozen17]),Surv(ss$time_days/30.44,ss$status),family='cox',alpha=1,nfolds=10)
stopifnot(max(abs(full$lambda-old$lambda))<1e-10,abs(full$lambda.min-old$lambda.min)<1e-10,max(abs(as.matrix(coef(full,s='lambda.min'))-as.matrix(coef(old,s='lambda.min'))))<1e-8)
cat('ANALYSIS_LOGIC_PASS: full original pipeline and saved CV reproduced\n')
if(mode=='preflight') {
 w(data.frame(patient_id=ss$patient_id,time_days=ss$time_days,status=ss$status),'TCGA_selection_patient_manifest.tsv')
 w(data.frame(gene=common,in_89=common%in%early,in_26=common%in%initial$s2,in_17=common%in%frozen17),'development_candidate_stages.tsv')
 rr<-do.call(rbind,lapply(c('lambda.min','lambda.1se'),function(l){cc<-as.matrix(coef(full,s=l))[,1];data.frame(rule=l,lambda=full[[l]],gene=names(cc),coefficient=cc,selected=cc!=0,n_selected=sum(cc!=0))}))
 w(rr,'full_data_lambda_comparison.tsv')
 saveRDS(list(x=xx,survival=ss,normal=nx,full=full),file.path(dest,'reconstructed_inputs.rds'))
}
set.seed(if(mode=='formal')2026091103L else 2026091102L)
indices<-replicate(B,sample.int(nrow(xx),nrow(xx),replace=TRUE));seeds<-sample.int(1e8,B)
saveRDS(list(indices=indices,seeds=seeds),file.path(dest,paste0(mode,'_resampling.rds')))
rows<-list();counts<-list()
for(b in seq_len(B)) {
 ii<-indices[,b];sel<-select_early(ii)
 for(level in c('A','B')) {
  cand<-if(level=='A')frozen17 else sel$s3
  co<-matrix(0,nrow=length(early),ncol=2,dimnames=list(early,c('lambda.min','lambda.1se')));lam<-c(NA_real_,NA_real_)
  if(length(cand)>=3) {
   # All bootstrap copies of the same patient share a CV fold.
   set.seed(seeds[b]);u<-unique(ii);uf<-sample(rep(1:10,length.out=length(u)));fold<-uf[match(ii,u)]
   cv<-cv.glmnet(scale_x(xx[ii,cand,drop=FALSE]),Surv(ss$time_days[ii]/30.44,ss$status[ii]),family='cox',alpha=1,nfolds=10,foldid=fold)
   for(j in 1:2)co[cand,j]<-as.matrix(coef(cv,s=colnames(co)[j]))[,1]
   lam<-c(cv$lambda.min,cv$lambda.1se)
  }
  for(j in 1:2) rows[[length(rows)+1]]<-data.frame(level=level,iteration=b,rule=colnames(co)[j],gene=early,coefficient=co[,j],eligible=early%in%cand)
  counts[[length(counts)+1]]<-data.frame(level=level,iteration=b,n_cox=length(sel$s2),n_candidates=length(cand),n_min=sum(co[,1]!=0),n_1se=sum(co[,2]!=0),lambda_min=lam[1],lambda_1se=lam[2],status=if(length(cand)>=3)'FIT' else 'INSUFFICIENT_CANDIDATES_NO_LASSO')
 }
 if(b%%50==0)cat(mode,b,'/',B,'\n')
}
rr<-do.call(rbind,rows);ct<-do.call(rbind,counts)
w(rr,paste0(mode,'_all_coefficients.tsv'));w(ct,paste0(mode,'_iteration_qc.tsv'))
summ<-do.call(rbind,lapply(split(rr,list(rr$level,rr$rule,rr$gene),drop=TRUE),function(d)data.frame(level=d$level[1],rule=d$rule[1],gene=d$gene[1],B=nrow(d),selection_frequency=mean(d$coefficient!=0),median_coefficient=median(d$coefficient),q25=quantile(d$coefficient,.25),q75=quantile(d$coefficient,.75),positive_frequency=mean(d$coefficient>0),negative_frequency=mean(d$coefficient<0),zero_frequency=mean(d$coefficient==0),eligibility_frequency=mean(d$eligible))))
w(summ,paste0(mode,'_stability_summary.tsv'))
stopifnot(nrow(ct)==2*B,all(table(rr$level,rr$rule)==B*length(early)),all(is.finite(rr$coefficient)))
writeLines(capture.output(sessionInfo()),file.path(dest,paste0(mode,'_session.txt')))
cat('RESULT_AUDIT_PASS\nSUCCESS\n')

from pathlib import Path
import hashlib,json,sys
import pandas as pd
import matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import Circle,Patch
from matplotlib.font_manager import FontProperties,fontManager
from matplotlib.text import Text
import pdfplumber
D=Path(__file__).parent
N=D.parent/'four_target_virtual_perturbation_integration_20260901_v1/server_return/four_target_virtual_perturbation_integration_20260901_v1'
src=N/'01_all_eight_network_gene_results.tsv'; cache=N/'01_significant_gene_set_overlaps.tsv'
x=pd.read_csv(src,sep='\t'); prior=pd.read_csv(cache,sep='\t')
targets=['MPO','CASP1','GPX4','CREB1']; rows=[]; detail=[]
assert not x.duplicated(['dataset','target','gene']).any()
assert x[['p.value','p.adj']].notna().all().all()
for g in targets:
 a=x[(x.dataset=='adult')&(x.target==g)].set_index('gene');p=x[(x.dataset=='pediatric')&(x.target==g)].set_index('gene')
 common=sorted((set(a.index)&set(p.index))-set(targets))
 aa=a.loc[common];pp=p.loc[common]
 sa=set(aa.index[aa['p.value']<.05]);sp=set(pp.index[pp['p.value']<.05]); inter=sa&sp
 fa=set(aa.index[aa['p.adj']<.05]);fp=set(pp.index[pp['p.adj']<.05])
 old=prior[(prior.comparison_scope=='cross_dataset')&(prior.target==g)&(prior.significance_level=='exploratory_P05')].iloc[0]
 assert (len(common),len(sa),len(sp),len(inter))==tuple(int(old[k]) for k in ['universe','set1','set2','intersection'])
 rows.append(dict(target=g,common_universe=len(common),adult=len(sa),pediatric=len(sp),adult_only=len(sa-sp),overlap=len(inter),pediatric_only=len(sp-sa),FDR_overlap=len(fa&fp),overlap_enrichment_p=old.hypergeom_p,overlap_enrichment_FDR=old.hypergeom_FDR))
 for gene in sorted(sa|sp):
  detail.append(dict(target=g,gene=gene,region='Shared' if gene in inter else ('Adult only' if gene in sa else 'Pediatric only'),adult_P=aa.loc[gene,'p.value'],pediatric_P=pp.loc[gene,'p.value'],adult_FDR=aa.loc[gene,'p.adj'],pediatric_FDR=pp.loc[gene,'p.adj']))
s=pd.DataFrame(rows);s.to_csv(D/'02_overlap_counts.tsv',sep='\t',index=False,encoding='utf-8-sig');pd.DataFrame(detail).to_csv(D/'02_gene_membership.tsv',sep='\t',index=False,encoding='utf-8-sig')
font=Path('C:/Windows/Fonts/msyh.ttc');fontManager.addfont(str(font));fp=FontProperties(fname=str(font),size=12)
mpl.rcParams.update({'font.family':fp.get_name(),'font.size':12,'pdf.fonttype':42,'axes.unicode_minus':False})
fig,axes=plt.subplots(2,2,figsize=(8,5.8));fig.subplots_adjust(left=.05,right=.95,top=.87,bottom=.11,wspace=.14,hspace=.28)
colors=['#5F91B5','#DC976D']
for ax,r in zip(axes.flat,rows):
 ax.set_aspect('equal');ax.set_xlim(-1.8,1.8);ax.set_ylim(-1.33,1.08);ax.axis('off')
 for cx,col in [(-.48,colors[0]),(.48,colors[1])]: ax.add_patch(Circle((cx,0),.94,facecolor=col,edgecolor=col,alpha=.40,lw=1.4))
 for cx,v in [(-1.0,r['adult_only']),(0,r['overlap']),(1.0,r['pediatric_only'])]: ax.text(cx,0,str(v),ha='center',va='center',fontproperties=fp)
 ax.text(0,-1.19,r['target'],ha='center',va='center',fontproperties=fp)
fig.legend(handles=[Patch(facecolor=colors[0],alpha=.60,label='Adult'),Patch(facecolor=colors[1],alpha=.60,label='Pediatric')],loc='upper center',bbox_to_anchor=(.5,.985),ncol=2,frameon=False,prop=fp)
fig.text(.5,.05,'P < 0.05 | Common tested genes | Areas not to scale',ha='center',fontproperties=fp)
for t in fig.findobj(Text):t.set_fontproperties(fp)
assert all(not a.get_title() for a in axes.flat)
out=D/'Figure5E_gene_overlap_P005_v1.pdf';fig.savefig(out);plt.close(fig)
with pdfplumber.open(out) as pdf:
 page=pdf.pages[0]; chars=page.chars
 assert len(pdf.pages)==1
 assert all(abs(v['size']-12)<.01 for v in chars)
 assert all(v['x0']>=0 and v['x1']<=page.width and v['top']>=0 and v['bottom']<=page.height for v in chars)
 assert all('MicrosoftYaHei' in v['fontname'] for v in chars),set(v['fontname'] for v in chars)
q={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'cache':str(cache),'cache_sha256':hashlib.sha256(cache.read_bytes()).hexdigest(),'output_sha256':hashlib.sha256(out.read_bytes()).hexdigest(),'counts':rows,'font':'Microsoft YaHei','font_points':12,'all_pdf_fonts':sorted(set(v['fontname'] for v in chars)),'no_panel_titles':True,'PDF_bounds_pass':True,'python':sys.version,'pandas':pd.__version__,'matplotlib':mpl.__version__,'visual_QA':'pending'}
(D/'03_QC.json').write_text(json.dumps(q,ensure_ascii=False,indent=2),encoding='utf-8')
(D/'04_caption.md').write_text('图5E 成人与儿童四目标虚拟扰动响应基因的交集。每对圆分别为成人（蓝色）与儿童（橙色），数字表示成人独有、共同及儿童独有的响应基因数。仅纳入同一目标在两个网络中均检测到的基因，并统一排除MPO、CASP1、GPX4、CREB1四个扰动目标；MPO/CASP1比较范围各1,687个，GPX4/CREB1各1,688个。按各原始网络P<0.05定义名义响应集合，未重算网络P值或FDR；圆面积不代表集合大小。MPO、CASP1、GPX4、CREB1的交集分别为0、1、2、24，按原网络BH-FDR<0.05定义的交集仍为0、0、0、2，完整P/FDR见02_gene_membership.tsv。图中基因数不是患者数，网络为成人1,699细胞/7患者和儿童3,070细胞/13患者的池化虚拟扰动。仅作探索性集合比较，不代表真实敲除后的表达变化。\n',encoding='utf-8')
print(s.to_string(index=False));print('PDF typography and raw/cache counts verified')

from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import Normalize
ROOT=Path(r'D:\26_01_AML');OUT=Path(__file__).parent
OLD=ROOT/'_codex_audit/figure5_composite_20260904_v5';REV=ROOT/'_codex_audit/candidate_reassessment_20260905_v2';NET=ROOT/'_codex_audit/four_target_virtual_perturbation_integration_20260901_v1'
paths=[OLD/'06_panelB_rank_correlations.tsv',OLD/'06_panelC_shared_backbone_GSEA.tsv',OLD/'06_panelD_candidate_branches.tsv',REV/'03_branch_all_four_target_evidence.tsv',NET/'05_target_summary.tsv']
a,b,oldc,c,t=[pd.read_csv(p,sep='\t') for p in paths]
targets=['MPO','CASP1','GPX4','CREB1'];cols=[(d,g) for d in ['adult','pediatric'] for g in targets]
assert len(a)==16 and len(b)==96 and len(c)==104
assert not b.duplicated(['source','ID','dataset','target']).any()
assert not c.duplicated(['source','ID','dataset','target']).any()
assert set(oldc.ID)==set(c.ID) and not set(b.ID)&set(c.ID)
for _,r in oldc.iterrows():
 v=c[(c.ID==r.ID)&(c.dataset==r.dataset)&(c.target==r.target)].iloc[0]
 assert abs(r.NES-v.NES)<1e-12 and abs(r.FDR-v['p.adjust'])<1e-12
assert np.isfinite(b[['NES','FDR']].to_numpy()).all() and np.isfinite(c[['NES','p.adjust']].to_numpy()).all()
assert b.FDR.lt(.05).all();assert t.strict_FDR_gene_overlap.tolist()==[0,0,0,2]
labels={
'GO:0002181':('CytoTrans','cytoplasmic translation'), 'GO:0006412':('Transl','translation'),
'GO:0009057':('MacroCat','macromolecule catabolic process'),'GO:0010628':('PosGEreg','positive regulation of gene expression'),'GO:0010629':('NegGEreg','negative regulation of gene expression'),
'GO:0034655':('NucCat','nucleobase-containing compound catabolic process'),'GO:0042127':('ProlifReg','regulation of cell population proliferation'),'GO:0043207':('BiotResp','response to external biotic stimulus'),
'GO:0043933':('ProtOrg','protein-containing complex organization'),'GO:0046907':('Transport','intracellular transport'),'GO:0051707':('OrgResp','response to other organism'),'KEGG_RIBOSOME':('Ribosome','ribosome'),
'GO:0032496':('LPS-resp','response to lipopolysaccharide'),'GO:0032637':('IL8-prod','interleukin-8 production'),'KEGG_TOLL_LIKE_RECEPTOR_SIGNALING_PATHWAY':('TLR-sig','Toll-like receptor signaling pathway'),
'GO:0006979':('OxStress','response to oxidative stress'),'GO:0030595':('LeukChem','leukocyte chemotaxis'),'GO:0097529':('MyeloMig','myeloid leukocyte migration'),'GO:2001233':('ApopReg','regulation of apoptotic signaling pathway'),
'GO:0001666':('Hypoxia','response to hypoxia'),'GO:0006091':('EnergyGen','generation of precursor metabolites and energy'),'GO:2000379':('ROS-reg','positive regulation of reactive oxygen species metabolic process'),
'GO:0032640':('TNF-prod','tumor necrosis factor production'),'GO:0008630':('DNA-Apop','intrinsic apoptotic signaling pathway in response to DNA damage'),'KEGG_NOD_LIKE_RECEPTOR_SIGNALING_PATHWAY':('NLR-sig','NOD-like receptor signaling pathway')}
assert max(len(v[0]) for v in labels.values())<=10
bids=b.ID.drop_duplicates().tolist();cids=oldc.sort_values('order').ID.drop_duplicates().tolist()
assert len(bids)==12 and len(cids)==13 and set(labels)==set(bids+cids)
for frame,name in [(a,'02_panel_A.tsv'),(b,'02_panel_B.tsv'),(c,'02_panel_C.tsv'),(t,'02_gene_counts.tsv')]:frame.to_csv(OUT/name,sep='\t',index=False,encoding='utf-8-sig')
pd.DataFrame([{'ID':k,'abbreviation':v[0],'full_name':v[1]} for k,v in labels.items()]).to_csv(OUT/'03_abbreviations.tsv',sep='\t',index=False,encoding='utf-8-sig')
mpl.rcParams.update({'font.family':'Arial','font.size':8.5,'pdf.fonttype':42,'axes.unicode_minus':False})
fig=plt.figure(figsize=(7.2,8.0),facecolor='white')
axA=fig.add_axes([.105,.625,.29,.265]);axB=fig.add_axes([.575,.59,.345,.33]);axC=fig.add_axes([.265,.145,.655,.325])
mat=a.pivot(index='row_target',columns='column_target',values='rho').loc[targets,targets].to_numpy()
axA.imshow(mat,cmap='Blues',vmin=0,vmax=1,aspect='auto')
axA.set_xticks(range(4),targets,rotation=40,ha='right',fontsize=8.5);axA.set_yticks(range(4),targets,fontsize=8.5)
axA.tick_params(length=0)
for i in range(4):
 for j in range(4):axA.text(j,i,f'{mat[i,j]:.2f}',ha='center',va='center',fontsize=9,color='white' if mat[i,j]>.65 else '#142C40')
for s in axA.spines.values():s.set_visible(False)
axA.set_xticks(np.arange(-.5,4,1),minor=True);axA.set_yticks(np.arange(-.5,4,1),minor=True);axA.grid(which='minor',color='white',linewidth=1.5);axA.tick_params(which='minor',length=0)
fig.text(.025,.959,'A',fontsize=15,fontweight='bold');fig.text(.45,.959,'B',fontsize=15,fontweight='bold');fig.text(.025,.495,'C',fontsize=15,fontweight='bold')
fig.text(.105,.939,'Upper: Adult   Lower: Pediatric',fontsize=8.0,color='#36454F')
fig.text(.105,.920,'Diagonal: cross-dataset',fontsize=8.0,color='#36454F')
# The compact evidence strip is part of A, not a fourth panel.
tax=fig.add_axes([.105,.525,.29,.052]);tax.axis('off');tt=t.set_index('target').loc[targets]
tab=tax.table(cellText=[tt.adult_FDR05_genes.tolist(),tt.pediatric_FDR05_genes.tolist(),tt.strict_FDR_gene_overlap.tolist()],rowLabels=['Adult FDR','Pedi FDR','Overlap'],cellLoc='center',loc='center',bbox=[0,0,1,1]);tab.auto_set_font_size(False);tab.set_fontsize(8.0)
for (i,j),cell in tab.get_celld().items():cell.set_edgecolor('#DCE2E8');cell.set_linewidth(.4);cell.set_facecolor('#F4F7FA' if i==2 else 'white')
norm=Normalize(-4,4);cmap=mpl.colormaps['RdBu_r']
def bubble(ax,frame,ids,fdrcol):
 for j,(d,g) in enumerate(cols):
  for i,k in enumerate(ids):
   hit=frame[(frame.ID==k)&(frame.dataset==d)&(frame.target==g)];assert len(hit)==1
   r=hit.iloc[0];f=float(r[fdrcol]);nes=float(r.NES);size=17+12*min(-np.log10(max(f,1e-30)),6)
   ax.scatter(j,i,s=size,facecolors=[cmap(norm(nes))] if f<.05 else 'none',edgecolors=[cmap(norm(nes))],linewidths=.8,zorder=3)
 ax.set_xticks(range(8),targets*2,rotation=45,ha='left',rotation_mode='anchor',fontsize=8.5)
 ax.tick_params(axis='x',top=True,labeltop=True,bottom=False,labelbottom=False,pad=2,length=0)
 ax.set_yticks(range(len(ids)),[labels[k][0] for k in ids],fontsize=8.5);ax.tick_params(axis='y',length=0,pad=5)
 ax.set_xlim(-.6,7.6);ax.set_ylim(len(ids)-.5,-.5);ax.axvline(3.5,color='#8294A6',lw=.9)
 for y in range(len(ids)):
  if y%2==0:ax.axhspan(y-.5,y+.5,color='#F1F4F7',zorder=0)
 for s in ax.spines.values():s.set_visible(False)
 ax.text(1.5,1.165,'Adult',transform=ax.get_xaxis_transform(),ha='center',fontsize=9,color='#345987')
 ax.text(5.5,1.165,'Pediatric',transform=ax.get_xaxis_transform(),ha='center',fontsize=9,color='#AC4A32')
bubble(axB,b,bids,'FDR');bubble(axC,c,cids,'p.adjust')
# Candidate rows retain prior order; no target-only section labels are drawn.
cax=fig.add_axes([.945,.21,.016,.55]);cb=fig.colorbar(mpl.cm.ScalarMappable(norm=norm,cmap=cmap),cax=cax,ticks=[-4,-2,0,2,4]);cb.ax.tick_params(labelsize=8);cb.ax.text(.5,1.025,'NES',transform=cb.ax.transAxes,ha='center',fontsize=8.5)
handles=[Line2D([],[],marker='o',ls='',markersize=np.sqrt(17+12*v),markerfacecolor='#657C90',markeredgecolor='#657C90',label=lab) for v,lab in [(1.301,'0.05'),(3,'0.001'),(6,'<=1e-6')]]
fig.legend(handles=handles,title='FDR (size)',loc='lower left',bbox_to_anchor=(.20,.026),ncol=3,frameon=False,fontsize=8.5,title_fontsize=8.5,columnspacing=1.2,handletextpad=.45)
sig=[Line2D([],[],marker='o',ls='',markerfacecolor='#657C90',markeredgecolor='#657C90',label='<0.05'),Line2D([],[],marker='o',ls='',markerfacecolor='none',markeredgecolor='#657C90',label='>=0.05')]
fig.legend(handles=sig,title='FDR (fill)',loc='lower left',bbox_to_anchor=(.66,.026),ncol=2,frameon=False,fontsize=8.5,title_fontsize=8.5,columnspacing=.9,handletextpad=.4)
assert all(not ax.get_title() for ax in fig.axes)
pdf=OUT/'Figure5_three_panel_network_v2.pdf';fig.savefig(pdf);plt.close(fig)
pd.DataFrame([{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size} for p in paths]).to_csv(OUT/'04_source_SHA256.tsv',sep='\t',index=False,encoding='utf-8-sig')
qc={'source_validation_passed':True,'A_correlations':len(a),'B_pathways':len(bids),'B_estimates':len(b),'C_pathways':len(cids),'C_estimates':len(c),'B_C_exact_ID_overlap':0,'C_new_reference_estimates':len(c)-len(oldc),'A_gene_counts':12,'figure_inches':[7.2,8.0],'min_font_points':8,'internal_titles':0,'C_nonsignificant_estimates':int(c['p.adjust'].ge(.05).sum()),'NES_max_abs':float(max(abs(b.NES).max(),abs(c.NES).max())),'python':sys.version,'pandas':pd.__version__,'matplotlib':mpl.__version__,'visual_QA':'pending','PDF_SHA256':hashlib.sha256(pdf.read_bytes()).hexdigest()}
assert qc['NES_max_abs']<=4
(OUT/'05_data_validation.json').write_text(json.dumps(qc,indent=2),encoding='utf-8');print(json.dumps(qc,indent=2))

options(stringsAsFactors = FALSE)

suppressPackageStartupMessages({
  library(ggplot2)
  library(survival)
  library(patchwork)
  library(grid)
})

project_root <- "D:/26_01_AML"
out_dir <- file.path(project_root, "_codex_audit/figure1_individual_panels_20260902_v1")
dir.create(out_dir, recursive = TRUE, showWarnings = FALSE)

source_paths <- c(
  historical_bootstrap = file.path(project_root, "_codex_audit/bootstrap_fixed_formula_20260727/fixed_formula_bootstrap_summary.csv"),
  tcga_metric = file.path(project_root, "_codex_audit/cindex_nomogram_reconciliation_20260902_v1/10_tcga_training_scale_metric.tsv"),
  tcga_bootstrap = file.path(project_root, "_codex_audit/cindex_nomogram_reconciliation_20260902_v1/10_tcga_training_scale_bootstrap_summary.tsv"),
  target_metric = file.path(project_root, "_codex_audit/target_recalculation_20260728/target_recalculation_summary.csv"),
  external_metric = file.path(project_root, "_codex_audit/external_survival_validation_20260804_v1/results/cohort_primary_continuous_results.tsv"),
  external_bootstrap = file.path(project_root, "_codex_audit/external_survival_validation_20260804_v1/results/bootstrap_cindex_summary.tsv"),
  delta_historical = file.path(project_root, "_codex_audit/lcdi_mpo_increment_20260803_v1/final/five_cohort_fixed_score_deltaC_summary.tsv"),
  paired_current = file.path(project_root, "_codex_audit/cindex_nomogram_reconciliation_20260902_v1/01_paired_lcdi_mpo_bootstrap.tsv"),
  patient_scores = file.path(project_root, "_codex_audit/cindex_nomogram_reconciliation_20260902_v1/01_patient_scores.tsv")
)
if (any(!file.exists(source_paths))) {
  stop("Missing required source: ", paste(names(source_paths)[!file.exists(source_paths)], collapse = ", "))
}

read_tsv <- function(path) read.delim(path, check.names = FALSE, fileEncoding = "UTF-8")
assert_close <- function(actual, expected, tol = 5e-10, label = "value") {
  if (length(actual) != 1L || !is.finite(actual) || abs(actual - expected) > tol) {
    stop(sprintf("Assertion failed for %s: actual=%.15g expected=%.15g", label, actual, expected))
  }
}

historical <- read.csv(source_paths[["historical_bootstrap"]], check.names = FALSE)
tcga_metric <- read_tsv(source_paths[["tcga_metric"]])
tcga_boot <- read_tsv(source_paths[["tcga_bootstrap"]])
target <- read.csv(source_paths[["target_metric"]], check.names = FALSE)
external <- read_tsv(source_paths[["external_metric"]])
external_boot <- read_tsv(source_paths[["external_bootstrap"]])
delta_hist <- read_tsv(source_paths[["delta_historical"]])
paired_current <- read_tsv(source_paths[["paired_current"]])
patient_scores <- read_tsv(source_paths[["patient_scores"]])

get_hist <- function(cohort) historical[historical$cohort == cohort, , drop = FALSE]
get_ext <- function(cohort) external[external$cohort == cohort, , drop = FALSE]
get_ext_boot <- function(cohort) external_boot[external_boot$cohort == cohort, , drop = FALSE]
get_delta <- function(cohort) delta_hist[delta_hist$cohort == cohort, , drop = FALSE]

gpl96 <- get_hist("GPL96_Train")
gpl570 <- get_hist("GPL570_Val1")
gse10358 <- get_hist("GSE10358_Val2")
gse71014 <- get_ext("GSE71014")
gse106291 <- get_ext("GSE106291")
beat <- get_ext("BeatAML2")

plot_input <- data.frame(
  cohort = c("GPL96", "GSE10358", "TCGA-LAML", "TARGET-AML", "BeatAML2", "GPL570", "GSE71014", "GSE106291"),
  source_cohort = c("GPL96_Train", "GSE10358_Val2", "TCGA_Val3", "TARGET_Val4", "BeatAML2", "GPL570_Val1", "GSE71014", "GSE106291"),
  role = c("Coefficient fitting", "Historical evaluation", "Developmental evaluation", "Cross-age evaluation", "Independent validation", "Auxiliary evaluation", "Additional external", "Additional external"),
  n = c(gpl96$n, gse10358$n, tcga_metric$n, target$n, beat$N, gpl570$n, gse71014$N, gse106291$N),
  events = c(gpl96$events, gse10358$events, tcga_metric$events, target$events, beat$events, gpl570$events, gse71014$events, gse106291$events),
  hr = c(gpl96$hr_per_sd_original, gse10358$hr_per_sd_original, tcga_metric$hr_per_sd, target$hr_per_sd_original, beat$HR_per_SD, gpl570$hr_per_sd_original, gse71014$HR_per_SD, gse106291$HR_per_SD),
  hr_low = c(gpl96$hr_per_sd_ci_lower, gse10358$hr_per_sd_ci_lower, tcga_metric$hr_ci_low, target$hr_per_sd_bootstrap_lower, beat$HR_low, gpl570$hr_per_sd_ci_lower, gse71014$HR_low, gse106291$HR_low),
  hr_high = c(gpl96$hr_per_sd_ci_upper, gse10358$hr_per_sd_ci_upper, tcga_metric$hr_ci_high, target$hr_per_sd_bootstrap_upper, beat$HR_high, gpl570$hr_per_sd_ci_upper, gse71014$HR_high, gse106291$HR_high),
  cindex = c(gpl96$cindex_original, gse10358$cindex_original, tcga_metric$cindex, target$cindex_original, beat$C_index, gpl570$cindex_original, gse71014$C_index, gse106291$C_index),
  c_low = c(gpl96$cindex_ci_lower, gse10358$cindex_ci_lower, tcga_boot$lcdi_p025, target$cindex_bootstrap_lower, get_ext_boot("BeatAML2")$q025, gpl570$cindex_ci_lower, get_ext_boot("GSE71014")$q025, get_ext_boot("GSE106291")$q025),
  c_high = c(gpl96$cindex_ci_upper, gse10358$cindex_ci_upper, tcga_boot$lcdi_p975, target$cindex_bootstrap_upper, get_ext_boot("BeatAML2")$q975, gpl570$cindex_ci_upper, get_ext_boot("GSE71014")$q975, get_ext_boot("GSE106291")$q975),
  stringsAsFactors = FALSE
)

# Freeze the exact values used in the accepted v10 manuscript.
expected_display <- data.frame(
  cohort = plot_input$cohort,
  hr = c(1.262, 1.811, 1.290, 1.391, 1.212, 0.962, 0.865, 1.042),
  cindex = c(0.566, 0.664, 0.561, 0.596, 0.548, 0.480, 0.424, 0.504)
)
if (any(round(plot_input$hr, 3) != expected_display$hr)) stop("HR display values do not match v10")
if (any(round(plot_input$cindex, 3) != expected_display$cindex)) stop("C-index display values do not match v10")

delta_input <- data.frame(
  cohort = c("GPL96", "GPL570", "GSE10358", "TCGA-LAML", "TARGET-AML", "BeatAML2"),
  role = c("Coefficient fitting", "Auxiliary evaluation", "Historical evaluation", "Developmental evaluation", "Cross-age evaluation", "Independent validation"),
  delta = c(
    get_delta("GPL96_Train")$intended_bootstrap_mean_delta_C,
    get_delta("GPL570_Val1")$intended_bootstrap_mean_delta_C,
    get_delta("GSE10358_Val2")$intended_bootstrap_mean_delta_C,
    tcga_boot$delta_boot_mean,
    get_delta("TARGET_Val4")$intended_bootstrap_mean_delta_C,
    paired_current[paired_current$cohort == "BeatAML2", "delta_boot_mean"]
  ),
  low = c(
    get_delta("GPL96_Train")$intended_p025,
    get_delta("GPL570_Val1")$intended_p025,
    get_delta("GSE10358_Val2")$intended_p025,
    tcga_boot$delta_p025,
    get_delta("TARGET_Val4")$intended_p025,
    paired_current[paired_current$cohort == "BeatAML2", "delta_p025"]
  ),
  high = c(
    get_delta("GPL96_Train")$intended_p975,
    get_delta("GPL570_Val1")$intended_p975,
    get_delta("GSE10358_Val2")$intended_p975,
    tcga_boot$delta_p975,
    get_delta("TARGET_Val4")$intended_p975,
    paired_current[paired_current$cohort == "BeatAML2", "delta_p975"]
  ),
  stringsAsFactors = FALSE
)
expected_delta <- c(-0.00166, -0.00397, -0.00403, -0.03259, -0.00696, -0.01639)
if (any(round(delta_input$delta, 5) != expected_delta)) stop("Delta C display values do not match v10")

write.table(plot_input, file.path(out_dir, "01_frozen_survival_inputs.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
write.table(delta_input, file.path(out_dir, "01_frozen_delta_inputs.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
write.table(data.frame(source = names(source_paths), path = unname(source_paths), stringsAsFactors = FALSE), file.path(out_dir, "01_source_manifest.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

role_colors <- c(
  "Coefficient fitting" = "#4D4D4D",
  "Historical evaluation" = "#0072B2",
  "Developmental evaluation" = "#009E73",
  "Cross-age evaluation" = "#56B4E9",
  "Independent validation" = "#D55E00",
  "Auxiliary evaluation" = "#999999",
  "Additional external" = "#B3B3B3"
)
role_shapes <- c(
  "Coefficient fitting" = 16,
  "Historical evaluation" = 17,
  "Developmental evaluation" = 15,
  "Cross-age evaluation" = 18,
  "Independent validation" = 23,
  "Auxiliary evaluation" = 1,
  "Additional external" = 0
)

base_theme <- theme_classic(base_family = "Arial", base_size = 10) +
  theme(
    plot.title = element_blank(),
    axis.title = element_text(face = "plain", colour = "#222222"),
    axis.text = element_text(colour = "#222222"),
    axis.line = element_line(linewidth = 0.45, colour = "#333333"),
    axis.ticks = element_line(linewidth = 0.4, colour = "#333333"),
    legend.title = element_blank(),
    legend.text = element_text(size = 8.5),
    legend.key.height = unit(4, "mm"),
    plot.margin = margin(7, 8, 7, 8)
  )

save_both <- function(plot, stem, width, height) {
  ggsave(file.path(out_dir, paste0(stem, ".png")), plot = plot, width = width, height = height, units = "in", dpi = 400, bg = "white")
  ggsave(file.path(out_dir, paste0(stem, ".pdf")), plot = plot, width = width, height = height, units = "in", device = cairo_pdf, bg = "white")
}

# Panel A: compact selection and cohort-role diagram.
selection <- data.frame(
  x = 1:6,
  y = 2.15,
  label = c("Candidate space\n113 genes", "Measurable\n106 genes", "Expression screen\n89 genes", "TCGA Cox\n26 genes", "Co-expression\n17 genes", "TCGA LASSO\n5 genes")
)
roles <- data.frame(
  x = c(1.1, 2.25, 3.65, 4.85, 6.05),
  y = 0.65,
  label = c("TCGA\nFeature selection", "GPL96\nCoefficient fitting", "GSE10358 / TARGET\nHistorical evaluation", "BeatAML2\nIndependent validation", "GSE71014 / GSE106291\nAdditional testing")
)
p_a <- ggplot() +
  annotate("text", x = 0.18, y = 2.15, label = "Selection", hjust = 0, family = "Arial", size = 3.2, colour = "#444444") +
  annotate("text", x = 0.18, y = 0.65, label = "Cohort role", hjust = 0, family = "Arial", size = 3.2, colour = "#444444") +
  geom_segment(data = data.frame(x = 1:5), aes(x = x + 0.39, xend = x + 0.61, y = 2.15, yend = 2.15), arrow = arrow(length = unit(2.2, "mm")), linewidth = 0.45, colour = "#777777") +
  geom_label(data = selection, aes(x = x, y = y, label = label), family = "Arial", size = 3.05, lineheight = 0.92, linewidth = 0.25, label.padding = unit(2.4, "mm"), fill = "#EAF2F8", colour = "#222222") +
  geom_segment(aes(x = 1.1, xend = 6.05, y = 1.18, yend = 1.18), linewidth = 0.45, colour = "#B0B0B0") +
  geom_segment(data = roles, aes(x = x, xend = x, y = 1.18, yend = 0.95), linewidth = 0.4, colour = "#B0B0B0") +
  geom_label(data = roles, aes(x = x, y = y, label = label), family = "Arial", size = 2.85, lineheight = 0.92, linewidth = 0.25, label.padding = unit(2.2, "mm"), fill = "#F7F7F7", colour = "#222222") +
  coord_cartesian(xlim = c(0.1, 6.55), ylim = c(0.15, 2.65), clip = "off") +
  theme_void(base_family = "Arial") +
  theme(plot.title = element_blank(), plot.margin = margin(5, 8, 5, 8))
save_both(p_a, "Fig1A_study_flow_v1", 10.2, 4.0)

# Panel B: frozen coefficients.
coef_df <- data.frame(
  gene = factor(c("MPO", "CASP1", "SLC16A4", "GPX4", "CREB1"), levels = c("MPO", "CASP1", "SLC16A4", "GPX4", "CREB1")),
  beta = c(-0.2095, -0.0106, -0.0636, -0.0721, 0.0925),
  direction = c("Negative coefficient", "Negative coefficient", "Negative coefficient", "Negative coefficient", "Positive coefficient")
)
p_b <- ggplot(coef_df, aes(x = beta, y = gene, fill = direction)) +
  geom_vline(xintercept = 0, colour = "#777777", linewidth = 0.45) +
  geom_col(width = 0.58) +
  geom_text(aes(label = sprintf("%+.4f", beta), hjust = ifelse(beta < 0, 1.08, -0.08)), family = "Arial", size = 3.1, colour = "#222222") +
  scale_fill_manual(values = c("Negative coefficient" = "#0072B2", "Positive coefficient" = "#D55E00")) +
  scale_x_continuous(limits = c(-0.255, 0.125), breaks = c(-0.2, -0.1, 0, 0.1)) +
  labs(x = "Frozen Cox coefficient", y = NULL) +
  base_theme +
  theme(legend.position = "top", axis.line.y = element_blank(), axis.ticks.y = element_blank())
save_both(p_b, "Fig1B_frozen_coefficients_v1", 5.2, 4.4)

# Shared cohort ordering for forest plots.
cohort_order <- rev(plot_input$cohort)
plot_input$cohort_f <- factor(plot_input$cohort, levels = cohort_order)

p_c <- ggplot(plot_input, aes(y = cohort_f, colour = role, shape = role)) +
  geom_vline(xintercept = 1, linetype = "dashed", colour = "#888888", linewidth = 0.45) +
  geom_segment(aes(x = hr_low, xend = hr_high, yend = cohort_f), linewidth = 0.7) +
  geom_point(aes(x = hr), size = 2.8, stroke = 0.9) +
  geom_text(aes(x = 3.18, label = sprintf("%.2f (%.2f–%.2f)", hr, hr_low, hr_high)), hjust = 1, colour = "#222222", family = "Arial", size = 2.75, show.legend = FALSE) +
  scale_x_log10(limits = c(0.52, 3.35), breaks = c(0.6, 1, 1.5, 2, 3), labels = c("0.6", "1.0", "1.5", "2.0", "3.0")) +
  scale_colour_manual(values = role_colors) +
  scale_shape_manual(values = role_shapes) +
  labs(x = "HR per 1-SD LCDI (95% interval)", y = NULL) +
  base_theme +
  theme(legend.position = "bottom", axis.line.y = element_blank(), axis.ticks.y = element_blank())
save_both(p_c, "Fig1C_HR_forest_v1", 7.4, 5.4)

p_d <- ggplot(plot_input, aes(y = cohort_f, colour = role, shape = role)) +
  geom_vline(xintercept = 0.5, linetype = "dashed", colour = "#888888", linewidth = 0.45) +
  geom_segment(aes(x = c_low, xend = c_high, yend = cohort_f), linewidth = 0.7) +
  geom_point(aes(x = cindex), size = 2.8, stroke = 0.9) +
  geom_text(aes(x = 0.79, label = sprintf("%.3f (%.3f–%.3f)", cindex, c_low, c_high)), hjust = 1, colour = "#222222", family = "Arial", size = 2.75, show.legend = FALSE) +
  scale_x_continuous(limits = c(0.29, 0.81), breaks = seq(0.3, 0.8, 0.1)) +
  scale_colour_manual(values = role_colors) +
  scale_shape_manual(values = role_shapes) +
  labs(x = "Harrell C-index (95% bootstrap interval)", y = NULL) +
  base_theme +
  theme(legend.position = "bottom", axis.line.y = element_blank(), axis.ticks.y = element_blank())
save_both(p_d, "Fig1D_Cindex_forest_v1", 7.4, 5.4)

fmt_p <- function(p) {
  if (p < 0.001) format(p, scientific = TRUE, digits = 2) else sprintf("%.3f", p)
}

km_stats <- list()
km_risk <- list()
make_km <- function(cohort_code, stem) {
  dat <- patient_scores[patient_scores$cohort == cohort_code, c("sample_id", "subject_id", "time", "status", "LCDI_per_sd")]
  dat <- dat[complete.cases(dat), ]
  dat$time <- as.numeric(dat$time)
  dat$status <- as.integer(dat$status)
  dat$LCDI_per_sd <- as.numeric(dat$LCDI_per_sd)
  cutoff <- median(dat$LCDI_per_sd)
  dat$group <- factor(ifelse(dat$LCDI_per_sd > cutoff, "High", "Low"), levels = c("Low", "High"))
  fit <- survfit(Surv(time, status) ~ group, data = dat)
  cox <- coxph(Surv(time, status) ~ group, data = dat)
  sm <- summary(cox)$coefficients
  ci <- summary(cox)$conf.int
  lr <- survdiff(Surv(time, status) ~ group, data = dat)
  lr_p <- pchisq(lr$chisq, df = length(lr$n) - 1, lower.tail = FALSE)
  s <- summary(fit)
  curve <- data.frame(time = s$time / 365.25, survival = s$surv, group = sub("group=", "", as.character(s$strata)))
  curve <- rbind(
    data.frame(time = 0, survival = 1, group = "Low"),
    data.frame(time = 0, survival = 1, group = "High"),
    curve
  )
  curve$group <- factor(curve$group, levels = c("High", "Low"))

  times_year <- c(0, 1, 3, 5)
  rs <- summary(fit, times = times_year * 365.25, extend = TRUE)
  risk <- data.frame(time = rep(times_year, times = 2), n_risk = rs$n.risk, group = sub("group=", "", as.character(rs$strata)))
  risk$group <- factor(risk$group, levels = c("High", "Low"))
  km_risk[[cohort_code]] <<- risk
  km_stats[[cohort_code]] <<- data.frame(
    cohort = cohort_code,
    n = nrow(dat),
    events = sum(dat$status),
    cutoff = cutoff,
    low_n = sum(dat$group == "Low"),
    low_events = sum(dat$status[dat$group == "Low"]),
    high_n = sum(dat$group == "High"),
    high_events = sum(dat$status[dat$group == "High"]),
    hr_high_vs_low = unname(exp(coef(cox))),
    hr_low = unname(ci[1, "lower .95"]),
    hr_high = unname(ci[1, "upper .95"]),
    cox_p = unname(sm[1, "Pr(>|z|)"]),
    logrank_p = lr_p,
    stringsAsFactors = FALSE
  )
  ann <- sprintf("HR %.2f (%.2f–%.2f)\nLog-rank P=%s", exp(coef(cox)), ci[1, "lower .95"], ci[1, "upper .95"], fmt_p(lr_p))
  cols <- c("High" = "#D55E00", "Low" = "#0072B2")
  p_curve <- ggplot(curve, aes(x = time, y = survival, colour = group)) +
    geom_step(linewidth = 0.85, direction = "hv") +
    annotate("text", x = 2.9, y = 0.18, label = ann, hjust = 0, family = "Arial", size = 2.85, colour = "#222222") +
    scale_colour_manual(values = cols, breaks = c("High", "Low"), labels = c("LCDI high", "LCDI low")) +
    scale_x_continuous(breaks = times_year, expand = expansion(mult = c(0.01, 0.02))) +
    scale_y_continuous(breaks = seq(0, 1, 0.2), expand = expansion(mult = c(0.01, 0.02))) +
    coord_cartesian(xlim = c(0, 5), ylim = c(0, 1)) +
    labs(x = NULL, y = "Overall survival") +
    base_theme +
    theme(legend.position = "top", legend.justification = "left", legend.margin = margin(0, 0, 2, 0), plot.margin = margin(5, 8, 0, 8))
  p_risk <- ggplot(risk, aes(x = time, y = group, label = n_risk, colour = group)) +
    geom_text(family = "Arial", size = 3.0, show.legend = FALSE) +
    annotate("text", x = 0, y = 2.65, label = "No. at risk", hjust = 0, family = "Arial", size = 2.85, colour = "#222222") +
    scale_colour_manual(values = cols) +
    scale_x_continuous(limits = c(0, 5), breaks = times_year, expand = expansion(mult = c(0.01, 0.02))) +
    scale_y_discrete(limits = c("Low", "High"), labels = c("Low", "High")) +
    labs(x = "Time (years)", y = NULL) +
    theme_classic(base_family = "Arial", base_size = 9) +
    theme(plot.title = element_blank(), axis.line.y = element_blank(), axis.ticks.y = element_blank(), axis.text.y = element_text(colour = "#222222"), plot.margin = margin(0, 8, 5, 8))
  combined <- p_curve / p_risk + plot_layout(heights = c(3.5, 1.25), guides = "collect")
  save_both(combined, stem, 5.6, 5.6)
}

make_km("GPL96_Train", "Fig1E_GPL96_KM_v1")
make_km("BeatAML2", "Fig1F_BeatAML2_KM_v1")
km_stats_df <- do.call(rbind, km_stats)
km_risk_df <- do.call(rbind, lapply(names(km_risk), function(nm) transform(km_risk[[nm]], cohort = nm)))
write.table(km_stats_df, file.path(out_dir, "02_km_statistics.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
write.table(km_risk_df, file.path(out_dir, "02_km_at_risk.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)

delta_input$cohort_f <- factor(delta_input$cohort, levels = rev(delta_input$cohort))
p_g <- ggplot(delta_input, aes(y = cohort_f, colour = role, shape = role)) +
  geom_vline(xintercept = 0, linetype = "dashed", colour = "#888888", linewidth = 0.45) +
  geom_segment(aes(x = low, xend = high, yend = cohort_f), linewidth = 0.75) +
  geom_point(aes(x = delta), size = 2.9, stroke = 0.9) +
  geom_text(aes(x = 0.057, label = sprintf("%+.3f (%+.3f to %+.3f)", delta, low, high)), hjust = 1, colour = "#222222", family = "Arial", size = 2.75, show.legend = FALSE) +
  scale_x_continuous(limits = c(-0.065, 0.061), breaks = seq(-0.06, 0.06, 0.03)) +
  scale_colour_manual(values = role_colors) +
  scale_shape_manual(values = role_shapes) +
  labs(x = expression(Delta*" C-index (LCDI - MPO)"), y = NULL) +
  base_theme +
  theme(legend.position = "bottom", axis.line.y = element_blank(), axis.ticks.y = element_blank())
save_both(p_g, "Fig1G_delta_Cindex_v1", 7.4, 5.1)

status <- data.frame(
  field = c("status", "panels_requested", "panels_generated", "png_generated", "pdf_generated", "titles_inside_panels", "word_modified", "source_files_modified"),
  value = c("passed", "7", "7", "7", "7", "0", "0", "0")
)
write.table(status, file.path(out_dir, "03_run_status.tsv"), sep = "\t", row.names = FALSE, quote = FALSE)
writeLines(capture.output(sessionInfo()), file.path(out_dir, "03_session_info.txt"), useBytes = TRUE)

cat("Generated 7 independent panels as PNG and PDF.\n")
cat("Output directory:", out_dir, "\n")
graphics.off()
invisible(gc())
quit(save = "no", status = 0L, runLast = FALSE)

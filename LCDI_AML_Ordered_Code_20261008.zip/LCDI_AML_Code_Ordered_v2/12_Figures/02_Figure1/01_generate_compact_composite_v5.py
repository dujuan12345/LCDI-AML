from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
BASE = PROJECT / "_codex_audit" / "figure1_individual_panels_20260902_v1"
V1_DIR = PROJECT / "_codex_audit" / "figure1_composite_20260902_v1"
V2_DIR = PROJECT / "_codex_audit" / "figure1_composite_20260902_v2"
V4_DIR = PROJECT / "_codex_audit" / "figure1_composite_20260902_v4"
OUT = PROJECT / "_codex_audit" / "figure1_composite_20260902_v5"

SOURCES = {
    "survival_summary": BASE / "01_frozen_survival_inputs.tsv",
    "delta_summary": BASE / "01_frozen_delta_inputs.tsv",
    "km_statistics": BASE / "02_km_statistics.tsv",
    "patient_scores": PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "01_patient_scores.tsv",
    "bootstrap_distributions": V4_DIR / "01_bootstrap_delta_distributions.tsv",
    "candidate_deg_plot_data": V4_DIR / "01_candidate_deg_plot_data.tsv",
    "candidate_deg_counts": V4_DIR / "01_candidate_deg_counts.tsv",
    "v1_generator": V1_DIR / "01_generate_advanced_figure1.py",
    "v2_generator": V2_DIR / "01_generate_figure1_five_panel_v2.py",
    "v4_composite": V4_DIR / "Figure1_restore_G_A_BCD_EG_v4.png",
}


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    missing = [name for name, path in SOURCES.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing sources: {missing}")

    mpl.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.labelsize": 9.5,
        "xtick.labelsize": 8.5, "ytick.labelsize": 8.5,
        "pdf.fonttype": 42, "ps.fonttype": 42, "axes.unicode_minus": False,
    })
    v1 = load_module("figure1_v1_compact", SOURCES["v1_generator"])
    v2 = load_module("figure1_v2_compact", SOURCES["v2_generator"])

    survival = pd.read_csv(SOURCES["survival_summary"], sep="\t")
    delta = pd.read_csv(SOURCES["delta_summary"], sep="\t")
    km_stats = pd.read_csv(SOURCES["km_statistics"], sep="\t").set_index("cohort")
    scores = pd.read_csv(SOURCES["patient_scores"], sep="\t")
    boot = pd.read_csv(SOURCES["bootstrap_distributions"], sep="\t")
    deg = pd.read_csv(SOURCES["candidate_deg_plot_data"], sep="\t")
    deg["plot_y"] = deg["minus_log10_fdr"].clip(upper=40)
    counts = {key: int(value) for key, value in pd.read_csv(SOURCES["candidate_deg_counts"], sep="\t").iloc[0].to_dict().items()}

    if len(boot) != 6000 or not (boot.groupby("cohort").size() == 1000).all():
        raise AssertionError("Bootstrap distributions differ from v4")
    if counts != {"input": 106, "estimable": 104, "not_estimable": 2,
                  "retained": 89, "up": 86, "down": 3, "not_retained": 15}:
        raise AssertionError("Candidate DEG counts differ from v4")
    if survival.cindex.round(3).tolist() != [0.566, 0.664, 0.561, 0.596, 0.548, 0.480, 0.424, 0.504]:
        raise AssertionError("C-index values differ from frozen manuscript values")
    if delta.delta.round(5).tolist() != [-0.00166, -0.00397, -0.00403, -0.03259, -0.00696, -0.01639]:
        raise AssertionError("Delta C-index values differ from frozen manuscript values")

    fig = plt.figure(figsize=(18.0, 12.4))
    outer = fig.add_gridspec(3, 1, height_ratios=[0.52, 1.0, 1.15], hspace=0.16)
    ax_a = fig.add_subplot(outer[0])
    v1.draw_panel_a(ax_a, "A")

    middle = outer[1].subgridspec(1, 3, width_ratios=[1.20, 0.82, 1.08], wspace=0.29)
    ax_b = fig.add_subplot(middle[0])
    ax_c = fig.add_subplot(middle[1])
    ax_d = fig.add_subplot(middle[2])
    v2.draw_volcano(ax_b, deg, counts, "B")
    v1.draw_panel_b(ax_c, "C")
    v1.draw_panel_d(ax_d, survival, "D")

    lower = outer[2].subgridspec(1, 2, width_ratios=[2.05, 1.12], wspace=0.22)
    egrid = lower[0].subgridspec(2, 2, height_ratios=[3.7, 1.08], hspace=0.035, wspace=0.14)
    e_axes = [fig.add_subplot(egrid[0, 0]), fig.add_subplot(egrid[0, 1])]
    e_risk = [fig.add_subplot(egrid[1, 0]), fig.add_subplot(egrid[1, 1])]
    v1.draw_km_pair(e_axes, e_risk, scores, km_stats, "E")
    ax_g = fig.add_subplot(lower[1])
    v1.draw_panel_g(ax_g, boot, delta, "G", add_legend=False)

    fig.legend(handles=v1.role_handles(), frameon=False, loc="lower center",
               bbox_to_anchor=(0.715, 0.008), ncol=4, fontsize=8.4,
               columnspacing=1.3, handlelength=1.9)
    fig.subplots_adjust(left=0.038, right=0.991, bottom=0.073, top=0.992)
    stem = "Figure1_compact_A_BCD_EG_v5"
    fig.savefig(OUT / f"{stem}.png", dpi=400, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)

    pd.DataFrame([
        ("figure_height_in", 14.0, 12.4, -11.43),
        ("outer_hspace", 0.29, 0.16, -44.83),
        ("middle_wspace", 0.38, 0.29, -23.68),
        ("lower_wspace", 0.30, 0.22, -26.67),
        ("km_pair_wspace", 0.18, 0.14, -22.22),
    ], columns=["parameter", "v4", "v5", "percent_change"]).to_csv(
        OUT / "01_layout_comparison.tsv", sep="\t", index=False
    )
    pd.DataFrame({"source": list(SOURCES), "path": [str(path) for path in SOURCES.values()]}).to_csv(
        OUT / "01_source_manifest.tsv", sep="\t", index=False
    )
    status = {
        "status": "passed", "composite_figures": 1, "png_generated": 1,
        "pdf_generated": 1, "internal_titles": 0, "layout": "A/BCD/EG",
        "content_changed": 0, "statistics_changed": 0,
        "word_modified": 0, "manuscript_modified": 0, "source_files_modified": 0,
    }
    pd.DataFrame(status.items(), columns=["field", "value"]).to_csv(OUT / "02_run_status.tsv", sep="\t", index=False)
    (OUT / "02_environment.json").write_text(json.dumps({
        "python": __import__("sys").version, "pandas": pd.__version__,
        "matplotlib": mpl.__version__,
    }, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()

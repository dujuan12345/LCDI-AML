from pathlib import Path
import importlib.util,json,hashlib,subprocess
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.colors import LinearSegmentedColormap,TwoSlopeNorm
D=Path(__file__).parent;A=D.parent;Q=D/'qa';Q.mkdir(exist_ok=True)
S=A/'single_covariate_increment_20260907_v1';J=A/'consistency_v30_20260907'
assert json.loads((S/'08_QC.json').read_text(encoding='utf8'))['passed'];assert json.loads((J/'05_increment_QC.json').read_text(encoding='utf8'))['passed']
single=pd.read_csv(S/'08_verified_results.tsv',sep='\t');joint=pd.read_csv(J/'05_verified_increment.tsv',sep='\t');lrt=pd.read_csv(J/'increment_bootstrap/02_increment_LRT.tsv',sep='\t')
joint=joint.rename(columns={'paired_delta':'corrected_delta','baseline_corrected_paired':'baseline_corrected','full_corrected_paired':'augmented_corrected'});joint['covariate']='Clin+Gen';joint=joint.merge(lrt[['cohort','P','FDR']],on='cohort',validate='m:1')
data=pd.concat([single,joint],ignore_index=True);assert len(data)==52
data.to_csv(D/'01_plot_data.tsv',sep='\t',index=False,encoding='utf-8-sig')
def load(path,name):
 spec=importlib.util.spec_from_file_location(name,path);m=importlib.util.module_from_spec(spec);spec.loader.exec_module(m);return m
old=load(A/'figure2_composite_20260903_v5/01_generate_figure2_pdf_only.py','original_v5');v1=load(A/'figure2_composite_20260903_v1/01_generate_figure2.py','original_v1')
def soft(h):
 x=np.array(mpl.colors.to_rgb(h));l=x@np.array([.2126,.7152,.0722]);return tuple(.94*(.56*x+.44*l)+.06)
blue=soft('#32688E');orange=soft('#C46735');green=soft('#009E73');cols={'TCGA':blue,'TARGET':orange}
old.TIME_COLORS={1:blue,3:green,5:orange};v1.MODEL_A=blue;v1.MODEL_D=orange
mpl.rcParams.update({'font.family':'Arial','font.size':9,'axes.labelsize':9.5,'xtick.labelsize':8.2,'ytick.labelsize':8.2,'pdf.fonttype':42,'axes.unicode_minus':False})
fig=plt.figure(figsize=(18,15.2));outer=fig.add_gridspec(3,2,height_ratios=[1.03,.91,1.18],wspace=.23,hspace=.30)
labels={'age':'Age','FAB':'FAB','cyto':'Cyto','FLT3':'FLT3','NPM1':'NPM1','CEBPA':'CEBPA','Clin+Gen':'Clin+Gen'}
order=list(labels)
def letter(ax,s):ax.text(-.15,1.05,s,transform=ax.transAxes,fontsize=15,fontweight='bold',va='bottom')
def fmt(v):return f'{v:.2e}' if v<.001 else f'{v:.3f}'
for j,(cohort,lab) in enumerate([('TCGA','A'),('TARGET','B')]):
 sub=outer[0,j].subgridspec(1,2,width_ratios=[1,.70],wspace=.06);ax=fig.add_subplot(sub[0]);ta=fig.add_subplot(sub[1],sharey=ax);letter(ax,lab)
 names=[x for x in order if not(cohort=='TARGET' and x=='FAB')];x=data[(data.cohort==cohort)&(data.metric=='C_index')].set_index('covariate').loc[names]
 for i,(name,r) in enumerate(x.iterrows()):
  if name=='Clin+Gen':ax.axhspan(i-.43,i+.43,color='#F0F2F4');ta.axhspan(i-.43,i+.43,color='#F0F2F4')
  ax.plot([r.baseline_corrected,r.augmented_corrected],[i,i],color=cols[cohort],lw=1.5,zorder=2)
  ax.plot(r.baseline_corrected,i,'o',mfc='white',mec=cols[cohort],mew=1.3,ms=5.5,zorder=3)
  ax.plot(r.augmented_corrected,i,'o',mfc=cols[cohort],mec=cols[cohort],ms=5.5,zorder=3)
  for xx,value in [(.12,f'{r.corrected_delta:+.3f}'),(.49,fmt(r.P)),(.84,fmt(r.FDR))]:ta.text(xx,i,value,ha='center',va='center',fontsize=8.4)
 ax.set_yticks(range(len(names)),[labels[x] for x in names]);ax.set_ylim(len(names)-.55,-.65);ax.set_xlim(.47,.71);ax.set_xticks([.50,.55,.60,.65,.70]);ax.set_xlabel('Corrected C-index')
 for side in ['top','right','left']:ax.spines[side].set_visible(False)
 ax.spines['bottom'].set_color('#9DA7AE');ax.tick_params(axis='y',length=0);ax.grid(axis='x',color='#E8ECEF',lw=.65)
 ax.text(.5,1.05,f'{cohort}  (n={145 if cohort=="TCGA" else 1857:,})',ha='center',va='bottom',transform=ax.transAxes,color=cols[cohort],fontsize=10.5,fontweight='bold')
 ta.set_xlim(0,1);ta.axis('off')
 for xx,label in [(.12,'Delta C'),(.49,'LRT P'),(.84,'FDR')]:ta.text(xx,1.05,label,ha='center',va='bottom',transform=ta.transAxes,fontsize=8.7,fontweight='bold')
 ax.legend(handles=[Line2D([],[],ls='',marker='o',mfc='white',mec=cols[cohort],label='Baseline'),Line2D([],[],ls='',marker='o',color=cols[cohort],label='+ LCDI')],frameon=False,loc='upper center',bbox_to_anchor=(.5,-.12),ncol=2,fontsize=8.5)
# C: one shared zero-centered scale for both cohorts and all time points.
gs=outer[1,0].subgridspec(1,3,width_ratios=[1,1,.065],wspace=.35);cm=LinearSegmentedColormap.from_list('soft_delta',['#668BA5','#F8F8F6','#B77764']);bound=np.ceil(data[data.metric.str.startswith('AUC')].corrected_delta.abs().max()*20)/20
assert data[data.metric.str.startswith('AUC')].corrected_delta.abs().max()<bound
norm=TwoSlopeNorm(vmin=-bound,vcenter=0,vmax=bound)
for j,cohort in enumerate(['TCGA','TARGET']):
 ax=fig.add_subplot(gs[j]);matrix=np.full((7,3),np.nan)
 for i,var in enumerate(order):
  for k,y in enumerate([1,3,5]):
   z=data[(data.cohort==cohort)&(data.covariate==var)&(data.metric==f'AUC_{y}yr')]
   if len(z):matrix[i,k]=z.iloc[0].corrected_delta
 color=cm.copy();color.set_bad('#E4E7E9');im=ax.imshow(matrix,cmap=color,norm=norm,aspect='auto')
 for i in range(7):
  for k in range(3):ax.text(k,i,'-' if np.isnan(matrix[i,k]) else f'{matrix[i,k]:+.3f}',ha='center',va='center',fontsize=8.1,color='#24282C')
 ax.set_xticks(range(3),['1y','3y','5y']);ax.set_yticks(range(7),[labels[x] for x in order]);ax.tick_params(length=0);ax.axhline(5.5,color='#5F6B74',lw=1.2)
 ax.set_xticks(np.arange(-.5,3,1),minor=True);ax.set_yticks(np.arange(-.5,7,1),minor=True);ax.grid(which='minor',color='white',lw=1);ax.tick_params(which='minor',length=0)
 ax.text(.5,1.04,cohort,transform=ax.transAxes,ha='center',va='bottom',fontsize=10,color=cols[cohort])
 for s in ax.spines.values():s.set_visible(False)
 if j==0:letter(ax,'C')
cax=fig.add_subplot(gs[2]);cb=fig.colorbar(im,cax=cax);cb.set_label('Delta AUC',fontsize=9);cb.set_ticks([-bound,0,bound])
# D: preserved original apparent decision curves; rename only the joint-model label.
dca_dir=A/'dca_curve_inference_20260907_v2';assert json.loads((dca_dir/'10_validation.json').read_text(encoding='utf8'))['passed']
dca=pd.read_csv(dca_dir/'02_observed_curves.tsv',sep='\t',keep_default_na=False);dca['model']=dca.model.replace({'All':'Treat all','None':'Treat none'});daxes=v1.draw_dca_pair(fig,outer[1,1],dca,'D')
dg=pd.read_csv(dca_dir/'09_LCDI_default_global.tsv',sep='\t')
for ax in daxes:
 leg=ax.get_legend()
 if leg:
  for text in leg.get_texts():
   if text.get_text()=='Full nomogram':text.set_text('Full model')
for ax,co in zip(daxes,['TCGA','TARGET']):
 rows=dg[dg.cohort==co].set_index('comparison');a=rows.loc['LCDI_vs_All'];n=rows.loc['LCDI_vs_None']
 ax.text(0,-.18,f'LCDI vs All: P/FDR={fmt(a.P_bootstrap_centered)}/{fmt(a.FDR)}\nLCDI vs None: P/FDR={fmt(n.P_bootstrap_centered)}/{fmt(n.FDR)}',transform=ax.transAxes,fontsize=6.7,va='top',linespacing=1.35)
# E/F: full original ROC/calibration routines and frozen numerical sources.
roc=pd.read_csv(old.SOURCES['roc_curves'],sep='\t');auc=pd.read_csv(old.SOURCES['roc_auc'],sep='\t');cal=pd.read_csv(old.SOURCES['calibration_curves'],sep='\t');metrics=pd.read_csv(old.SOURCES['calibration_metrics'],sep='\t')
assert len(roc)==6024 and len(auc)==6 and len(cal)==27 and len(metrics)==12 and auc.absolute_difference_apparent.max()<1e-10
for j,(cohort,lab) in enumerate([('TCGA','E'),('TARGET','F')]):
 ax=fig.add_subplot(outer[2,j]);old.draw_roc_with_calibration(ax,cohort,roc,auc,cal,metrics,lab)
fig.subplots_adjust(left=.058,right=.875,bottom=.048,top=.955);old.scale_figure_text(fig,old.TEXT_SCALE)
pdf=D/'Figure2_covariate_increment_ABC_v30.pdf';fig.savefig(pdf,bbox_inches='tight',facecolor='white');plt.close(fig)
subprocess.run(['gswin64c','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=png16m','-r220',f'-sOutputFile={Q}/Figure2.png',str(pdf)],check=True,stdout=subprocess.DEVNULL)
sources=[S/'08_verified_results.tsv',J/'05_verified_increment.tsv',J/'increment_bootstrap/02_increment_LRT.tsv',A/'figure2_composite_20260903_v5/01_generate_figure2_pdf_only.py',A/'figure2_composite_20260903_v1/01_generate_figure2.py',dca_dir/'02_observed_curves.tsv',dca_dir/'09_LCDI_default_global.tsv']+[old.SOURCES[k] for k in ['roc_curves','roc_auc','calibration_curves','calibration_metrics']]
(D/'01_figure_QC.json').write_text(json.dumps({'sources':[{'path':str(p),'sha256':hashlib.sha256(p.read_bytes()).hexdigest()} for p in sources],'A_B_comparisons':13,'C_delta_AUC_cells':39,'A_B_LRT_P_and_FDR':True,'D_two_model_curves_preserved':True,'D_reference':'Treat-all unified to same case/control IPCW; audit retained','D_primary_tests':'LCDI vs Treat-all / Treat-none; 5000 paired bootstraps','E_F_complete_content_preserved':True,'D_legend_change':'Full nomogram -> Full model','visual':'pending'},indent=2),encoding='utf8')
print('Built',pdf)

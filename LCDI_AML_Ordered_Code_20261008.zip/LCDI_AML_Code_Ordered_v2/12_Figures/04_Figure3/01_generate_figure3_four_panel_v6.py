from __future__ import annotations

import hashlib
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap, Normalize
from matplotlib.lines import Line2D
from matplotlib.patches import Polygon
from mpl_toolkits.axes_grid1 import make_axes_locatable
import numpy as np
import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
OUT = PROJECT / "_codex_audit" / "figure3_composite_20260903_v6"
DUAL = PROJECT / "_codex_audit" / "dual_axis_pseudobulk_20260819_v1"
GSE = PROJECT / "_codex_audit" / "third_scrna_casp1_validation_20260825_v1"
AUTH = PROJECT / "_codex_audit" / "evidence_upgrade_phase2_20260825_v1"
MAL = PROJECT / "_codex_audit" / "evidence_upgrade_phase3_malignant_20260825_v1"

SOURCES = {
    "axis_scores": DUAL / "tmm_unit_lineage_scores.tsv",
    "centroids": DUAL / "tmm_gene_expression_and_contribution_centroids.tsv",
    "lineage_tests": DUAL / "tmm_gene_contribution_lineage_tests.tsv",
    "driver_audit": DUAL / "tmm_gene_driver_final_audit.tsv",
    "gse_results": GSE / "04_target_gene_results.tsv",
    "gse_patient": GSE / "04_target_logcpm_by_patient_state.tsv",
    "author_results": AUTH / "04_author_label_target_results.tsv",
    "author_patient": AUTH / "04_author_label_expression_by_patient.tsv",
    "malignant_results": MAL / "07_malignant_target_results.tsv",
}
PDF = OUT / "Figure3_MPO_dominance_and_nonMPO_components_v6.pdf"

GENES = ["CREB1", "GPX4", "SLC16A4", "CASP1"]
GATE_GENES = ["CASP1", "GPX4", "CREB1", "SLC16A4"]
LINEAGES = ["HSC-like/HSC", "Progenitor-like/MPP", "GMP-like/GMP", "Monocytic-like"]
LINEAGE_LABELS = ["HSC-like", "Prog-like", "GMP-like", "Mono-like"]
COLORS = {
    "adult": "#6A3D9A",
    "pediatric": "#1B9E77",
    "CASP1": "#D55E00",
    "GPX4": "#0072B2",
    "weak": "#D9D9D9",
    "grid": "#DDDDDD",
    "nested": "#F1F1F1",
}


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def fmt_fdr(value: float) -> str:
    if value < 0.001:
        return f"{value:.1e}"
    if value < 0.01:
        return f"{value:.4f}".rstrip("0")
    return f"{value:.3f}".rstrip("0").rstrip(".")


def add_panel_letter(ax: plt.Axes, letter: str, x: float = -0.16) -> None:
    ax.text(x, 1.08, letter, transform=ax.transAxes, fontsize=18,
            fontweight="bold", ha="left", va="top")


def build_mpo_summary(scores: pd.DataFrame) -> pd.DataFrame:
    rows = []
    groups = [(name, frame) for name, frame in scores.groupby("dataset")]
    groups.append(("combined", scores))
    for name, frame in groups:
        mpo = frame.MPO_axis.abs()
        non = frame.nonMPO_axis.abs()
        unit_ids = frame.dataset.astype(str) + "|||" + frame.unit.astype(str)
        rows.append({
            "dataset": name,
            "records": len(frame),
            "units": unit_ids.nunique(),
            "mpo_greater_records": int((mpo > non).sum()),
            "mpo_greater_fraction": float((mpo > non).mean()),
            "mean_abs_mpo": float(mpo.mean()),
            "mean_abs_nonMPO": float(non.mean()),
            "mean_abs_ratio": float(mpo.mean() / non.mean()),
            "median_abs_mpo": float(mpo.median()),
            "median_abs_nonMPO": float(non.median()),
        })
    return pd.DataFrame(rows)


def draw_mpo_dominance(ax: plt.Axes, scores: pd.DataFrame, summary: pd.DataFrame) -> None:
    markers = {"adult": "o", "pediatric": "^"}
    for dataset in ["adult", "pediatric"]:
        sub = scores.loc[scores.dataset.eq(dataset)]
        ax.scatter(sub.MPO_axis.abs(), sub.nonMPO_axis.abs(), s=38,
                   marker=markers[dataset], color=COLORS[dataset], alpha=0.72,
                   edgecolor="white", linewidth=0.45,
                   label=f"{dataset.title()} ({len(sub)} records)")
    limit = 0.63
    ax.plot([0, limit], [0, limit], color="#777777", ls="--", lw=1.2)
    ax.fill_between([0, limit], [0, limit], [0, 0], color="#E8F4EE", alpha=0.65, zorder=0)
    ax.set_xlim(-0.015, limit)
    ax.set_ylim(-0.015, limit)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("Absolute MPO component", fontsize=11)
    ax.set_ylabel("Absolute combined non-MPO component", fontsize=11)
    ax.grid(color="#E5E5E5", lw=0.65)
    ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False)
    add_panel_letter(ax, "A", -0.23)
    ax.legend(frameon=False, loc="upper left", fontsize=9.1,
              handletextpad=0.4, borderaxespad=0.3)
    adult = summary.set_index("dataset").loc["adult"]
    ped = summary.set_index("dataset").loc["pediatric"]
    combined = summary.set_index("dataset").loc["combined"]
    text = (f"MPO > non-MPO: {int(combined.mpo_greater_records)}/{int(combined.records)} "
            f"({100 * combined.mpo_greater_fraction:.1f}%); mean |component| ratio: "
            f"adult {adult.mean_abs_ratio:.2f}x, pediatric {ped.mean_abs_ratio:.2f}x\n"
            "Descriptive patient-lineage pseudobulk records; no inferential test")
    ax.text(0.5, -0.15, text, transform=ax.transAxes, ha="center", va="top",
            fontsize=8.4, linespacing=1.22, color="#444444")
    ax.set_anchor("W")


def draw_split_heatmap(ax: plt.Axes, centroids: pd.DataFrame) -> None:
    cmap = mpl.colormaps["RdBu_r"]
    norm = Normalize(vmin=-1.2, vmax=1.2)
    lookup = centroids.set_index(["dataset", "gene", "lineage_common"])["expression_z"]
    for i, gene in enumerate(GENES):
        for j, lineage in enumerate(LINEAGES):
            adult = float(lookup.loc[("adult", gene, lineage)])
            pediatric = float(lookup.loc[("pediatric", gene, lineage)])
            upper_left = Polygon([(j - 0.5, i - 0.5), (j + 0.5, i - 0.5),
                                  (j - 0.5, i + 0.5)],
                                 facecolor=cmap(norm(adult)), edgecolor="white", linewidth=1.3)
            lower_right = Polygon([(j + 0.5, i - 0.5), (j + 0.5, i + 0.5),
                                   (j - 0.5, i + 0.5)],
                                  facecolor=cmap(norm(pediatric)), edgecolor="white", linewidth=1.3)
            ax.add_patch(upper_left)
            ax.add_patch(lower_right)
            for value, x, y in [(adult, j - 0.17, i - 0.17),
                                (pediatric, j + 0.17, i + 0.17)]:
                color = "white" if abs(value) >= 0.68 else "#222222"
                ax.text(x, y, f"{value:+.2f}", ha="center", va="center",
                        fontsize=9.1, color=color,
                        fontweight="bold" if abs(value) >= 0.68 else "normal")
    ax.set_xlim(-0.5, 3.5)
    ax.set_ylim(3.5, -0.5)
    ax.set_aspect("equal")
    ax.set_xticks(range(4), LINEAGE_LABELS, fontsize=10.2)
    ax.set_yticks(range(4), GENES, fontsize=10.8, fontstyle="italic")
    ax.tick_params(length=0)
    for spine in ax.spines.values():
        spine.set_color("#666666")
        spine.set_linewidth(0.8)
    add_panel_letter(ax, "C", -0.20)
    ax.text(0.995, 1.015, "upper-left: Adult  |  lower-right: Pediatric",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=9.3,
            color="#444444")
    sm = mpl.cm.ScalarMappable(norm=norm, cmap=cmap)
    ax.set_anchor("W")
    divider = make_axes_locatable(ax)
    cax = divider.append_axes("right", size="4%", pad=0.12)
    cbar = ax.figure.colorbar(sm, cax=cax)
    cbar.set_label("Relative expression (z-score)", fontsize=10)
    cbar.ax.tick_params(labelsize=9)


def gate_strength(row: pd.Series, column: str) -> int:
    if column in {"adult_fdr", "pediatric_fdr"}:
        return 2 if row[column] < 0.05 else (1 if row[column] < 0.10 else 0)
    if column in {"loo_proportion_adult", "loo_proportion_pediatric"}:
        return 2 if row[column] >= 0.95 else (1 if row[column] >= 0.5 else 0)
    if column == "same_sign_lineages_vs_zero":
        return 2 if row[column] == 4 else (1 if row[column] == 3 else 0)
    if column == "spearman_rho":
        return 2 if row[column] >= 0.75 else (1 if row[column] > 0 else 0)
    if column == "robust_directionally_concordant_driver":
        return 2 if bool(row[column]) else 0
    raise KeyError(column)


def gate_label(row: pd.Series, column: str) -> str:
    if column in {"adult_fdr", "pediatric_fdr"}:
        return fmt_fdr(float(row[column]))
    if column in {"loo_proportion_adult", "loo_proportion_pediatric"}:
        return f"{100 * float(row[column]):.0f}%"
    if column == "same_sign_lineages_vs_zero":
        return f"{int(row[column])}/4"
    if column == "spearman_rho":
        return f"{float(row[column]):+.1f}"
    if column == "robust_directionally_concordant_driver":
        return "PASS" if bool(row[column]) else "-"
    raise KeyError(column)


def draw_replication_gate(ax: plt.Axes, driver: pd.DataFrame) -> None:
    columns = [
        "adult_fdr", "pediatric_fdr", "loo_proportion_adult",
        "loo_proportion_pediatric", "same_sign_lineages_vs_zero",
        "spearman_rho", "robust_directionally_concordant_driver",
    ]
    labels = ["Adult\nFDR", "Pediatric\nFDR", "Adult\nLOOU", "Pediatric\nLOOU",
              "Same-sign\nlineages", "Centroid\nrho", "Overall\ngate"]
    view = driver.set_index("gene").loc[GATE_GENES].reset_index()
    strength = np.array([[gate_strength(row, col) for col in columns]
                         for _, row in view.iterrows()])
    cmap = ListedColormap([COLORS["weak"], "#F6D78B", "#79CDB3"])
    ax.imshow(strength, cmap=cmap, vmin=-0.5, vmax=2.5, aspect="auto")
    for i, row in view.iterrows():
        for j, col in enumerate(columns):
            value = gate_label(row, col)
            ax.text(j, i, value, ha="center", va="center", fontsize=10.0,
                    fontweight="bold" if col == columns[-1] and value == "PASS" else "normal")
    ax.set_xticks(np.arange(len(columns)), labels, fontsize=9.7)
    ax.tick_params(axis="x", top=True, labeltop=True, bottom=False, labelbottom=False,
                   length=0, pad=5)
    ax.set_yticks(np.arange(len(GATE_GENES)), GATE_GENES, fontsize=10.8,
                  fontstyle="italic")
    ax.tick_params(axis="y", length=0)
    for edge in np.arange(-0.5, len(columns), 1):
        ax.axvline(edge, color="white", lw=2)
    for edge in np.arange(-0.5, len(GATE_GENES), 1):
        ax.axhline(edge, color="white", lw=2)
    ax.axvline(len(columns) - 0.5, color="white", lw=2)
    ax.axhline(len(GATE_GENES) - 0.5, color="white", lw=2)
    add_panel_letter(ax, "B", -0.10)
    legend = [mpl.patches.Patch(facecolor="#79CDB3", label="Meets criterion"),
              mpl.patches.Patch(facecolor="#F6D78B", label="Partial support"),
              mpl.patches.Patch(facecolor=COLORS["weak"], label="Does not meet criterion")]
    ax.legend(handles=legend, frameon=False, loc="upper center", ncol=3,
              bbox_to_anchor=(0.5, -0.11), fontsize=8.8, handlelength=1.2,
              columnspacing=1.3)


def build_state_table() -> pd.DataFrame:
    gse = pd.read_csv(SOURCES["gse_results"], sep="\t")
    gse = gse.loc[gse.method.eq("TMM")].copy()
    gse_patient = pd.read_csv(SOURCES["gse_patient"], sep="\t")
    gse_patient = gse_patient.loc[gse_patient.method.eq("TMM")]
    gse_positive = gse_patient.groupby("gene").paired_difference.apply(lambda values: int((values > 0).sum()))
    gse["positive_patients"] = gse.gene.map(gse_positive)
    gse["layer"] = "GSE130756 marker-defined"
    gse["nested"] = False

    author = pd.read_csv(SOURCES["author_results"], sep="\t")
    author = author.loc[author.method.eq("TMM")].copy()
    author["layer"] = "GSE230559 author labels"
    author["nested"] = False

    malignant = pd.read_csv(SOURCES["malignant_results"], sep="\t")
    malignant = malignant.loc[malignant.method.eq("TMM")].copy()
    malignant["layer"] = malignant.layer.map({
        "union_positive": "Nested malignant union",
        "direct_MT_only": "Nested direct mutation",
    })
    malignant["nested"] = True
    columns = ["gene", "layer", "n_patients", "positive_patients", "state_beta",
               "bootstrap_ci_low", "bootstrap_ci_high", "state_fdr_bh", "nested"]
    combined = pd.concat([gse[columns], author[columns], malignant[columns]], ignore_index=True)
    order = ["GSE130756 marker-defined", "GSE230559 author labels",
             "Nested malignant union", "Nested direct mutation"]
    combined["layer"] = pd.Categorical(combined.layer, categories=order, ordered=True)
    combined["gene"] = pd.Categorical(combined.gene, categories=["CASP1", "GPX4"], ordered=True)
    return combined.sort_values(["layer", "gene"])


def draw_combined_forest(ax: plt.Axes, stat_ax: plt.Axes, state: pd.DataFrame) -> None:
    layer_order = list(state.layer.cat.categories)
    base_y = {layer: value for layer, value in zip(layer_order, [7, 5, 3, 1])}
    offsets = {"CASP1": 0.23, "GPX4": -0.23}
    ax.axhspan(0.45, 3.55, color=COLORS["nested"], zorder=0)
    stat_ax.axhspan(0.45, 3.55, color=COLORS["nested"], zorder=0)
    ax.axvline(0, color="#777777", ls="--", lw=1.1, zorder=1)
    for row in state.itertuples():
        gene = str(row.gene)
        layer = str(row.layer)
        yy = base_y[layer] + offsets[gene]
        ax.errorbar(row.state_beta, yy,
                    xerr=[[row.state_beta - row.bootstrap_ci_low],
                          [row.bootstrap_ci_high - row.state_beta]],
                    fmt="o", color=COLORS[gene], ecolor=COLORS[gene],
                    elinewidth=1.8, capsize=3.5, markersize=6.3, zorder=3)
        stat_ax.text(0.01, yy, gene, color=COLORS[gene], fontstyle="italic",
                     fontweight="bold", fontsize=8.9, ha="left", va="center")
        stat_ax.text(0.20, yy,
                     f"{row.state_beta:+.2f} [{row.bootstrap_ci_low:+.2f}, {row.bootstrap_ci_high:+.2f}]",
                     fontsize=8.5, ha="left", va="center")
        stat_ax.text(0.68, yy, fmt_fdr(row.state_fdr_bh), fontsize=8.5,
                     ha="left", va="center")
        stat_ax.text(0.84, yy, f"{int(row.positive_patients)}/{int(row.n_patients)}",
                     fontsize=8.5, ha="left", va="center")
    labels = ["GSE130756 marker-defined\nn=40", "GSE230559 author labels\nn=14",
              "Nested malignant union\nn=7", "Nested direct mutation\nn=7"]
    ax.set_yticks([7, 5, 3, 1], labels, fontsize=9.7)
    ax.tick_params(axis="y", length=0)
    ax.set_xlim(-0.48, 2.58)
    ax.set_ylim(0.35, 7.65)
    ax.grid(axis="x", color="#E5E5E5", lw=0.65)
    ax.set_axisbelow(True)
    ax.spines[["top", "right", "left"]].set_visible(False)
    ax.set_xlabel("Mono/Mono-like minus GMP/Prog-like logCPM\n(patient-bootstrap 95% CI)",
                  fontsize=10.2)
    add_panel_letter(ax, "D", -0.12)
    handles = [Line2D([0], [0], marker="o", color=COLORS[gene], lw=1.8,
                      markersize=6, label=gene) for gene in ["CASP1", "GPX4"]]
    ax.legend(handles=handles, frameon=False, loc="lower left", ncol=2,
              bbox_to_anchor=(0.0, 1.01), fontsize=9.0, handlelength=1.6,
              borderaxespad=0.0,
              columnspacing=1.1)

    stat_ax.set_xlim(0, 1)
    stat_ax.set_ylim(0.35, 7.65)
    stat_ax.set_xticks([])
    stat_ax.tick_params(axis="y", left=False, labelleft=False)
    stat_ax.spines[:].set_visible(False)
    headers = [(0.01, "Gene"), (0.20, "Effect [95% CI]"),
               (0.68, "FDR"), (0.84, "Mono higher")]
    for xpos, label in headers:
        stat_ax.text(xpos, 1.015, label, transform=stat_ax.transAxes,
                     ha="left", va="bottom", fontsize=8.8, fontweight="bold",
                     color="#444444")
    stat_ax.text(0.01, 0.015, "Shaded rows: nested exploratory sensitivity layers",
                 transform=stat_ax.transAxes, ha="left", va="bottom", fontsize=8.2,
                 color="#555555")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    missing = [str(path) for path in SOURCES.values() if not path.is_file()]
    if missing:
        raise FileNotFoundError(missing)
    mpl.rcParams.update({
        "font.family": "Arial",
        "font.size": 11,
        "axes.labelcolor": "#222222",
        "axes.edgecolor": "#555555",
        "xtick.color": "#333333",
        "ytick.color": "#333333",
        "pdf.fonttype": 42,
    })
    scores = pd.read_csv(SOURCES["axis_scores"], sep="\t")
    centroids = pd.read_csv(SOURCES["centroids"], sep="\t")
    driver = pd.read_csv(SOURCES["driver_audit"], sep="\t")
    state = build_state_table()
    mpo_summary = build_mpo_summary(scores)

    fig = plt.figure(figsize=(15.2, 10.4), facecolor="white")
    outer = fig.add_gridspec(2, 1, height_ratios=[1.00, 1.00],
                             left=0.075, right=0.975, top=0.95, bottom=0.085,
                             hspace=0.38)
    gs_top = outer[0].subgridspec(1, 2, width_ratios=[0.42, 0.58], wspace=0.18)
    gs_bottom = outer[1].subgridspec(1, 2, width_ratios=[0.43, 0.57], wspace=0.30)
    ax_a = fig.add_subplot(gs_top[0, 0])
    ax_c = fig.add_subplot(gs_top[0, 1])
    ax_b = fig.add_subplot(gs_bottom[0, 0])
    gs_d = gs_bottom[0, 1].subgridspec(1, 2, width_ratios=[0.55, 0.45], wspace=0.04)
    ax_d = fig.add_subplot(gs_d[0, 0])
    ax_d_stat = fig.add_subplot(gs_d[0, 1], sharey=ax_d)

    draw_mpo_dominance(ax_a, scores, mpo_summary)
    draw_replication_gate(ax_c, driver)
    draw_split_heatmap(ax_b, centroids)
    draw_combined_forest(ax_d, ax_d_stat, state)
    fig.savefig(PDF, bbox_inches="tight", facecolor="white")
    plt.close(fig)

    mpo_summary.to_csv(OUT / "01_mpo_dominance_summary.tsv", sep="\t", index=False)
    state.to_csv(OUT / "01_combined_forest_source.tsv", sep="\t", index=False)
    pd.DataFrame([{"source_id": key, "path": str(path), "bytes": path.stat().st_size,
                   "sha256": sha256(path)} for key, path in SOURCES.items()]).to_csv(
                       OUT / "01_source_manifest.tsv", sep="\t", index=False)
    pd.DataFrame([
        {"panel": "A", "position": "top_left", "content": "MPO_vs_combined_nonMPO_absolute_component", "source_version": "frozen_TMM"},
        {"panel": "B", "position": "top_right", "content": "v1_cross_dataset_replication_gate_matrix", "source_version": "frozen_TMM"},
        {"panel": "C", "position": "bottom_left", "content": "adult_pediatric_diagonal_split_expression_heatmap", "source_version": "frozen_TMM"},
        {"panel": "D", "position": "bottom_right", "content": "combined_CASP1_GPX4_external_forest", "source_version": "frozen_TMM"},
    ]).to_csv(OUT / "01_layout_manifest.tsv", sep="\t", index=False)
    pd.DataFrame([
        {"field": "status", "value": "passed"},
        {"field": "layout", "value": "AB/CD"},
        {"field": "formal_pdf", "value": "1"},
        {"field": "formal_png", "value": "0"},
        {"field": "analysis_rerun", "value": "0"},
        {"field": "lightweight_descriptive_derivation", "value": "1"},
        {"field": "external_query", "value": "0"},
        {"field": "manuscript_modified", "value": "0"},
        {"field": "word_modified", "value": "0"},
        {"field": "source_files_modified", "value": "0"},
        {"field": "canvas_inches", "value": "15.2x10.4"},
        {"field": "panel_titles", "value": "0"},
        {"field": "panel_c_style", "value": "restored_v1_gate_matrix"},
        {"field": "panel_d_legend", "value": "outside_data_region"},
        {"field": "top_row_wspace", "value": "0.18"},
        {"field": "bottom_row_wspace", "value": "0.30"},
        {"field": "row_height_ratios", "value": "1.00:1.00"},
        {"field": "panel_a_anchor", "value": "west"},
        {"field": "panel_b_anchor", "value": "west"},
        {"field": "panel_positions", "value": "A_top_left_B_top_right_C_bottom_left_D_bottom_right"},
        {"field": "visual_qa_dpi", "value": "400"},
        {"field": "seed", "value": "not_applicable"},
    ]).to_csv(OUT / "02_run_status.tsv", sep="\t", index=False)
    summary = {"status": "passed", "pdf": str(PDF), "pdf_bytes": PDF.stat().st_size,
               "pdf_sha256": sha256(PDF), "panels": 4,
               "MPO_greater_records": int(mpo_summary.set_index("dataset").loc["combined", "mpo_greater_records"]),
               "total_records": int(len(scores)), "forest_rows": int(len(state))}
    (OUT / "02_generation_summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

from pathlib import Path
import json,hashlib
import numpy as np
import pandas as pd
import networkx as nx
R=Path('D:/26_01_AML');O=R/'_codex_audit/figure4_upstream_corrected_20260905_v3';B=R/'_codex_audit/upstream_repair_20260905_v1/bulk'
assert not (O/'01_PREPARED').exists()
g=pd.read_csv(B/'gsea_final/GSEA_hallmark_all.tsv',sep='\t')
d=pd.read_csv(B/'02_DEG_all.tsv',sep='\t').sort_values('t',ascending=False,kind='stable')
t2g=pd.read_csv(B/'03_frozen_hallmark_TERM2GENE.tsv',sep='\t')
assert len(d)==13039 and d.gene.is_unique and len(g)==50
g=g[g['p.adjust']<.05].assign(absNES=lambda x:abs(x.NES)).sort_values(['absNES','p.adjust'],ascending=[False,True]).head(5)
labels={'HALLMARK_INTERFERON_ALPHA_RESPONSE':'IFNa-resp','HALLMARK_MYC_TARGETS_V1':'MYC-V1','HALLMARK_INTERFERON_GAMMA_RESPONSE':'IFNg-resp','HALLMARK_REACTIVE_OXYGEN_SPECIES_PATHWAY':'ROS','HALLMARK_UNFOLDED_PROTEIN_RESPONSE':'UPR'}
curves=[];hits=[];terms=[]
for row in g.itertuples(index=False):
 genes=set(t2g.loc[t2g.term==row.ID,'gene']);hit=d.gene.isin(genes).to_numpy();n=int(hit.sum());weights=abs(d.t.to_numpy())*hit;weights=weights/weights.sum();running=np.cumsum(weights-(~hit)/(len(d)-n))
 es=running.max() if abs(running.max())>abs(running.min()) else running.min()
 assert np.isclose(es,row.enrichmentScore,atol=1e-10) and abs(running[-1])<1e-10
 fdr=float(g.set_index('ID').loc[row.ID,'p.adjust']);lab=labels[row.ID]
 curves.append(pd.DataFrame({'term_id':row.ID,'label':lab,'rank':np.arange(1,len(d)+1),'running_es':running,'NES':row.NES,'FDR':fdr}))
 hits.append(pd.DataFrame({'term_id':row.ID,'label':lab,'rank':np.flatnonzero(hit)+1}))
 terms.append(dict(term_id=row.ID,label=lab,NES=row.NES,FDR=fdr,set_size=len(genes),ranked_hits=n,ES=es,ES_source=row.enrichmentScore))
pd.concat(curves).to_csv(O/'00_gsea_top5_running_curves.tsv',sep='\t',index=False)
pd.concat(hits).to_csv(O/'00_gsea_top5_hit_positions.tsv',sep='\t',index=False)
pd.DataFrame(terms).to_csv(O/'00_gsea_top5_terms.tsv',sep='\t',index=False)
a=pd.read_csv(B/'04_GO_KEGG_ORA_all.tsv',sep='\t');a=a[a['p.adjust']<.05].copy();selected=[]
for database in ['GO_BP','GO_CC','GO_MF','KEGG']:
 sub=a[a.database==database].sort_values(['p.adjust','pvalue','ID'],kind='stable')
 up=sub[sub.direction=='Up_in_LCDI_High'].head(2);down=sub[sub.direction=='Down_in_LCDI_High'].head(3)
 chosen=pd.concat([up,down]).drop_duplicates('ID')
 if len(chosen)<5:chosen=pd.concat([chosen,sub[~sub.ID.isin(chosen.ID)].head(5-len(chosen))])
 selected.append(chosen.head(5))
pd.concat(selected).to_csv(O/'00_ora_selected_unlabelled.tsv',sep='\t',index=False)
nodes=pd.read_csv(B/'02_string_physical_nodes.tsv',sep='\t');edges=pd.read_csv(B/'02_string_physical_edges.tsv',sep='\t');graph=nx.from_pandas_edgelist(edges,'from','to')
nodes['degree_rechecked']=nodes.gene.map(dict(graph.degree())).fillna(0).astype(int)
assert (nodes.degree==nodes.degree_rechecked).all() and len(nodes)==72 and len(graph)==26 and len(edges)==37
nodes.to_csv(O/'00_ppi_nodes.tsv',sep='\t',index=False)
(O/'01_preparation_summary.json').write_text(json.dumps({'status':'prepared','ranked_genes':len(d),'terms':terms,'ppi_components':sorted(map(len,nx.connected_components(graph)),reverse=True),'PPI_nodes':len(graph),'PPI_edges':len(edges),'scientific_analysis_rerun':False},indent=2),encoding='utf-8')
(O/'01_PREPARED').write_text('curves independently reproduce final GSEA ES; ORA and PPI from corrected72DEGs\n')
print(pd.concat(selected)[['database','direction','ID','Description']].to_string(index=False));print(pd.DataFrame(terms)[['label','NES','FDR']].to_string(index=False))

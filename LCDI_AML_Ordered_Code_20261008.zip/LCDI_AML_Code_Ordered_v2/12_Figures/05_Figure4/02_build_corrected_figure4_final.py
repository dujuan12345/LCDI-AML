from __future__ import annotations

import hashlib
import json
import textwrap
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import networkx as nx
import numpy as np
import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
OUT = PROJECT / "_codex_audit" / "figure4_upstream_corrected_20260905_v3"
BULK = PROJECT / "_codex_audit" / "upstream_repair_20260905_v1" / "bulk"
SUPP = PROJECT / "_codex_audit" / "figure4_go_kegg_ppi_20260903_v1"
LINEAGE = PROJECT / "_codex_audit" / "lineage_decomposition_20260828_v2"
SINGLE = PROJECT / "_codex_audit" / "singlecell_systematic_remining_20260802_v1"

SOURCES = {
    "hallmark_gsea": BULK / "gsea_final" / "GSEA_hallmark_all.tsv",
    "deg_rank_source": BULK / "02_DEG_all.tsv",
    "frozen_hallmark_sets": BULK / "03_frozen_hallmark_TERM2GENE.tsv",
    "gsea_curves": OUT / "00_gsea_top5_running_curves.tsv",
    "gsea_hits": OUT / "00_gsea_top5_hit_positions.tsv",
    "gsea_terms": OUT / "00_gsea_top5_terms.tsv",
    "ora_plot_terms": OUT / "00_ora_plot_terms.tsv",
    "ora_all": BULK / "04_GO_KEGG_ORA_all.tsv",
    "ora_summary": BULK / "04_ORA_summary.tsv",
    "ppi_nodes": OUT / "00_ppi_nodes.tsv",
    "ppi_edges": BULK / "02_string_physical_edges.tsv",
    "ppi_status": BULK / "02_string_local_status.json",
    "bulk_sc_concordance": SINGLE / "01_bulk_singlecell_pathway_concordance.tsv",
    "controlled_associations": LINEAGE / "06_controlled_associations.tsv",
    "lineage_run_status": LINEAGE / "01_run_status.tsv",
    "overall_gate": LINEAGE / "13_overall_gate_summary.tsv",
}
PDF = OUT / "Figure4_corrected_ABC_complete_v3_final.pdf"

PATHWAY_IDS = [
    "HALLMARK_MYC_TARGETS_V1", "HALLMARK_E2F_TARGETS", "HALLMARK_G2M_CHECKPOINT",
    "HALLMARK_MTORC1_SIGNALING", "HALLMARK_OXIDATIVE_PHOSPHORYLATION",
    "HALLMARK_GLYCOLYSIS", "HALLMARK_DNA_REPAIR",
]
PATHWAY_LABELS = ["MYC targets V1", "E2F targets", "G2M checkpoint", "mTORC1 signaling",
                  "Oxidative phosphorylation", "Glycolysis", "DNA repair"]
DATASET_COLORS = {"adult": "#6A3D9A", "pediatric": "#1B9E77"}
DIRECTION_COLORS = {"Down_in_LCDI_High": "#4DBBD5", "Up_in_LCDI_High": "#E64B35"}
DB_LABELS = {"GO_BP": "GO: BP", "GO_CC": "GO: CC", "GO_MF": "GO: MF", "KEGG": "KEGG"}
GSEA_COLORS = ["#E64B35", "#3C5488", "#F39B7F", "#00A087", "#4DBBD5"]


def sha256(path: Path) -> str:
    return hashlib.sha256(path.read_bytes()).hexdigest().upper()


def add_letter(ax: plt.Axes, letter: str, x: float = -0.12, y: float = 1.06) -> None:
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=19, fontweight="bold", ha="left", va="top")


def draw_gsea(curve_ax: plt.Axes, rug_ax: plt.Axes, curves: pd.DataFrame,
              hits: pd.DataFrame, terms: pd.DataFrame) -> pd.DataFrame:
    ordered = terms.reset_index(drop=True).copy()
    max_rank = int(curves["rank"].max())
    for idx, row in ordered.iterrows():
        term = row["term_id"]
        sub = curves.loc[curves.term_id.eq(term)]
        color = GSEA_COLORS[idx]
        curve_ax.plot(sub["rank"], sub["running_es"], color=color, lw=1.65,
                      label=f"{row['label']:<9}  NES={row['NES']:+.2f}  FDR={row['FDR']:.1e}")
        term_hits = hits.loc[hits.term_id.eq(term), "rank"].to_numpy()
        rug_ax.vlines(term_hits, idx + 0.12, idx + 0.88, color=color, lw=0.38, alpha=0.78)
    curve_ax.axhline(0, color="#777777", ls="--", lw=0.75)
    curve_ax.set_xlim(1, max_rank)
    curve_ax.set_ylabel("Running enrichment score", fontsize=9.2)
    curve_ax.tick_params(axis="x", labelbottom=False)
    curve_ax.grid(axis="y", color="#E8E8E8", lw=0.5)
    curve_ax.spines[["top", "right"]].set_visible(False)
    curve_ax.legend(frameon=True, facecolor="white", edgecolor="none", framealpha=0.92, fontsize=8.5, loc="upper right", handlelength=2.2,
                    borderaxespad=0.2, labelspacing=0.35)
    add_letter(curve_ax, "A", -0.11, 1.07)
    curve_ax.text(0.01, 0.02, "Top 5 by |NES| among Hallmark FDR < 0.05",
                  transform=curve_ax.transAxes, fontsize=7.6, color="#444444", va="bottom")
    rug_ax.set_xlim(1, max_rank)
    rug_ax.set_ylim(0, len(ordered) + 0.05)
    rug_ax.set_yticks([])
    rug_ax.set_xlabel("Ranked genes (moderated t: LCDI High vs Low)", fontsize=9.2)
    rug_ax.spines[["top", "right", "left"]].set_visible(False)
    return ordered


def select_ora_terms(terms: pd.DataFrame) -> pd.DataFrame:
    selected = []
    for database in ["GO_BP", "GO_CC", "GO_MF", "KEGG"]:
        sub = terms.loc[terms.database.eq(database)].copy().sort_values("p.adjust")
        up = sub.loc[sub.direction.eq("Up_in_LCDI_High")].head(2)
        down = sub.loc[sub.direction.eq("Down_in_LCDI_High")].head(3)
        chosen = pd.concat([up, down]).drop_duplicates("ID")
        if len(chosen) < 5:
            chosen = pd.concat([chosen, sub.loc[~sub.ID.isin(chosen.ID)].head(5 - len(chosen))])
        selected.append(chosen.head(5))
    data = pd.concat(selected, ignore_index=True)
    ratios = data.GeneRatio.str.split("/", expand=True).astype(float)
    data["gene_ratio"] = ratios[0] / ratios[1]
    data["short_term"] = data.display_term
    return data


def draw_ora(axes: list[plt.Axes], data: pd.DataFrame) -> None:
    count_min, count_max = float(data.Count.min()), float(data.Count.max())
    fdr_min, fdr_max = float(data["p.adjust"].min()), float(data["p.adjust"].max())
    norm = mpl.colors.LogNorm(vmin=max(fdr_min, 1e-30), vmax=fdr_max)
    cmap = mpl.colors.LinearSegmentedColormap.from_list("reference_fdr", ["#E64B35", "#F1B6A8", "#4DBBD5"])
    for idx, (ax, database) in enumerate(zip(axes, ["GO_BP", "GO_CC", "GO_MF", "KEGG"])):
        sub = data.loc[data.database.eq(database)].sort_values(["direction", "p.adjust"], ascending=[False, True]).copy()
        y = np.arange(len(sub))[::-1]
        labels = [("Up | " if direction == "Up_in_LCDI_High" else "Down | ") + term
                  for direction, term in zip(sub.direction, sub.short_term)]
        sizes = 35 + 125 * (sub.Count.astype(float) - count_min) / max(count_max - count_min, 1)
        ax.scatter(sub.gene_ratio, y, s=sizes, c=sub["p.adjust"], cmap=cmap, norm=norm,
                   edgecolor="white", linewidth=0.65, alpha=0.95)
        ax.set_yticks(y, labels, fontsize=8.4)
        ax.set_xlabel("GeneRatio", fontsize=8.4)
        # No subplot titles: ontology positions are defined in the caption.
        ax.set_xlim(left=0)
        ax.grid(axis="x", color="#E8E8E8", lw=0.5)
        ax.spines[["top", "right"]].set_visible(False)
        if idx == 0:
            add_letter(ax, "B", -0.29, 1.16)
    cbar = axes[0].figure.colorbar(mpl.cm.ScalarMappable(norm=norm, cmap=cmap), ax=axes,
                                  fraction=0.017, pad=0.012, aspect=25)
    cbar.set_label("FDR (low to high)", fontsize=8.0)
    legend_counts = sorted({int(count_min), int(round((count_min + count_max) / 2)), int(count_max)})
    handles = []
    for count in legend_counts:
        size = 35 + 125 * (count - count_min) / max(count_max - count_min, 1)
        handles.append(plt.scatter([], [], s=size, facecolor="#BDBDBD", edgecolor="white", label=str(count)))
    axes[-1].legend(handles=handles, title="Count", frameon=False, fontsize=7.0, title_fontsize=7.5,
                    loc="lower right", bbox_to_anchor=(1.02, 0.02), labelspacing=0.6)


def component_positions(graph: nx.Graph):
    comps = sorted((graph.subgraph(c).copy() for c in nx.connected_components(graph)),
                   key=lambda item: (-item.number_of_nodes(), tuple(sorted(item.nodes()))))
    pos = {}
    raw = nx.spring_layout(comps[0], seed=20260905, k=1.15, iterations=1000, weight=None)
    xs=np.array([v[0] for v in raw.values()]); ys=np.array([v[1] for v in raw.values()])
    for node,v in raw.items():
        pos[node]=np.array([0.10+0.80*(v[0]-xs.min())/max(np.ptp(xs),1e-9),
                            0.42+0.43*(v[1]-ys.min())/max(np.ptp(ys),1e-9)])
    for center,comp in zip(np.linspace(0.06,0.90,len(comps)-1),comps[1:]):
        for node,yy in zip(sorted(comp.nodes()),np.linspace(0.27,0.09,len(comp))):
            pos[node]=np.array([center,yy])
    assert set(pos)==set(graph.nodes())
    return pos,comps


def draw_ppi(ax, nodes, edges):
    graph=nx.from_pandas_edgelist(edges,"from","to",edge_attr="combined_score")
    direction=nodes.set_index("gene").direction.to_dict();pos,comps=component_positions(graph)
    for u,v in graph.edges():
        sc=graph[u][v]["combined_score"]
        nx.draw_networkx_edges(graph,pos,edgelist=[(u,v)],ax=ax,width=0.4+2.0*(sc-400)/600,
                               alpha=0.25+0.55*(sc-400)/600,edge_color="#737373")
    nx.draw_networkx_nodes(graph,pos,ax=ax,node_color=[DIRECTION_COLORS[direction[n]] for n in graph.nodes()],
                          node_size=[70+35*graph.degree(n) for n in graph.nodes()],edgecolors="white",linewidths=0.8)
    if "MPO" in graph:
        nx.draw_networkx_nodes(graph,pos,nodelist=["MPO"],ax=ax,node_color=[DIRECTION_COLORS[direction["MPO"]]],
                              node_size=[70+35*graph.degree("MPO")],edgecolors="black",linewidths=1.8)
    nx.draw_networkx_labels(graph,pos,labels={n:n for n in comps[0]},ax=ax,font_size=7.0,font_weight="bold",
                            bbox={"facecolor":"white","edgecolor":"none","alpha":0.82,"pad":0.20})
    for comp in comps[1:]:
        for n in comp:
            ax.annotate(n,pos[n],xytext=(7,0),textcoords="offset points",ha="left",va="center",fontsize=6.9,fontweight="bold")
    ax.set_xlim(-0.05,1.09);ax.set_ylim(-0.01,1.0);ax.set_axis_off();add_letter(ax,"C",-0.07,1.05)
    ax.text(0.0,0.99,"STRING v12 physical; score >= 400; no added neighbors",transform=ax.transAxes,
            ha="left",va="top",fontsize=7.5,color="#444444")
    handles=[Line2D([0],[0],marker="o",color="none",markerfacecolor=c,markeredgecolor="white",markersize=6,label=l)
             for c,l in [("#E64B35","Up"),("#4DBBD5","Down")]]
    handles.append(Line2D([0],[0],marker="o",color="none",markerfacecolor="#4DBBD5",markeredgecolor="black",markersize=6,label="MPO"))
    ax.legend(handles=handles,frameon=False,ncol=3,fontsize=7.0,loc="upper right",bbox_to_anchor=(1.0,0.95),handletextpad=0.25,columnspacing=0.8)
    ax.text(0.0,-0.015,"Mapped 70/72; connected 26; isolated 46; edges 37",transform=ax.transAxes,
            ha="left",va="top",fontsize=7.5,color="#444444")
    pd.DataFrame([{"gene":n,"x":float(v[0]),"y":float(v[1]),"degree":graph.degree(n)} for n,v in pos.items()]).to_csv(OUT/"01_ppi_layout_coordinates.tsv",sep="\t",index=False)
    return nodes.loc[nodes.gene.isin(graph.nodes())].copy()


def draw_single_cell(ax: plt.Axes, concordance: pd.DataFrame) -> pd.DataFrame:
    lookup = concordance.set_index("pathway")
    data = pd.DataFrame({"pathway": PATHWAY_LABELS,
        "adult": [float(lookup.loc[k, "adult_sc_LCDI_rho"]) for k in PATHWAY_IDS],
        "pediatric": [float(lookup.loc[k, "pediatric_sc_LCDI_rho"]) for k in PATHWAY_IDS]})
    matrix = data[["adult", "pediatric"]].to_numpy(); vmax = max(abs(matrix.min()), abs(matrix.max()))
    image = ax.imshow(matrix, cmap="RdBu_r", vmin=-vmax, vmax=vmax, aspect="auto")
    for i in range(matrix.shape[0]):
        for j in range(matrix.shape[1]):
            ax.text(j, i, f"{matrix[i, j]:+.2f}", ha="center", va="center", fontsize=8.7,
                    color="white" if abs(matrix[i, j]) > 0.30 else "#222222",
                    fontweight="bold" if abs(matrix[i, j]) > 0.30 else "normal")
    ax.set_xticks([0, 1], ["Adult", "Pediatric"], fontsize=9.4)
    ax.tick_params(axis="x", top=True, labeltop=True, bottom=False, labelbottom=False, length=0)
    ax.set_yticks(np.arange(len(data)), PATHWAY_LABELS, fontsize=8.0); ax.tick_params(axis="y", length=0)
    for edge in np.arange(-0.5, 2.5, 1): ax.axvline(edge, color="white", lw=2)
    for edge in np.arange(-0.5, len(data) + 0.5, 1): ax.axhline(edge, color="white", lw=2)
    cbar = ax.figure.colorbar(image, ax=ax, fraction=0.055, pad=0.03)
    cbar.set_label("Cell-level Spearman rho", fontsize=8.2)
    add_letter(ax, "D", -0.30, 1.10)
    ax.text(0.5, -0.10, "Descriptive cell-level associations; cells are not independent biological replicates",
            transform=ax.transAxes, ha="center", va="top", fontsize=6.9, color="#444444")
    return data


def draw_control(ax: plt.Axes, controlled: pd.DataFrame) -> pd.DataFrame:
    data = controlled.loc[(controlled.predictor == "LCDI_z") & (controlled.family == "pathway")].copy()
    label_to_id = dict(zip(PATHWAY_LABELS, PATHWAY_IDS)); data["endpoint_id_order"] = data.endpoint.map(label_to_id)
    data["order"] = data.endpoint_id_order.map({key: i for i, key in enumerate(PATHWAY_IDS)})
    data = data.sort_values(["order", "dataset"])
    base_y = {label: len(PATHWAY_LABELS) - 1 - i for i, label in enumerate(PATHWAY_LABELS)}
    offsets = {"adult": 0.17, "pediatric": -0.17}
    for row in data.itertuples(index=False):
        yy = base_y[row.endpoint] + offsets[row.dataset]; color = DATASET_COLORS[row.dataset]
        raw = float(row.raw_record_rho); adjusted = float(row.patient_and_lineage_controlled_rho)
        ax.plot([raw, adjusted], [yy, yy], color=color, lw=1.8, alpha=0.85)
        ax.scatter(raw, yy, s=42, facecolor="white", edgecolor=color, linewidth=1.4, zorder=3)
        ax.scatter(adjusted, yy, s=42, facecolor=color, edgecolor="white", linewidth=0.5, zorder=3)
    ax.axvline(0, color="#777777", ls="--", lw=0.9)
    ax.set_yticks([base_y[label] for label in PATHWAY_LABELS], PATHWAY_LABELS, fontsize=8.0)
    ax.set_xlabel("Spearman rho", fontsize=9.0); ax.set_xlim(-0.70, 0.30)
    ax.grid(axis="x", color="#E6E6E6", lw=0.55); ax.set_axisbelow(True)
    ax.spines[["top", "right"]].set_visible(False); add_letter(ax, "E", -0.23, 1.10)
    handles = [Line2D([0], [0], color=DATASET_COLORS["adult"], lw=2, label="Adult"),
               Line2D([0], [0], color=DATASET_COLORS["pediatric"], lw=2, label="Pediatric"),
               Line2D([0], [0], marker="o", color="#666666", markerfacecolor="white", lw=0, label="Raw"),
               Line2D([0], [0], marker="o", color="#666666", markerfacecolor="#666666", lw=0, label="Controlled")]
    ax.legend(handles=handles, frameon=False, ncol=4, loc="upper center", bbox_to_anchor=(0.5, 1.08),
              fontsize=7.4, handlelength=1.3, columnspacing=0.8)
    ax.text(0.5, -0.11, "Adult: 11 patients/33 records; Pediatric: 15 patients/42 records; 2,000 patient-cluster bootstraps\nCross-age controlled pathway gate: 0/7",
            transform=ax.transAxes, ha="center", va="top", fontsize=7.0, color="#444444")
    return data


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    if PDF.exists(): raise FileExistsError("Refusing to overwrite existing PDF")
    missing = [str(path) for path in SOURCES.values() if not path.is_file()]
    if missing: raise FileNotFoundError(missing)
    mpl.rcParams.update({"font.family": "Arial", "font.size": 9, "pdf.fonttype": 42})
    curves = pd.read_csv(SOURCES["gsea_curves"], sep="\t")
    hits = pd.read_csv(SOURCES["gsea_hits"], sep="\t")
    terms = pd.read_csv(SOURCES["gsea_terms"], sep="\t")
    ora = pd.read_csv(SOURCES["ora_plot_terms"], sep="\t")
    nodes = pd.read_csv(SOURCES["ppi_nodes"], sep="\t"); edges = pd.read_csv(SOURCES["ppi_edges"], sep="\t")
    concordance = pd.read_csv(SOURCES["bulk_sc_concordance"], sep="\t")
    controlled = pd.read_csv(SOURCES["controlled_associations"], sep="\t")

    fig = plt.figure(figsize=(18.5, 12.6), facecolor="white")
    outer = fig.add_gridspec(2, 1, height_ratios=[1.20, 0.80], left=0.05, right=0.975,
                             top=0.96, bottom=0.075, hspace=0.28)
    top = outer[0].subgridspec(1, 2, width_ratios=[0.43, 0.57], wspace=0.25)
    agrid = top[0, 0].subgridspec(2, 1, height_ratios=[0.82, 0.18], hspace=0.03)
    ax_a = fig.add_subplot(agrid[0, 0]); ax_arug = fig.add_subplot(agrid[1, 0])
    bgrid = top[0, 1].subgridspec(2, 2, hspace=0.48, wspace=0.66)
    baxes = [fig.add_subplot(bgrid[i, j]) for i in range(2) for j in range(2)]
    bottom = outer[1].subgridspec(1, 3, width_ratios=[0.37, 0.27, 0.36], wspace=0.60)
    ax_c = fig.add_subplot(bottom[0, 0]); ax_d = fig.add_subplot(bottom[0, 1]); ax_e = fig.add_subplot(bottom[0, 2])

    gsea_selected = draw_gsea(ax_a, ax_arug, curves, hits, terms)
    ora_selected = select_ora_terms(ora); draw_ora(baxes, ora_selected)
    ppi_plotted = draw_ppi(ax_c, nodes, edges)
    sc_data = draw_single_cell(ax_d, concordance); control_data = draw_control(ax_e, controlled)
    assert all(not ax.get_title() and not ax.get_title(loc="left") and not ax.get_title(loc="right") for ax in fig.axes)
    fig.savefig(PDF, bbox_inches="tight", facecolor="white")
    pd.DataFrame([{"axes":i,"title":ax.get_title(),"x0":ax.get_position().x0,"y0":ax.get_position().y0,"width":ax.get_position().width,"height":ax.get_position().height} for i,ax in enumerate(fig.axes)]).to_csv(OUT/"01_axes_no_titles.tsv",sep="\t",index=False)
    plt.close(fig)

    gsea_selected.to_csv(OUT / "01_panelA_gsea_top5_terms.tsv", sep="\t", index=False)
    ora_selected.to_csv(OUT / "01_panelB_go_kegg_terms.tsv", sep="\t", index=False)
    ppi_plotted.to_csv(OUT / "01_panelC_ppi_connected_nodes.tsv", sep="\t", index=False)
    edges.to_csv(OUT / "01_panelC_ppi_edges.tsv", sep="\t", index=False)
    sc_data.to_csv(OUT / "01_panelD_singlecell_pathways.tsv", sep="\t", index=False)
    control_data.to_csv(OUT / "01_panelE_controlled_pathways.tsv", sep="\t", index=False)
    pd.DataFrame([{"source_id": key, "path": str(path), "bytes": path.stat().st_size, "sha256": sha256(path)}
                  for key, path in SOURCES.items()]).to_csv(OUT / "01_source_manifest.tsv", sep="\t", index=False)
    pd.DataFrame([
        {"panel": "A", "position": "top_left", "content": "top5_Hallmark_GSEA_running_curves"},
        {"panel": "B", "position": "top_right", "content": "GO_BP_CC_MF_and_KEGG_GeneRatio_dotplots"},
        {"panel": "C", "position": "bottom_left", "content": "STRING_v12_physical_PPI_all_connected_nodes"},
        {"panel": "D", "position": "bottom_center", "content": "adult_pediatric_cell_level_pathway_rho"},
        {"panel": "E", "position": "bottom_right", "content": "raw_to_patient_lineage_controlled_pathway_rho"},
    ]).to_csv(OUT / "01_layout_manifest.tsv", sep="\t", index=False)
    pd.DataFrame([{"field": "status", "value": "rendered_pending_visual"}, {"field": "layout", "value": "AB/CDE"},
        {"field": "formal_pdf", "value": "1"}, {"field": "formal_png", "value": "0"},
        {"field": "panel_titles", "value": "0"}, {"field": "analysis_rerun", "value": "0"},
        {"field": "visual_qa_dpi", "value": "400"}, {"field": "seed", "value": "20260905_PPI_layout_only"},
        {"field": "reference_scripts_role", "value": "prior_project_Figure4_v2_layout_only"},
    ]).to_csv(OUT / "02_run_status.tsv", sep="\t", index=False)
    summary = {"status": "rendered_pending_visual", "pdf": str(PDF), "pdf_bytes": PDF.stat().st_size,
        "pdf_sha256": sha256(PDF), "panels": 5, "gsea_top_terms": int(len(gsea_selected)),
        "ora_terms_plotted": int(len(ora_selected)), "ppi_nodes_plotted": int(len(ppi_plotted)),
        "ppi_edges": int(len(edges)), "singlecell_pathways": int(len(sc_data)),
        "controlled_rows": int(len(control_data)), "formal_png": 0}
    (OUT / "02_generation_summary.json").write_text(json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()

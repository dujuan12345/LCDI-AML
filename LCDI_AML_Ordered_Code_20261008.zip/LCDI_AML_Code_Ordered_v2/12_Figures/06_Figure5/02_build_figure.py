from pathlib import Path
import json,hashlib,sys
import numpy as np,pandas as pd,matplotlib as mpl
mpl.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
R=Path(r'D:\26_01_AML');O=Path(__file__).parent;P=R/'_codex_audit/figure5_three_panel_20260907_v1';V=R/'_codex_audit/candidate_reassessment_20260905_v2'
sources=[V/'03_all_lineage_LCDI_directions.tsv',O/'03_new_gene_associations.tsv',P/'02_panel_A.tsv',P/'02_panel_B.tsv',P/'02_panel_C.tsv',P/'02_gene_counts.tsv',P/'03_abbreviations.tsv']
a,b,c,d,e,counts,ab=[pd.read_csv(p,sep='\t') for p in sources]
a=a[a.kept].copy();markers=['MEIS1','NRIP1','MSI2','ELANE','AZU1','LYZ','MNDA','CD14'];b=b[b.endpoint_id.isin(markers)].copy()
assert len(a)==8 and len(b)==32 and len(c)==16 and len(d)==96 and len(e)==104
assert set(b.predictor)=={'LCDI_z','MPO_risk_z'} and set(b.n)=={16,22}
assert not b.duplicated(['dataset','endpoint_id','predictor']).any()
assert all(b.bootstrap_ci_low<=b.rho) and all(b.bootstrap_ci_high>=b.rho)
assert sum(a[a.dataset=='pediatric'].spearman_rho>0)==2
for frame,name in [(a,'A_branches'),(b,'B_patient_markers'),(c,'C_network_correlation'),(d,'D_shared_pathways'),(e,'E_candidate_pathways'),(counts,'C_gene_counts')]:frame.to_csv(O/f'02_{name}.tsv',sep='\t',index=False,encoding='utf-8-sig')
targets=['MPO','CASP1','GPX4','CREB1'];colors={'adult':'#32688E','pediatric':'#C46735'};names={'adult':'Adult','pediatric':'Pediatric'}
mpl.rcParams.update({'font.family':'Arial','font.size':11.5,'pdf.fonttype':42,'axes.unicode_minus':False})
fig=plt.figure(figsize=(10,12.4),facecolor='white')
def clean(ax):
 for side in ['top','right','left']:ax.spines[side].set_visible(False)
 ax.spines['bottom'].set_color('#A7B3BE');ax.tick_params(axis='y',length=0);ax.tick_params(axis='x',labelsize=11.2)
 ax.axvline(0,c='#A7B3BE',lw=.8,ls='--',zorder=0)
def letter(x,y,s):fig.text(x,y,s,fontsize=19,fontweight='bold')
letter(.025,.97,'A');letter(.43,.97,'B');letter(.025,.65,'C');letter(.025,.325,'D');letter(.44,.325,'E')
# A: two cohort views, highlighted L3 and a thin L1 reference; original median bins.
trajectory_root=R/'_codex_audit/figure5_composite_20260903_v2'
tp=trajectory_root/'03_panelA_pseudotime_points.tsv';tb=trajectory_root/'03_panelA_pseudotime_bins.tsv';ts=trajectory_root/'03_panelA_pseudotime_stats.tsv'
points=pd.read_csv(tp,sep='\t');bins=pd.read_csv(tb,sep='\t');stats=pd.read_csv(ts,sep='\t');sources.extend([tp,tb,ts])
assert len(stats)==4 and set(stats.lineage)=={'L1','L3'}
trajectory_export=[]
for j,ds in enumerate(['adult','pediatric']):
 ax=fig.add_axes([.105,.862-j*.12,.265,.080])
 for lin in ['L1','L3']:
  block=bins[(bins.dataset==names[ds])&(bins.lineage==lin)].sort_values('pseudotime').copy()
  # Each trajectory is mapped to its own cached median-bin range, exactly as in the prior figure.
  low,high=block.pseudotime.min(),block.pseudotime.max();block['scaled_pt']=(block.pseudotime-low)/(high-low)
  trajectory_export.append(block)
  if lin=='L3':
   cloud=points[(points.dataset==names[ds])&(points.lineage==lin)].copy();xp=((cloud.pseudotime-low)/(high-low)).clip(0,1)
   ax.scatter(xp,cloud.LCDI_score,s=1.1,c=colors[ds],alpha=.045,edgecolors='none',rasterized=True,zorder=1)
  ax.plot(block.scaled_pt,block.LCDI_score,color=colors[ds],lw=2.2 if lin=='L3' else 1.2,ls='-' if lin=='L3' else '--',alpha=1 if lin=='L3' else .68,zorder=3 if lin=='L3' else 2)
 ax.axhline(0,c='#CCD3D8',lw=.6,zorder=0);ax.set_xlim(0,1);ax.set_ylim(-1.16,.32);ax.set_yticks([-1,0]);ax.tick_params(labelsize=11.2);ax.set_ylabel('LCDI',fontsize=11.5,labelpad=2)
 ax.set_xticks([0,.5,1]);ax.set_xlabel('Scaled pseudotime',fontsize=11.5 if j==1 else 0) if j==1 else None
 if j==0:ax.tick_params(axis='x',labelbottom=False)
 for side in ['top','right']:ax.spines[side].set_visible(False)
 ax.spines['left'].set_color('#A7B3BE');ax.spines['bottom'].set_color('#A7B3BE')
 ax.text(.02,.90,names[ds],transform=ax.transAxes,color=colors[ds],fontsize=11.5,va='top')
 rho=float(stats[(stats.dataset==names[ds])&(stats.lineage=='L3')].spearman_rho.iloc[0]);ax.text(.98,.10,f'L3 rho={rho:+.3f}',transform=ax.transAxes,ha='right',fontsize=11.2)
pd.concat(trajectory_export).to_csv(O/'02_A_trajectory_bins.tsv',sep='\t',index=False,encoding='utf-8-sig');stats.to_csv(O/'02_A_trajectory_stats.tsv',sep='\t',index=False,encoding='utf-8-sig')
fig.legend(handles=[Line2D([],[],c='#425B70',lw=2.2,label='L3'),Line2D([],[],c='#425B70',lw=1.2,ls='--',label='L1')],loc='center',bbox_to_anchor=(.24,.953),ncol=2,frameon=False,fontsize=11.2,columnspacing=1.4)
# B: patient-level forest plots, preserving both predictors and all six markers.
for j,ds in enumerate(['adult','pediatric']):
 ax=fig.add_axes([.16+j*.44,.417,.30,.195]);clean(ax)
 for i,g in enumerate(markers):
  if i in [0,5]:ax.axhspan(i-.5,i+2.5,color='#F3F6F8',zorder=-1)
  for pred,off,shape in [('LCDI_z',-.25,'o'),('MPO_risk_z',.25,'D')]:
   r=b[(b.dataset==ds)&(b.endpoint_id==g)&(b.predictor==pred)].iloc[0];y=i+off
   ax.plot([r.bootstrap_ci_low,r.bootstrap_ci_high],[y,y],color=colors[ds],alpha=.55,lw=1.1,zorder=1)
   ax.plot(r.rho,y,marker=shape,ms=5.3,mfc=colors[ds] if r.fdr<.05 else 'white',mec=colors[ds],mew=1.1,ls='',zorder=3)
   nominal=(r.p_value<.05 and r.fdr>=.05);label='*' if r.fdr<.05 else ('†' if nominal else '')
   ax.text(1.10,y,label,transform=ax.get_yaxis_transform(),ha='center',va='center',fontsize=11.2,color=colors[ds] if r.fdr<.05 else '#47535F',fontweight='bold' if r.fdr<.05 else 'normal',clip_on=False)
 ax.set_ylim(7.55,-.55);ax.set_xlim(-1.05,1.05);ax.set_xticks([-1,0,1]);ax.set_yticks(range(8),markers if j==0 else [],fontsize=11.5);ax.set_xlabel('Spearman rho',fontsize=11.5)
 ax.text(.5,1.075,f'{names[ds]} (n={16 if j==0 else 22})',transform=ax.transAxes,ha='center',color=colors[ds],fontsize=12)
predhandles=[Line2D([],[],marker='o',ls='',mfc='white',mec='#34495E',label='LCDI'),Line2D([],[],marker='D',ls='',mfc='white',mec='#34495E',label='MPO-risk')]
predhandles.extend([Line2D([],[],ls='',label='† P<0.05 only'),Line2D([],[],ls='',label='* FDR<0.05')])
fig.legend(handles=predhandles,loc='center',bbox_to_anchor=(.58,.362),ncol=4,frameon=False,fontsize=11.2,columnspacing=.7,handletextpad=.4)
# C: response correlations and strict gene overlap.
ax=fig.add_axes([.105,.115,.265,.17]);mat=c.pivot(index='row_target',columns='column_target',values='rho').loc[targets,targets].to_numpy();ax.imshow(mat,cmap='Blues',vmin=0,vmax=1,aspect='auto')
ax.set_xticks(range(4),targets,rotation=40,ha='right',fontsize=11.2);ax.set_yticks(range(4),targets,fontsize=11.2);ax.tick_params(length=0)
for i in range(4):
 for j in range(4):ax.text(j,i,f'{mat[i,j]:.2f}',ha='center',va='center',fontsize=12,color='white' if mat[i,j]>.65 else '#173147')
for s in ax.spines.values():s.set_visible(False)
ax.set_xticks(np.arange(-.5,4,1),minor=True);ax.set_yticks(np.arange(-.5,4,1),minor=True);ax.grid(which='minor',color='white',lw=1.4);ax.tick_params(which='minor',length=0)
fig.text(.105,.308,'Upper: Adult / Lower: Pediatric',fontsize=11.2);fig.text(.105,.293,'Diagonal: cross-dataset',fontsize=11.2)
tax=fig.add_axes([.105,.028,.265,.045]);tax.axis('off');cc=pd.read_csv(R/'_codex_audit/figure5E_overlap_20260907_v1/02_overlap_counts.tsv',sep='\t').set_index('target').loc[targets];tab=tax.table(cellText=[cc.adult.tolist(),cc.pediatric.tolist(),cc.overlap.tolist()],rowLabels=['Adult P','Pedi P','Overlap'],cellLoc='center',bbox=[0,0,1,1]);tab.auto_set_font_size(False);tab.set_fontsize(11.2)
for (i,j),cell in tab.get_celld().items():cell.set_edgecolor('#DCE2E8');cell.set_linewidth(.5);cell.set_facecolor('#F1F5F8' if i==2 else 'white')
# D: fixed-size tile heatmap. All displayed shared terms meet FDR; no bubble encoding.
lookup=ab.set_index('ID');dids=d.ID.drop_duplicates().tolist();columns=[(ds,g) for ds in ['adult','pediatric'] for g in targets]
dm=np.array([[d[(d.ID==k)&(d.dataset==ds)&(d.target==g)].NES.iloc[0] for ds,g in columns] for k in dids]);assert d.FDR.lt(.05).all() and dm.min()>0
ax=fig.add_axes([.59,.043,.315,.239]);im=ax.imshow(dm,cmap='YlOrRd',vmin=0,vmax=4,aspect='auto')
ax.set_yticks(range(12),[lookup.loc[k,'abbreviation'] for k in dids],fontsize=11.5);ax.set_xticks(range(8),targets*2,rotation=45,ha='left',rotation_mode='anchor',fontsize=11.2);ax.tick_params(axis='x',top=True,labeltop=True,bottom=False,labelbottom=False,length=0,pad=2);ax.tick_params(axis='y',length=0)
ax.set_xticks(np.arange(-.5,8,1),minor=True);ax.set_yticks(np.arange(-.5,12,1),minor=True);ax.grid(which='minor',color='white',lw=1.1);ax.tick_params(which='minor',length=0);ax.axvline(3.5,c='#52697B',lw=1.5)
for s in ax.spines.values():s.set_visible(False)
for x,ds in [(1.5,'adult'),(5.5,'pediatric')]:ax.text(x,1.145,names[ds],transform=ax.get_xaxis_transform(),ha='center',color=colors[ds],fontsize=12)
ca=fig.add_axes([.926,.071,.016,.17]);cb=fig.colorbar(im,cax=ca,ticks=[0,2,4]);cb.ax.tick_params(labelsize=11.2);cb.ax.text(.5,1.06,'NES',transform=cb.ax.transAxes,ha='center',fontsize=11.5)

fig.text(.105,.011,'P < 0.05; common tested genes',fontsize=10)

import matplotlib.patheffects as pe
U=R/'_codex_audit/figure5B_umap_20260907_v1'
qa={}
groups=['HSC','Prog','GMP','Gran','ProMono','Mono','cDC','pDC','HLA-II']
colors=dict(zip(groups,['#8465A9','#6386C7','#3BA6A0','#8BAC49','#D6AF4A','#D47A55','#C0649B','#8B6F58','#9A9DA4']))
mapping={'MPP_GMP':'Prog','MPP_MEP':'Prog','Granulocytes':'Gran','Granulocytes (cycling)':'Gran','HLA-II+':'HLA-II','CD14+':'Mono','CD16+':'Mono','CD14+ IFN+':'Mono','DC precursor':'cDC','cDC1':'cDC','cDC2':'cDC'}
for j,ds in enumerate(['adult','pediatric']):
 ax=fig.add_axes([.47+j*.255,.735,.225,.205])
 cp=U/f'03_{ds}_cells.tsv';lp=U/f'03_{ds}_curves.tsv';sources.extend([cp,lp])
 c=pd.read_csv(cp,sep='\t');curves=pd.read_csv(lp,sep='\t');assert not c.cell.duplicated().any()
 c['display_group']=c.celltype.map(lambda v:mapping.get(v,v.replace('-like','')))
 assert set(c.display_group)<=set(groups),set(c.display_group)-set(groups)
 c[['cell','celltype','display_group']].to_csv(O/f'04_{ds}_annotation_map.tsv',sep='\t',index=False)
 for group in groups:
  block=c[c.display_group==group];ax.scatter(block.UMAP1,block.UMAP2,s=1.0,alpha=.48,c=colors[group],edgecolors='none',rasterized=True)
 for lin in curves.lineage.unique():
  if lin in ['L1','L3']:continue
  b=curves[curves.lineage==lin].sort_values('order');ax.plot(b.UMAP1,b.UMAP2,color='#777777',alpha=.28,lw=.75,zorder=3)
 for lin in ['L1','L3']:
  b=curves[curves.lineage==lin].sort_values('order').drop_duplicates(['UMAP1','UMAP2']);xy=b[['UMAP1','UMAP2']].to_numpy()
  ax.plot(xy[:,0],xy[:,1],color='#20252B',lw=1.5 if lin=='L3' else 1.1,ls='-' if lin=='L3' else '--',zorder=5,path_effects=[pe.Stroke(linewidth=2.5,foreground='white',alpha=.65),pe.Normal()])
  end=xy[-1];ax.annotate(lin,xy=end,xytext=(7,6 if lin=='L3' else -12),textcoords='offset points',fontsize=9,fontweight='bold',zorder=8,bbox=dict(facecolor='white',edgecolor='none',alpha=.8,pad=1))
  if lin=='L3':
   ax.plot(*xy[0],marker='*',ms=9,mfc='white',mec='#20252B',mew=1.2,zorder=7)
   ax.annotate('Start',xy=xy[0],xytext=(-8,12),textcoords='offset points',fontsize=8,ha='right',zorder=8,bbox=dict(facecolor='white',edgecolor='none',alpha=.8,pad=1))
 ax.set_aspect('equal',adjustable='datalim');ax.margins(.09);ax.set_xlabel('UMAP1',fontsize=9);ax.set_ylabel('UMAP2' if ds=='adult' else '',fontsize=9)
 for side in ['top','right']:ax.spines[side].set_visible(False)
 ax.spines['left'].set_color('#AAB5BE');ax.spines['bottom'].set_color('#AAB5BE');ax.tick_params(labelsize=8)
 ax.text(.5,-.22,'Adult' if ds=='adult' else 'Pediatric',transform=ax.transAxes,ha='center',fontsize=10)
 qa[ds]={'cells':len(c),'curves':curves.lineage.nunique(),'groups':c.groupby('display_group').size().to_dict()}

fig.legend(handles=[Line2D([],[],color='#20252B',lw=1.5,label='L3'),Line2D([],[],color='#20252B',lw=1.1,ls='--',label='L1'),Line2D([],[],color='#777777',alpha=.5,lw=.8,label='Other'),Line2D([],[],ls='',marker='*',ms=8,mfc='white',mec='#20252B',label='Start')],loc='center',bbox_to_anchor=(.72,.968),ncol=4,frameon=False,fontsize=9,columnspacing=1)
fig.legend(handles=[Line2D([],[],marker='o',ls='',color=colors[g],ms=5,label=g) for g in groups],loc='center',bbox_to_anchor=(.72,.663),ncol=5,frameon=False,columnspacing=.9,handletextpad=.25,fontsize=9)
assert all(not ax.get_title() for ax in fig.axes)
pdf=O/'Figure5_rearranged_v27.pdf';fig.savefig(pdf);plt.close(fig)
qc={'layout':'A LCDI trajectory; B UMAP; C marker associations; D network correlation and nominal intersection; E shared pathways','C_associations':32,'D_overlap':[0,1,2,24],'E_NES':96,'internal_titles':0,'source_hashes':{str(p):hashlib.sha256(p.read_bytes()).hexdigest() for p in sources},'PDF_SHA256':hashlib.sha256(pdf.read_bytes()).hexdigest(),'visual_QA':'pending'}
(O/'02_figure_QC.json').write_text(json.dumps(qc,indent=2),encoding='utf-8');print('Figure built')

from pathlib import Path
import pandas as pd,numpy as np,matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.colors import ListedColormap,BoundaryNorm
import json,hashlib
P=Path(__file__).parent;R=P.parent.parent;S=P/'supplement_figures';S.mkdir(exist_ok=True)
sources=[]
def rd(p):
    f=R/p;sources.append(f);return pd.read_csv(f,sep='\t')
plt.rcParams.update({'font.family':'Arial','font.size':9,'pdf.fonttype':42,'axes.spines.top':False,'axes.spines.right':False})
blue='#2B6C9C';orange='#D87843'
def letter(ax,s):ax.text(-.1,1.06,s,transform=ax.transAxes,fontweight='bold',fontsize=13)
def save(fig,n):
    fig.savefig(S/f'FigureS{n}.pdf',bbox_inches='tight');fig.savefig(S/f'_FigureS{n}_embed.png',dpi=240,bbox_inches='tight');plt.close(fig)
captions={}
# S1: fixed, already fitted interaction models; no survival refitting.
effects=rd('_codex_audit/chapter6_interactions_20260731_v1/interaction_group_specific_effects.tsv')
tests=rd('_codex_audit/chapter6_interactions_20260731_v1/interaction_global_tests.tsv')
assert len(effects)==12 and len(tests)==4
fig,axs=plt.subplots(1,2,figsize=(10,4.0),gridspec_kw={'width_ratios':[1.3,1]});fig.subplots_adjust(left=.18,right=.98,bottom=.23,top=.88,wspace=.7)
for ax,prefix,lab in zip(axs,['LCDI_by_age_group','MPO_by_AYA_status'],['A','B']):
    sub=effects[effects.model==prefix];y=np.arange(len(sub))
    for suf,color,off,marker,label in [('',blue,-.10,'o','Unadjusted'),('_adjusted_cyto',orange,.10,'s','Cyto-adjusted')]:
        z=effects[effects.model==prefix+suf];x=z.HR_per_global_SD.to_numpy()
        ax.errorbar(x,y+off,xerr=np.vstack([x-z.CI_low,z.CI_high-x]),fmt=marker,color=color,capsize=2,label=label,ms=4)
    labels=['0-<2','2-<10','10-<21','>=21'] if lab=='A' else ['Non-AYA','AYA']
    ax.set_yticks(y,[f'{v}  ({n}/{e})' for v,n,e in zip(labels,sub.n,sub.events)]);ax.invert_yaxis();ax.set_ylim(len(sub)-.5,-.5)
    ax.axvline(1,color='.65',lw=.8,ls='--');ax.set_xlabel(('LCDI' if lab=='A' else 'MPO expression')+' HR per global SD');letter(ax,lab)
    z=tests[tests.model.str.startswith(prefix)];ax.text(0,-.29,'Interaction P: '+ ' / '.join(f'{v:.4g}' for v in z.P),transform=ax.transAxes,fontsize=8)
axs[0].legend(loc='lower left',bbox_to_anchor=(0,1.01),frameon=False,ncol=2,fontsize=8);save(fig,1)
captions[1]='补图S1 TARGET年龄异质性及细胞遗传学风险调整。A，LCDI在0–<2、2–<10、10–<21及≥21岁组的Cox交互模型分层HR；B，MPO表达在AYA（10–<21岁）与Non-AYA组的HR。括号为患者数/死亡事件；总n=1,944，事件685。蓝圆为未调整，橙方为细胞遗传学风险调整，线段为95%CI；两评分均按TARGET全体SD标准化，MPO为表达升高方向而非MPO-risk。LCDI全局交互P/FDR未调整0.0330/0.0330、调整0.0729/0.0729；MPO为0.001685/0.003370与0.002073/0.004146，两项同类交互分别作BH校正。LCDI交互项PH诊断P约0.046/0.047，年龄差异保持探索性定位；本图不表示跨队列复制。Cyto，细胞遗传学风险；SD，标准差。'
# S2: all five genes; effect and uncertainty, not survival interpretation.
ex=rd('_codex_audit/gse13159_expression_validation_20260804_v1/results/primary_five_gene_results.tsv');assert len(ex)==5 and set(ex.n_aml)=={501} and set(ex.n_healthy)=={73}
fig,ax=plt.subplots(figsize=(9,3.5));fig.subplots_adjust(left=.15,right=.63,bottom=.18,top=.83)
x=ex.rank_biserial.to_numpy();y=np.arange(5)
for i,z in ex.iterrows():
    color=orange if z.rank_biserial>0 else blue
    ax.errorbar(z.rank_biserial,i,xerr=[[z.rank_biserial-z.rank_biserial_ci_low],[z.rank_biserial_ci_high-z.rank_biserial]],fmt='o',color=color,capsize=3,mfc=color if z.bh_fdr_5_genes<.05 else 'white')
    ax.text(1.04,i,f'{z.raw_p:.3g}',transform=ax.get_yaxis_transform());ax.text(1.36,i,f'{z.bh_fdr_5_genes:.3g}',transform=ax.get_yaxis_transform())
ax.text(1.04,1.08,'P',transform=ax.transAxes,fontweight='bold');ax.text(1.36,1.08,'FDR',transform=ax.transAxes,fontweight='bold');ax.set_yticks(y,ex.gene);ax.invert_yaxis();ax.axvline(0,color='.6',ls='--',lw=.8);ax.set_xlim(-.5,.85);ax.set_xlabel('Rank-biserial effect (AML vs healthy BM)');save(fig,2)
captions[2]='补图S2 同平台骨髓数据中的五基因表达差异。GSE13159纳入501例AML与73例健康骨髓；每基因使用不依赖分组标签、在纳入样本中平均信号最高的特异_at探针。点为秩二列效应量，正值表示AML表达偏高，负值表示偏低；横线为2,000次患者层Bootstrap 95%CI（seed=20260804），右侧保留双侧Mann–Whitney P及五基因家族BH-FDR，实心表示FDR<0.05。GPX4升高，MPO/CREB1降低；CASP1为名义信号（FDR=0.0536），SLC16A4无支持（FDR=0.9801）。该比较解释AML–健康表达方向，不验证预后系数，也不与TCGA–CD34跨平台比较混为同一对照。BM，骨髓。'
# S3: corrected 580-record scoring, six predefined coupling/algorithm variants.
cu=rd('_codex_audit/upstream_repair_20260905_v1/bulk/cached_supplements/all_corrected_statistics.tsv')
sig=cu[(cu.family=='signatures')&cu.endpoint.str.startswith('Neutrophil_')]
qt=cu[(cu.endpoint=='Neutrophils')&cu.family.str.startswith('quanti_')]
assert len(sig)==len(qt)==3
fig,axs=plt.subplots(1,2,figsize=(10,3.4));fig.subplots_adjust(left=.18,right=.98,bottom=.19,top=.84,wspace=.95)
for ax,z,labels,lab in [(axs[0],sig,['Original','-MPO','-MPO/ELANE/CTSG'],'A'),(axs[1],qt,['Primary','No mRNA scale','Tumor filter'],'B')]:
    y=np.arange(3);ax.hlines(y,0,z.rho,color=blue,lw=2);ax.scatter(z.rho,y,s=36,color=blue)
    ax.set_yticks(y,labels);ax.set_ylim(2.5,-.5);ax.set_xlim(-.65,.03);ax.axvline(0,color='.6',lw=.8);ax.set_xlabel('Spearman rho with LCDI');letter(ax,lab)
    for i,(_,v) in enumerate(z.iterrows()):ax.text(v.rho-.015,i-.2,f'{v.rho:.3f}',ha='right',fontsize=8)
save(fig,3)
captions[3]='补图S3 髓系签名去重叠及去卷积参数敏感性。A，当前冻结LCDI与原中性粒细胞签名、去MPO、再去MPO/ELANE/CTSG签名的相关，rho分别−0.5234、−0.3898、−0.2573，FDR分别4.21×10⁻⁴¹、8.69×10⁻²²、6.49×10⁻¹⁰。B，quantiSeq中性粒细胞推断组分在主参数、不做mRNA含量缩放及tumor过滤参数下的rho分别−0.2430、−0.2388、−0.2137，FDR分别3.35×10⁻⁸、6.33×10⁻⁸、2.25×10⁻⁶。均为GPL96的580条表达记录；P/FDR沿用各既定家族全部终点校正，未为本图六项重新校正。点线展示相关大小而非CI。去重叠后相关衰减但保留负方向；去卷积为组成推断，不等同于实测细胞比例。本图不作为独立患者复现。'
# S4: all saved branches and endpoint modules, descriptive only.
lin=rd('_codex_audit/candidate_reassessment_20260905_v2/03_all_lineage_LCDI_directions.tsv');ep=rd('_codex_audit/chapter8_lightweight_supplements_20260802_v1/04_endpoint_signature_summary.tsv')
assert len(lin)==13 and len(ep)==32
fig=plt.figure(figsize=(10,6));gs=fig.add_gridspec(1,2,width_ratios=[1,1.35],left=.17,right=.94,bottom=.18,top=.89,wspace=.65);ax=fig.add_subplot(gs[0]);ay=fig.add_subplot(gs[1])
lin=lin.assign(k=lin.lineage.str[1:].astype(int)).sort_values(['dataset','k']);y=np.arange(13)
for i,(_,z) in enumerate(lin.iterrows()):
    color=blue if z.dataset=='adult' else orange;ax.plot([0,z.spearman_rho],[i,i],color=color,lw=1);ax.scatter(z.spearman_rho,i,facecolors=color if z.kept else 'white',edgecolors=color,s=35)
ax.set_yticks(y,[('Ad ' if z.dataset=='adult' else 'Pe ')+z.lineage for _,z in lin.iterrows()]);ax.set_ylim(12.7,-.7);ax.set_xlim(-.6,.25);ax.axvline(0,color='.6',lw=.8);ax.set_xlabel('LCDI-pseudotime rho');letter(ax,'A')
ep['label']=ep.dataset.map({'adult':'Ad','pediatric':'Pe'})+' L'+ep.lineage.str.replace('Lineage','');order=['Ad L1','Ad L3','Ad L4','Ad L5','Pe L1','Pe L2','Pe L3','Pe L4'];cols=['progenitor','granulocytic','monocytic','dendritic']
mat=ep.pivot(index='label',columns='marker_set',values='overall_late_minus_early').loc[order,cols]
im=ay.imshow(mat,cmap='RdBu_r',vmin=-1.3,vmax=1.3,aspect='auto');ay.set_yticks(range(8),order);ay.set_xticks(range(4),['Prog','Gran','Mono','DC'],rotation=45,ha='right');letter(ay,'B')
for i in range(8):
    for j in range(4):ay.text(j,i,f'{mat.iloc[i,j]:+.2f}',ha='center',va='center',fontsize=8,color='white' if abs(mat.iloc[i,j])>.8 else 'black')
fig.colorbar(im,ax=ay,shrink=.7,pad=.03,label='Late - early module score');save(fig,4)
captions[4]='补图S4 完整保存分支与端点状态参照。A，成人9条及儿童4条保存轨迹的LCDI–拟时序Spearman rho；实心为保留分支，空心为成人未保留分支，两个数据集的L编号独立。成人rho沿用原汇总精度，细胞数不作为独立患者样本量，不标推断性显著性。B，成人保留L1/L3/L4/L5与儿童L1–L4的晚端（≥90%拟时序分位）减早端（≤10%）模块平均分差。Prog、Gran、Mono、DC分别为项目整理的祖细胞、粒系、单核及树突状态参照，完整基因列表见补充源数据，不是正式谱系追踪。成人L3早晚端共同样本为0，儿童为1，因此B仅描述组成与状态差异，不进行患者配对推断。成人分支选择使用过LCDI相关强度；全分支展示用于披露选择背景，不能作为选择后确认性验证。Ad/Pe，成人/儿童。'
# S5: all available target program comparisons and all five control scenarios.
tf=rd('_codex_audit/upstream_repair_20260905_v1/tf/02_display_corrected_TF_effects.tsv');ss=rd('_codex_audit/upstream_repair_20260905_v1/tf/04_display_adult_control_sensitivity.tsv')
assert len(tf)==72 and len(ss)==170
tforder=['MYC','E2F1','E2F2','E2F3','E2F4','E2F7','E2F8','STAT1','STAT2','IRF1','IRF3','IRF7','IRF9']
tforder=[g for g in tforder if g in set(tf.TF)]+[g for g in tf.TF.unique() if g not in tforder]
tforder=[g for prog in ['MYC/E2F','IFN/STAT/IRF'] for g in tforder if g in set(tf.loc[tf.program==prog,'TF'])]
tf['col']=tf.cohort.map({'Adult':'Ad','Pediatric':'Pe'})+' '+tf.method.replace({'decoupleR':'ULM','SCENIC':'SCN','VIPER':'VIP'})
cols=['Ad ULM','Ad VIP','Ad SCN','Pe ULM','Pe VIP','Pe SCN'];mat=tf.pivot(index='TF',columns='col',values='effect_z').reindex(index=tforder,columns=cols)
fig,axs=plt.subplots(1,2,figsize=(11,5.7),gridspec_kw={'width_ratios':[1.2,1]});fig.subplots_adjust(left=.09,right=.96,bottom=.22,top=.9,wspace=.6)
cm=plt.get_cmap('RdBu_r').copy();cm.set_bad('#E7E7E7');limit=float(np.nanmax(np.abs(mat.values)));im=axs[0].imshow(mat,cmap=cm,vmin=-limit,vmax=limit,aspect='auto');axs[0].set_yticks(range(len(mat)),mat.index);axs[0].set_xticks(range(6),cols,rotation=45,ha='right');letter(axs[0],'A');fig.colorbar(im,ax=axs[0],shrink=.7,pad=.03,label='Standardized source effect')
ss['flip']=~ss.same_direction.astype(bool);ct=ss.groupby(['sensitivity','method']).flip.sum().unstack().reindex(['controls_min20cells','omit_BM1','omit_BM2','omit_BM3','omit_BM4'])
assert int(ct.values.sum())==21
y=np.arange(5);left=np.zeros(5)
for method,color in zip(['decoupleR','VIPER','SCENIC'],[blue,orange,'#8073AC']):
    vals=ct[method].values;axs[1].barh(y,vals,left=left,label=method.replace('decoupleR','ULM'),color=color)
    for i,v in enumerate(vals):
        if v:axs[1].text(left[i]+v/2,i,str(v),ha='center',va='center',color='white',fontsize=8)
    left+=vals
axs[1].set_yticks(y,['Control >=20 cells','Omit BM1','Omit BM2','Omit BM3','Omit BM4']);axs[1].invert_yaxis();axs[1].set_xlabel('Reversed TF-method comparisons');axs[1].legend(frameon=False,loc='upper left',bbox_to_anchor=(0,-.15),ncol=2,fontsize=8);letter(axs[1],'B');save(fig,5)
captions[5]='补图S5 TF活性程序及成人对照来源敏感性。A，MYC/E2F与IFN/STAT/IRF两个既定程序的全部72项可用队列×方法×TF比较，显示已保存标准化来源效应；红/蓝为病例来源相对比较来源高/低，灰格为不可用。MYC/E2F为34/38负方向，IFN为29/34正方向。成人以16例D0病例和4位正常供者比较；儿童为21病例来源及21微环境来源单位，不等于两组独立患者，也不是LCDI High–Low。B，成人最少20细胞控制过滤和逐一省略BM1–BM4供者共170项敏感性结果中发生的21项方向翻转，计数单位为TF×方法×情景，不是21个独立TF。图中不作新的推断性检验，RNA推断活性不等于实测蛋白活性。ULM，decoupleR单变量线性模型；VIP，VIPER；SCN，SCENIC；Ad/Pe，成人/儿童。'
for n,cap in captions.items():(S/f'FigureS{n}_caption.md').write_text(cap+'\n',encoding='utf-8')
allframes={'S1_group_effects':effects,'S1_interactions':tests,'S2_five_gene_expression':ex,'S3_corrected_all_families':cu,'S4_all_lineages':lin,'S4_endpoint_modules':ep,'S5_TF_effects':tf,'S5_control_sensitivity':ss}
for name,frame in allframes.items():frame.to_csv(S/f'{name}.tsv',sep='\t',index=False,encoding='utf-8-sig')
pd.DataFrame([{'path':str(f),'bytes':f.stat().st_size,'sha256':hashlib.sha256(f.read_bytes()).hexdigest()} for f in sources]).to_csv(S/'source_manifest.tsv',sep='\t',index=False,encoding='utf-8-sig')
(S/'03_build_QC.json').write_text(json.dumps({'figures':5,'new_statistical_tests':0,'S1_effects':12,'S2_genes':5,'S3_variants':6,'S4_branches':13,'S4_module_effects':32,'S5_comparisons':72,'S5_sensitivity':170,'S5_reversals':21,'panel_titles':False},indent=2),encoding='utf-8')
print('BUILT 5 SUPPLEMENT FIGURES')

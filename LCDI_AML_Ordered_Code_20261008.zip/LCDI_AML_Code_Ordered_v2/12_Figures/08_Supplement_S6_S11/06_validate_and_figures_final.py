from pathlib import Path
import json
import numpy as np
import pandas as pd
from scipy.optimize import minimize_scalar
from scipy.stats import norm,t
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D

O=Path.cwd()/'review_addendum_4plus1_20260911';F=O/'09_figures'
def rd(p):return pd.read_csv(O/p,sep='\t')
checks=[]
def check(name,value):
 checks.append({'check':name,'pass':bool(value)})
 if not value:
  (O/'11_logs/result_validation.json').write_text(json.dumps(checks,indent=2));raise AssertionError(name)
for log in ['prepare','meta_audited','increment_final','stability_formal','stability_preflight_final']:
 r=json.loads((O/f'11_logs/{log}.run.json').read_text());check(log+'_exit_zero',r['exit_code']==0)
effects=rd('01_cohort_heterogeneity/cohort_effects.tsv');meta=rd('01_cohort_heterogeneity/random_effects_meta_audited.tsv')
for _,r in effects.iterrows():
 d=rd(f'10_tables/{r.dataset}_frozen_components.tsv');pred=sum(d['Z_'+g]*b for g,b in [('CREB1',.0925),('SLC16A4',-.0636),('GPX4',-.0721),('CASP1',-.0106),('MPO',-.2095)])
 check(r.dataset+'_formula',np.max(abs(pred-d.LCDI))<1e-10)
 # Independent pair-count implementation of Harrell concordance (risk orientation).
 ti=d.time.to_numpy();ev=d.status.to_numpy();sc=pred.to_numpy();num=den=0.
 for j in np.where(ev==1)[0]:
  mask=ti>ti[j];den+=mask.sum();num+=(sc[j]>sc[mask]).sum()+.5*(sc[j]==sc[mask]).sum()
  ties=(ti==ti[j])&(ev==0);den+=ties.sum();num+=(sc[j]>sc[ties]).sum()+.5*(sc[j]==sc[ties]).sum()
 check(r.dataset+'_C_independent',abs(num/den-r.cindex)<1e-10)
for _,r in meta.iterrows():
 d=effects.set_index('dataset').loc[r.datasets.split(';')];y=np.log(d.hr.to_numpy());v=((np.log(d.upper)-np.log(d.lower))/3.92).to_numpy()**2
 def objective(tau):
  w=1/(v+tau);mu=sum(w*y)/sum(w);return .5*(sum(np.log(v+tau))+np.log(sum(w))+sum(w*(y-mu)**2))
 opt=minimize_scalar(objective,bounds=(0,1),method='bounded',options={'xatol':1e-13});tau=0 if objective(0)<opt.fun else opt.x;w=1/(v+tau);mu=sum(w*y)/sum(w)
 check(r['set']+'_'+r.CI_method+'_REML',abs(objective(tau)-objective(r.tau2))<1e-7 and abs(np.exp(mu)-r.pooled_HR)<1e-5)
 if r.CI_method=='knha':se=np.sqrt(sum(w*(y-mu)**2)/(len(y)-1)/sum(w));crit=t.ppf(.975,len(y)-1)
 else:se=np.sqrt(1/sum(w));crit=norm.ppf(.975)
 check(r['set']+'_'+r.CI_method+'_CI',max(abs(np.exp([mu-crit*se,mu+crit*se])-np.array([r.lower,r.upper])))<1e-5)
inc=rd('02_mpo_nonmpo_increment/paired_increment.tsv');reps=rd('02_mpo_nonmpo_increment/paired_bootstrap_replicates.tsv');cond=rd('02_mpo_nonmpo_increment/conditional_survival.tsv')
for _,r in inc.iterrows():
 z=reps[reps.dataset==r.dataset];v=(z['M1_'+r.metric]-z['M0_'+r.metric]).dropna()
 check(r.dataset+'_'+r.metric+'_paired_values',np.allclose(v,z.loc[v.index,'delta_'+r.metric]))
 check(r.dataset+'_'+r.metric+'_valid',len(v)==r.valid)
 if pd.notna(r.lower):check(r.dataset+'_'+r.metric+'_CI',np.allclose(v.quantile([.025,.975]),[r.lower,r.upper],atol=1e-12))
check('conditional_df_one',(cond.df==1).all());check('TCGA_baseline_0561',abs(effects.set_index('dataset').loc['TCGA','cindex']-.561022120518688)<1e-12)
stab=rd('03_selection_stability/formal_stability_summary.tsv');coef=rd('03_selection_stability/formal_all_coefficients.tsv')
for _,r in stab.iterrows():
 v=coef[(coef.level==r.level)&(coef.rule==r.rule)&(coef.gene==r.gene)].coefficient
 check(f'{r.level}_{r.rule}_{r.gene}_frequency',len(v)==1000 and abs((v!=0).mean()-r.selection_frequency)<1e-12 and abs(r.positive_frequency+r.negative_frequency+r.zero_frequency-1)<1e-12)
check('all_results_valid',True)
(O/'11_logs/result_validation.json').write_text(json.dumps(checks,indent=2))

plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':220})
colors={'TARGET':'#527e99','BeatAML2':'#bd785e','GSE71014':'#778c71','GSE106291':'#9687a7','GSE10358':'#bd9c55','TCGA':'#777777','GPL96':'#999999','GPL570':'#bbbbbb'}
primary=['TARGET','BeatAML2','GSE71014','GSE106291'];order=primary+['GSE10358','TCGA','GPL96','GPL570']
def save(fig,name):
 fig.savefig(F/(name+'.pdf'),bbox_inches='tight');fig.savefig(F/(name+'.png'),bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5.8));ds=effects.set_index('dataset');ys=[];labels=[]
for j,n in enumerate(primary+['GSE10358','GPL570']):
 r=ds.loc[n];y=8-j;ax.errorbar(r.hr,y,xerr=[[r.hr-r.lower],[r.upper-r.hr]],fmt='o',color=colors[n],capsize=3);ys.append(y);labels.append(n)
 ax.text(3.1,y,f'{int(r.n)}/{int(r.events)}   {r.hr:.2f} [{r.lower:.2f}, {r.upper:.2f}]',va='center',fontsize=9)
r=meta[(meta['set']=='PRIMARY_META')&(meta.CI_method=='knha')].iloc[0]
ax.errorbar(r.pooled_HR,1,xerr=[[r.pooled_HR-r.lower],[r.upper-r.pooled_HR]],fmt='D',color='black',capsize=4)
ax.plot([r.prediction_lower,r.prediction_upper],[.4,.4],color='black',ls='--',lw=2)
ys += [1,.4];labels += ['Pooled KH','95% PI']
ax.set_yticks(ys,labels);ax.set_xscale('log');ax.set_xlim(.4,7);ax.set_xticks([.5,1,2,3],['0.5','1','2','3']);ax.axvline(1,color='.7',ls=':');ax.set_xlabel('HR per SD');ax.set_ylim(0,9)
ax.text(3.1,8.7,'N / Events     HR [95% CI]',fontsize=9)
ax.axhline(4.5,color='.8',ls='--');ax.text(.43,4.7,'Sensitivity',fontsize=9)
ax.text(.43,.05,f'I² = {r.I2:.1f}%   tau² = {r.tau2:.3f}',fontsize=9)
ax.legend(handles=[Line2D([0],[0],marker='o',ls='',color=colors[n],label=l) for n,l in [('TARGET','Evaluation'),('BeatAML2','Strict'),('GSE71014','Additional'),('GSE10358','Historical'),('GPL570','Records')]],loc='upper center',bbox_to_anchor=(.5,-.15),ncol=5,frameon=False)
save(fig,'S1_external_heterogeneity')

fig,ax=plt.subplots(figsize=(8,5.5));ds=cond.set_index('dataset')
for j,n in enumerate(order):
 r=ds.loc[n];y=len(order)-j;ax.errorbar(r.hr,y,xerr=[[r.hr-r.lower],[r.upper-r.hr]],fmt='o',color=colors[n],capsize=3);ax.text(1.85,y,f'{r.hr:.2f} [{r.lower:.2f}, {r.upper:.2f}]   {r.p:.3g} / {r.FDR:.3g}',va='center',fontsize=9)
ax.set_yticks(range(1,9),order[::-1]);ax.set_xscale('log');ax.set_xlim(.4,4.4);ax.set_xticks([.5,.75,1,1.5],['0.5','0.75','1','1.5']);ax.axvline(1,color='.7',ls=':');ax.axhline(4.5,color='.8',ls='--');ax.set_xlabel('HR per SD');ax.text(1.85,8.7,'HR [95% CI]       P / FDR',fontsize=9);ax.set_ylim(.5,9)
save(fig,'S2_nonMPO_conditional_HR')

ci=inc[inc.metric=='C'].set_index('dataset');fig,(ax,bx)=plt.subplots(1,2,figsize=(9,5.5),sharey=True,gridspec_kw={'width_ratios':[1,1.3]})
for j,n in enumerate(order):
 r=ci.loc[n];y=8-j;ax.plot([r.M0,r.M1],[y,y],color=colors[n]);ax.scatter(r.M0,y,facecolor='white',edgecolor=colors[n],s=40);ax.scatter(r.M1,y,color=colors[n],s=40);bx.errorbar(r.delta,y,xerr=[[r.delta-r.lower],[r.upper-r.delta]],fmt='o',color=colors[n],capsize=3)
ax.set_yticks(range(1,9),order[::-1]);ax.set_xlabel('C-index');bx.set_xlabel('Delta C');bx.axvline(0,color='.7',ls=':');ax.axhline(4.5,color='.8',ls='--');bx.axhline(4.5,color='.8',ls='--');ax.legend(handles=[Line2D([0],[0],marker='o',ls='',markerfacecolor='white',color='black',label='M0'),Line2D([0],[0],marker='o',ls='',color='black',label='M1')],frameon=False)
fig.tight_layout();save(fig,'S3_paired_delta_C')

aa=inc[inc.metric!='C'].copy();aa['year']=aa.metric.str.extract(r'AUC(\d)').astype(int);mat=aa.pivot(index='dataset',columns='year',values='delta').loc[order];fig,ax=plt.subplots(figsize=(6,5.3));im=ax.imshow(mat,cmap='RdBu_r',vmin=-.10,vmax=.10,aspect='auto')
for i,n in enumerate(order):
 for j,y in enumerate([1,3,5]):
  r=aa[(aa.dataset==n)&(aa.year==y)].iloc[0];label=f'{r.delta:+.3f}' if np.isfinite(r.delta) else 'NA';label+='*' if np.isfinite(r.delta) and pd.isna(r.lower) else '';ax.text(j,i,label,ha='center',va='center',color='white' if abs(r.delta)>.065 else 'black')
ax.set_xticks([0,1,2],['1 y','3 y','5 y']);ax.set_yticks(range(8),order);ax.axhline(3.5,color='white',lw=2);fig.colorbar(im,ax=ax,label='Delta AUC');fig.tight_layout();save(fig,'S4_delta_AUC')

five=['CREB1','SLC16A4','GPX4','CASP1','MPO'];sm=stab.copy();wide=sm.pivot(index=['level','gene'],columns='rule',values='selection_frequency').reset_index().rename(columns={'lambda.min':'selection_frequency_lambda_min','lambda.1se':'selection_frequency_lambda_1se'})
wide.to_csv(O/'03_selection_stability/selection_frequency_all_genes.tsv',sep='\t',index=False);wide[wide.gene.isin(five)].to_csv(O/'03_selection_stability/selection_frequency_frozen5.tsv',sep='\t',index=False);sm.to_csv(O/'03_selection_stability/coefficient_stability.tsv',sep='\t',index=False)
top=wide[wide.level=='B'].nlargest(10,'selection_frequency_lambda_min').gene.tolist();genes=list(dict.fromkeys(five+top));fig,axs=plt.subplots(1,2,figsize=(9,7),sharey=True)
for ax,level in zip(axs,['A','B']):
 for rule,mark,col in [('lambda.min','o','#527e99'),('lambda.1se','s','#bd785e')]:
  dd=sm[(sm.level==level)&(sm.rule==rule)].set_index('gene');v=dd.loc[genes,'selection_frequency'];ax.plot(v,np.arange(len(genes)),mark,ls='',color=col,label=rule)
 ax.set_xlim(-.03,1.03);ax.set_yticks(range(len(genes)),genes);ax.invert_yaxis();ax.set_xlabel('Frequency');ax.set_title('Level '+level);ax.grid(axis='x',alpha=.2);ax.legend(frameon=False)
fig.tight_layout();save(fig,'S5_selection_frequency')
fig,axs=plt.subplots(1,2,figsize=(9,4.5),sharey=True)
for ax,level in zip(axs,['A','B']):
 dd=sm[(sm.level==level)&(sm.rule=='lambda.min')].set_index('gene').loc[five];arr=dd[['negative_frequency','zero_frequency','positive_frequency']].to_numpy();ax.imshow(arr,vmin=0,vmax=1,cmap='Blues',aspect='auto')
 for i in range(5):
  for j in range(3):ax.text(j,i,f'{100*arr[i,j]:.1f}%',ha='center',va='center',color='white' if arr[i,j]>.55 else 'black')
 ax.set_xticks([0,1,2],['Negative','Zero','Positive']);ax.set_yticks(range(5),five);ax.set_title('Level '+level)
fig.tight_layout();save(fig,'S6_coefficient_sign_stability')
# Co-selection is descriptive: genes outside frozen five are alternatives, not a replacement model.
co=[]
for level in ['A','B']:
 pp=coef[(coef.level==level)&(coef.rule=='lambda.min')].pivot(index='iteration',columns='gene',values='coefficient').ne(0)
 for g in pp.columns:
  if g not in five:co.append(dict(level=level,gene=g,selection_frequency=pp[g].mean(),**{'joint_'+f:float((pp[g]&pp[f]).mean()) for f in five}))
pd.DataFrame(co).sort_values(['level','selection_frequency'],ascending=[True,False]).to_csv(O/'03_selection_stability/alternative_gene_coselection.tsv',sep='\t',index=False)
(F/'FIGURE_LEGENDS.md').write_text('''# Figure legends

S1：冻结LCDI每SD总生存效应。四个主评价队列为TARGET、BeatAML2、GSE71014、GSE106291；下方历史/记录队列不参与该pooled值。队列线为统一Cox Wald 95%CI，菱形为REML合并HR及Knapp–Hartung CI，虚线为同实现95%预测区间。Strict表示BeatAML2主要独立复现；Additional表示附加评价（GSE106291含独立性未完全确认来源）。GPL570为表达记录层。开发队列不进入本图Meta。CI=confidence interval；HR=hazard ratio；SD=standard deviation；PI=prediction interval；KH=Knapp–Hartung；N/events=记录或患者数/死亡数。其他Meta情景见全表。

S2：控制MPO-risk后冻结non-MPO单一组分每SD的条件HR；外部四项Wald P作为独立BH家族，LRT另为四项家族。虚线以下是历史、开发、记录层敏感性，不能与外部复现混用。non-MPO=CREB1、SLC16A4、GPX4、CASP1冻结加权和。MPO-risk是负向MPO经SD标准化；MPO component是−0.2095×原分支Z(MPO)。FDR=false discovery rate；P=two-sided Wald probability。

S3：M0=Surv~MPO-risk；M1=M0+冻结non-MPO单一组分。空心/实心表示同一队列M0/M1表观拟合C-index；右侧为配对ΔC=M1−M0及1000次患者/记录Bootstrap百分位区间，每次两模型在同一抽样中重拟合，评分基因标准化参数不变。指标基于拟合线性预测量，M0方向可随拟合系数变化，故不能与固定MPO-risk Fig1 C-index直接互换。未解释为重新开发的五变量模型；乐观度校正ΔC另见表。

S4：1、3、5年配对ΔAUC=M1−M0，marginal IPCW timeROC，时间单位365.25天/年。全部1000次重抽样共享患者索引；完整区间和有效次数见paired_increment.tsv。NA表示无法估计，*表示点值存在但有效重抽样不足95%，不提供稳定区间。颜色在±0.10截断以保持比较；格内数字保留真实值。AUC=area under time-dependent ROC curve；IPCW=inverse probability of censoring weighting。

S5：A层固定17候选，B层从固定89候选重做outcome-dependent筛选。每层1000次TCGA患者Bootstrap，10折CV中同患者副本保持同折。圆/方分别lambda.min/lambda.1se；展示冻结五基因及B层选择频率最高的其他基因。不是替代模型。

S6：上述两层lambda.min的负/零/正系数频率，以全部1000次为分母，零包括未入选。展示TCGA LASSO系数方向，不能与GPL96冻结LCDI Cox系数方向混淆。lambda.1se及所有候选的完整频率、系数中位数/IQR和共同入选表保留在03目录。IQR=interquartile range；CV=cross-validation。
''',encoding='utf-8')
print(f'ANALYSIS_LOGIC_PASS\nRESULT_AUDIT_PASS ({len(checks)} checks)\nSUCCESS')

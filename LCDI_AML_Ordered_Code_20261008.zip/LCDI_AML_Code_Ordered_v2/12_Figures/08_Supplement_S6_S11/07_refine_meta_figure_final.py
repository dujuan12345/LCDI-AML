from pathlib import Path
import pandas as pd
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
O=Path.cwd()/'review_addendum_4plus1_20260911';F=O/'09_figures'
effects=pd.read_csv(O/'01_cohort_heterogeneity/cohort_effects.tsv',sep='\t')
meta=pd.read_csv(O/'01_cohort_heterogeneity/random_effects_meta_audited.tsv',sep='\t')
plt.rcParams.update({'font.family':'Arial','font.size':10,'axes.spines.top':False,'axes.spines.right':False,'pdf.fonttype':42,'savefig.dpi':220})
colors={'TARGET':'#527e99','BeatAML2':'#bd785e','GSE71014':'#778c71','GSE106291':'#9687a7','GSE10358':'#bd9c55','TCGA':'#777777','GPL96':'#999999','GPL570':'#bbbbbb'}
primary=['TARGET','BeatAML2','GSE71014','GSE106291'];order=primary+['GSE10358','TCGA','GPL96','GPL570']
def save(fig,name):
 fig.savefig(F/(name+'.pdf'),bbox_inches='tight');fig.savefig(F/(name+'.png'),bbox_inches='tight');plt.close(fig)
fig,ax=plt.subplots(figsize=(9,5.8));ds=effects.set_index('dataset');ys=[];labels=[]
for j,n in enumerate(primary+['GSE10358','GPL570']):
 r=ds.loc[n];y=8-j;ax.errorbar(r.hr,y,xerr=[[r.hr-r.lower],[r.upper-r.hr]],fmt='o',color=colors[n],capsize=3);ys.append(y);labels.append(n)
 ax.text(3.1,y,f'{int(r.n)}/{int(r.events)}   {r.hr:.2f} [{r.lower:.2f}, {r.upper:.2f}]',va='center',fontsize=9)
r=meta[(meta['set']=='PRIMARY_META')&(meta.CI_method=='knha')].iloc[0]
ax.errorbar(r.pooled_HR,1,xerr=[[r.pooled_HR-r.lower],[r.upper-r.pooled_HR]],fmt='D',color='black',capsize=4)
ax.plot([r.prediction_lower,r.prediction_upper],[.4,.4],color='black',ls='--',lw=2)
ys += [1,.4];labels += ['Pooled KH','95% PI']
ax.set_yticks(ys,labels);ax.set_xscale('log');ax.set_xlim(.4,7);ax.set_xticks([.5,1,2,3],['0.5','1','2','3']);ax.axvline(1,color='.7',ls=':');ax.set_xlabel('HR per SD');ax.set_ylim(0,9)
ax.text(3.1,8.7,'N / Events     HR [95% CI]',fontsize=9)
ax.axhline(4.5,color='.8',ls='--');ax.text(.43,4.7,'Sensit.',fontsize=9)
ax.text(.43,.05,f'I² = {r.I2:.1f}%   tau² = {r.tau2:.3f}',fontsize=9)
ax.legend(handles=[Line2D([0],[0],marker='o',ls='',color=colors[n],label=l) for n,l in [('TARGET','Evaluation'),('BeatAML2','Strict'),('GSE71014','Additional'),('GSE106291','Add. mix'),('GSE10358','Historical'),('GPL570','Records')]],loc='upper center',bbox_to_anchor=(.5,-.15),ncol=3,frameon=False)
ax.text(3.1,1,f'{r.pooled_HR:.2f} [{r.lower:.2f}, {r.upper:.2f}]',va='center',fontsize=9)
ax.text(3.1,.4,f'[{r.prediction_lower:.2f}, {r.prediction_upper:.2f}]',va='center',fontsize=9)
save(fig,'S1_external_heterogeneity_v3')


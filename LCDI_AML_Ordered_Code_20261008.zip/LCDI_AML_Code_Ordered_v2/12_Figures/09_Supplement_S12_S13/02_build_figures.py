from pathlib import Path
import csv,json,math,statistics,hashlib,shutil,sys
import reportlab,PIL
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from pdf2image import convert_from_path

P=Path(__file__).parent; S=P.parent/'clinical_qpcr_recovery_20260814_v1'
OUT=P/'supplement_S1-S13';OUT.mkdir(exist_ok=True);QA=P/'qa';QA.mkdir(exist_ok=True)
read=lambda p:list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
values=read(S/'11_patient_level_qpcr_values.tsv');summary=read(S/'12_patient_level_qpcr_summary.tsv')
schemes=[('GAPDH_initial','结果分析-GAPDH','GAPDH I'),('ACTB_initial','结果分析-ACTB','ACTB I'),('GAPDH_retest','GAPDH复测','GAPDH R'),('ACTB_retest','ACTB复测','ACTB R')]
all_schemes=schemes+[('dual_reference_initial_exploratory',None,'Dual I'),('dual_reference_retest_exploratory',None,'Dual R')]
genes=['MPO','CREB1','GPX4','SLC16A4']
colors={'control':'#32688E','disease':'#B27655'}
def rows(sheet,g,group=None):return [r for r in values if r['sheet']==sheet and r['gene']==g and (group is None or r['group']==group)]
def series(analysis,g,group):
    if analysis.startswith('dual'):
        a=schemes[1 if 'initial' in analysis else 3][1];b=schemes[0 if 'initial' in analysis else 2][1]
        aa=rows(a,g,group);bb={r['sample_id']:r for r in rows(b,g,group)}
        return [(float(r['delta_ct'])+float(bb[r['sample_id']]['delta_ct']))/2 for r in aa if r['delta_ct'] and bb[r['sample_id']]['delta_ct']]
    sheet=next(s[1] for s in schemes if s[0]==analysis)
    return [float(r['delta_ct']) for r in rows(sheet,g,group) if r['delta_ct']]
verification=json.loads((P/'02_statistics_verification.json').read_text(encoding='utf-8'))
assert verification['passed'];checks=verification['checks']
for g in genes+['CASP1']:
    for sample in [f'{c}{i}' for c in 'CD' for i in range(1,6)]:
        rs=[r for r in values if r['gene']==g and r['sample_id']==sample]
        assert len({r['target_ct_mean'] for r in rs})==1

def txt(c,x,y,s,size=12,bold=False,color='#222222',align='left'):
    c.setFillColor(HexColor(color));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size)
    {'left':c.drawString,'right':c.drawRightString,'center':c.drawCentredString}[align](x,y,s)
def line(c,x1,y1,x2,y2,col='#BCC4CA',width=.6):
    c.setStrokeColor(HexColor(col));c.setLineWidth(width);c.line(x1,y1,x2,y2)
def point(c,x,y,col,rad=3.8,hollow=False):
    c.setStrokeColor(HexColor(col));c.setFillColor(white if hollow else HexColor(col));c.setLineWidth(1.1);c.circle(x,y,rad,fill=1,stroke=1)
f12=OUT/'FigureS12_patient_qPCR_log2_v1.pdf';c=canvas.Canvas(str(f12),pagesize=(1050,900))
c.setTitle('Figure S12 Individual-level qPCR on a log2 scale')
txt(c,35,867,'S12',20,True);txt(c,96,868,'Individual-level qPCR',19,True)
txt(c,35,842,'5 non-AML and 5 AML individuals; the same individuals are shown in each normalization scheme.',12)
point(c,768,872,colors['control']);txt(c,780,868,'non-AML',12);point(c,900,872,colors['disease']);txt(c,912,868,'AML',12)
for j,(_,_,lab) in enumerate(schemes):txt(c,181+j*228,810,lab,15,True,align='center')
plotrows=[]
for i,g in enumerate(genes):
    base=642-i*165;allv=[-float(r['delta_ct']) for r in values if r['gene']==g and r['delta_ct']]
    lo=math.floor(min(allv))-1;hi=math.ceil(max(allv))+1
    txt(c,31,base+111,chr(65+i),17,True);txt(c,53,base+111,g,13,True)
    for j,(analysis,sheet,lab) in enumerate(schemes):
        x=109+j*228;w=156;h=106;fy=lambda v:base+(v-lo)/(hi-lo)*h
        for tick in range(lo,hi+1):
            if tick%4==0:
                line(c,x,fy(tick),x+w,fy(tick),col='#E5E9EC');txt(c,x-6,fy(tick)-3,str(tick),10,align='right')
        line(c,x,base,x+w,base);line(c,x,base,x,base+h)
        for k,grp in enumerate(['control','disease']):
            rr=sorted([r for r in rows(sheet,g,grp) if r['delta_ct']],key=lambda r:r['sample_id']);assert len(rr)==5
            center=x+40+k*78
            for off,r in zip([-12,-6,0,6,12],rr):
                point(c,center+off,fy(-float(r['delta_ct'])),colors[grp],hollow=(r['target_ct_ge_35']=='True'))
                plotrows.append(dict(r,plot_value_minus_delta_ct=-float(r['delta_ct'])))
            mean=statistics.mean(-float(r['delta_ct']) for r in rr)
            line(c,center-18,fy(mean),center+18,fy(mean),colors[grp],1.8)
            txt(c,center,base-17,'non-AML' if k==0 else 'AML',11,align='center')
        if j==0:
            c.saveState();c.translate(79,base+53);c.rotate(90);txt(c,0,0,'-Delta Ct',11,align='center');c.restoreState()
line(c,35,108,1015,108)
casp=[r for r in values if r['gene']=='CASP1' and r['sheet']==schemes[0][1] and r['delta_ct']]
ctinfo={r['group']:float(r['target_ct_mean']) for r in casp}
txt(c,35,85,'E  CASP1',14,True);txt(c,146,85,'Ct available: non-AML 1/5; AML 1/5. No group test or interval.',12)
txt(c,146,66,f"Mean target Ct: non-AML {ctinfo['control']:.2f}; AML {ctinfo['disease']:.2f}. Remaining 4/5 per group: missing, not zero.",11)
txt(c,35,43,'Each dot = one individual; bars = means; open dots = mean target Ct >=35 (quantification requires caution).',11)
txt(c,35,24,'I: initial reference assay; R: reference reassay. Targets were not reassayed. -Delta Ct = log2(2^-Delta Ct).',11)
c.save()

f13=OUT/'FigureS13_qPCR_effect_sensitivity_v1.pdf';c=canvas.Canvas(str(f13),pagesize=(1160,860));c.setTitle('Figure S13 qPCR effect and normalization sensitivity')
txt(c,35,825,'S13',20,True);txt(c,99,826,'qPCR effect and normalization sensitivity',19,True)
txt(c,35,800,'AML vs non-AML; 5 individuals per group. Estimates and 95% CI use individual-level Delta Ct.',12)
range_all=[float(r[k]) for r in summary if r['gene'] in genes for k in ('log2fc_ci_low','log2fc_ci_high')]
bound=math.ceil(max(abs(x) for x in range_all)/4)*4
for i,g in enumerate(genes):
    ox=35+(i%2)*565;top=748-(i//2)*308;px=ox+89;pw=202;fy=lambda v:px+(v+bound)/(2*bound)*pw
    txt(c,ox,top,chr(65+i)+'  '+g,16,True)
    txt(c,ox+303,top-23,'log2FC [95% CI]',10,True);txt(c,ox+449,top-23,'P',10,True,align='center');txt(c,ox+504,top-23,'FDR',10,True,align='center')
    line(c,fy(0),top-43,fy(0),top-215,'#A8B0B8',.8)
    for k,(analysis,_,lab) in enumerate(all_schemes):
        r=next(r for r in summary if r['analysis']==analysis and r['gene']==g);y=top-49-k*29
        est,low,high=[float(r[n]) for n in ('log2fc','log2fc_ci_low','log2fc_ci_high')]
        col='#32688E' if 'initial' in analysis else '#B27655'
        txt(c,ox,y-4,lab,11)
        line(c,fy(low),y,fy(high),y,col,1.3);point(c,fy(est),y,col,3.3,hollow=analysis.startswith('dual'))
        txt(c,ox+303,y-4,f'{est:+.2f} [{low:+.2f}, {high:+.2f}]',10)
        for xx,key in [(ox+449,'welch_p'),(ox+504,'welch_bh_fdr')]:txt(c,xx,y-4,f'{float(r[key]):.3f}',10,bold=float(r[key])<.05,align='center')
    axis_y=top-216;line(c,px,axis_y,px+pw,axis_y)
    for t in [-bound,-bound/2,0,bound/2,bound]:line(c,fy(t),axis_y-3,fy(t),axis_y);txt(c,fy(t),axis_y-16,f'{t:g}',10,align='center')
    txt(c,px+pw/2,axis_y-33,'log2FC (AML / non-AML)',11,align='center')
    txt(c,px,axis_y-50,'Lower in AML',10,color='#555555');txt(c,px+pw,axis_y-50,'Higher in AML',10,color='#555555',align='right')
line(c,35,145,1125,145)
txt(c,35,120,'E  CASP1',14,True);txt(c,144,120,'Only 1/5 individuals per group has target Ct; no effect CI, P value or FDR is estimable.',12)
txt(c,35,96,'I: initial reference assay; R: reference reassay; Dual: geometric-mean ACTB/GAPDH normalization (exploratory).',11)
txt(c,35,75,'P: two-sided Welch test. FDR: BH correction across 4 testable genes within each normalization scheme.',11)
txt(c,35,54,'Bold P <0.05 denotes a nominal signal. All FDR values are >=0.05. Exact Mann-Whitney sensitivity results accompany the source table.',11)
txt(c,35,33,'The six schemes use the same individuals and target assays; they are sensitivity analyses, not independent replication.',11)
c.save()

fullstats=[]
for r in summary:
    fullstats.append(dict(r,test_family=r['analysis']+'__four_testable_genes',testable_genes=4,biological_unit='independent_individual',CI_method='Welch_Satterthwaite_95pct',group_control_label='non-AML',status='not_estimable' if r['gene']=='CASP1' else 'exploratory'))
for name,rr in [('qPCR_patient_values.tsv',values),('qPCR_full_statistics.tsv',fullstats)]:
    with (OUT/name).open('w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(rr[0]),delimiter='\t');w.writeheader();w.writerows(rr)
prior=P.parent/'all_figures_fontplus2_20260917_v1/delivery'
copied=[]
for i in range(1,12):
    src=prior/f'FigureS{i}_fontplus2_v34.pdf';dst=OUT/src.name;shutil.copy2(src,dst)
    assert hashlib.sha256(src.read_bytes()).digest()==hashlib.sha256(dst.read_bytes()).digest();copied.append(str(src))
captions='''

补图S12 临床骨髓qPCR的患者层对数表达分布。A–D分别为MPO、CREB1、GPX4和SLC16A4；每列为一种内参归一化方案，每点代表1名独立个体（非AML比较组5例、AML组5例），横线为组均值。先在个体内平均3个技术重复Ct，再计算ΔCt＝目标基因平均Ct－内参平均Ct。纵轴−ΔCt＝log₂(2^−ΔCt)，向上表示归一化表达升高；同一基因各方案共用纵轴范围，不将不同基因间绝对数值作为表达丰度的直接比较。空心点标记目标基因平均Ct≥35，仅为高Ct提示，不替代实验确定的定量界限。E，CASP1每组仅1例有目标Ct记录，其他个体缺失，不以0或固定Ct填补，不作组间检验；Ct记录存在不等于已证明可靠定量。I，initial reference assay，内参初测；R，reference reassay，内参复测；Ct，cycle threshold，阈值循环数；AML，acute myeloid leukemia，急性髓系白血病。各列为同一批个体，目标基因未复测；非AML比较组不等同于统一健康对照。

补图S13 qPCR组间效应及内参归一化敏感性。A–D分别为MPO、CREB1、GPX4和SLC16A4在6种方案下的AML相对非AML比较组效应。点为log₂ fold change＝−[mean(ΔCt_AML)−mean(ΔCt_non-AML)]，线为Welch–Satterthwaite方法的95%置信区间；0表示无组间差异，正值表示AML组较高。每个可检验基因均为5比5名独立个体。右侧列出在个体ΔCt上进行的双侧Welch检验原始P值及BH-FDR；分别在每种归一化方案的4个可检验基因内校正，不跨方案混池。粗体P<0.05仅表示名义显著，全部结果均未达到FDR<0.05；完整精度、精确Mann–Whitney敏感性结果及检验家族见qPCR_full_statistics.tsv。E，CASP1每组仅1例有Ct记录，不提供效应区间或推断性统计。I/R，内参初测/复测；Dual，ACTB与GAPDH双内参几何均值归一化，作为探索性敏感性分析；CI，confidence interval，置信区间；FC，fold change，倍数变化；BH，Benjamini–Hochberg；FDR，false discovery rate，假发现率。蓝色/棕色分别表示初测/内参复测，空心点表示双内参方案。6种方案共享个体和目标基因检测，不能计为6次独立复现。GPX4在6种方案下均为AML组升高；CREB1也均偏高，但与既有同平台外部表达参照的降低方向相反，当前数据不支持其方向复现；MPO及SLC16A4方向依赖归一化方案。
'''
(OUT/'Supplement_figure_legends_S1-S13.md').write_text((prior/'Supplement_figure_legends.md').read_text(encoding='utf-8-sig')+captions,encoding='utf-8')
(OUT/'qPCR_补图说明.txt').write_text('新增补图S12–S13，接续本项目已交付S1–S11。既有11张PDF原样复制；本包不替代v38正文。正文qPCR结果末尾可补充“患者层表达分布与内参归一化敏感性见补图S12–S13”。\n\n对数尺度确认：患者表达绘制−ΔCt＝log₂(2^−ΔCt)，不是对ΔCt再取log；组间效应绘制log₂ fold change。使用全部原始个体，无离群值删除，无伪重复，无技术孔显著性星号。\n\n'+captions,encoding='utf-8')
pop=r'C:\Users\31937\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin'
for file in [f12,f13]:convert_from_path(file,dpi=125,poppler_path=pop)[0].save(QA/(file.stem+'.png'))
result={'numeric_reconciliations':checks,'n_numeric_estimates':len(checks),'BH_families':6,'BH_family_size':4,'all_frozen_stats_reproduced':True,'new_hypotheses_or_changed_tests':0,'target_assays_identical_across_reference_schemes':True,'patient_points':len(plotrows),'CASP1_target_ct':ctinfo,'forest_range':[-bound,bound],'copied_prior_figures':copied,'new_figures':[str(f12),str(f13)],'source_statistics':str(S/'12_patient_level_qpcr_summary.tsv'),'visual_QA':'pending','environment':{'python':sys.version,'reportlab':reportlab.Version,'Pillow':PIL.__version__},'statistics_environment':verification['environment'],'historical_text_discrepancy':'20260902 direction narrative says CREB1 initial GAPDH lower. Frozen 20260814 mean-DeltaCt statistics and raw Ct show log2FC +0.6167; old technical-well mean fold is 0.961. These are different estimands. New figures follow individual-level mean DeltaCt consistently.'}
(P/'02_numerical_QC.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps({'status':'numeric_passed','estimates':len(checks),'points':len(plotrows),'forest_bound':bound,'CASP1_ct':ctinfo,'pdfs':2}))

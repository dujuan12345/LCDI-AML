from pathlib import Path
import sys, json, re, importlib.util
import matplotlib
matplotlib.use('Agg')
from matplotlib.figure import Figure
from matplotlib.text import Text
import matplotlib.pyplot as plt

D=Path(__file__).parent
A=D.parent
ORIGINAL_SAVE=Figure.savefig
audit=[]
def save(self,path,*args,**kwargs):
    if str(path).lower().endswith('.png'): return
    if not hasattr(self,'_fontplus2_done'):
        if 'Figure4' in str(path):
            for t in list(self.findobj(Text)):
                if t.get_text()=='B':t.remove()
            self.text(.45,.988,'B',fontsize=19,fontweight='bold',va='top')
        if 'Figure3' in str(path):
            for ax in self.axes:
                if ax.get_xlabel().startswith('Mono/Mono-like'):
                    ax.set_xlabel('Mono/Mono-like minus\\nGMP/Prog-like logCPM\\n(patient-bootstrap 95% CI)'.replace('\\n','\n'),fontsize=10.2)
        self.canvas.draw()
        texts=[t for t in self.findobj(Text) if t.get_text().strip()]
        before=[{'text':t.get_text(),'before_pt':t.get_fontsize()} for t in texts]
        for t in texts:t.set_fontsize(t.get_fontsize()+2)
        for r,t in zip(before,texts):r['after_pt']=t.get_fontsize()
        self._fontplus2_done=True
        audit.append({'output':str(path),'text':before})
    ORIGINAL_SAVE(self,path,*args,**kwargs)
Figure.savefig=save

sources={
 'Figure1':A/'figure1_composite_20260902_v5/01_generate_compact_composite_v5.py',
 'Figure2':A/'figure2_ABC_v30_20260907/01_figure.py',
 'Figure3':A/'figure3_composite_20260903_v6/01_generate_figure3_four_panel_v6.py',
 'Figure4':A/'figure4_upstream_corrected_20260905_v3/02_build_corrected_figure4_final.py',
 'Figure5':A/'figure5_integrated_v27_20260907/02_build_figure.py',
 'Supplement':A/'candidate_definition_v23_20260907/03_supplement_figures.py',
}
selected=sys.argv[1:]
for label,src in sources.items():
    if selected and label not in selected:continue
    matplotlib.rcdefaults()
    suffix='_r4' if selected else ''
    out=D/(label+suffix);out.mkdir(exist_ok=True)
    code=src.read_text(encoding='utf-8-sig')
    if label=='Figure1':
        code=code.replace('hspace=0.16','hspace=0.28')
    if label=='Figure3':
        code=code.replace('divider.append_axes("right", size="4%", pad=0.12)', 'divider.append_axes("bottom", size="4%", pad=0.48)')
        code=code.replace('ax.figure.colorbar(sm, cax=cax)', 'ax.figure.colorbar(sm, cax=cax, orientation="horizontal")')
        code=code.replace('fig.savefig(PDF,', '''ax_b.set_position([.075,.10,.25,.35])
    ax_d.set_position([.51,.10,.17,.35])
    ax_d_stat.set_position([.70,.10,.31,.35])
    fig.savefig(PDF,''')
        code=code.replace('stat_ax.text(0.01, 0.015, "Shaded rows: nested exploratory sensitivity layers"','stat_ax.text(0.01, -0.10, "Shaded rows: nested exploratory\\nsensitivity layers"')
    if label=='Figure2':
        code=code.replace("letter(ax,lab)","letter(ax,lab)")
        code=code.replace("fig.subplots_adjust(left=", "\nfor a in fig.axes:\n for t in a.texts:\n  if t.get_text() in ['E','F']:\n   x,y=t.get_position();t.set_position((x,y-.035))\nfig.subplots_adjust(left=")
    if label=='Figure5':
        code=code.replace("ax.text(x,1.145,names[ds]", "ax.text(x,1.24,names[ds]")
    if label=='Figure4':
        code=code.replace('add_letter(ax, "B", -0.29, 1.16)', 'add_letter(ax, "B", -0.29, 1.06)')
    if label in ['Figure1','Figure3','Figure4']:
        code=code.replace('    main()','    main()')
        code=code[:code.rfind('if __name__ == "__main__":')]
        ns={'__file__':str(src),'__name__':'font_redraw_'+label}
        exec(compile(code,str(src),'exec'),ns)
        ns['OUT']=out
        if 'PDF' in ns:ns['PDF']=out/(label+'_fontplus2.pdf')
        ns['main']()
    elif label=='Figure2':
        code=code.replace("D=Path(__file__).parent;A=D.parent",f"D=Path({str(out)!r});A=Path({str(A)!r})")
        code='\n'.join(line for line in code.splitlines() if not line.startswith('subprocess.run('))
        exec(compile(code,str(src),'exec'),{'__file__':str(src),'__name__':'font_redraw_2'})
    elif label=='Figure5':
        code=code.replace("O=Path(__file__).parent",f"O=Path({str(out)!r})")
        code=code.replace("O/'03_new_gene_associations.tsv'",f"Path({str(src.parent/'03_new_gene_associations.tsv')!r})")
        exec(compile(code,str(src),'exec'),{'__file__':str(src),'__name__':'font_redraw_5'})
    else:
        code=code.replace("P=Path(__file__).parent;R=P.parent.parent;S=P/'supplement_figures'",f"P=Path({str(out)!r});R=Path({str(A.parent)!r});S=P/'supplement_figures'")
        exec(compile(code,str(src),'exec'),{'__file__':str(src),'__name__':'font_redraw_supp'})
    (out/'font_changes.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf8')
    print('REDRAW COMPLETE',label,flush=True)
    audit.clear()

from pathlib import Path
import shutil,json,subprocess
D=Path(__file__).parent
source=D.parent/'style_v28_20260907/02_build.py'
code=source.read_text(encoding='utf8')
prefix=code[:code.index('qc=[]')]
loop=code[code.index('qc=[]'):code.index('# Restore the v26')]
ns={'__file__':str(D/'02_finish_figures.py'),'__name__':'recolor'}
exec(compile(prefix,str(source),'exec'),ns)
labels=['Figure1','Figure3','Figure4','Figure5']+[f'FigureS{i}' for i in range(1,6)]
paths=[next(next(p for p in [D/(n+'_r4'),D/(n+'_r3'),D/(n+'_r2'),D/n] if p.exists()).glob('*.pdf')) for n in labels[:4]]+[D/f'Supplement_r4/supplement_figures/FigureS{i}.pdf' for i in range(1,6)]
ns['sources']=paths;ns['labels']=labels
exec(compile(loop,str(source),'exec'),ns)
src=next((D/'Figure2_r4').glob('*.pdf'))
dest=D/'figures/Figure2_soft_v28.pdf'
shutil.copy2(src,dest)
subprocess.run(['gswin64c','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=png16m','-r220',f'-sOutputFile={D}/qa/Figure2.png',str(dest)],check=True,stdout=subprocess.DEVNULL)
(D/'02_recolor_QC.json').write_text(json.dumps(ns['qc'],indent=2),encoding='utf8')

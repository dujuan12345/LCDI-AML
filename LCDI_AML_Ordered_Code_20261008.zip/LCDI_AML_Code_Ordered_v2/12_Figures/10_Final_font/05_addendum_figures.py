from pathlib import Path
import json,subprocess
import pandas as pd,numpy as np
D=Path(__file__).parent
hook=(D/'01_redraw.py').read_text(encoding='utf8').split('sources={')[0]
exec(compile(hook,str(D/'01_redraw.py'),'exec'))
O=D.parent.parent/'review_addendum_4plus1_20260911'
F=D/'addendum';F.mkdir(exist_ok=True)
def rd(p):return pd.read_csv(O/p,sep='\t')
effects=rd('01_cohort_heterogeneity/cohort_effects.tsv')
meta=rd('01_cohort_heterogeneity/random_effects_meta_audited.tsv')
inc=rd('02_mpo_nonmpo_increment/paired_increment.tsv')
cond=rd('02_mpo_nonmpo_increment/conditional_survival.tsv')
stab=rd('03_selection_stability/formal_stability_summary.tsv')
source=O/'12_scripts/06_validate_and_figures_final.py'
code=source.read_text(encoding='utf8');code=code[code.index('plt.rcParams.update'):code.index('# Co-selection')]
code='\n'.join(l for l in code.splitlines() if not l.startswith('wide.to_csv'))
exec(compile('from matplotlib.lines import Line2D\n'+code,str(source),'exec'))
source=O/'12_scripts/07_refine_meta_figure_final.py'
code=source.read_text(encoding='utf8').replace("O=Path.cwd()/'review_addendum_4plus1_20260911';F=O/'09_figures'",'')
exec(compile(code,str(source),'exec'))
(D/'05_addendum_font_changes.json').write_text(json.dumps(audit,ensure_ascii=False,indent=2),encoding='utf8')
names=['S1_external_heterogeneity_v3','S2_nonMPO_conditional_HR','S3_paired_delta_C','S4_delta_AUC','S5_selection_frequency','S6_coefficient_sign_stability']
for j,n in enumerate(names,6):
    target=D/f'figures/FigureS{j}_fontplus2_v34.pdf';target.write_bytes((F/(n+'.pdf')).read_bytes())
    subprocess.run(['gswin64c','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=png16m','-r180',f'-sOutputFile={D}/qa/FigureS{j}.png',str(target)],check=True,stdout=subprocess.DEVNULL)
print('Six addendum figures redrawn from frozen summary tables; no analysis rerun')

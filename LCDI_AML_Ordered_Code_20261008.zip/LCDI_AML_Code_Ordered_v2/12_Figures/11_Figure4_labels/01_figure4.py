from pathlib import Path
import json
D=Path(__file__).parent;A=D.parent
prior=A/'all_figures_fontplus2_20260917_v1'
hook=(prior/'01_redraw.py').read_text(encoding='utf8').split('sources={')[0]
exec(compile(hook,str(prior/'01_redraw.py'),'exec'))
base_save=Figure.savefig
cd_axes=[];changes=[]
def save_cd(fig,path,*args,**kwargs):
    fig.canvas.draw()
    for ax in cd_axes:
        for t in ax.findobj(Text):
            if t.get_text().strip():
                changes.append({'text':t.get_text(),'v34_size':t.get_fontsize()+2,'v35_size':t.get_fontsize()+3,'bold':True})
                t.set_fontsize(t.get_fontsize()+1);t.set_fontweight('bold')
    return base_save(fig,path,*args,**kwargs)
Figure.savefig=save_cd
src=A/'figure4_upstream_corrected_20260905_v3/02_build_corrected_figure4_final.py'
code=src.read_text(encoding='utf8');code=code[:code.rfind('if __name__ == "__main__":')]
ns={'__file__':str(src),'__name__':'figure4_v35'}
exec(compile(code,str(src),'exec'),ns)
out=D/'raw';out.mkdir(exist_ok=True);ns['OUT']=out;ns['PDF']=out/'Figure4_CD_bold_plus1_v35.pdf'
for name in ['draw_ppi','draw_single_cell']:
    original=ns[name]
    def wrapper(ax,*args,_func=original,**kwargs):
        before=list(ax.figure.axes);value=_func(ax,*args,**kwargs)
        cd_axes.append(ax);cd_axes.extend(a for a in ax.figure.axes if a not in before)
        return value
    ns[name]=wrapper
matplotlib.rcdefaults();ns['main']()
(D/'01_CD_font_changes.json').write_text(json.dumps(changes,indent=2),encoding='utf8')
# Apply the exact existing v28/v34 palette conversion to the new vector PDF.
style=A/'style_v28_20260907/02_build.py';code=style.read_text(encoding='utf8')
prefix=code[:code.index('qc=[]')];loop=code[code.index('qc=[]'):code.index('# Restore the v26')]
pal={'__file__':str(D/'01_figure4.py'),'__name__':'recolor'}
exec(compile(prefix,str(style),'exec'),pal)
pal['sources']=[ns['PDF']];pal['labels']=['Figure4']
exec(compile(loop,str(style),'exec'),pal)
final=D/'Figure4_CD_bold_plus1_v35.pdf';final.write_bytes((D/'figures/Figure4_soft_v28.pdf').read_bytes())
print(final)

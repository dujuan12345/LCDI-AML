from pathlib import Path
from io import BytesIO
import csv,json,hashlib
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,Color,white
from pypdf import PdfReader,PdfWriter
from pypdf.generic import DecodedStreamObject,NameObject
from pdf2image import convert_from_path
from PIL import ImageChops
P=Path(__file__).parent;A=P.parent
src=A/'all_figures_fontplus2_20260917_v1/figures/Figure5_fontplus2_v34.pdf'
table=A/'figure5_three_panel_20260907_v1/02_panel_A.tsv'
count=A/'figure5E_overlap_20260907_v1/02_overlap_counts.tsv'
read=lambda p:list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
rows=read(table);counts=read(count);genes=['MPO','CASP1','GPX4','CREB1']
assert len(rows)==16 and len(counts)==4
for r in rows:
 i,j=genes.index(r['row_target']),genes.index(r['column_target'])
 assert r['scope']==('adult' if j>i else 'pediatric' if i>j else 'cross_age')
reader=PdfReader(src);page=reader.pages[0];W,H=float(page.mediabox.width),float(page.mediabox.height)
buf=BytesIO();c=canvas.Canvas(buf,pagesize=(W,H))
c.setFillColor(white);c.rect(0,0,311,312,fill=1,stroke=0)
c.setFillColor(HexColor('#000000'));c.setFont('Helvetica-Bold',21);c.drawString(18,290,'D')
colors={'adult':'#32688E','pediatric':'#B27655','cross_age':'#24272B'}
labels=[('adult','Upper R: Adult'),('pediatric','Lower L: Pediatric'),('cross_age','Diagonal: Ad vs Pe')]
for k,(scope,label) in enumerate(labels):
 y=274-k*16;c.setStrokeColor(HexColor(colors[scope]));c.setLineWidth(1.7)
 c.setDash(3,2) if scope=='pediatric' else c.setDash()
 c.rect(54,y-2,10,9,fill=0,stroke=1);c.setDash()
 c.setFillColor(HexColor(colors[scope]));c.setFont('Helvetica-Bold',13);c.drawString(70,y,label)
c.setFont('Helvetica',10.6);c.setFillColor(HexColor('#394650'));c.drawString(70,229,'Cell values: Spearman rho')
x0,y0,cw,ch=80,88,47,30
for j,g in enumerate(genes):
 c.setFont('Helvetica',12);c.setFillColor(HexColor('#111111'));c.drawCentredString(x0+(j+.5)*cw,211,g)
for i,g in enumerate(genes):
 c.setFillColor(HexColor('#111111'));c.setFont('Helvetica',13);c.drawRightString(75,y0+(3-i+.5)*ch-4,g)
 for j in range(4):
  r=next(r for r in rows if r['row_target']==g and r['column_target']==genes[j]);v=float(r['rho'])
  # A single sequential fill scale retains rho as the color encoding; outlines encode comparison scope.
  lo=(.95,.97,.98);hi=(.20,.36,.49);rgb=tuple(a+(b-a)*v for a,b in zip(lo,hi))
  x,y=x0+j*cw,y0+(3-i)*ch
  c.setFillColor(Color(*rgb));c.setStrokeColor(white);c.setLineWidth(1);c.rect(x,y,cw,ch,fill=1,stroke=1)
  c.setStrokeColor(HexColor(colors[r['scope']]));c.setLineWidth(1.8)
  c.setDash(3,2) if r['scope']=='pediatric' else c.setDash()
  c.rect(x+1.8,y+1.8,cw-3.6,ch-3.6,fill=0,stroke=1);c.setDash()
  c.setFillColor(white if v>.60 else HexColor('#173147'));c.setFont('Helvetica',14)
  c.drawCentredString(x+cw/2,y+ch/2-4.5,f'{v:.2f}')
# Table columns align directly with the matrix; spell out that these are counts.
c.setFillColor(HexColor('#25313B'));c.setFont('Helvetica',11)
c.drawString(29,72,'Gene counts (model P < 0.05)')
for i,(lab,key) in enumerate([('Adult','adult'),('Pediatric','pediatric'),('Shared','overlap')]):
 y=51-i*16;c.setFillColor(HexColor('#EEF2F5') if i==2 else white);c.setStrokeColor(HexColor('#DCE2E8'));c.setLineWidth(.5);c.rect(28,y-4,240,16,fill=1,stroke=1)
 c.setFillColor(HexColor('#111111'));c.setFont('Helvetica',11.5);c.drawString(32,y,lab)
 for j,g in enumerate(genes):c.drawCentredString(x0+(j+.5)*cw,y,next(r for r in counts if r['target']==g)[key])
c.setFillColor(HexColor('#394650'));c.setFont('Helvetica',10.5);c.drawString(29,4,'Shared = Adult and Pediatric intersection')
c.save();overlay=PdfReader(buf).pages[0]
# Clip the previous D region from rendering before inserting its replacement.
stream=DecodedStreamObject();stream.set_data(f'q 0 0 {W} {H} re 0 0 311 312 re W* n\n'.encode()+page.get_contents().get_data()+b'\nQ\n')
page[NameObject('/Contents')]=stream;page.merge_page(overlay)
out=P/'Figure5_D_comparison_labels_v38_20261007.pdf';writer=PdfWriter();writer.add_page(page)
with out.open('wb') as f:writer.write(f)
pop=r'C:\Users\31937\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin'
before=convert_from_path(src,dpi=150,poppler_path=pop)[0];after=convert_from_path(out,dpi=150,poppler_path=pop)[0]
after.save(P/'qa/figure5_after.png')
# All content outside the replacement rectangle must render identically.
diff=ImageChops.difference(before,after);box=(0,round((H-312)/H*after.height)-2,round(311/W*after.width)+2,after.height)
from PIL import ImageDraw
ImageDraw.Draw(diff).rectangle(box,fill=(0,0,0))
print('outside difference',diff.getbbox(),'dimensions',W,H,'box',box)
diff.save(P/'qa/figure5_difference.png')
assert diff.getbbox() is None
convert_from_path(out,dpi=260,poppler_path=pop)[0].save(P/'qa/figure5_embed.png')
q={'source':str(src),'source_sha256':hashlib.sha256(src.read_bytes()).hexdigest(),'output':str(out),'rho_values':rows,'counts':counts,'outside_D_pixel_identical':True,'visual_QA':'pending','method':'vector replacement of panel D; no statistical recalculation'}
(P/'03_figure_QC.json').write_text(json.dumps(q,ensure_ascii=False,indent=2),encoding='utf-8')
print(out)

from pathlib import Path
import csv,json,math,statistics,shutil
from reportlab.pdfgen import canvas
from reportlab.lib.colors import HexColor,white
from pdf2image import convert_from_path
P=Path(__file__).parent;A=P.parent;S=A/'clinical_qpcr_recovery_20260814_v1'
read=lambda p:list(csv.DictReader(p.open(encoding='utf-8-sig'),delimiter='\t'))
v=read(S/'11_patient_level_qpcr_values.tsv');stats=read(S/'12_patient_level_qpcr_summary.tsv')
print('SHEETS',sorted(set(r['sheet'] for r in v)));print('ANALYSES',sorted(set(r['analysis'] for r in stats)))
print('refs',sorted(set(r['reference'] for r in v)))
if __name__=='__main__' and '--inspect' in __import__('sys').argv:raise SystemExit
schemes=[('GAPDH_initial','结果分析-GAPDH','GAPDH I'),('ACTB_initial','结果分析-ACTB','ACTB I'),('GAPDH_retest','GAPDH复测','GAPDH R'),('ACTB_retest','ACTB复测','ACTB R')]
genes=['MPO','CREB1','GPX4','SLC16A4']
assert set(s[1] for s in schemes)<=set(r['sheet'] for r in v)
out=P/'FigureS12_patient_qPCR_v38_20261007.pdf';c=canvas.Canvas(str(out),pagesize=(1200,860));colors={'control':'#32688E','disease':'#B27655'}
def text(x,y,s,size=12,bold=False,color='#222222'):
 c.setFillColor(HexColor(color));c.setFont('Helvetica-Bold' if bold else 'Helvetica',size);c.drawString(x,y,s)
text(22,831,'A',20,True);text(52,833,'Individual-level expression',16,True)
text(807,831,'B',20,True);text(837,833,'AML vs non-AML effect',16,True)
text(53,811,'Each dot = one individual; same 5 AML and 5 non-AML individuals across schemes',12)
for j,(_,_,lab) in enumerate(schemes):text(91+j*181,784,lab,14,True)
allchecks=[]
for i,g in enumerate(genes):
 base=604-i*166
 vals=[-float(r['delta_ct']) for r in v if r['gene']==g and r['sheet'] in [s[1] for s in schemes] and r['delta_ct']]
 lo=math.floor(min(vals))-1;hi=math.ceil(max(vals))+1
 text(24,base+74,g,13,True)
 for j,(analysis,sheet,lab) in enumerate(schemes):
  xx=93+j*181;ww=131;hh=112
  xy=lambda val:base+(val-lo)/(hi-lo)*hh
  c.setStrokeColor(HexColor('#BFC7CE'));c.setLineWidth(.6);c.line(xx,base,xx+ww,base);c.line(xx,base,xx,base+hh)
  for tick in [lo,(lo+hi)/2,hi]:
   yy=xy(tick);c.line(xx-3,yy,xx,yy);c.setFillColor(HexColor('#50565C'));c.setFont('Helvetica',9);c.drawRightString(xx-5,yy-3,f'{tick:g}')
  for k,grp in enumerate(['control','disease']):
   rr=sorted([r for r in v if r['gene']==g and r['sheet']==sheet and r['group']==grp and r['delta_ct']],key=lambda r:r['sample_id'])
   assert len(rr)==5 and len(set(r['sample_id'] for r in rr))==5
   centre=xx+35+k*62
   for off,r in zip([-10,-5,0,5,10],rr):
    c.setFillColor(HexColor(colors[grp]));c.circle(centre+off,xy(-float(r['delta_ct'])),2.9,fill=1,stroke=0)
   mean=statistics.mean(-float(r['delta_ct']) for r in rr);c.setStrokeColor(HexColor(colors[grp]));c.setLineWidth(1.6);c.line(centre-15,xy(mean),centre+15,xy(mean))
   c.setFillColor(HexColor('#333333'));c.setFont('Helvetica',10);c.drawCentredString(centre,base-14,'non-AML' if k==0 else 'AML')
  st=next(r for r in stats if r['gene']==g and r['analysis']==analysis)
  for grp,key in [('control','mean_delta_ct_control'),('disease','mean_delta_ct_disease')]:
   actual=statistics.mean(float(r['delta_ct']) for r in v if r['gene']==g and r['sheet']==sheet and r['group']==grp and r['delta_ct'])
   assert abs(actual-float(st[key]))<1e-10
  allchecks.append(g+'/'+analysis)
 # all 6 frozen estimates, including combined-reference sensitivity.
 sr=[r for r in stats if r['gene']==g]
 assert len(sr)==6
 x0=943;x1=1175;flo=min(float(r['log2fc_ci_low']) for r in sr);fhi=max(float(r['log2fc_ci_high']) for r in sr)
 flo=min(math.floor(flo)-1,-1);fhi=max(math.ceil(fhi)+1,1);fx=lambda t:x0+(t-flo)/(fhi-flo)*(x1-x0)
 c.setStrokeColor(HexColor('#AAAAAA'));c.setDash(2,2);c.line(fx(0),base,fx(0),base+119);c.setDash()
 for k,r in enumerate(sr):
  yy=base+111-k*19
  label=r['analysis'].replace('_initial',' I').replace('_retest',' R').replace('combined','Dual').replace('ACTB_GAPDH','Dual').replace('Combined','Dual')
  text(815,yy-3,label,9.5)
  col=colors['disease'] if float(r['log2fc'])>0 else colors['control'];c.setStrokeColor(HexColor(col));c.setLineWidth(1.3)
  c.line(fx(float(r['log2fc_ci_low'])),yy,fx(float(r['log2fc_ci_high'])),yy)
  c.setFillColor(HexColor(col));c.circle(fx(float(r['log2fc'])),yy,3,fill=1,stroke=0)
 for tick in [flo,0,fhi]:
  c.setFillColor(HexColor('#50565C'));c.setFont('Helvetica',9);c.drawCentredString(fx(tick),base-14,str(tick))
text(55,83,'A: -Delta Ct; higher values indicate higher normalized expression. Bars show group means.',12)
text(815,83,'B: log2 fold change with 95% CI',11)
text(22,57,'C',20,True);text(52,59,'CASP1: Ct available in 1/5 non-AML and 1/5 AML individuals; no group inference.',13,True)
text(52,38,'I = initial reference assay; R = reference reassay; Dual = combined GAPDH/ACTB normalization.',11.5)
text(52,19,'Targets were not reassayed. CASP1 includes a high Ct value; Ct availability does not establish reliable quantification.',11)
c.save()
pop=r'C:\Users\31937\.cache\codex-runtimes\codex-primary-runtime\dependencies\native\poppler\Library\bin'
convert_from_path(out,dpi=110,poppler_path=pop)[0].save(P/'qa/figureS12.png')
shutil.copy2(S/'12_patient_level_qpcr_summary.tsv',P/'TableS6_patient_qPCR_full_statistics.tsv')
(P/'05_qpcr_QC.json').write_text(json.dumps({'source_values':str(S/'11_patient_level_qpcr_values.tsv'),'source_stats':str(S/'12_patient_level_qpcr_summary.tsv'),'mean_matches':allchecks,'scatter_panels':16,'effect_estimates':24,'statistics_rows':len(stats),'new_tests':0,'visual_QA':'pending'},indent=2),encoding='utf-8')
print(out)

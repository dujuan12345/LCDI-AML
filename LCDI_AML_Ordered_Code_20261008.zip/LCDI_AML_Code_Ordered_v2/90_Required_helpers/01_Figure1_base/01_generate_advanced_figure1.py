from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
from matplotlib.patches import FancyArrowPatch, FancyBboxPatch, PathPatch, Rectangle
from matplotlib.path import Path as MplPath
import numpy as np
import pandas as pd
from scipy.stats import gaussian_kde


PROJECT = Path(r"D:\26_01_AML")
BASE = PROJECT / "_codex_audit" / "figure1_individual_panels_20260902_v1"
OUT = PROJECT / "_codex_audit" / "figure1_composite_20260902_v1"

SOURCES = {
    "survival_summary": BASE / "01_frozen_survival_inputs.tsv",
    "delta_summary": BASE / "01_frozen_delta_inputs.tsv",
    "km_statistics": BASE / "02_km_statistics.tsv",
    "patient_scores": PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "01_patient_scores.tsv",
    "historical_delta_iterations": PROJECT / "_codex_audit" / "lcdi_mpo_increment_20260803_v1" / "final" / "five_cohort_fixed_score_bootstrap_iterations.tsv",
    "tcga_delta_iterations": PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "10_tcga_training_scale_bootstrap_iterations.tsv",
    "paired_delta_iterations": PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "01_paired_bootstrap_iterations.tsv",
}

ROLE_STYLE = {
    "Development": ("#3F3F3F", "o"),
    "Historical evaluation": ("#0072B2", "s"),
    "Independent validation": ("#D55E00", "D"),
    "Additional evaluation": ("#A6A6A6", "o"),
}
HIGH = "#D55E00"
LOW = "#0072B2"


def read_tsv(path: Path) -> pd.DataFrame:
    return pd.read_csv(path, sep="\t")


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.png", dpi=400, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def style_axis(ax: plt.Axes) -> None:
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.spines["left"].set_linewidth(0.8)
    ax.spines["bottom"].set_linewidth(0.8)
    ax.tick_params(width=0.8, length=4, color="#333333")


def role_handles() -> list[Line2D]:
    handles = []
    for label, (color, marker) in ROLE_STYLE.items():
        handles.append(
            Line2D(
                [0], [0], color=color, marker=marker, lw=1.4, markersize=5.5,
                markerfacecolor="white" if label == "Additional evaluation" else color,
                markeredgecolor=color, markeredgewidth=1.0, label=label,
            )
        )
    return handles


def label_panel(ax: plt.Axes, letter: str, x: float = -0.10, y: float = 1.04) -> None:
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=15, fontweight="bold", ha="left", va="bottom")


def ribbon(ax: plt.Axes, x0: float, x1: float, y: float, h0: float, h1: float, color: str, alpha: float = 0.30) -> None:
    verts = [
        (x0, y + h0),
        (x0 + 0.42 * (x1 - x0), y + h0),
        (x0 + 0.58 * (x1 - x0), y + h1),
        (x1, y + h1),
        (x1, y - h1),
        (x0 + 0.58 * (x1 - x0), y - h1),
        (x0 + 0.42 * (x1 - x0), y - h0),
        (x0, y - h0),
        (x0, y + h0),
    ]
    codes = [MplPath.MOVETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4, MplPath.LINETO, MplPath.CURVE4, MplPath.CURVE4, MplPath.CURVE4, MplPath.CLOSEPOLY]
    ax.add_patch(PathPatch(MplPath(verts, codes), facecolor=color, edgecolor="none", alpha=alpha))


def draw_panel_a(ax: plt.Axes, panel_letter: str | None = None) -> None:
    ax.set_xlim(-0.25, 10.3)
    ax.set_ylim(-1.15, 1.25)
    ax.axis("off")
    counts = [113, 106, 89, 26, 17, 5]
    labels = ["Candidate\nspace", "Measurable", "Expression\nscreen", "TCGA Cox", "Co-expression", "TCGA LASSO"]
    xs = np.array([0.45, 1.85, 3.25, 4.65, 6.05, 7.45])
    heights = 0.10 + 0.26 * np.sqrt(np.asarray(counts) / max(counts))
    for i in range(len(xs) - 1):
        ribbon(ax, xs[i] + 0.48, xs[i + 1] - 0.48, 0.65, heights[i], heights[i + 1], "#56B4E9", 0.38)
    for x, count, label, height in zip(xs, counts, labels, heights):
        ax.add_patch(FancyBboxPatch((x - 0.48, 0.65 - max(0.25, height)), 0.96, 2 * max(0.25, height), boxstyle="round,pad=0.025,rounding_size=0.04", facecolor="#EAF2F8", edgecolor="#4D4D4D", linewidth=0.8))
        ax.text(x, 0.70, label, ha="center", va="center", fontsize=8.4, linespacing=0.9)
        ax.text(x, 0.47, str(count), ha="center", va="center", fontsize=8.5, fontweight="bold")
    ax.add_patch(FancyArrowPatch((7.95, 0.65), (8.25, 0.65), arrowstyle="->", mutation_scale=10, color="#777777", lw=0.9))
    ax.add_patch(FancyBboxPatch((8.27, 0.38), 0.98, 0.54, boxstyle="round,pad=0.025,rounding_size=0.04", facecolor="#F5E9E2", edgecolor="#4D4D4D", linewidth=0.8))
    ax.text(8.76, 0.65, "GPL96\ncoefficients", ha="center", va="center", fontsize=8.4)
    ax.add_patch(FancyArrowPatch((9.27, 0.65), (9.48, 0.65), arrowstyle="->", mutation_scale=10, color="#777777", lw=0.9))
    ax.add_patch(FancyBboxPatch((9.50, 0.38), 0.72, 0.54, boxstyle="round,pad=0.025,rounding_size=0.04", facecolor="#F5E9E2", edgecolor="#4D4D4D", linewidth=0.8))
    ax.text(9.86, 0.65, "Frozen\nLCDI", ha="center", va="center", fontsize=8.4, fontweight="bold")

    destinations = [
        (2.0, -0.68, -0.12, "GSE10358 / TARGET\nHistorical evaluation", "#0072B2"),
        (5.1, -0.68, -0.20, "BeatAML2\nIndependent validation", "#D55E00"),
        (8.2, -0.68, -0.28, "GSE71014 / GSE106291\nAdditional evaluation", "#A6A6A6"),
    ]
    for x, y, lane, text, color in destinations:
        ax.add_patch(FancyBboxPatch((x - 0.88, y - 0.24), 1.76, 0.48, boxstyle="round,pad=0.025,rounding_size=0.04", facecolor="#F7F7F7", edgecolor=color, linewidth=1.0))
        ax.text(x, y, text, ha="center", va="center", fontsize=8.0, linespacing=0.92)
        ax.plot([9.86, 9.86, x], [0.36, lane, lane], color=color, lw=1.0, alpha=0.82)
        ax.add_patch(FancyArrowPatch((x, lane), (x, y + 0.27), arrowstyle="->", mutation_scale=9, color=color, lw=1.0, alpha=0.82))
    if panel_letter:
        label_panel(ax, panel_letter, -0.015, 1.01)


def draw_panel_b(ax: plt.Axes, panel_letter: str | None = None) -> None:
    genes = ["MPO", "CASP1", "SLC16A4", "GPX4", "CREB1"]
    beta = np.array([-0.2095, -0.0106, -0.0636, -0.0721, 0.0925])
    y = np.arange(len(genes))
    colors = np.where(beta < 0, LOW, HIGH)
    ax.axvline(0, color="#777777", lw=0.9)
    for yi, value, color in zip(y, beta, colors):
        ax.plot([0, value], [yi, yi], color=color, lw=2.2, solid_capstyle="round")
        ax.scatter([value], [yi], s=58, color=color, edgecolor="white", linewidth=0.7, zorder=3)
        if value <= -0.15:
            ax.text(value + 0.010, yi, f"{value:+.4f}", ha="left", va="center", fontsize=7.6, color="#222222", bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.92, "pad": 0.8})
        elif value < 0:
            ax.text(value - 0.012, yi, f"{value:+.4f}", ha="right", va="center", fontsize=7.6)
        else:
            ax.text(value + 0.010, yi, f"{value:+.4f}", ha="left", va="center", fontsize=7.6)
    ax.set_yticks(y, labels=genes)
    ax.set_xlim(-0.255, 0.13)
    ax.set_xticks([-0.2, -0.1, 0.0, 0.1])
    ax.set_xlabel("Frozen Cox coefficient")
    style_axis(ax)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    if panel_letter:
        label_panel(ax, panel_letter, -0.14, 1.02)


def draw_panel_c(ax: plt.Axes, survival: pd.DataFrame, panel_letter: str | None = None, add_legend: bool = True) -> None:
    ax.axvline(0.5, color="#888888", lw=0.85, ls="--")
    ax.axhline(1.0, color="#888888", lw=0.85, ls="--")
    offsets = {
        "GPL96": (8, 5), "GSE10358": (7, 7), "TCGA-LAML": (-72, 18), "TARGET-AML": (8, -22),
        "BeatAML2": (-66, -17), "GPL570": (8, -16), "GSE71014": (8, 7), "GSE106291": (8, 8),
    }
    for _, row in survival.iterrows():
        color, marker = ROLE_STYLE[row.role]
        size = 34 + 21 * math.log10(float(row.n))
        ax.errorbar(row.cindex, row.hr, xerr=[[row.cindex - row.c_low], [row.c_high - row.cindex]], yerr=[[row.hr - row.hr_low], [row.hr_high - row.hr]], fmt="none", ecolor=color, elinewidth=0.95, alpha=0.68, capsize=0, zorder=1)
        ax.scatter([row.cindex], [row.hr], s=size, marker=marker, color="white" if row.role == "Additional evaluation" else color, edgecolor=color, linewidth=1.15, zorder=3)
        dx, dy = offsets[row.cohort]
        ax.annotate(row.cohort, (row.cindex, row.hr), xytext=(dx, dy), textcoords="offset points", fontsize=7.0, ha="left", va="bottom")
    ax.set_xlim(0.29, 0.79)
    ax.set_yscale("log")
    ax.set_ylim(0.52, 3.15)
    ax.set_yticks([0.6, 1.0, 1.5, 2.0, 3.0], labels=["0.6", "1.0", "1.5", "2.0", "3.0"])
    ax.set_xlabel("Harrell C-index")
    ax.set_ylabel("HR per 1-SD LCDI")
    style_axis(ax)
    if add_legend:
        ax.legend(handles=role_handles(), frameon=False, loc="upper center", bbox_to_anchor=(0.54, -0.18), ncol=2, fontsize=7.1, columnspacing=1.0, handlelength=1.8)
    if panel_letter:
        label_panel(ax, panel_letter, -0.14, 1.02)


def evidence_matrix(survival: pd.DataFrame) -> tuple[np.ndarray, list[str]]:
    role_columns = ["Development", "Historical", "Independent", "Additional"]
    evidence_columns = ["HR > 1", "HR interval > 1", "C > 0.5"]
    values = np.zeros((len(survival), len(role_columns) + len(evidence_columns)), dtype=int)
    for i, row in survival.reset_index(drop=True).iterrows():
        role_col = {
            "Development": 0,
            "Historical evaluation": 1,
            "Independent validation": 2,
            "Additional evaluation": 3,
        }[row.role]
        values[i, role_col] = 1
        values[i, 4] = int(row.hr > 1)
        values[i, 5] = int(row.hr_low > 1)
        values[i, 6] = int(row.cindex > 0.5)
    return values, role_columns + evidence_columns


def draw_panel_d(ax: plt.Axes, survival: pd.DataFrame, panel_letter: str | None = None) -> None:
    values, columns = evidence_matrix(survival)
    nrow, ncol = values.shape
    ax.set_xlim(-0.5, ncol - 0.5)
    ax.set_ylim(nrow - 0.5, -0.5)
    ax.set_xticks(range(ncol), labels=columns, rotation=48, ha="right", rotation_mode="anchor", fontsize=7.1)
    ax.set_yticks(range(nrow), labels=survival.cohort, fontsize=7.4)
    for i in range(nrow):
        for j in range(ncol):
            ax.add_patch(Rectangle((j - 0.44, i - 0.38), 0.88, 0.76, facecolor="#F3F3F3", edgecolor="#D8D8D8", linewidth=0.45))
            if values[i, j] == 1:
                if j < 4:
                    color = list(ROLE_STYLE.values())[j][0]
                    marker = list(ROLE_STYLE.values())[j][1]
                else:
                    color, marker = "#5A8F7B", "o"
                ax.scatter(j, i, s=37, marker=marker, color=color, edgecolor="white", linewidth=0.45, zorder=3)
    ax.axvline(3.5, color="#B0B0B0", lw=0.8)
    ax.tick_params(axis="both", length=0)
    for spine in ax.spines.values():
        spine.set_visible(False)
    if panel_letter:
        label_panel(ax, panel_letter, -0.16, 1.02)


def km_curve(time: np.ndarray, status: np.ndarray) -> tuple[np.ndarray, np.ndarray]:
    event_times = np.unique(time[status == 1])
    xs, ys = [0.0], [1.0]
    survival = 1.0
    for t in event_times:
        n_risk = int(np.sum(time >= t))
        n_event = int(np.sum((time == t) & (status == 1)))
        survival *= 1.0 - n_event / n_risk
        xs.append(float(t))
        ys.append(float(survival))
    return np.asarray(xs), np.asarray(ys)


def at_risk(time: np.ndarray, years: list[float]) -> list[int]:
    return [int(np.sum(time >= yr * 365.25)) for yr in years]


def format_p(value: float) -> str:
    return f"{value:.1e}" if value < 0.001 else f"{value:.3f}"


def draw_km_pair(curve_axes: list[plt.Axes], risk_axes: list[plt.Axes], scores: pd.DataFrame, km_stats: pd.DataFrame, panel_letter: str | None = None) -> list[dict]:
    years = [0, 1, 3, 5]
    risk_output: list[dict] = []
    for idx, (cohort, tag) in enumerate([("GPL96_Train", "GPL96"), ("BeatAML2", "BeatAML2")]):
        ax, rax = curve_axes[idx], risk_axes[idx]
        dat = scores.loc[scores.cohort == cohort, ["time", "status", "LCDI_per_sd"]].dropna().astype({"time": float, "status": int, "LCDI_per_sd": float})
        cutoff = float(dat.LCDI_per_sd.median())
        dat["group"] = np.where(dat.LCDI_per_sd > cutoff, "High", "Low")
        for group, color in [("High", HIGH), ("Low", LOW)]:
            sub = dat.loc[dat.group == group]
            x, y = km_curve(sub.time.to_numpy(), sub.status.to_numpy())
            ax.step(x / 365.25, y, where="post", color=color, lw=1.45, label=f"LCDI {group.lower()}")
            counts = at_risk(sub.time.to_numpy(), years)
            for yr, count in zip(years, counts):
                risk_output.append({"cohort": cohort, "group": group, "time_years": yr, "n_risk": count})
        metrics = km_stats.loc[cohort]
        ax.text(0.56, 0.075, f"HR {metrics.hr_high_vs_low:.2f} ({metrics.hr_low:.2f} to {metrics.hr_high:.2f})\nLog-rank P={format_p(float(metrics.logrank_p))}", transform=ax.transAxes, ha="left", va="bottom", fontsize=7.1, bbox={"facecolor": "white", "edgecolor": "none", "alpha": 0.90, "pad": 1.2})
        ax.text(0.02, 0.96, tag, transform=ax.transAxes, ha="left", va="top", fontsize=8.0, color="#444444")
        ax.set_xlim(0, 5)
        ax.set_ylim(0, 1.02)
        ax.set_xticks(years)
        ax.tick_params(axis="x", labelbottom=False)
        if idx == 0:
            ax.set_ylabel("Overall survival")
        else:
            ax.set_ylabel("")
            ax.tick_params(axis="y", labelleft=False)
        style_axis(ax)

        rax.set_xlim(-0.58, 5)
        rax.set_ylim(-0.55, 1.55)
        rax.set_yticks([])
        rax.set_xticks(years)
        rax.set_xlabel("Time (years)")
        rax.text(-0.50, 1.42, "No. at risk", ha="left", va="bottom", fontsize=6.9)
        rax.text(-0.23, 1, "High", ha="right", va="center", fontsize=7.2)
        rax.text(-0.23, 0, "Low", ha="right", va="center", fontsize=7.2)
        for row in [r for r in risk_output if r["cohort"] == cohort]:
            yy = 1 if row["group"] == "High" else 0
            rax.text(row["time_years"], yy, str(row["n_risk"]), ha="center", va="center", fontsize=7.2, color=HIGH if row["group"] == "High" else LOW)
        rax.spines["top"].set_visible(False)
        rax.spines["right"].set_visible(False)
        rax.spines["left"].set_visible(False)
        rax.spines["bottom"].set_linewidth(0.8)
        rax.tick_params(axis="x", width=0.8, length=3)
    curve_axes[1].legend(frameon=False, loc="upper right", fontsize=7.0, handlelength=2.2)
    if panel_letter:
        label_panel(curve_axes[0], panel_letter, -0.20, 1.05)
    return risk_output


def draw_panel_g(ax: plt.Axes, boot: pd.DataFrame, delta_summary: pd.DataFrame, panel_letter: str | None = None, add_legend: bool = False) -> None:
    order = delta_summary.cohort.tolist()
    y_positions = np.arange(len(order))[::-1]
    ax.axvline(0, color="#888888", lw=0.85, ls="--")
    for y, cohort in zip(y_positions, order):
        values = boot.loc[boot.cohort == cohort, "delta"].dropna().to_numpy(dtype=float)
        row = delta_summary.loc[delta_summary.cohort == cohort].iloc[0]
        color, _ = ROLE_STYLE[row.role]
        grid = np.linspace(np.quantile(values, 0.002), np.quantile(values, 0.998), 220)
        density = gaussian_kde(values)(grid)
        density = density / density.max() * 0.34
        ax.fill_between(grid, y, y + density, color=color, alpha=0.35, linewidth=0)
        ax.plot(grid, y + density, color=color, lw=1.0)
        ax.plot([row.low, row.high], [y - 0.11, y - 0.11], color=color, lw=1.55, solid_capstyle="round")
        ax.scatter([row.delta], [y - 0.11], s=28, color=color, edgecolor="white", linewidth=0.45, zorder=3)
    ax.set_yticks(y_positions, labels=order)
    ax.set_xlim(-0.075, 0.062)
    ax.set_xticks([-0.06, -0.03, 0, 0.03, 0.06])
    ax.set_ylim(-0.45, len(order) - 0.35)
    ax.set_xlabel("Delta C-index (LCDI - MPO)")
    style_axis(ax)
    ax.spines["left"].set_visible(False)
    ax.tick_params(axis="y", length=0)
    if add_legend:
        ax.legend(handles=role_handles(), frameon=False, loc="upper center", bbox_to_anchor=(0.55, -0.17), ncol=2, fontsize=7.0)
    if panel_letter:
        label_panel(ax, panel_letter, -0.16, 1.02)


def load_bootstrap() -> pd.DataFrame:
    historical = read_tsv(SOURCES["historical_delta_iterations"])
    tcga = read_tsv(SOURCES["tcga_delta_iterations"])
    paired = read_tsv(SOURCES["paired_delta_iterations"])
    pieces = []
    mapping = {
        "GPL96_Train": "GPL96",
        "GPL570_Val1": "GPL570",
        "GSE10358_Val2": "GSE10358",
        "TARGET_Val4": "TARGET-AML",
    }
    for source, display in mapping.items():
        values = historical.loc[historical.cohort == source, ["iteration", "delta_C_intended_LCDI_minus_MPO"]].copy()
        values.columns = ["iteration", "delta"]
        values["cohort"] = display
        pieces.append(values)
    values = tcga[["iteration", "delta_c"]].copy()
    values.columns = ["iteration", "delta"]
    values["cohort"] = "TCGA-LAML"
    pieces.append(values)
    values = paired.loc[paired.cohort == "BeatAML2", ["iteration", "delta_c"]].copy()
    values.columns = ["iteration", "delta"]
    values["cohort"] = "BeatAML2"
    pieces.append(values)
    boot = pd.concat(pieces, ignore_index=True)[["cohort", "iteration", "delta"]]
    counts = boot.groupby("cohort").size()
    if len(counts) != 6 or not (counts == 1000).all():
        raise AssertionError(f"Bootstrap counts invalid: {counts.to_dict()}")
    return boot


def individual_panels(survival: pd.DataFrame, delta: pd.DataFrame, scores: pd.DataFrame, km_stats: pd.DataFrame, boot: pd.DataFrame) -> None:
    fig, ax = plt.subplots(figsize=(11.0, 3.4))
    draw_panel_a(ax)
    save_figure(fig, "Fig1A_evidence_flow_advanced_v1")

    fig, ax = plt.subplots(figsize=(5.0, 4.4))
    draw_panel_b(ax)
    fig.tight_layout()
    save_figure(fig, "Fig1B_coefficient_lollipop_v1")

    fig, ax = plt.subplots(figsize=(6.2, 5.0))
    draw_panel_c(ax, survival, add_legend=True)
    fig.subplots_adjust(left=0.13, right=0.97, bottom=0.23, top=0.98)
    save_figure(fig, "Fig1C_bivariate_evidence_map_v1")

    fig, ax = plt.subplots(figsize=(6.0, 5.0))
    draw_panel_d(ax, survival)
    fig.subplots_adjust(left=0.23, right=0.98, bottom=0.26, top=0.98)
    save_figure(fig, "Fig1D_evidence_matrix_v1")

    fig = plt.figure(figsize=(10.5, 5.3))
    grid = fig.add_gridspec(2, 2, height_ratios=[3.7, 1.08], hspace=0.05, wspace=0.18)
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])]
    risk_axes = [fig.add_subplot(grid[1, 0]), fig.add_subplot(grid[1, 1])]
    draw_km_pair(axes, risk_axes, scores, km_stats)
    fig.subplots_adjust(left=0.08, right=0.99, bottom=0.11, top=0.99)
    save_figure(fig, "Fig1E_dual_KM_v1")

    fig, ax = plt.subplots(figsize=(6.8, 5.0))
    draw_panel_g(ax, boot, delta, add_legend=True)
    fig.subplots_adjust(left=0.22, right=0.98, bottom=0.22, top=0.98)
    save_figure(fig, "Fig1G_bootstrap_halfeye_v1")


def composite(survival: pd.DataFrame, delta: pd.DataFrame, scores: pd.DataFrame, km_stats: pd.DataFrame, boot: pd.DataFrame) -> None:
    fig = plt.figure(figsize=(18.0, 14.0))
    outer = fig.add_gridspec(3, 1, height_ratios=[0.58, 1.0, 1.18], hspace=0.29)
    ax_a = fig.add_subplot(outer[0])
    draw_panel_a(ax_a, "A")

    middle = outer[1].subgridspec(1, 3, width_ratios=[0.82, 1.16, 1.02], wspace=0.34)
    ax_b = fig.add_subplot(middle[0])
    ax_c = fig.add_subplot(middle[1])
    ax_d = fig.add_subplot(middle[2])
    draw_panel_b(ax_b, "B")
    draw_panel_c(ax_c, survival, "C", add_legend=False)
    draw_panel_d(ax_d, survival, "D")

    lower = outer[2].subgridspec(1, 2, width_ratios=[2.05, 1.12], wspace=0.30)
    egrid = lower[0].subgridspec(2, 2, height_ratios=[3.7, 1.08], hspace=0.05, wspace=0.18)
    e_axes = [fig.add_subplot(egrid[0, 0]), fig.add_subplot(egrid[0, 1])]
    e_risk = [fig.add_subplot(egrid[1, 0]), fig.add_subplot(egrid[1, 1])]
    draw_km_pair(e_axes, e_risk, scores, km_stats, "E")
    ax_g = fig.add_subplot(lower[1])
    draw_panel_g(ax_g, boot, delta, "G", add_legend=False)

    fig.legend(handles=role_handles(), frameon=False, loc="lower center", bbox_to_anchor=(0.72, 0.015), ncol=4, fontsize=8.6, columnspacing=1.5, handlelength=2.0)
    fig.subplots_adjust(left=0.045, right=0.985, bottom=0.085, top=0.985)
    save_figure(fig, "Figure1_advanced_composite_A_BCD_EG_v1")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    missing = [name for name, path in SOURCES.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing sources: {missing}")
    mpl.rcParams.update({
        "font.family": "Arial",
        "font.size": 9,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.unicode_minus": False,
    })

    survival = read_tsv(SOURCES["survival_summary"])
    delta = read_tsv(SOURCES["delta_summary"])
    km_stats = read_tsv(SOURCES["km_statistics"]).set_index("cohort")
    scores = read_tsv(SOURCES["patient_scores"])
    boot = load_bootstrap()

    if survival.hr.round(3).tolist() != [1.262, 1.811, 1.290, 1.391, 1.212, 0.962, 0.865, 1.042]:
        raise AssertionError("HR values differ from frozen manuscript values")
    if survival.cindex.round(3).tolist() != [0.566, 0.664, 0.561, 0.596, 0.548, 0.480, 0.424, 0.504]:
        raise AssertionError("C-index values differ from frozen manuscript values")
    if delta.delta.round(5).tolist() != [-0.00166, -0.00397, -0.00403, -0.03259, -0.00696, -0.01639]:
        raise AssertionError("Delta C values differ from frozen manuscript values")

    individual_panels(survival, delta, scores, km_stats, boot)
    composite(survival, delta, scores, km_stats, boot)

    boot.to_csv(OUT / "01_bootstrap_delta_distributions.tsv", sep="\t", index=False)
    values, columns = evidence_matrix(survival)
    matrix = pd.DataFrame(values, index=survival.cohort, columns=columns)
    matrix.index.name = "cohort"
    matrix.to_csv(OUT / "01_evidence_matrix.tsv", sep="\t")
    pd.DataFrame({"source": list(SOURCES), "path": [str(path) for path in SOURCES.values()]}).to_csv(OUT / "01_source_manifest.tsv", sep="\t", index=False)
    pd.DataFrame(
        [
            ("row1", "A", "full width", "evidence flow"),
            ("row2", "B", "0.82", "coefficient lollipop"),
            ("row2", "C", "1.16", "bivariate evidence map"),
            ("row2", "D", "1.02", "evidence matrix"),
            ("row3", "E", "2.05", "GPL96 and BeatAML2 KM"),
            ("row3", "G", "1.12", "bootstrap half-eye"),
        ],
        columns=["row", "panel", "relative_width", "content"],
    ).to_csv(OUT / "01_layout_manifest.tsv", sep="\t", index=False)
    status = {
        "status": "passed",
        "individual_panels": 6,
        "composite_figures": 1,
        "png_generated": 7,
        "pdf_generated": 7,
        "internal_titles": 0,
        "layout": "A/BCD/EG",
        "word_modified": 0,
        "source_files_modified": 0,
    }
    pd.DataFrame(status.items(), columns=["field", "value"]).to_csv(OUT / "02_run_status.tsv", sep="\t", index=False)
    (OUT / "02_environment.json").write_text(json.dumps({"python": __import__("sys").version, "pandas": pd.__version__, "numpy": np.__version__, "matplotlib": mpl.__version__, "scipy": __import__("scipy").__version__}, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()

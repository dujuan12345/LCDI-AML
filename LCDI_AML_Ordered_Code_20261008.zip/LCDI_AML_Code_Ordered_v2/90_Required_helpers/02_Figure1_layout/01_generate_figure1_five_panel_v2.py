from __future__ import annotations

import importlib.util
import json
import math
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
BASE = PROJECT / "_codex_audit" / "figure1_individual_panels_20260902_v1"
PREVIOUS = PROJECT / "_codex_audit" / "figure1_composite_20260902_v1"
OUT = PROJECT / "_codex_audit" / "figure1_composite_20260902_v2"

SOURCES = {
    "survival_summary": BASE / "01_frozen_survival_inputs.tsv",
    "km_statistics": BASE / "02_km_statistics.tsv",
    "patient_scores": PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "01_patient_scores.tsv",
    "candidate_deg": PROJECT / "AML_Lactylation_PCD" / "results" / "tables" / "deg_results_all.csv",
    "previous_generator": PREVIOUS / "01_generate_advanced_figure1.py",
}

UP = "#D55E00"
DOWN = "#0072B2"
OTHER = "#B8B8B8"
FINAL = "#7A1F1F"
FINAL_GENES = ["CREB1", "SLC16A4", "GPX4", "CASP1", "MPO"]


def load_previous_module():
    spec = importlib.util.spec_from_file_location("figure1_v1", SOURCES["previous_generator"])
    if spec is None or spec.loader is None:
        raise ImportError("Cannot load previous figure generator")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    module.OUT = OUT
    return module


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.png", dpi=400, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def prepare_deg() -> tuple[pd.DataFrame, dict[str, int]]:
    deg = pd.read_csv(SOURCES["candidate_deg"])
    deg["logFC"] = pd.to_numeric(deg["logFC"], errors="coerce")
    deg["FDR"] = pd.to_numeric(deg["adj.P.Val"], errors="coerce")
    deg["estimable"] = deg[["logFC", "FDR"]].notna().all(axis=1)
    deg["direction"] = "Not retained"
    deg.loc[deg.estimable & (deg.logFC > 1) & (deg.FDR < 0.05), "direction"] = "Up"
    deg.loc[deg.estimable & (deg.logFC < -1) & (deg.FDR < 0.05), "direction"] = "Down"
    deg["minus_log10_fdr"] = -np.log10(deg.FDR.clip(lower=np.finfo(float).tiny))
    deg["plot_y"] = deg.minus_log10_fdr.clip(upper=40)
    counts = {
        "input": int(len(deg)),
        "estimable": int(deg.estimable.sum()),
        "not_estimable": int((~deg.estimable).sum()),
        "retained": int(deg.direction.isin(["Up", "Down"]).sum()),
        "up": int((deg.direction == "Up").sum()),
        "down": int((deg.direction == "Down").sum()),
        "not_retained": int((deg.estimable & (deg.direction == "Not retained")).sum()),
    }
    return deg, counts


def draw_volcano(ax: plt.Axes, deg: pd.DataFrame, counts: dict[str, int], panel_letter: str | None = None) -> None:
    visible = deg.loc[deg.estimable].copy()
    style = {
        "Not retained": (OTHER, 24, 0.72),
        "Down": (DOWN, 37, 0.88),
        "Up": (UP, 37, 0.88),
    }
    for label in ["Not retained", "Down", "Up"]:
        subset = visible.loc[visible.direction == label]
        color, size, alpha = style[label]
        ax.scatter(subset.logFC, subset.plot_y, s=size, color=color, alpha=alpha,
                   edgecolor="white", linewidth=0.35, zorder=2)

    selected = visible.loc[visible.Gene.isin(FINAL_GENES)].copy()
    ax.scatter(selected.logFC, selected.plot_y, s=62, color=FINAL, marker="D",
               edgecolor="white", linewidth=0.65, zorder=4)

    offsets = {
        "CREB1": (-12, 7),
        "CASP1": (7, 6),
        "SLC16A4": (7, 5),
        "GPX4": (-43, 6),
        "MPO": (7, 2),
    }
    for _, row in selected.iterrows():
        dx, dy = offsets[row.Gene]
        ax.annotate(row.Gene, (row.logFC, row.plot_y), xytext=(dx, dy),
                    textcoords="offset points", fontsize=7.4, fontweight="bold",
                    ha="left", va="bottom",
                    arrowprops={"arrowstyle": "-", "lw": 0.55, "color": "#555555"})

    ax.axvline(-1, color="#777777", lw=0.8, ls="--", zorder=1)
    ax.axvline(1, color="#777777", lw=0.8, ls="--", zorder=1)
    ax.axhline(-math.log10(0.05), color="#777777", lw=0.8, ls="--", zorder=1)
    ax.set_xlim(-6.0, 7.0)
    ax.set_ylim(0, 43.4)
    ax.set_xticks([-6, -3, 0, 3, 6])
    ax.set_yticks([0, 10, 20, 30, 40], labels=["0", "10", "20", "30", "≥40"])
    ax.set_xlabel("log2 fold change")
    ax.set_ylabel("−log10(FDR)")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.tick_params(width=0.8, length=4, color="#333333")

    handles = [
        Line2D([0], [0], marker="o", color="none", markerfacecolor=UP, markeredgecolor="white", markersize=6, label=f"Up ({counts['up']})"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=DOWN, markeredgecolor="white", markersize=6, label=f"Down ({counts['down']})"),
        Line2D([0], [0], marker="o", color="none", markerfacecolor=OTHER, markeredgecolor="white", markersize=6, label=f"Not retained ({counts['not_retained']})"),
        Line2D([0], [0], marker="D", color="none", markerfacecolor=FINAL, markeredgecolor="white", markersize=6, label="Final LCDI genes"),
    ]
    ax.legend(handles=handles, frameon=False, loc="upper left", fontsize=7.0,
              handletextpad=0.4, borderaxespad=0.25, ncol=1)
    ax.text(0.985, 0.03, f"{counts['estimable']} estimable / {counts['input']} candidates",
            transform=ax.transAxes, ha="right", va="bottom", fontsize=7.0, color="#555555")
    if panel_letter:
        ax.text(-0.14, 1.02, panel_letter, transform=ax.transAxes, fontsize=15,
                fontweight="bold", ha="left", va="bottom")


def individual_panels(v1, survival: pd.DataFrame, scores: pd.DataFrame,
                      km_stats: pd.DataFrame, deg: pd.DataFrame, counts: dict[str, int]) -> None:
    fig, ax = plt.subplots(figsize=(11.0, 3.4))
    v1.draw_panel_a(ax)
    save_figure(fig, "Fig1A_evidence_flow_v2")

    fig, ax = plt.subplots(figsize=(5.4, 4.7))
    draw_volcano(ax, deg, counts)
    fig.subplots_adjust(left=0.14, right=0.98, bottom=0.13, top=0.98)
    save_figure(fig, "Fig1B_candidate_DEG_volcano_v2")

    fig, ax = plt.subplots(figsize=(5.0, 4.4))
    v1.draw_panel_b(ax)
    fig.tight_layout()
    save_figure(fig, "Fig1C_coefficient_lollipop_v2")

    fig, ax = plt.subplots(figsize=(6.0, 5.0))
    v1.draw_panel_d(ax, survival)
    fig.subplots_adjust(left=0.23, right=0.98, bottom=0.26, top=0.98)
    save_figure(fig, "Fig1D_evidence_matrix_v2")

    fig = plt.figure(figsize=(10.5, 5.3))
    grid = fig.add_gridspec(2, 2, height_ratios=[3.7, 1.08], hspace=0.05, wspace=0.18)
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])]
    risk_axes = [fig.add_subplot(grid[1, 0]), fig.add_subplot(grid[1, 1])]
    v1.draw_km_pair(axes, risk_axes, scores, km_stats)
    fig.subplots_adjust(left=0.08, right=0.99, bottom=0.11, top=0.99)
    save_figure(fig, "Fig1E_dual_KM_v2")


def composite(v1, survival: pd.DataFrame, scores: pd.DataFrame,
              km_stats: pd.DataFrame, deg: pd.DataFrame, counts: dict[str, int]) -> None:
    fig = plt.figure(figsize=(18.0, 14.0))
    outer = fig.add_gridspec(3, 1, height_ratios=[0.56, 1.0, 1.20], hspace=0.30)
    ax_a = fig.add_subplot(outer[0])
    v1.draw_panel_a(ax_a, "A")

    middle = outer[1].subgridspec(1, 3, width_ratios=[1.20, 0.82, 1.08], wspace=0.38)
    ax_b = fig.add_subplot(middle[0])
    ax_c = fig.add_subplot(middle[1])
    ax_d = fig.add_subplot(middle[2])
    draw_volcano(ax_b, deg, counts, "B")
    v1.draw_panel_b(ax_c, "C")
    v1.draw_panel_d(ax_d, survival, "D")

    egrid = outer[2].subgridspec(2, 2, height_ratios=[3.7, 1.08], hspace=0.05, wspace=0.18)
    e_axes = [fig.add_subplot(egrid[0, 0]), fig.add_subplot(egrid[0, 1])]
    e_risk = [fig.add_subplot(egrid[1, 0]), fig.add_subplot(egrid[1, 1])]
    v1.draw_km_pair(e_axes, e_risk, scores, km_stats, "E")

    fig.subplots_adjust(left=0.050, right=0.985, bottom=0.065, top=0.985)
    save_figure(fig, "Figure1_five_panel_A_BCD_E_v2")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    missing = [name for name, path in SOURCES.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing sources: {missing}")

    mpl.rcParams.update({
        "font.family": "Arial",
        "font.size": 9,
        "axes.labelsize": 9.5,
        "xtick.labelsize": 8.5,
        "ytick.labelsize": 8.5,
        "pdf.fonttype": 42,
        "ps.fonttype": 42,
        "axes.unicode_minus": False,
    })
    v1 = load_previous_module()
    survival = pd.read_csv(SOURCES["survival_summary"], sep="\t")
    km_stats = pd.read_csv(SOURCES["km_statistics"], sep="\t").set_index("cohort")
    scores = pd.read_csv(SOURCES["patient_scores"], sep="\t")
    deg, counts = prepare_deg()

    expected_counts = {"input": 106, "estimable": 104, "not_estimable": 2,
                       "retained": 89, "up": 86, "down": 3, "not_retained": 15}
    if counts != expected_counts:
        raise AssertionError(f"DEG counts differ from frozen values: {counts}")
    if set(FINAL_GENES) != set(deg.loc[deg.Gene.isin(FINAL_GENES) & deg.direction.eq("Up"), "Gene"]):
        raise AssertionError("All five final LCDI genes must be retained and up-regulated")
    if survival.cindex.round(3).tolist() != [0.566, 0.664, 0.561, 0.596, 0.548, 0.480, 0.424, 0.504]:
        raise AssertionError("C-index values differ from frozen manuscript values")

    individual_panels(v1, survival, scores, km_stats, deg, counts)
    composite(v1, survival, scores, km_stats, deg, counts)

    deg.loc[:, ["Gene", "Category", "logFC", "FDR", "estimable", "direction", "minus_log10_fdr"]].to_csv(
        OUT / "01_candidate_deg_plot_data.tsv", sep="\t", index=False
    )
    values, columns = v1.evidence_matrix(survival)
    matrix = pd.DataFrame(values, index=survival.cohort, columns=columns)
    matrix.index.name = "cohort"
    matrix.to_csv(OUT / "01_evidence_matrix.tsv", sep="\t")
    pd.DataFrame({"source": list(SOURCES), "path": [str(path) for path in SOURCES.values()]}).to_csv(
        OUT / "01_source_manifest.tsv", sep="\t", index=False
    )
    pd.DataFrame([
        ("row1", "A", "full width", "evidence flow"),
        ("row2", "B", "1.20", "candidate-gene DEG volcano"),
        ("row2", "C", "0.82", "coefficient lollipop"),
        ("row2", "D", "1.08", "evidence matrix"),
        ("row3", "E", "full width", "GPL96 and BeatAML2 KM"),
    ], columns=["row", "panel", "relative_width", "content"]).to_csv(
        OUT / "01_layout_manifest.tsv", sep="\t", index=False
    )
    pd.DataFrame([counts]).to_csv(OUT / "01_candidate_deg_counts.tsv", sep="\t", index=False)
    status = {
        "status": "passed",
        "individual_panels": 5,
        "composite_figures": 1,
        "png_generated": 6,
        "pdf_generated": 6,
        "internal_titles": 0,
        "layout": "A/BCD/E",
        "removed_former_panels": "C_bivariate;G_delta_halfeye",
        "word_modified": 0,
        "manuscript_modified": 0,
        "source_files_modified": 0,
    }
    pd.DataFrame(status.items(), columns=["field", "value"]).to_csv(OUT / "02_run_status.tsv", sep="\t", index=False)
    (OUT / "02_environment.json").write_text(json.dumps({
        "python": __import__("sys").version,
        "pandas": pd.__version__,
        "numpy": np.__version__,
        "matplotlib": mpl.__version__,
    }, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()

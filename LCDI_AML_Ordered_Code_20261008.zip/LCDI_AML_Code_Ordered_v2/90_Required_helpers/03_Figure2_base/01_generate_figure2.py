from __future__ import annotations

import json
import math
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.lines import Line2D
import numpy as np
import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
DCA_DIR = PROJECT / "_codex_audit" / "figure2_dca_preview_20260903_v1"
NOMO_DIR = PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "final_branch_nomogram" / "final"
OUT = PROJECT / "_codex_audit" / "figure2_composite_20260903_v1"

SOURCES = {
    "nomogram_axes": DCA_DIR / "07_nomogram_axis_ticks.tsv",
    "nomogram_survival_ticks": DCA_DIR / "07_nomogram_survival_ticks.tsv",
    "nomogram_scale_summary": DCA_DIR / "07_nomogram_scale_summary.tsv",
    "nomogram_coefficient_qc": DCA_DIR / "07_nomogram_coefficient_qc.tsv",
    "performance": NOMO_DIR / "bootstrap_optimism_corrected_performance.tsv",
    "calibration_curves": NOMO_DIR / "calibration_modelD_curves.tsv",
    "calibration_metrics": NOMO_DIR / "calibration_modelD_metrics.tsv",
    "dca_curves": DCA_DIR / "01_dca_curve_values.tsv",
    "dca_validation": DCA_DIR / "04_validation_summary.json",
}

TCGA = "#3F3F3F"
TARGET = "#D55E00"
MODEL_A = "#0072B2"
MODEL_D = "#D55E00"
TIME_COLORS = {1: "#0072B2", 3: "#009E73", 5: "#D55E00"}


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.png", dpi=400, bbox_inches="tight", facecolor="white")
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def panel_letter(ax: plt.Axes, letter: str, x: float = -0.10, y: float = 1.03) -> None:
    ax.text(x, y, letter, transform=ax.transAxes, fontsize=15, fontweight="bold",
            ha="left", va="bottom")


def draw_scale(ax: plt.Axes, y: float, x0: float, x1: float, color: str = "#454545",
               lw: float = 0.8) -> None:
    ax.plot([x0, x1], [y, y], color=color, lw=lw, solid_capstyle="round", zorder=1)


def draw_nomogram(ax: plt.Axes, cohort: str, axes: pd.DataFrame,
                  survival_ticks: pd.DataFrame, summary: pd.DataFrame,
                  letter: str | None = None) -> None:
    sub = axes.loc[axes.cohort == cohort].copy()
    surv = survival_ticks.loc[survival_ticks.cohort == cohort].copy()
    info = summary.loc[summary.cohort == cohort].iloc[0]
    predictors = sub.sort_values("row_order").predictor.drop_duplicates().tolist()
    nvar = len(predictors)
    y_top = nvar + 4.35
    y_vars = {pred: nvar + 3.15 - i for i, pred in enumerate(predictors)}
    y_total = 2.45
    y_surv = {1: 1.55, 3: 0.75, 5: -0.05}

    ax.set_xlim(-0.23, 1.04)
    ax.set_ylim(-0.65, y_top + 0.95)
    ax.axis("off")
    cohort_label = "TCGA-LAML" if cohort == "TCGA" else "TARGET-AML"
    ax.text(0.0, y_top + 0.70,
            f"{cohort_label} · N={int(info['n']):,}, events={int(info['events']):,}",
            ha="left", va="top", fontsize=9.0, fontweight="bold")

    draw_scale(ax, y_top, 0, 1, lw=0.95)
    ax.text(-0.03, y_top, "Points", ha="right", va="center", fontsize=8.0, fontweight="bold")
    for value in range(0, 101, 20):
        x = value / 100
        ax.plot([x, x], [y_top - 0.07, y_top + 0.07], color="#454545", lw=0.7)
        ax.text(x, y_top + 0.12, str(value), ha="center", va="bottom", fontsize=6.8)

    for predictor in predictors:
        rows = sub.loc[sub.predictor == predictor].sort_values("position")
        y = y_vars[predictor]
        color = "#C75D14" if cohort == "TCGA" and predictor == "age" else "#4A4A4A"
        draw_scale(ax, y, float(rows.position.min()), float(rows.position.max()), color=color, lw=0.9)
        ax.text(-0.03, y, rows.display_name.iloc[0], ha="right", va="center",
                fontsize=7.7, fontweight="bold" if predictor == "age" and cohort == "TCGA" else "normal",
                color=color)
        positions = rows.position.to_numpy(float)
        categorical = rows.kind.iloc[0] == "categorical"
        for index, row in enumerate(rows.itertuples(index=False)):
            x = float(row.position)
            ax.plot([x, x], [y - 0.065, y + 0.065], color=color, lw=0.75)
            if categorical:
                offset = 0.12 if index % 2 == 0 else -0.13
                va = "bottom" if offset > 0 else "top"
            else:
                offset, va = 0.12, "bottom"
            ax.text(x, y + offset, str(row.value_label), ha="center", va=va,
                    fontsize=6.35, color="#333333")
        if categorical and len(positions) > 2:
            close = np.diff(np.sort(positions)) < 0.10
            if close.any():
                ax.text(1.015, y, "", fontsize=1)

    total_max = float(info.total_points_max)
    draw_scale(ax, y_total, 0, 1, lw=0.95)
    ax.text(-0.03, y_total, "Total points", ha="right", va="center", fontsize=8.0, fontweight="bold")
    step = 50 if total_max >= 250 else 25
    total_values = np.arange(0, math.floor(total_max / step) * step + 1, step)
    for value in total_values:
        x = value / total_max
        ax.plot([x, x], [y_total - 0.07, y_total + 0.07], color="#454545", lw=0.7)
        ax.text(x, y_total + 0.12, f"{value:.0f}", ha="center", va="bottom", fontsize=6.6)

    for year in [1, 3, 5]:
        rows = surv.loc[surv.year == year].sort_values("position")
        y = y_surv[year]
        draw_scale(ax, y, float(rows.position.min()), float(rows.position.max()), color=TIME_COLORS[year], lw=1.0)
        ax.text(-0.03, y, f"{year}-year survival", ha="right", va="center", fontsize=7.4)
        for row in rows.itertuples(index=False):
            x = float(row.position)
            ax.plot([x, x], [y - 0.06, y + 0.06], color=TIME_COLORS[year], lw=0.7)
            ax.text(x, y - 0.11, f"{row.survival_probability:.1f}", ha="center", va="top",
                    fontsize=6.1, color="#333333")
    if letter:
        panel_letter(ax, letter, -0.02, 1.005)


def draw_performance(ax: plt.Axes, performance: pd.DataFrame, letter: str | None = None) -> None:
    data = performance.loc[performance.metric == "C_index"].copy()
    model_x = {model: index for index, model in enumerate(["A", "B", "C", "D"])}
    cohort_style = {"TCGA": (TCGA, "o"), "TARGET": (TARGET, "s")}
    for cohort, (color, marker) in cohort_style.items():
        sub = data.loc[data.cohort == cohort].sort_values("model")
        x = np.array([model_x[m] for m in sub.model])
        y = sub.optimism_corrected.to_numpy(float)
        low = sub.corrected_distribution_p025.to_numpy(float)
        high = sub.corrected_distribution_p975.to_numpy(float)
        ax.plot(x, y, color=color, lw=1.7, zorder=2)
        ax.errorbar(x, y, yerr=[y - low, high - y], fmt=marker, ms=6.0,
                    color=color, ecolor=color, elinewidth=1.0, capsize=2.5,
                    markerfacecolor="white" if cohort == "TARGET" else color,
                    markeredgewidth=1.2, zorder=3, label=cohort)
        for xi, yi in zip(x, y):
            ax.text(xi, yi + 0.012, f"{yi:.3f}", ha="center", va="bottom",
                    fontsize=6.9, color=color)
    tcga = data.loc[data.cohort == "TCGA"].set_index("model")
    gain = float(tcga.loc["B", "optimism_corrected"] - tcga.loc["A", "optimism_corrected"])
    ax.annotate(f"TCGA largest step  +{gain:.3f}",
                xy=(1, tcga.loc["B", "optimism_corrected"]), xytext=(1.48, 0.727),
                fontsize=7.4, ha="center", color="#333333",
                arrowprops={"arrowstyle": "->", "lw": 0.8, "color": "#777777"})
    ax.set_xlim(-0.25, 3.25)
    ax.set_ylim(0.48, 0.76)
    ax.set_xticks([0, 1, 2, 3], labels=["A\nLCDI", "B\nAge/FAB*", "C\n+ Cytogenetics", "D\n+ Mutations"])
    ax.set_ylabel("Optimism-corrected C-index")
    ax.grid(axis="y", color="#E4E4E4", lw=0.6)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.legend(frameon=False, loc="lower right", fontsize=7.5)
    ax.text(0.01, 0.02, "*TARGET Model B adds age only", transform=ax.transAxes,
            fontsize=6.8, color="#555555", ha="left", va="bottom")
    if letter:
        panel_letter(ax, letter, -0.12, 1.02)


def draw_dca_axis(ax: plt.Axes, data: pd.DataFrame, cohort: str, show_ylabel: bool) -> None:
    ax.axhline(0, color="#222222", lw=0.85)
    for model, color, lw, ls in [
        ("A", MODEL_A, 1.6, "-"), ("D", MODEL_D, 2.1, "-"),
        ("Treat all", "#888888", 1.5, "--")
    ]:
        sub = data.loc[data.model == model].sort_values("threshold")
        ax.plot(sub.threshold, sub.net_benefit, color=color, lw=lw, ls=ls)
    ax.set_xlim(0.05, 0.75)
    ax.set_ylim((-0.06, 0.74) if cohort == "TCGA" else (-0.04, 0.36))
    ax.set_xticks([0.1, 0.2, 0.4, 0.6])
    ax.set_xlabel("Threshold probability")
    if show_ylabel:
        ax.set_ylabel("Net benefit")
    ax.grid(axis="y", color="#E6E6E6", lw=0.55)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.text(0.02, 0.97, cohort, transform=ax.transAxes, ha="left", va="top",
            fontsize=8.5, fontweight="bold")


def draw_dca_pair(fig: plt.Figure, slot, curves: pd.DataFrame, letter: str | None = None) -> list[plt.Axes]:
    grid = slot.subgridspec(1, 2, wspace=0.22)
    axes = [fig.add_subplot(grid[0, 0]), fig.add_subplot(grid[0, 1])]
    for index, cohort in enumerate(["TCGA", "TARGET"]):
        sub = curves.loc[(curves.cohort == cohort) & (curves.year == 3)]
        draw_dca_axis(axes[index], sub, cohort, show_ylabel=(index == 0))
    handles = [
        Line2D([0], [0], color=MODEL_A, lw=1.7, label="LCDI only"),
        Line2D([0], [0], color=MODEL_D, lw=2.2, label="Full nomogram"),
        Line2D([0], [0], color="#888888", lw=1.5, ls="--", label="Treat all"),
        Line2D([0], [0], color="#222222", lw=0.9, label="Treat none"),
    ]
    axes[1].legend(handles=handles, frameon=False, fontsize=6.4, loc="upper right",
                   handlelength=2.0, borderaxespad=0.3)
    if letter:
        panel_letter(axes[0], letter, -0.16, 1.02)
    return axes


def draw_calibration(ax: plt.Axes, cohort: str, curves: pd.DataFrame,
                     metrics: pd.DataFrame, letter: str | None = None) -> None:
    ax.plot([0, 1], [0, 1], color="#777777", lw=1.0, ls="--")
    cohort_curves = curves.loc[curves.cohort == cohort]
    cohort_metrics = metrics.loc[(metrics.cohort == cohort) & (metrics.metric == "ICI")].set_index("year")
    for year in [1, 3, 5]:
        sub = cohort_curves.loc[cohort_curves.year == year].sort_values("mean_predicted")
        color = TIME_COLORS[year]
        ax.fill_between(sub.mean_predicted, sub.corrected_distribution_p025,
                        sub.corrected_distribution_p975, color=color, alpha=0.10, linewidth=0)
        ax.plot(sub.mean_predicted, sub.optimism_corrected_observed, color=color,
                marker="o", ms=4.0, lw=1.6,
                label=f"{year} year · ICI={cohort_metrics.loc[year, 'optimism_corrected']:.3f}")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_xlabel("Predicted survival")
    ax.set_ylabel("Observed survival")
    ax.grid(color="#E7E7E7", lw=0.55)
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.text(0.03, 0.97, cohort, transform=ax.transAxes, ha="left", va="top",
            fontsize=9.0, fontweight="bold")
    ax.legend(frameon=False, loc="lower right", fontsize=7.1)
    if letter:
        panel_letter(ax, letter, -0.12, 1.02)


def individual_panels(axes: pd.DataFrame, survival_ticks: pd.DataFrame,
                      summary: pd.DataFrame, performance: pd.DataFrame,
                      dca: pd.DataFrame, calibration: pd.DataFrame,
                      calibration_metrics: pd.DataFrame) -> None:
    for cohort, letter in [("TCGA", "A"), ("TARGET", "B")]:
        fig, ax = plt.subplots(figsize=(8.5, 5.7))
        draw_nomogram(ax, cohort, axes, survival_ticks, summary)
        save_figure(fig, f"Fig2{letter}_{cohort}_nomogram_v1")

    fig, ax = plt.subplots(figsize=(6.6, 5.0))
    draw_performance(ax, performance)
    fig.subplots_adjust(left=0.13, right=0.98, bottom=0.16, top=0.97)
    save_figure(fig, "Fig2C_nested_model_performance_v1")

    fig = plt.figure(figsize=(10.8, 4.7))
    draw_dca_pair(fig, fig.add_gridspec(1, 1)[0], dca)
    fig.subplots_adjust(left=0.08, right=0.99, bottom=0.13, top=0.98)
    save_figure(fig, "Fig2D_3yr_DCA_v1")

    for cohort, letter in [("TCGA", "E"), ("TARGET", "F")]:
        fig, ax = plt.subplots(figsize=(6.2, 5.2))
        draw_calibration(ax, cohort, calibration, calibration_metrics)
        fig.subplots_adjust(left=0.13, right=0.98, bottom=0.13, top=0.98)
        save_figure(fig, f"Fig2{letter}_{cohort}_calibration_v1")


def composite(axes: pd.DataFrame, survival_ticks: pd.DataFrame,
              summary: pd.DataFrame, performance: pd.DataFrame,
              dca: pd.DataFrame, calibration: pd.DataFrame,
              calibration_metrics: pd.DataFrame) -> None:
    fig = plt.figure(figsize=(18.0, 14.2))
    outer = fig.add_gridspec(3, 1, height_ratios=[1.12, 0.83, 0.92], hspace=0.27)

    top = outer[0].subgridspec(1, 2, wspace=0.13)
    ax_a = fig.add_subplot(top[0, 0])
    ax_b = fig.add_subplot(top[0, 1])
    draw_nomogram(ax_a, "TCGA", axes, survival_ticks, summary, "A")
    draw_nomogram(ax_b, "TARGET", axes, survival_ticks, summary, "B")

    middle = outer[1].subgridspec(1, 2, width_ratios=[0.86, 1.14], wspace=0.20)
    ax_c = fig.add_subplot(middle[0, 0])
    draw_performance(ax_c, performance, "C")
    draw_dca_pair(fig, middle[0, 1], dca, "D")

    bottom = outer[2].subgridspec(1, 2, wspace=0.22)
    ax_e = fig.add_subplot(bottom[0, 0])
    ax_f = fig.add_subplot(bottom[0, 1])
    draw_calibration(ax_e, "TCGA", calibration, calibration_metrics, "E")
    draw_calibration(ax_f, "TARGET", calibration, calibration_metrics, "F")

    fig.subplots_adjust(left=0.045, right=0.988, bottom=0.055, top=0.985)
    save_figure(fig, "Figure2_nomogram_performance_DCA_calibration_v1")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    missing = [name for name, path in SOURCES.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing Figure 2 sources: {missing}")
    mpl.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.labelsize": 9.5,
        "xtick.labelsize": 8.2, "ytick.labelsize": 8.2,
        "pdf.fonttype": 42, "ps.fonttype": 42, "axes.unicode_minus": False,
    })

    axes = pd.read_csv(SOURCES["nomogram_axes"], sep="\t")
    survival_ticks = pd.read_csv(SOURCES["nomogram_survival_ticks"], sep="\t")
    summary = pd.read_csv(SOURCES["nomogram_scale_summary"], sep="\t")
    performance = pd.read_csv(SOURCES["performance"], sep="\t")
    calibration = pd.read_csv(SOURCES["calibration_curves"], sep="\t")
    calibration_metrics = pd.read_csv(SOURCES["calibration_metrics"], sep="\t")
    dca = pd.read_csv(SOURCES["dca_curves"], sep="\t")

    if len(axes) != 44 or len(survival_ticks) != 42:
        raise AssertionError("Nomogram axes differ from frozen preparation")
    if performance.loc[performance.metric == "C_index"].shape[0] != 8:
        raise AssertionError("Nested model C-index rows invalid")
    if len(calibration) != 27 or len(calibration_metrics) != 12:
        raise AssertionError("Calibration inputs invalid")
    if len(dca) != 2736:
        raise AssertionError("DCA input rows invalid")

    individual_panels(axes, survival_ticks, summary, performance, dca,
                      calibration, calibration_metrics)
    composite(axes, survival_ticks, summary, performance, dca,
              calibration, calibration_metrics)

    pd.DataFrame({"source": list(SOURCES), "path": [str(path) for path in SOURCES.values()]}).to_csv(
        OUT / "01_source_manifest.tsv", sep="\t", index=False
    )
    pd.DataFrame([
        ("row1", "A", "1.0", "TCGA full nomogram"),
        ("row1", "B", "1.0", "TARGET full nomogram"),
        ("row2", "C", "0.86", "nested corrected C-index"),
        ("row2", "D", "1.14", "3-year two-cohort DCA"),
        ("row3", "E", "1.0", "TCGA calibration"),
        ("row3", "F", "1.0", "TARGET calibration"),
    ], columns=["row", "panel", "relative_width", "content"]).to_csv(
        OUT / "01_layout_manifest.tsv", sep="\t", index=False
    )
    status = {
        "status": "passed", "individual_panels": 6, "composite_figures": 1,
        "png_generated": 7, "pdf_generated": 7, "internal_titles": 0,
        "layout": "AB/CD/EF", "word_modified": 0,
        "manuscript_modified": 0, "source_files_modified": 0,
    }
    pd.DataFrame(status.items(), columns=["field", "value"]).to_csv(
        OUT / "02_run_status.tsv", sep="\t", index=False
    )
    (OUT / "02_environment.json").write_text(json.dumps({
        "python": __import__("sys").version, "pandas": pd.__version__,
        "numpy": np.__version__, "matplotlib": mpl.__version__,
    }, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()

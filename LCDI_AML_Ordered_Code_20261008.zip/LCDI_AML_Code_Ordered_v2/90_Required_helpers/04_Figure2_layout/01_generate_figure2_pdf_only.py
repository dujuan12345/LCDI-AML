from __future__ import annotations

import importlib.util
import json
from pathlib import Path

import matplotlib as mpl
import matplotlib.pyplot as plt
from matplotlib.text import Text
import numpy as np
import pandas as pd


PROJECT = Path(r"D:\26_01_AML")
V1_DIR = PROJECT / "_codex_audit" / "figure2_composite_20260903_v1"
DCA_DIR = PROJECT / "_codex_audit" / "figure2_dca_preview_20260903_v1"
NOMO_DIR = PROJECT / "_codex_audit" / "cindex_nomogram_reconciliation_20260902_v1" / "final_branch_nomogram" / "final"
OUT = PROJECT / "_codex_audit" / "figure2_composite_20260903_v5"

SOURCES = {
    "v1_generator": V1_DIR / "01_generate_figure2.py",
    "nomogram_axes": DCA_DIR / "07_nomogram_axis_ticks.tsv",
    "nomogram_survival_ticks": DCA_DIR / "07_nomogram_survival_ticks.tsv",
    "nomogram_scale_summary": DCA_DIR / "07_nomogram_scale_summary.tsv",
    "performance": NOMO_DIR / "bootstrap_optimism_corrected_performance.tsv",
    "dca_curves": DCA_DIR / "01_dca_curve_values.tsv",
    "roc_curves": DCA_DIR / "08_timeROC_curve_values.tsv",
    "roc_auc": DCA_DIR / "08_timeROC_auc_summary.tsv",
    "calibration_curves": NOMO_DIR / "calibration_modelD_curves.tsv",
    "calibration_metrics": NOMO_DIR / "calibration_modelD_metrics.tsv",
    "roc_run_status": DCA_DIR / "08_timeROC_run_status.tsv",
}
TIME_COLORS = {1: "#0072B2", 3: "#009E73", 5: "#D55E00"}
TEXT_SCALE = 1.14


def load_module(name: str, path: Path):
    spec = importlib.util.spec_from_file_location(name, path)
    if spec is None or spec.loader is None:
        raise ImportError(f"Cannot load {path}")
    module = importlib.util.module_from_spec(spec)
    spec.loader.exec_module(module)
    return module


def save_figure(fig: plt.Figure, stem: str) -> None:
    fig.savefig(OUT / f"{stem}.pdf", bbox_inches="tight", facecolor="white")
    plt.close(fig)


def scale_figure_text(fig: plt.Figure, factor: float) -> None:
    for text_item in fig.findobj(match=Text):
        if text_item.get_text():
            text_item.set_fontsize(text_item.get_fontsize() * factor)


def draw_roc_with_calibration(ax: plt.Axes, cohort: str, roc_curves: pd.DataFrame,
                              auc: pd.DataFrame, calibration: pd.DataFrame,
                              metrics: pd.DataFrame, letter: str | None = None) -> None:
    ax.plot([0, 1], [0, 1], color="#888888", lw=1.0, ls="--", zorder=0)
    cohort_roc = roc_curves.loc[roc_curves.cohort == cohort]
    cohort_auc = auc.loc[auc.cohort == cohort].set_index("year")
    cohort_metrics = metrics.loc[(metrics.cohort == cohort) & (metrics.metric == "ICI")].set_index("year")
    for year in [1, 3, 5]:
        sub = cohort_roc.loc[cohort_roc.year == year].sort_values(["false_positive_rate", "true_positive_rate"])
        ax.plot(sub.false_positive_rate, sub.true_positive_rate,
                color=TIME_COLORS[year], lw=1.8,
                label=f"{year} year · apparent AUC={cohort_auc.loc[year, 'apparent_auc_timeROC']:.3f}")
    ax.set_xlim(0, 1)
    ax.set_ylim(0, 1)
    ax.set_aspect("equal", adjustable="box")
    ax.set_xlabel("1 − Specificity")
    ax.set_ylabel("Sensitivity")
    ax.spines["top"].set_visible(False)
    ax.spines["right"].set_visible(False)
    ax.grid(color="#E8E8E8", lw=0.55)
    ax.text(0.03, 0.97, cohort, transform=ax.transAxes, ha="left", va="top",
            fontsize=9.2, fontweight="bold")
    ax.legend(frameon=False, loc="upper left", bbox_to_anchor=(1.03, 0.58),
              fontsize=6.8, handlelength=2.2, borderaxespad=0.0)

    stat_lines = ["Bootstrap-corrected AUC | ICI"]
    for year in [1, 3, 5]:
        stat_lines.append(
            f"{year}y   {cohort_auc.loc[year, 'optimism_corrected']:.3f} | "
            f"{cohort_metrics.loc[year, 'optimism_corrected']:.3f}"
        )
    ax.text(1.03, 0.98, "\n".join(stat_lines), transform=ax.transAxes,
            ha="left", va="top", fontsize=6.65, linespacing=1.28,
            clip_on=False,
            bbox={"facecolor": "white", "edgecolor": "#D0D0D0", "linewidth": 0.6,
                  "boxstyle": "round,pad=0.35", "alpha": 0.94})

    inset = ax.inset_axes([0.57, 0.08, 0.39, 0.38])
    inset.plot([0, 1], [0, 1], color="#999999", lw=0.7, ls="--")
    cohort_cal = calibration.loc[calibration.cohort == cohort]
    for year in [1, 3, 5]:
        sub = cohort_cal.loc[cohort_cal.year == year].sort_values("mean_predicted")
        inset.plot(sub.mean_predicted, sub.optimism_corrected_observed,
                   color=TIME_COLORS[year], lw=1.1, marker="o", ms=2.4)
    inset.set_xlim(0, 1)
    inset.set_ylim(0, 1)
    inset.set_xticks([0, 0.5, 1])
    inset.set_yticks([0, 0.5, 1])
    inset.tick_params(labelsize=5.4, width=0.5, length=2)
    inset.spines["top"].set_visible(False)
    inset.spines["right"].set_visible(False)
    inset.text(0.05, 0.95, "Calibration", transform=inset.transAxes,
               ha="left", va="top", fontsize=6.0, fontweight="bold")
    inset.set_xlabel("Predicted", fontsize=5.5, labelpad=1)
    inset.set_ylabel("Observed", fontsize=5.5, labelpad=1)
    if letter:
        ax.text(-0.12, 1.02, letter, transform=ax.transAxes, fontsize=15,
                fontweight="bold", ha="left", va="bottom")


def individual_panels(v1, axes: pd.DataFrame, survival_ticks: pd.DataFrame,
                      summary: pd.DataFrame, performance: pd.DataFrame,
                      dca: pd.DataFrame, roc: pd.DataFrame, auc: pd.DataFrame,
                      calibration: pd.DataFrame, metrics: pd.DataFrame) -> None:
    for cohort, letter in [("TCGA", "A"), ("TARGET", "B")]:
        fig, ax = plt.subplots(figsize=(8.5, 5.7))
        v1.draw_nomogram(ax, cohort, axes, survival_ticks, summary)
        save_figure(fig, f"Fig2{letter}_{cohort}_nomogram_v4")

    fig, ax = plt.subplots(figsize=(6.6, 5.0))
    v1.draw_performance(ax, performance)
    fig.subplots_adjust(left=0.13, right=0.98, bottom=0.16, top=0.97)
    save_figure(fig, "Fig2C_nested_model_performance_v4")

    fig = plt.figure(figsize=(10.8, 4.7))
    v1.draw_dca_pair(fig, fig.add_gridspec(1, 1)[0], dca)
    fig.subplots_adjust(left=0.08, right=0.99, bottom=0.13, top=0.98)
    save_figure(fig, "Fig2D_3yr_DCA_v4")

    for cohort, letter in [("TCGA", "E"), ("TARGET", "F")]:
        fig, ax = plt.subplots(figsize=(7.7, 5.5))
        draw_roc_with_calibration(ax, cohort, roc, auc, calibration, metrics)
        fig.subplots_adjust(left=0.10, right=0.75, bottom=0.11, top=0.98)
        save_figure(fig, f"Fig2{letter}_{cohort}_ROC_calibration_inset_v4")


def composite(v1, axes: pd.DataFrame, survival_ticks: pd.DataFrame,
              summary: pd.DataFrame, performance: pd.DataFrame,
              dca: pd.DataFrame, roc: pd.DataFrame, auc: pd.DataFrame,
              calibration: pd.DataFrame, metrics: pd.DataFrame) -> None:
    fig = plt.figure(figsize=(18.0, 15.2))
    outer = fig.add_gridspec(3, 1, height_ratios=[1.12, 0.83, 1.18], hspace=0.22)
    top = outer[0].subgridspec(1, 2, wspace=0.13)
    ax_a = fig.add_subplot(top[0, 0])
    ax_b = fig.add_subplot(top[0, 1])
    v1.draw_nomogram(ax_a, "TCGA", axes, survival_ticks, summary, "A")
    v1.draw_nomogram(ax_b, "TARGET", axes, survival_ticks, summary, "B")

    middle = outer[1].subgridspec(1, 2, width_ratios=[0.86, 1.14], wspace=0.20)
    ax_c = fig.add_subplot(middle[0, 0])
    v1.draw_performance(ax_c, performance, "C")
    v1.draw_dca_pair(fig, middle[0, 1], dca, "D")

    bottom = outer[2].subgridspec(1, 2, wspace=0.22)
    ax_e = fig.add_subplot(bottom[0, 0])
    ax_f = fig.add_subplot(bottom[0, 1])
    draw_roc_with_calibration(ax_e, "TCGA", roc, auc, calibration, metrics, "E")
    draw_roc_with_calibration(ax_f, "TARGET", roc, auc, calibration, metrics, "F")
    fig.subplots_adjust(left=0.045, right=0.988, bottom=0.042, top=0.985)
    scale_figure_text(fig, TEXT_SCALE)
    save_figure(fig, "Figure2_ROC_with_calibration_insets_v5")


def main() -> None:
    OUT.mkdir(parents=True, exist_ok=True)
    missing = [name for name, path in SOURCES.items() if not path.exists()]
    if missing:
        raise FileNotFoundError(f"Missing Figure 2 v5 sources: {missing}")
    mpl.rcParams.update({
        "font.family": "Arial", "font.size": 9, "axes.labelsize": 9.5,
        "xtick.labelsize": 8.2, "ytick.labelsize": 8.2,
        "pdf.fonttype": 42, "ps.fonttype": 42, "axes.unicode_minus": False,
    })
    v1 = load_module("figure2_v1", SOURCES["v1_generator"])
    v1.OUT = OUT
    axes = pd.read_csv(SOURCES["nomogram_axes"], sep="\t")
    survival_ticks = pd.read_csv(SOURCES["nomogram_survival_ticks"], sep="\t")
    summary = pd.read_csv(SOURCES["nomogram_scale_summary"], sep="\t")
    performance = pd.read_csv(SOURCES["performance"], sep="\t")
    dca = pd.read_csv(SOURCES["dca_curves"], sep="\t")
    roc = pd.read_csv(SOURCES["roc_curves"], sep="\t")
    auc = pd.read_csv(SOURCES["roc_auc"], sep="\t")
    calibration = pd.read_csv(SOURCES["calibration_curves"], sep="\t")
    metrics = pd.read_csv(SOURCES["calibration_metrics"], sep="\t")

    if len(roc) != 6024 or len(auc) != 6:
        raise AssertionError("timeROC input structure invalid")
    if float(auc.absolute_difference_apparent.max()) > 1e-10:
        raise AssertionError("timeROC AUC is not reconciled with final performance")
    if len(calibration) != 27 or len(metrics) != 12:
        raise AssertionError("Calibration input structure invalid")

    composite(v1, axes, survival_ticks, summary, performance, dca,
              roc, auc, calibration, metrics)

    pd.DataFrame({"source": list(SOURCES), "path": [str(path) for path in SOURCES.values()]}).to_csv(
        OUT / "01_source_manifest.tsv", sep="\t", index=False
    )
    pd.DataFrame([
        ("row1", "A", "1.0", "TCGA full nomogram"),
        ("row1", "B", "1.0", "TARGET full nomogram"),
        ("row2", "C", "0.86", "nested corrected C-index"),
        ("row2", "D", "1.14", "3-year two-cohort DCA"),
        ("row3", "E", "1.0", "TCGA timeROC with calibration inset"),
        ("row3", "F", "1.0", "TARGET timeROC with calibration inset"),
    ], columns=["row", "panel", "relative_width", "content"]).to_csv(
        OUT / "01_layout_manifest.tsv", sep="\t", index=False
    )
    status = {
        "status": "passed", "individual_panels": 0, "composite_figures": 1,
        "png_generated": 0, "pdf_generated": 1, "internal_titles": 0,
        "layout": "AB/CD/EF", "roc_curve_type": "apparent timeROC",
        "embedded_calibration": 1, "embedded_corrected_auc_ici": 1,
        "roc_legend_position": "outside right lower",
        "corrected_auc_ici_position": "outside right upper",
        "composite_figsize_inches": "18.0x15.2",
        "bottom_height_ratio": 1.18,
        "bottom_wspace": 0.22,
        "text_scale_factor": TEXT_SCALE,
        "formal_raster_output": 0,
        "word_modified": 0, "manuscript_modified": 0, "source_files_modified": 0,
    }
    pd.DataFrame(status.items(), columns=["field", "value"]).to_csv(
        OUT / "02_run_status.tsv", sep="\t", index=False
    )
    (OUT / "02_environment.json").write_text(json.dumps({
        "python": __import__("sys").version, "pandas": pd.__version__,
        "numpy": np.__version__, "matplotlib": mpl.__version__,
    }, indent=2), encoding="utf-8")
    print(json.dumps(status, indent=2))


if __name__ == "__main__":
    main()

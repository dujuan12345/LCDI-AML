# ===============================================================
# utils_pvalue_format.R
# ---------------------------------------------------------------
# 标准化的 p 值 / 数值显示工具.
# 在所有 J3-J8 脚本开头 source("utils_pvalue_format.R") 即可使用.
#
# 设计原则:
#   1. p 值 < 1e-4 时使用科学计数 (e.g. "1.6e-19"), 不强转成 0
#   2. p 值 >= 1e-4 时使用 3 位有效数字 (e.g. "0.023")
#   3. 提供 ggplot 标签函数 + table 用文本格式 + 文件名安全格式
# ===============================================================

# 把数值 p 值转成字符串, 永远不会显示成 0.00
# @param p 数值或数值向量
# @param threshold p < threshold 时使用科学计数, 默认 1e-4
# @param sig_digits 科学计数下的有效数字位数
# @param normal_digits 普通显示的有效数字位数
# @return 字符串向量
format_pval <- function(p, threshold = 1e-4,
                        sig_digits = 2, normal_digits = 3) {
  if (length(p) == 0) return(character(0))
  out <- character(length(p))
  for (i in seq_along(p)) {
    pi <- p[i]
    if (is.na(pi)) {
      out[i] <- "NA"
    } else if (pi == 0) {
      # R 内部 p == 0 通常是数值下溢; 标注为 < 2.2e-308 (machine eps)
      out[i] <- "<2.2e-308"
    } else if (pi < threshold) {
      # 例如 1.6e-19 -> "1.6e-19"
      out[i] <- formatC(pi, format = "e", digits = sig_digits - 1)
    } else {
      out[i] <- formatC(signif(pi, normal_digits), format = "fg",
                        digits = normal_digits, flag = "#")
    }
  }
  out
}

# 在 ggplot 注释 / 图标题里用的 p 值字符串 (含 "P=")
format_pval_label <- function(p, prefix = "P", italic = FALSE, ...) {
  s <- format_pval(p, ...)
  if (italic) {
    # 用 parse=TRUE 渲染斜体的 P
    paste0("italic(", prefix, ")==\"", s, "\"")
  } else {
    # 极小值用 "<" 而非 "="
    op <- ifelse(grepl("^<", s), "", "=")
    paste0(prefix, op, s)
  }
}

# 文件名安全 p 值字符串 (不含 "<", 用 "lt" 替代; "." 保留)
format_pval_for_filename <- function(p, ...) {
  s <- format_pval(p, ...)
  s <- gsub("<", "lt", s)
  s <- gsub(" ", "", s)
  s
}

# 科学计数转 expression 风格 (用于 ggplot 中显示 1.6 x 10^-19)
# 返回一个可被 ggplot 的 parse=TRUE 解析的字符串
format_pval_expression <- function(p, ...) {
  s <- format_pval(p, ...)
  # 把 "1.6e-19" -> "1.6 %*% 10^-19"
  out <- s
  ix <- grepl("e", out, ignore.case = TRUE)
  if (any(ix)) {
    parts <- strsplit(out[ix], "e", fixed = FALSE)
    out[ix] <- sapply(parts, function(pp) {
      mant <- pp[1]
      exp  <- as.integer(pp[2])
      sprintf("%s %%*%% 10^%d", mant, exp)
    })
  }
  out
}

# 一次性给 data.frame 的指定列做格式化, 返回带新列的 data.frame
format_pval_columns <- function(df, cols = NULL, suffix = "_fmt", ...) {
  if (is.null(cols)) {
    cols <- grep("^(p|p_?val|p_?value|adj\\.?p|p\\.?adj|fdr|q_?val|q_?value)",
                 colnames(df), value = TRUE, ignore.case = TRUE)
  }
  for (cn in cols) {
    if (cn %in% colnames(df)) {
      df[[paste0(cn, suffix)]] <- format_pval(df[[cn]], ...)
    }
  }
  df
}

# ---------------- 自检 ----------------
if (sys.nframe() == 0) {
  test_p <- c(1.6e-19, 2.9e-10, 0.023, 0.547, 1.0, 0, NA)
  cat("format_pval 自检:\n")
  for (i in seq_along(test_p)) {
    cat(sprintf("  format_pval(%g) = %s\n",
                test_p[i], format_pval(test_p[i])))
  }
}


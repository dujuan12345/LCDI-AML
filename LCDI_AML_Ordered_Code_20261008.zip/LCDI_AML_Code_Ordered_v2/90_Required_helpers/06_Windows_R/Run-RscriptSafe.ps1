param(
 [Parameter(Mandatory=$true)][string]$ScriptPath,
 [Parameter(Mandatory=$true)][string]$LogPrefix,
 [string]$WorkingDirectory='D:\26_01_AML',
 [string[]]$ScriptArguments=@()
)
$taskPython='C:\Users\31937\anaconda3\python.exe'
$taskLauncher=Join-Path $PSScriptRoot 'run_rscript_safe.py'
& $taskPython $taskLauncher --script $ScriptPath --log-prefix $LogPrefix --workdir $WorkingDirectory -- @ScriptArguments
exit $LASTEXITCODE

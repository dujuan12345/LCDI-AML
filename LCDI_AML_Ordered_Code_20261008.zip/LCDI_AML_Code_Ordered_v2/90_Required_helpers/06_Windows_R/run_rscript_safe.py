"""Run the existing project Rscript with valid Windows architecture metadata.

No R/package installation changes; no crash/exception suppression; native exit
code and raw stdout/stderr are retained. Refuses to overwrite existing logs.
"""
from pathlib import Path
import argparse,ctypes,datetime,hashlib,json,os,struct,subprocess,sys,time

ROOT=Path(r'D:\26_01_AML')
RSCRIPT=Path(r'D:\R-4.5.2\bin\x64\Rscript.exe')

def project_path(value):
 p=Path(value).resolve()
 if not p.is_relative_to(ROOT.resolve()):raise ValueError('Path must be inside the AML project: '+str(p))
 return p

def main():
 p=argparse.ArgumentParser(description=__doc__)
 p.add_argument('--script',required=True);p.add_argument('--log-prefix',required=True)
 p.add_argument('--workdir',default=str(ROOT));p.add_argument('script_args',nargs=argparse.REMAINDER)
 a=p.parse_args();script=project_path(a.script);workdir=project_path(a.workdir);prefix=project_path(a.log_prefix)
 if not script.is_file() or not RSCRIPT.is_file() or not workdir.is_dir():raise FileNotFoundError('Rscript, script or working directory is missing')
 info=ctypes.create_string_buffer(64);ctypes.windll.kernel32.GetNativeSystemInfo(ctypes.byref(info));arch=struct.unpack_from('H',info.raw)[0]
 if arch!=9:raise RuntimeError('This verified launcher is for native AMD64 Windows only')
 env=os.environ.copy();before=env.get('PROCESSOR_ARCHITECTURE');restored=not before
 if before and before.upper()!='AMD64':raise RuntimeError('Unexpected PROCESSOR_ARCHITECTURE; refusing to mask an architecture mismatch')
 env['PROCESSOR_ARCHITECTURE']='AMD64'
 args=a.script_args[1:] if a.script_args[:1]==['--'] else a.script_args
 command=[str(RSCRIPT),'--vanilla',str(script),*args]
 files={k:Path(str(prefix)+suffix) for k,suffix in [('stdout','.stdout.log'),('stderr','.stderr.log'),('status','.run.json')]}
 if any(x.exists() for x in files.values()):raise FileExistsError('Log prefix already exists; use a new prefix')
 prefix.parent.mkdir(parents=True,exist_ok=True)
 record={'state':'starting','command':command,'working_directory':str(workdir),'started':datetime.datetime.now().astimezone().isoformat(),'script_sha256':hashlib.sha256(script.read_bytes()).hexdigest(),'Rscript':str(RSCRIPT),'native_architecture_code':arch,'processor_architecture_before':before,'processor_architecture_child':'AMD64','restored_missing_architecture':restored,'crash_suppression':False,'stdin':'DEVNULL','stdout':str(files['stdout']),'stderr':str(files['stderr']),'python':sys.version}
 def save():files['status'].write_text(json.dumps(record,ensure_ascii=False,indent=2),encoding='utf-8')
 save();start=time.time()
 with files['stdout'].open('wb') as so,files['stderr'].open('wb') as se:
  proc=subprocess.Popen(command,cwd=workdir,env=env,stdin=subprocess.DEVNULL,stdout=so,stderr=se,creationflags=subprocess.CREATE_NO_WINDOW)
  record.update(state='running',pid=proc.pid);save()
  try:code=proc.wait()
  except KeyboardInterrupt:
   proc.terminate();proc.wait();record.update(state='interrupted',exit_code=proc.returncode,seconds=round(time.time()-start,2));save();return 130
 record.update(state='passed' if code==0 else 'failed',exit_code=code,exit_hex=hex(code&0xffffffff),seconds=round(time.time()-start,2),finished=datetime.datetime.now().astimezone().isoformat());save()
 print(json.dumps({'state':record['state'],'exit_code':code,'exit_hex':record['exit_hex'],'status_file':str(files['status'])},ensure_ascii=True))
 # R's normal status (including stop()=1) is returned exactly; native crash codes
 # remain fully recorded even if a shell displays them as signed integers.
 return code

if __name__=='__main__':
 try:sys.exit(main())
 except Exception as e:print(type(e).__name__+': '+str(e),file=sys.stderr);sys.exit(2)

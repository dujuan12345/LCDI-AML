from pathlib import Path
from zipfile import ZipFile,ZIP_DEFLATED
from lxml import etree as E
from copy import deepcopy
from collections import Counter
from difflib import SequenceMatcher
from io import BytesIO
import re,json,hashlib,zlib,subprocess,sys
import numpy as np
from PIL import Image
from pdfminer.pdfparser import PDFParser
from pdfminer.pdfdocument import PDFDocument
from pdfminer.pdftypes import PDFStream,PDFObjRef,resolve1
from pdfminer.psparser import PSLiteral,PSKeyword
import pdfplumber
D=Path(__file__).parent;A=D.parent
F=D/'figures';F.mkdir(exist_ok=True)
Q=D/'qa';Q.mkdir(exist_ok=True)
sources=[A/'figure1_composite_20260902_v5/Figure1_compact_A_BCD_EG_v5.pdf',A/'figure2_composite_20260903_v5/Figure2_ROC_with_calibration_insets_v5.pdf',A/'figure3_composite_20260903_v6/Figure3_MPO_dominance_and_nonMPO_components_v6.pdf',A/'figure4_upstream_corrected_20260905_v3/Figure4_corrected_ABC_complete_v3_final.pdf',A/'figure5_integrated_v27_20260907/Figure5_rearranged_v27.pdf']+[A/f'candidate_definition_v23_20260907/supplement_figures/FigureS{i}.pdf' for i in range(1,6)]
labels=[f'Figure{i}' for i in range(1,6)]+[f'FigureS{i}' for i in range(1,6)]
sha=lambda p:hashlib.sha256(p.read_bytes()).hexdigest()
def soften(rgb):
 x=np.asarray(rgb,dtype=float)
 lum=np.sum(x*np.array([.2126,.7152,.0722]),axis=-1,keepdims=True)
 chroma=np.max(x,axis=-1,keepdims=True)-np.min(x,axis=-1,keepdims=True)
 # Preserve all neutral ink and whitespace; use the same low-chroma treatment throughout.
 amount=np.clip(chroma/.08,0,1)
 muted=.56*x+.44*lum
 muted=.94*muted+.06
 return np.clip(x*(1-amount)+muted*amount,0,1)
def canonical(rgb,label):
 x=np.array(rgb,dtype=float)
 pairs={'#0072B2':'#32688E','#2B6C9C':'#32688E','#D55E00':'#C46735','#D87843':'#C46735'}
 if label in ['Figure3','Figure4']:pairs.update({'#6A3D9A':'#32688E','#1B9E77':'#C46735'})
 for old,new in pairs.items():
  a=np.array([int(old[i:i+2],16) for i in [1,3,5]])/255
  b=np.array([int(new[i:i+2],16) for i in [1,3,5]])/255
  mask=np.max(np.abs(x-a),axis=-1)<.0001
  x=np.where(np.expand_dims(mask,-1),b,x)
 return soften(x)
def ser(o):
 if isinstance(o,PDFObjRef):return f'{o.objid} 0 R'.encode()
 if isinstance(o,PSLiteral):return b'/'+re.sub(rb'[^!-~]|[#%()/<>\[\]{}]',lambda m:b'#'+m[0].hex().encode(),o.name.encode() if isinstance(o.name,str) else o.name)
 if isinstance(o,PSKeyword):return o.name
 if isinstance(o,PDFStream):
  a=dict(o.attrs);raw=o.rawdata
  if raw is None:raw=zlib.compress(o.get_data());a['Filter']=PSLiteral('FlateDecode');a.pop('DecodeParms',None)
  a['Length']=len(raw)
  return ser(a)+b'\nstream\n'+raw+b'\nendstream'
 if isinstance(o,dict):return b'<< '+b' '.join(ser(PSLiteral(k))+b' '+ser(v) for k,v in o.items())+b' >>'
 if isinstance(o,(tuple,list)):return b'[ '+b' '.join(ser(v) for v in o)+b' ]'
 if isinstance(o,bytes):return b'<'+o.hex().encode()+b'>'
 if isinstance(o,str):return ser(o.encode())
 if o is None:return b'null'
 if isinstance(o,bool):return b'true' if o else b'false'
 return str(o).encode()
num=rb'[-+]?(?:\d*\.\d+|\d+\.?\d*)'
pat=re.compile(rb'(?<![\w./])('+num+rb')\s+('+num+rb')\s+('+num+rb')\s+(rg|RG|scn|SCN|sc|SC)(?!\w)')
qc=[]
for src,label in zip(sources,labels):
 with src.open('rb') as fp:
  doc=PDFDocument(PDFParser(fp));ids=sorted(set(i for xr in doc.xrefs for i in xr.get_objids()));objects={i:doc.getobj(i) for i in ids}
  contentids=set()
  def add(v):
   if isinstance(v,PDFObjRef):contentids.add(v.objid)
   elif isinstance(v,list):
    for item in v:add(item)
  for obj in objects.values():
   if isinstance(obj,dict) and 'Contents' in obj:add(obj['Contents'])
  counts={'vector_rgb':0,'raster_rgb':0,'indexed_palettes':0}
  for oid,obj in objects.items():
   if not isinstance(obj,PDFStream):continue
   subtype=str(obj.attrs.get('Subtype',''))
   cs=resolve1(obj.attrs.get('ColorSpace'))
   if 'Image' in subtype and isinstance(cs,list) and 'Indexed' in str(cs[0]) and 'DeviceRGB' in str(cs[1]):
    lookup=resolve1(cs[3]);lookup=lookup.get_data() if isinstance(lookup,PDFStream) else lookup
    palette=np.frombuffer(lookup,dtype=np.uint8).reshape(-1,3)
    obj.attrs['ColorSpace']=[cs[0],cs[1],cs[2],np.rint(255*canonical(palette/255,label)).astype('uint8').tobytes()]
    counts['indexed_palettes']+=1
   if oid in contentids or 'Form' in subtype:
    def sub(m):
     counts['vector_rgb']+=1
     v=canonical([float(m[i]) for i in [1,2,3]],label)
     return (' '.join(f'{x:.7f}' for x in v)+' ').encode()+m[4]
    raw=pat.sub(sub,obj.get_data());obj.rawdata=zlib.compress(raw);obj.data=None;obj.attrs['Filter']=PSLiteral('FlateDecode');obj.attrs.pop('DecodeParms',None)
   elif 'Image' in subtype and 'DeviceRGB' in str(resolve1(obj.attrs.get('ColorSpace'))) and obj.attrs.get('BitsPerComponent')==8:
    raw=obj.get_data();w=obj.attrs['Width'];h=obj.attrs['Height']
    if len(raw)==w*h*3:
     arr=np.frombuffer(raw,dtype=np.uint8).reshape(h,w,3)
     raw=np.rint(255*canonical(arr/255,label)).astype('uint8').tobytes();obj.rawdata=zlib.compress(raw);obj.data=None;obj.attrs['Filter']=PSLiteral('FlateDecode');obj.attrs.pop('DecodeParms',None);counts['raster_rgb']+=1
  data=bytearray(b'%PDF-1.7\n%\xe2\xe3\xcf\xd3\n');offsets={}
  for oid,obj in objects.items():
   offsets[oid]=len(data);data+=f'{oid} 0 obj\n'.encode()+ser(obj)+b'\nendobj\n'
  pos=len(data);n=max(ids)+1;data+=f'xref\n0 {n}\n0000000000 65535 f \n'.encode()
  for i in range(1,n):data+=(f'{offsets[i]:010d} 00000 n \n' if i in offsets else '0000000000 00000 f \n').encode()
  root=next(xr.trailer['Root'] for xr in doc.xrefs if 'Root' in xr.trailer)
  data+=b'trailer\n'+ser({'Size':n,'Root':root})+f'\nstartxref\n{pos}\n%%EOF\n'.encode()
 dest=F/f'{label}_soft_v28.pdf';dest.write_bytes(data)
 with pdfplumber.open(src) as p,pdfplumber.open(dest) as q:
  assert len(p.pages)==len(q.pages)==1
  a,b=p.pages[0],q.pages[0]
  assert a.extract_text()==b.extract_text(),label
  assert [(c['text'],round(c['x0'],4),round(c['top'],4),round(c['size'],4)) for c in a.chars]==[(c['text'],round(c['x0'],4),round(c['top'],4),round(c['size'],4)) for c in b.chars],label
  counts.update({'label':label,'source':str(src),'output':str(dest),'text_geometry_font_unchanged':True,'width':a.width,'height':a.height})
 subprocess.run(['gswin64c','-dSAFER','-dBATCH','-dNOPAUSE','-sDEVICE=png16m','-r220',f'-sOutputFile={Q/label}.png',str(dest)],check=True,stdout=subprocess.DEVNULL)
 qc.append(counts);print(label,counts,flush=True)
# Restore the v26 (document section excluded from the code edition).

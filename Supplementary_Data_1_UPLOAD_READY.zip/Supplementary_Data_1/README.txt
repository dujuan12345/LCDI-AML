﻿Supplementary Data 1: processed analysis tables and cell annotations

This supplement accompanies the LCDI AML manuscript. Start with DATA_INDEX.csv
for file roles and original source locations, PUBLIC_DATASETS.csv for public data
accessions, and DATA_DICTIONARY.csv for common field definitions.

01_Model: frozen formula, scaling parameters and gene/signature membership.
02_Cohorts: cohort clinical inputs, selected expression and frozen score components.
03_Single_cell: full exported annotations, Fig3/Fig4 cell membership, patient-level
  and patient-lineage inputs, external sample metadata and TF-specific metadata.
04_Trajectories: saved UMAP, pseudotime/weights, lineage order and marker expression.
05_Bulk: saved model scores, complete DEG statistics/ranking inputs, gene sets,
  enrichment results and immune/signature scores.
06_Virtual_perturbation: sampled-cell membership and complete saved gene responses.
07_qPCR: coded patient-level Ct/DeltaCt/expression summaries.
08_Supplementary_tables: numbered supplementary tables at original stored precision.

CSV files use UTF-8 with BOM. Preserve identifiers as text. Whole-transcriptome
pseudobulk matrices are supplied in the companion RDS objects in Supplementary
Data 2, with genes in rows and analysis groups in columns. They are not duplicated
as large CSVs here. Marker-expression tables have cells in rows and genes in columns. Source table values were copied
as strings; R-object numeric exports were checked to relative error <=2e-14.
The companion Supplementary Data 2 preserves selected R objects byte-for-byte.

Full annotations contain 41,086 adult and 74,440 pediatric cells. These are not
biological sample counts. Fig3 gates retain 9,559 adult/39,750 pediatric cells in
34/48 patient-lineage groups from 12/21 units. Fig4 further requires two lineages:
33/42 records from 11/15 units. Trajectory and TF inputs use separate cell subsets;
do not substitute those annotations or sample counts for the primary analysis.

Public raw expression/sequencing files remain at their source repositories and
are not redistributed here. Several scoring branches and historical within-cohort
standardizations are retained with their source labels; do not combine them as if
they were identical. Supplementary Data 2 provides compact cached inputs without
the multi-gigabyte complete Seurat objects or original sequencing files.

Scope: review and reuse of the supplied processed inputs, annotations and reported
results. This is not a validated raw-data-to-all-figures automatic pipeline. Code
paths and software dependencies still need configuration. Missing original
preprocessing stages, raw matrices, complete fitted trajectory/network objects,
external references and run-specific QC records may be needed for some upstream
reruns. No scientific models were refitted during this data preparation.

Analysis code: https://github.com/dujuan12345/LCDI-AML
These supplementary archives are provided as manuscript attachments. Their local
preparation does not imply they have already been uploaded to the code repository.

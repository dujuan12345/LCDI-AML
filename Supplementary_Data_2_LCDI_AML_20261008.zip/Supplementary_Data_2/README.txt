﻿Supplementary Data 2: compact R objects

OBJECT_INDEX.csv lists every object, its original relative input path and SHA256.
Objects are byte-identical copies. Load them with readRDS in the documented R
environment. They include selected clinical/model inputs, compact trajectories,
external pseudobulk matrices, lineage-control inputs and sampled perturbation counts.
Use with Supplementary Data 1 and the analysis code repository.

The RDS files retain their original structures and analysis branches. Compact
trajectory objects contain saved pseudotime/weights but are not complete Seurat
or fitted Slingshot objects. Matrix objects require the Matrix package when used.
Public raw datasets, complete multi-gigabyte objects and all historical caches
are not included. No new normalization, model fitting or statistical tests were run.

Preparation was local; no data-repository upload is asserted.
